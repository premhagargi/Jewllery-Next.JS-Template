// utils/api.ts
import config from "../config.json";
const BASE_URL = config.NEXT_PUBLIC_API_URL;
import Cookies from "js-cookie";
function getToken() {
  return Cookies.get("token");
}


interface ApiResponse<T> {
  data?: T;
  error?: string;
  status: number;
}

export const api = {
  get: async <T>(endpoint: string): Promise<ApiResponse<T>> => {
    try {
      const token = getToken();
      const headers: HeadersInit = token
        ? { Authorization: `${token}` } // Include Authorization header if token exists
        : {}; // Leave headers empty if no token
  
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        headers,
      });
  
      const data = await response.json();
  
      return {
        data,
        status: response.status,
      };
    } catch (error) {
      console.error("GET request failed:", error);
      return {
        error: error instanceof Error ? error.message : "Unknown error occurred",
        status: 500,
      };
    }
  },
  

  post: async <T>(endpoint: string, body: unknown): Promise<ApiResponse<T>> => {
    try {
      const token = Cookies.get("token"); // Retrieve the token
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${token}`, // Include Authorization header
        },
        body: JSON.stringify(body),
      });
      const data = await response.json();

      return {
        data,
        status: response.status,
      };
    } catch (error) {
      console.error('POST request failed:', error);
      return {
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        status: 500,
      };
    }
  },

  put: async <T>(endpoint: string, body: unknown): Promise<ApiResponse<T>> => {
    try {
      const token = Cookies.get("token"); // Retrieve the token
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `${token}`, // Include Authorization header
        },
        body: JSON.stringify(body),
      });
      const data = await response.json();

      return {
        data,
        status: response.status,
      };
    } catch (error) {
      console.error('PUT request failed:', error);
      return {
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        status: 500,
      };
    }
  },

  patch: async <T>(endpoint: string, body: Record<string, unknown>): Promise<ApiResponse<T>> => {
    try {
      const token = Cookies.get("token"); // Retrieve the token
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'PATCH',
        headers: {
          Authorization: `${token}`, // Include Authorization header
          'Content-Type': 'application/json', // Specify JSON content
        },
        body: JSON.stringify(body), // Include the body as JSON
      });
      const data = await response.json();
  
      return {
        data,
        status: response.status,
      };
    } catch (error) {
      console.error('PATCH request failed:', error);
      return {
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        status: 500,
      };
    }
  },
  
  delete: async <T>(endpoint: string): Promise<ApiResponse<T>> => {
    try {
      const token = Cookies.get("token"); // Retrieve the token
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: 'DELETE',
        headers: {
          Authorization: `${token}`, // Include Authorization header
        },
      });
      const data = await response.json();

      return {
        data,
        status: response.status,
      };
    } catch (error) {
      console.error('DELETE request failed:', error);
      return {
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        status: 500,
      };
    }
  },
};
