/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import dummyImage from "../../../../public/assets/user/product-placeholder.jpg";
import { toast } from "sonner";
import { load } from "@cashfreepayments/cashfree-js";
import { useRouter } from "next/navigation";
import { SetStateAction, useEffect, useState } from "react";
import { useGlobalState } from "@/context/GlobalStateContext";
import { api } from "../../../../utils/api";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { MailWarning, Smartphone } from "lucide-react"; 
import { Input } from "@/components/ui/input";


import config from "../../../../config.json";

interface PaymentModes {
  id: number;
  payment_method: string;
}

interface State {
  id: string;
  state_name: string;
  country_id: string;
}

declare module "@cashfreepayments/cashfree-js" {
  export function load(options: { mode: string }): any;
}

export default function Checkout() {
  const router = useRouter();
  const { addressList, fetchData, countryList, stateList, cityList } =
    useGlobalState();
  const [paymentModeList, setPaymentModes] = useState<PaymentModes[]>([]);
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [cartData, setCartData] = useState<any>({});
  const [profileData, setProfileData] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [paymentSessionId, setPaymentSessionId] = useState("");
  const [selectedAddress, setSelectedAddress] = useState<number | null>(null);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState<number | null>(
    null
  );
  const [isAddDailogOpen, setIsAddDailogOpen] = useState(false);
  const [filteredStates, setFilteredStates] = useState<State[]>([]);
    const [filteredStatesEdit, setFilteredStatesEdit] = useState<State[]>([]);
     const [isEditingS, setIsEditingS] = useState(false);
       const [filteredCities, setFilteredCities] = useState(cityList);
         const [isEditingCi, setIsEditingCi] = useState(false);
  

  const initializeSDK = async () => {
    const cashfree = await load({ mode: "production" });
    return cashfree;
  };

  const handleSelectAddress = (id: SetStateAction<number | null>) => {
    setSelectedAddress(id);
    if (typeof window !== "undefined") {
      const selectedAddressObj = addressList.find((address) => address.id === id);
      if (selectedAddressObj) {
        sessionStorage.setItem("orderAddress", JSON.stringify(selectedAddressObj));
      }
    }
  };

  const handleSelectPaymentMode = (mode: PaymentModes) => {
    setSelectedPaymentMode(mode.id);
  };

  const fetchPaymentModes = async () => {
    try {
      const url = `/api/v1/order/getPaymentModes`;
      const response = await api.get(url);
      if (response.data) {
        setPaymentModes((response.data as { data: PaymentModes[] }).data || []);
      } else {
        console.error("Error fetching payment modes");
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  
  interface UserProfileResponse {
    data: {
      data: any; 
    };
  }
  
  const fetchUserProfile = async () => {
    try {
      const url = `/api/v1/getProfile`;
      const response = await api.get<UserProfileResponse>(url);
      if (response.data) {
        setProfileData(response.data.data);
      } else {
        console.error("Error fetching user profile");
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  const calculateDiscount = () => {
    return cartItems
      .reduce((total, item) => {
        const originalPrice = Number(
          item.EstShopInventory?.exp_onlinesellprice_aft || 0
        );
        const offerPrice = Number(item.EstShopInventory?.offer_price || 0);
        const quantity = Number(item.quantity || 1);
        return total + (originalPrice - offerPrice) * quantity;
      }, 0)
      .toFixed(2);
  };

  const calculateDiscountPercentage = () => {
    const totalOriginalPrice = cartItems.reduce((total, item) => {
      const originalPrice = Number(
        item.EstShopInventory?.exp_onlinesellprice_aft || 0
      );
      const quantity = Number(item.quantity || 1);
      return total + originalPrice * quantity;
    }, 0);

    const totalDiscount = Number(calculateDiscount());

    if (totalOriginalPrice === 0) return "0";
    return ((totalDiscount / totalOriginalPrice) * 100).toFixed(2);
  };

  const placeOrder = async () => {
    try {
      const url = `/api/v1/order/placeOrder`;
      const paymentReferenceId =
        typeof window !== "undefined"
          ? localStorage.getItem("paymentReferenceId")
          : null;
          const payload: any = {
            address_id: selectedAddress,
            payment_method_id: selectedPaymentMode,
            items: cartData.cartItems.map((item: any) => ({
              product_id: item?.EstShopInventory?.ProductMaster?.product_id, 
              quantity: item.quantity,
              inventory_id: item.EstShopInventory?.id,
              est_shop_id: item.EstShopInventory.est_shop_id,
            })),
          };
          console.log('payload:', payload)
          
          if (selectedPaymentMode !== 1) {
            payload.paymentReferenceId = paymentReferenceId;
          }
          
          const response = await api.post(url, payload);

      if ((response.data as { status: string }).status === "Success") {
        toast.success("Order placed successfully!");
        const orderData = (response.data as { data: any }).data;
        if (typeof window !== "undefined") {
          sessionStorage.setItem("orderDetails", JSON.stringify(orderData));
          localStorage.removeItem("paymentReferenceId");
          localStorage.removeItem("paymentSessionId")
          localStorage.removeItem("orderStatus")
        }
        setTimeout(() => {
          setLoading(false);
        }, 2000);
        router.push(`/orderConfirm`);
        try {
          const clearCartUrl = "/api/v1/cart/clearcart";
          await api.delete(clearCartUrl);
          fetchData("cart");
        } catch (cartError) {
          console.error("Failed to clear cart:", cartError);
        }
      } else {
        toast.error("Failed to place order. Redirecting back to checkout page.");
      }
    } catch (error: any) {
      if (error.response?.status === 400) {
        console.error("Insufficient stock error:", error.response.data.message);
        toast.error(
          error.response.data.message ||
            "Insufficient stock. Please update your cart."
        );
      } else {
        console.error("API request failed:", error);
        toast.error("Something went wrong. Please try again.");
      }
    }
  };

  function formatIndianCurrency(num: any) {
    if (num === null || num === undefined || isNaN(num)) {
      return "₹0.00"; // or return an empty string or fallback
    }
  
    const numberValue = typeof num === "string" ? parseFloat(num) : num;
  
    return numberValue.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  


  const calculateGST = () => {
    if (!cartItems || cartItems.length === 0)
      return { cgst: 0, sgst: 0, igst: 0, totalTaxRate: 0 };

    let totalCGST = 0,
      totalSGST = 0,
      totalIGST = 0;

    cartItems.forEach((item) => {
      const tax = item?.ProductMaster?.TaxRate || {};
      totalCGST += parseFloat(tax.tax_cgst) || 0;
      totalSGST += parseFloat(tax.tax_sgst) || 0;
      totalIGST += parseFloat(tax.tax_igst) || 0;
    });

    return {
      cgst: totalCGST,
      sgst: totalSGST,
      igst: totalIGST,
      totalTaxRate: totalIGST > 0 ? totalIGST : totalCGST + totalSGST,
    };
  };

  const { cgst, sgst, igst, totalTaxRate } = calculateGST();
  const totalPrice = parseFloat(cartData?.totalPrice) || 0;
  const preTaxAmount = totalTaxRate
    ? totalPrice / (1 + totalTaxRate / 100)
    : totalPrice;
  const taxAmount = totalPrice - preTaxAmount;
  const cgstAmount = (cgst / totalTaxRate) * taxAmount;
  const sgstAmount = (sgst / totalTaxRate) * taxAmount;
  const igstAmount = (igst / totalTaxRate) * taxAmount;


  const initiatePayment = async () => {
    try {
      // setLoading(true);
      const cashfree = await initializeSDK();
  
      if (!paymentSessionId) {
        console.error("Payment session ID is not available");
        toast.error("Payment session ID is missing. Please try again.");
        return;
      }
  
      const checkoutOptions = {
        paymentSessionId: paymentSessionId,
        redirectTarget: "_modal",
      };
  
      const result = await cashfree.checkout(checkoutOptions);
      console.log("Cashfree result:", result);
  
      if (result?.paymentDetails) {
        const { paymentMessage, status } = result.paymentDetails;
  
        if (paymentMessage === "Payment finished. Check status.") {
          toast.success("Payment completed. Verifying...");
        } else if (status === "CANCELLED") {
          toast.info("Payment was cancelled. Redirecting back to checkout.");
          router.push("/checkout");
          return;
        } else {
          toast.info("Processing payment. Please wait...");
        }
      } else {
        // toast.info("No payment details. Verifying payment status...");
      }
  
      // ✅ Single call to checkOrderStatus (after result handling)
      await checkOrderStatus();
  
    } catch (error: any) {
      console.error("Payment error:", error);
  
      if (
        error?.message === "Payment has been aborted. Please try again" ||
        error?.e === "Payment has been aborted. Please try again"
      ) {
        toast.warning("You aborted the payment. Redirecting to checkout...");
        checkOrderStatus();
        router.push("/checkout");
      } else {
        toast.error("Payment failed. Please try again.");
        router.push("/checkout");
      }
    } finally {
      setLoading(false);
    }
  };
  

  
  const checkOrderStatus = async (retryCount = 0) => {
    const orderId = localStorage.getItem("paymentReferenceId");
  
    if (!orderId) {
      console.error("Order ID is missing");
      // toast.error("Order ID missing. Please try again.");
      return;
    }
  
    try {
      const response = await api.get(`/api/v1/order/paymentOrderStatus?order_id=${orderId}`);
      const data = (response.data as { data: { order_status: string } }).data;
      console.log("order status data:", data.order_status);
  
      switch (data.order_status) {
        case "PAID":
          toast.success("Payment is successful!");
          placeOrder();
          break;
  
        case "PENDING":
          if (retryCount < 3) {
            toast.info(`Payment pending... checking status (${retryCount + 1}/3)`);
            setTimeout(() => checkOrderStatus(retryCount + 1), 3000); // Retry after 3s
          } else {
            toast.info("Payment still pending. Checking payment details...");
            await checkPaymentStatus(false); // do not call checkOrderStatus again
          }
          break;
  
        case "ACTIVE":
          toast.info("Payment has been cancelled.");
          localStorage.setItem('orderStatus', "ACTIVE");
          await checkPaymentStatus(false);
          router.push("/checkout");
          break;
  
        case "FAILED":
          toast.error("Payment failed. Please try again.");
          router.push("/checkout");
          break;
  
        default:
          // toast.error("Unknown payment status. Please contact support.");
          router.push("/checkout");
      }
  
    } catch (error) {
      console.error("Error fetching payment status:", error);
      toast.error("Unable to fetch payment status. Please try again.");
      router.push("/checkout");
    }
  };
  
  
    
  const checkPaymentStatus = async (shouldCallCheckOrderStatus = true) => {
    const orderId = localStorage.getItem("paymentReferenceId");
  
    if (!orderId) {
      console.error("Order ID is missing");
      toast.error("Order ID missing. Please try again.");
      return;
    }
  
    try {
      const response = await api.get(`/api/v1/order/paymentStatus?order_id=${orderId}`);
      const payments = (response.data as { data: any[] }).data;
      console.log('payments:', payments);
  
      if (!Array.isArray(payments) || payments.length === 0) {
        // toast.error("No payment records found.");
        router.push("/checkout");
        return;
      }
  
      // 1. Look for first SUCCESS and exit if found
      for (const payment of payments) {
        if (payment.payment_status === "SUCCESS") {
          console.log("Payment status: SUCCESS");
          toast.success("Payment is successful!");
          if (shouldCallCheckOrderStatus) await checkOrderStatus();
          return;
        }
      }
  
      // 2. If no SUCCESS, look for first other status
      for (const payment of payments) {
        console.log("Payment status:", payment.payment_status);
  
        switch (payment.payment_status) {
          case "PENDING":
            toast.info("Payment is pending. We'll update you once confirmed.");
            router.push("/checkout");
            return;
          case "FAILED":
            toast.error("Payment failed. Please try again.");
            router.push("/checkout");
            return;
          default:
            toast.error("Unknown payment status. Please contact support.");
            router.push("/checkout");
            return;
        }
      }
  
    } catch (error) {
      console.error("Error fetching payment status:", error);
      toast.error("Unable to fetch payment status. Please try again.");
      router.push("/checkout");
    }
  };
  
  
  const handlePlaceOrder = async () => {
    if (!profileData.email_verified || !profileData.mobile_verified) {
      const verificationType = !profileData.email_verified ? 'email' : 'mobile';
      const IconComponent = verificationType === 'email' ? MailWarning : Smartphone;
  
      toast.error(
        <div className="relative bg-white p-4 pt-8 rounded-sm max-w-sm w-full overflow-hidden">
          <div className="absolute -top-4 -left-4 w-16 h-16 rounded-full flex items-center justify-center">
            <IconComponent className="w-9 h-9 text-black" />
          </div>
          <div className="pl-6">
            <h3 className="text-gray-900 text-lg font-semibold mb-2">
              Verification Required
            </h3>
            <p className="text-gray-600 text-sm mb-6">
              Please verify your {verificationType} to proceed with the payment.
            </p>
            <div className="flex gap-3">
              <button
                className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-3 rounded-lg font-medium hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-sm hover:shadow-md transform hover:scale-105"
                onClick={() => {
                  router.push('/profile');
                  toast.dismiss();
                }}
              >
                Verify Now
              </button>
              <button
                className="px-4 py-3 text-gray-600 hover:text-gray-800 font-medium transition-colors duration-200 rounded-lg hover:bg-gray-50"
                onClick={() => toast.dismiss()}
              >
                Later
              </button>
            </div>
          </div>
        </div>,
        {
          duration: 5500,
          position: 'top-right',
        }
      );
      return;
    }
  
    if (!selectedAddress) {
      toast.error("Please select an address to proceed");
      return;
    }
  
    if (selectedPaymentMode === 1) {
      if (typeof window !== "undefined") {
        const userConfirmed = window.confirm(
          "Are you sure you want to place the order?"
        );
        if (userConfirmed) {
          placeOrder();
        }
      }
    } else {
      try {
          const existingSessionId = localStorage.getItem("paymentSessionId");
          const existingOrderId = localStorage.getItem("paymentReferenceId");
          const existingOrderStatus = localStorage.getItem("orderStatus")
        if (existingOrderStatus == "ACTIVE" && existingOrderId) {
          console.log("Existing Session ID:", existingSessionId);
          console.log("Existing Order Status:", existingOrderStatus);
          if (existingSessionId && existingOrderStatus == "ACTIVE") {
            setPaymentSessionId(existingSessionId);
            toast.info("Redirecting to payment gateway");
            initiatePayment();
            return;
          }
        }
  
        const url = "/api/v1/order/paymentGateway";
        interface PaymentGatewayResponse {
          status: string;
          statusCode: number;
          message: string;
          code?: string; // Added the 'code' property
          data: {
            payment_session_id: string;
            order_id: string;
            code?: string; // Added 'code' property to match the usage
            message?: string; // Added 'message' property to match the usage
          };
        }
  
        const paymentResponse = await api.post<PaymentGatewayResponse>(url, {
          amount: formatIndianCurrency(cartData?.totalPrice).replace(/,/g, ''),
        });
        
  
        const responseData = paymentResponse.data?.data;
        // console.log('Response data',responseData.message)
        // ✅ Handle logical error from Cashfree even if statusCode is 200
        if (responseData?.code === "order_create_failed" && responseData?.message?.includes("max order amount")) {
          toast.error(
            <div className="bg-white p-4 rounded shadow-sm text-sm text-gray-800">
              <strong className="text-red-600 block mb-1">Order Limit Exceeded</strong>
              The order amount exceeds the maximum allowed by our payment provider. Please reduce your cart total and try again.
            </div>,
            {
              duration: 6000,
              position: 'top-right',
            }
          );
          return;
        }
      
        if (typeof window !== "undefined") {
          localStorage.setItem(
            "paymentReferenceId",
            paymentResponse.data?.data.order_id || ""
          );
          localStorage.setItem(
            "paymentSessionId",
            paymentResponse.data?.data.payment_session_id || ""
          );
        }
  
        toast.info("Please wait, Redirecting to payment gateway");
  
        if (paymentResponse.data?.data?.payment_session_id) {
          setPaymentSessionId(paymentResponse.data.data.payment_session_id);
          // console.log("Payment session ID set:", paymentResponse.data.data.payment_session_id);
        } else {
          console.error("Error: Payment session ID missing in response");
        }
      } catch (error: any) {
        console.error("API request failed:", error);
        console.log('the error:', error?.error)
         // ✅ Handle logical error from Cashfree even if statusCode is 200
         if (error?.error?.data?.code === "order_create_failed" && error?.error?.message?.includes("max order amount")) {
          toast.error(
            <div className="bg-white p-4 rounded shadow-sm text-sm text-gray-800">
              <strong className="text-red-600 block mb-1">Order Limit Exceeded</strong>
              The order amount exceeds the maximum allowed by our payment provider. Please reduce your cart total and try again.
            </div>,
            {
              duration: 6000,
              position: 'top-right',
            }
          );
          return;
        }
        toast.error("Failed to initiate payment. Please try again.");
      }
    }
  };
  

  useEffect(() => {
    if (paymentSessionId) {
      initiatePayment();
    }
  }, [paymentSessionId]);

  const fetchCartData = async () => {
    try {
      // setLoading(true);
      const response = await api.get("/api/v1/cart/cartdata");
      setCartItems(
        (response.data as { data: { cartItems: any[] } }).data.cartItems || []
      );
      setCartData((response.data as { data: any }).data || {});
    } catch (err) {
      console.error("Error fetching cart data:", err);
    } finally {
      // setLoading(false);
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      document.title = "Checkout";
    }
    const primary = addressList.find((address) => address.primary_address);
    if (primary) {
      setSelectedAddress(primary.id);
      if (typeof window !== "undefined") {
        sessionStorage.setItem("orderAddress", JSON.stringify(primary));
      }
    }
    fetchPaymentModes();
    fetchCartData();
    fetchUserProfile();
  }, [addressList]);

  useEffect(() => {
    
  console.log("Leaving the checkout page")
    return () => {
      localStorage.removeItem("paymentReferenceId");
      localStorage.removeItem("paymentSessionId");
      localStorage.removeItem("orderStatus");
    }
  }, [])
  
  const [addAddressData, setAddAddressData] = useState({
      address_line1: "",
      name: "",
      address_line2: "",
      country: "101",
      contact_no: "",
      state: "",
      city: "",
      postal_code: "",
    });

    const [errorsAdd, setAddErrors] = useState({
        address_line1: "",
        address_line2: "",
        name: "",
        contact_no: "",
        postal_code: "",
        state: "",
        city: "",
        country: "",
      });

  const handleCountrySelect = async (country_id: string) => {
      console.log(`handleCountrySelect called with country_id: ${country_id}`);
      try {
        // Define the expected response type
        interface State {
          id: string;
          state_name: string;
          country_id: string;
        }
    
        interface StateResponse {
          status: string;
          statusCode: number;
          message: string;
          data: State[];
        }
    
        // Ensure the API response is typed
        const response = await api.get<StateResponse>(
          `/api/v1/stateData?country_id=${country_id}`
        );
    
        console.log("State API response:", response.data);
        if (response.status === 200) {
          // Access the states directly from response.data.data
          const states = response.data?.data || [];
          console.log("Parsed states:", states);
          const filtered = states.filter(
            (state: State) => state.country_id === country_id
          );
          setFilteredStates(filtered);
          setFilteredStatesEdit(filtered);
          if (filtered.length === 0) {
            toast.warning("No states found for India.");
          }
        } else {
          throw new Error(`API returned status: ${response.status}`);
        }
      } catch (err) {
        console.error("Failed to fetch states:", err);
        toast.error("Failed to load states. Please try again.");
        setFilteredStates([]);
        setFilteredStatesEdit([]);
      }
    };

    const handleAddAddress = async () => {
        const newErrors = {
          address_line1: "",
          address_line2: "",
          postal_code: "",
          city: "",
          state: "",
          country: "",
          name: "",
          contact_no: "",
        };
    
        if (!addAddressData?.address_line1)
          newErrors.address_line1 = "Street Address 1 is required.";
        if (!addAddressData?.name) newErrors.name = "Name is required";
        if (!addAddressData?.contact_no) {
          newErrors.contact_no = "Contact number is required.";
        } else if (!/^\d{10}$/.test(addAddressData.contact_no)) {
          newErrors.contact_no = "Contact number must be 10 digits.";
        }
        if (!addAddressData?.address_line2)
          newErrors.address_line2 = "Street Address 2 is required.";
        if (!addAddressData?.state) newErrors.state = "Please select a state.";
        if (!addAddressData?.city) newErrors.city = "Please select a city";
        if (!addAddressData?.country) newErrors.country = "Country is required.";
    
        if (!addAddressData?.postal_code)
          newErrors.postal_code = "Pincode is required.";
        else if (addAddressData.postal_code.length !== 6)
          newErrors.postal_code = "Pincode must be 6 digits.";
    
        setAddErrors(newErrors);
    
        if (
          newErrors.address_line1 ||
          newErrors.address_line2 ||
          newErrors.postal_code ||
          newErrors.city ||
          newErrors.state ||
          newErrors.name ||
          newErrors.contact_no ||
          newErrors.country
        ) {
          return;
        }
    
        try {
          const response = await api.post("/api/v1/address/addAddress", {
            address_line1: addAddressData.address_line1,
            contact_no: addAddressData.contact_no,
            address_line2: addAddressData.address_line2,
            name: addAddressData.name,
            state: addAddressData.state,
            country: addAddressData.country,
            city: addAddressData.city,
            postal_code: addAddressData.postal_code,
          });
    
          if (response.status === 200) {
            toast.success("Address added successfully");
            fetchData("address");
            setIsAddDailogOpen(false);
            setAddAddressData({
              address_line1: "",
              name: "",
              contact_no: "",
              address_line2: "",
              postal_code: "",
              state: "",
              city: "",
              country: "101",
            });
          }
        } catch (err) {
          console.error("Failed to add address:", err);
          alert("An error occurred while adding the address. Please try again.");
        }
      };

      const handleStateSelect = async (state_id: string) => {
          if (!state_id || localStorage.getItem("state_id") === state_id) return;
      
          localStorage.setItem("state_id", state_id);
          try {
            await fetchData("cities");
            setFilteredCities(cityList.filter((city) => city.state_id === state_id));
          } catch (err) {
            console.error("Failed to fetch cities:", err);
            toast.error("Failed to load cities. Please try again.");
          }
        };

      const handleInputChange = (field: string, value: string) => {
    setAddAddressData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  if (loading) {
    return (
      <div className="w-full h-screen p-6 space-y-6 bg-gray-100">
        <div className="flex gap-6">
          <div className="w-1/4 space-y-4">
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
          </div>
          <div className="flex-1 space-y-6">
            <div className="h-10 w-2/3 bg-gray-300 animate-pulse rounded-md"></div>
            <div className="grid grid-cols-3 gap-6">
              <div className="h-40 bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-40 bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-40 bg-gray-300 animate-pulse rounded-md"></div>
            </div>
            <div className="space-y-3">
              <div className="h-6 w-full bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-6 w-4/5 bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-6 w-3/5 bg-gray-300 animate-pulse rounded-md"></div>
            </div>
            <div className="space-y-3">
              <div className="h-6 w-full bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-6 w-4/5 bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-6 w-3/5 bg-gray-300 animate-pulse rounded-md"></div>
            </div>
            <div className="space-y-3">
              <div className="h-6 w-full bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-6 w-4/5 bg-gray-300 animate-pulse rounded-md"></div>
              <div className="h-6 w-3/5 bg-gray-300 animate-pulse rounded-md"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Function to get image path for a cart item
  const getImagePath = (item: any) => {
    try {
      const rawPath = item?.EstShopInventory?.image_path;
      if (!rawPath) return dummyImage.src;
      const parsedImages = JSON.parse(rawPath);
      return Array.isArray(parsedImages) && parsedImages[0]?.src
        ? `${config.NEXT_PUBLIC_API_URL}/${parsedImages[0].src}`
        : dummyImage.src;
    } catch (error) {
      console.error("Error parsing image_path for item:", item, error);
      return dummyImage.src;
    }
  };

  return (
    <div>
      <div className="w-[90%] h-auto mx-auto my-5">
        <div className="flex gap-6 text-sm">
          <div className="w-[70%] rounded-lg overflow-hidden h-[fit-content]">
            <div className="flex justify-between items-center border rounded-md p-3">
              <span className="text-lg font-bold px-1">
                Select Delivery Address
              </span>
              <Dialog
                            open={isAddDailogOpen}
                            onOpenChange={(open) => {
                              setIsAddDailogOpen(open);
                              if (open) {
                                console.log(
                                  "Add Address dialog opened, calling handleCountrySelect"
                                );
                                handleCountrySelect("101");
                              }
                            }}
                          >
                            <DialogTrigger asChild>
                              <div className="flex justify-end">
                                <Button
                                  onClick={() => {
                                    setIsAddDailogOpen(true);
                                  }}
                                  className="bg-[#6a3a18]"
                                >
                                  + Add New Address
                                </Button>
                              </div>
                            </DialogTrigger>
                            <DialogContent className="w-[400px] h-[80%] px-8 overflow-auto rounded-lg">
                              <div className="text-sm flex flex-col gap-4">
                                <div>
                                  <DialogTitle>
                                    <span className="font-bold text-lg">Add Address</span>
                                  </DialogTitle>
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>Name *</span>
                                  <Input
                                    type="text"
                                    placeholder="Enter Name"
                                    value={addAddressData.name}
                                    onChange={(e) =>
                                      handleInputChange("name", e.target.value)
                                    }
                                  />
                                  {errorsAdd.name && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.name}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>Street Address *</span>
                                  <Input
                                    type="text"
                                    placeholder="Enter Street Address 1"
                                    value={addAddressData.address_line1}
                                    onChange={(e) =>
                                      handleInputChange("address_line1", e.target.value)
                                    }
                                  />
                                  {errorsAdd.address_line1 && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.address_line1}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>Street Address 2 *</span>
                                  <Input
                                    type="text"
                                    placeholder="Enter Street Address 2"
                                    value={addAddressData.address_line2}
                                    onChange={(e) =>
                                      handleInputChange("address_line2", e.target.value)
                                    }
                                  />
                                  {errorsAdd.address_line2 && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.address_line2}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>Contact Number *</span>
                                  <Input
                                    type="tel"
                                    placeholder="Enter phone number"
                                    value={addAddressData.contact_no}
                                    onChange={(e) =>
                                      handleInputChange("contact_no", e.target.value)
                                    }
                                  />
                                  {errorsAdd.contact_no && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.contact_no}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>Country *</span>
                                  <div className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-not-allowed">
                                    India
                                  </div>
                                  <input
                                    type="hidden"
                                    value="101"
                                    onChange={(e) => handleInputChange("country", "101")}
                                  />
                                  {errorsAdd.country && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.country}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>State *</span>
                                  <div className="relative">
                                    {isEditingS ? (
                                      <input
                                        autoFocus
                                        className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                                        placeholder="Search states..."
                                        onBlur={() => setIsEditingS(false)}
                                        onChange={(e) => {
                                          const searchInput = e.target.value.toLowerCase();
                                          setFilteredStates(
                                            filteredStates.filter((state) =>
                                              state.state_name
                                                .toLowerCase()
                                                .includes(searchInput)
                                            )
                                          );
                                        }}
                                      />
                                    ) : (
                                      <div
                                        className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                                        onClick={() => {
                                          console.log(
                                            "State dropdown clicked, calling handleCountrySelect"
                                          );
                                          setIsEditingS(true);
                                          handleCountrySelect("101");
                                        }}
                                      >
                                        {addAddressData.state
                                          ? filteredStates.find(
                                              (s) => s.id === addAddressData.state
                                            )?.state_name || "Select a State"
                                          : "Select a State"}
                                      </div>
                                    )}
                                    {isEditingS && (
                                      <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                        {filteredStates.length === 0 ? (
                                          <div className="px-3 py-2 text-gray-500">
                                            No states available
                                          </div>
                                        ) : (
                                          filteredStates.map((state) => (
                                            <div
                                              key={state.id}
                                              className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                                              onMouseDown={() => {
                                                console.log(
                                                  `Selected state: ${state.state_name} (ID: ${state.id})`
                                                );
                                                handleInputChange("state", state.id);
                                                handleStateSelect(state.id);
                                                setIsEditingS(false);
                                              }}
                                            >
                                              {state.state_name}
                                            </div>
                                          ))
                                        )}
                                      </div>
                                    )}
                                  </div>
                                  {errorsAdd.state && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.state}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>City *</span>
                                  <div className="relative">
                                    {isEditingCi ? (
                                      <input
                                        autoFocus
                                        className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                                        placeholder="Search cities..."
                                        onBlur={() => setIsEditingCi(false)}
                                        onChange={(e) => {
                                          const searchInput = e.target.value.toLowerCase();
                                          setFilteredCities(
                                            cityList.filter((city) =>
                                              city.city_name
                                                .toLowerCase()
                                                .includes(searchInput)
                                            )
                                          );
                                        }}
                                      />
                                    ) : (
                                      <div
                                        className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                                        onClick={() => setIsEditingCi(true)}
                                      >
                                        {addAddressData.city
                                          ? cityList.find((c) => c.id === addAddressData.city)
                                              ?.city_name || "Select a City"
                                          : "Select a City"}
                                      </div>
                                    )}
                                    {isEditingCi && (
                                      <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                        {filteredCities.map((city) => (
                                          <div
                                            key={city.id}
                                            className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                                            onMouseDown={() => {
                                              handleInputChange("city", city.id);
                                              setIsEditingCi(false);
                                            }}
                                          >
                                            {city.city_name}
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                  {errorsAdd.city && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.city}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  <span>Pincode *</span>
                                  <Input
                                    type="text"
                                    placeholder="Enter your pincode"
                                    value={addAddressData.postal_code}
                                    onChange={(e) =>
                                      handleInputChange(
                                        "postal_code",
                                        e.target.value.slice(0, 6)
                                      )
                                    }
                                  />
                                  {errorsAdd.postal_code && (
                                    <span className="text-red-500 text-xs">
                                      {errorsAdd.postal_code}
                                    </span>
                                  )}
                                </div>
                                <div className="flex justify-end mt-4">
                                  <Button
                                    className="bg-[#6a3a18] w-[90px] hover:bg-[#6a3a18]"
                                    onClick={() => handleAddAddress()}
                                  >
                                    Save
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
              {/* <button
                className="bg-[#9a602e] text-white px-3 py-1 rounded-sm hover:bg-[#814d24]"
                onClick={() => setIsAddDailogOpen(true)}
              >
                Add New Address
              </button> */}
            </div>
            {/* <Dialog
              open={isAddDailogOpen}
              onOpenChange={(open) => setIsAddDailogOpen(open)}
            >
              <DialogContent className="w-[400px] h-[80%] px-8 overflow-auto rounded-lg">
                <div className="text-sm flex flex-col gap-4">
                  <div>
                    <DialogTitle>
                      <span className="font-bold text-lg">Add Address</span>
                    </DialogTitle>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Name *</span>
                    <Input
                      type="text"
                      placeholder="Enter Name"
                      value={addAddressData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                    />
                    {errorsAdd.name && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.name}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Street Address *</span>
                    <Input
                      type="text"
                      placeholder="Enter Street Address 1"
                      value={addAddressData.address_line1}
                      onChange={(e) =>
                        handleInputChange("address_line1", e.target.value)
                      }
                    />
                    {errorsAdd.address_line1 && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.address_line1}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Street Address 2 *</span>
                    <Input
                      type="text"
                      placeholder="Enter Street Address 2"
                      value={addAddressData.address_line2}
                      onChange={(e) =>
                        handleInputChange("address_line2", e.target.value)
                      }
                    />
                    {errorsAdd.address_line2 && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.address_line2}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Contact Number *</span>
                    <Input
                      type="tel"
                      placeholder="Enter phone number"
                      value={addAddressData.contact_no}
                      onChange={(e) =>
                        handleInputChange("contact_no", e.target.value)
                      }
                    />
                    {errorsAdd.contact_no && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.contact_no}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Country *</span>
                    <div className="relative">
                      {isEditingCEdit ? (
                        <input
                          autoFocus
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                          placeholder="Search countries..."
                          onBlur={() => setIsEditingCEdit(false)}
                          onChange={(e) => {
                            const searchInput = e.target.value.toLowerCase();
                            setFilteredCountriesEdit(
                              countryList.filter((country) =>
                                country.country_name
                                  .toLowerCase()
                                  .includes(searchInput)
                              )
                            );
                          }}
                        />
                      ) : (
                        <div
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                          onClick={() => setIsEditingCEdit(true)}
                        >
                          {addAddressData?.country
                            ? countryList.find(
                                (c) => c.id === addAddressData.country
                              )?.country_name || "Select a Country"
                            : "Select a Country"}
                        </div>
                      )}
                      {isEditingCEdit && (
                        <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                          {filteredCountriesEdit.map((country) => (
                            <div
                              key={country.id}
                              className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                              onMouseDown={() => {
                                handleInputChange("country", country.id);
                                handleCountrySelect(country.id);
                                setIsEditingCEdit(false);
                              }}
                            >
                              {country.country_name}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    {errorsAdd?.country && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.country}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>State *</span>
                    <div className="relative">
                      {isEditingSEdit ? (
                        <input
                          autoFocus
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                          placeholder="Search states..."
                          onBlur={() => setIsEditingSEdit(false)}
                          onChange={(e) => {
                            const searchInput = e.target.value.toLowerCase();
                            setFilteredStatesEdit(
                              stateList.filter((state) =>
                                state.state_name
                                  .toLowerCase()
                                  .includes(searchInput)
                              )
                            );
                          }}
                        />
                      ) : (
                        <div
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                          onClick={() => setIsEditingSEdit(true)}
                        >
                          {addAddressData?.state
                            ? stateList.find(
                                (s) => s.id === addAddressData.state
                              )?.state_name || "Select a State"
                            : "Select a State"}
                        </div>
                      )}
                      {isEditingSEdit && (
                        <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                          {filteredStatesEdit.map((state) => (
                            <div
                              key={state.id}
                              className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                              onMouseDown={() => {
                                handleInputChange("state", state.id);
                                handleStateSelect(state.id);
                                setIsEditingSEdit(false);
                              }}
                            >
                              {state.state_name}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    {errorsAdd?.state && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.state}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>City *</span>
                    <div className="relative">
                      {isEditingCiEdit ? (
                        <input
                          autoFocus
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                          placeholder="Search cities..."
                          onBlur={() => setIsEditingCiEdit(false)}
                          onChange={(e) => {
                            const searchInput = e.target.value.toLowerCase();
                            setFilteredCitiesEdit(
                              cityList.filter((city) =>
                                city.city_name
                                  .toLowerCase()
                                  .includes(searchInput)
                              )
                            );
                          }}
                        />
                      ) : (
                        <div
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                          onClick={() => setIsEditingCiEdit(true)}
                        >
                          {addAddressData?.city
                            ? cityList.find(
                                (c) => c.id === addAddressData.city
                              )?.city_name || "Select a City"
                            : "Select a City"}
                        </div>
                      )}
                      {isEditingCiEdit && (
                        <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                          {filteredCitiesEdit.map((city) => (
                            <div
                              key={city.id}
                              className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                              onMouseDown={() => {
                                handleInputChange("city", city.id);
                                setIsEditingCiEdit(false);
                              }}
                            >
                              {city.city_name}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    {errorsAdd?.city && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.city}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Pincode *</span>
                    <Input
                      type="text"
                      placeholder="Enter your pincode"
                      value={addAddressData.postal_code}
                      onChange={(e) =>
                        handleInputChange(
                          "postal_code",
                          e.target.value.slice(0, 6)
                        )
                      }
                    />
                    {errorsAdd.postal_code && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.postal_code}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button
                      className="bg-[#6a3a18] w-[90px] hover:bg-[#6a3a18]"
                      onClick={() => handleAddAddress()}
                    >
                      Save
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog> */}

            {addressList.map((address) => (
              <div
                key={address.id}
                className={`border rounded-md px-4 py-4 mb-4 cursor-pointer transition-shadow mt-2 ${
                  selectedAddress === address.id
                    ? "shadow-lg border-green-500"
                    : "hover:shadow-md"
                }`}
                onClick={() => handleSelectAddress(address.id)}
              >
                <div className="mb-3 flex items-center">
                  <input
                    type="radio"
                    checked={selectedAddress === address.id}
                    readOnly
                    className="mr-2"
                  />
                  <span className="text-lg font-bold mr-2">{address.name}</span>
                  <span className="font-medium">
                    {address.primary_address ? "(Default)" : ""}
                  </span>
                </div>
                <div className="flex flex-col gap-4 text-sm">
                  <div>
                    <span>{address.address_line1}</span>,
                    <span> {address.address_line2}</span>,
                    <span> {address.City.city_name}</span>,
                    <span> {address.State.state_name}</span>,
                    <span> {address.Country.country_name}</span> -
                    <span> {address.postal_code}</span>
                  </div>
                  <div>
                    <span>
                      Mobile:{" "}
                      <span className="font-bold">
                        +91 {address.contact_no}
                      </span>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="border w-[40%] h-fit rounded-md overflow-hidden p-4">
            <div className="flex flex-col gap-4">
              <span>Billing Details</span>
              <div className="flex flex-col gap-6">
                {cartItems.map((item: any) => (
                  <div
                    key={item.id}
                    className="flex justify-between border-b pb-4"
                  >
                    <div className="flex gap-2">
                      <img
                        src={getImagePath(item)}
                        alt={item.EstShopInventory?.ProductMaster?.product_name}
                        loading="lazy"
                        className="w-[80px] h-[80px] object-cover"
                        width={80}
                        height={80}
                        onError={(e) => {
                          e.currentTarget.src = dummyImage.src;
                        }}
                      />
                      <div className="flex flex-col gap-1">
                        <span>{item.EstShopInventory?.ProductMaster?.product_name}</span>
                        <span>Qty: {item.quantity}</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-md font-semibold">
                        ₹{formatIndianCurrency(Number(item.EstShopInventory.offer_price))}
                      </span>
                    </div>
                  </div>
                ))}
                <div className="border-t border-b py-2 flex flex-col gap-2">
                  <div className="flex justify-between text-gray-800">
                    <p>Total MRP</p>
                    <p>
                      ₹{" "}
                      {formatIndianCurrency(
                        cartItems.reduce(
                          (total, item) =>
                            total +
                            (Number(
                              item.EstShopInventory.exp_onlinesellprice_aft
                            ) || 0) * (item.quantity || 1),
                          0
                        )
                      )}
                    </p>
                  </div>
                  <div className="flex justify-between text-gray-800">
                    <p>Discount</p>
                    <p className="text-green-600">
                      -₹ {formatIndianCurrency(calculateDiscount())}{" "}
                      <span>({calculateDiscountPercentage()}%)</span>
                    </p>
                  </div>
                  <hr className="my-2 border-t border-gray-300" />
                  <div className="flex justify-between text-black font-bold">
                    <span>TOTAL</span>
                    <span>₹ {formatIndianCurrency(cartData?.totalPrice)}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
  <span>Choose payment method</span>
  <div>
    {/* <div className="flex gap-2 items-center">
      <input
        type="radio"
        name="paymentMode"
        checked={selectedPaymentMode === 1}
        onChange={() => handleSelectPaymentMode({ id: 1, payment_method: "COD" })}
      />
      <span>COD</span>
    </div> */}
    <div className="flex gap-2 items-center">
      <input
        type="radio"
        name="paymentMode"
        checked={selectedPaymentMode === 2}
        onChange={() => handleSelectPaymentMode({ id: 2, payment_method: "Online Payment" })}
      />
      <span>Online Payment</span>
    </div>
  </div>
</div>
                <Button
                  onClick={handlePlaceOrder}
                  disabled={!selectedPaymentMode}
                >
                  Continue
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}