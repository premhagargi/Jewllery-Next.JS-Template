/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import { IoFilter } from "react-icons/io5";
import { api } from "../../../../utils/api";
import { useState, useEffect } from "react";
import JewelleryWishlistCard from "@/components/user/jewelleryWishlistCard";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useGlobalState } from "@/context/GlobalStateContext";
import { Heart } from "lucide-react";
import Link from "next/link";
import { PiUserLight } from "react-icons/pi";
import { FiPackage } from "react-icons/fi";
import { useRouter } from "next/navigation";
import Cookies from "js-cookie";
import { GoHeart, GoLocation, GoPasskeyFill, GoTrash } from "react-icons/go";
import { MdOutlineContactSupport } from "react-icons/md";
import { BiLogOut } from "react-icons/bi";
import Image from "next/image";
import "../../loading.css";
import UserImage from "../../../../public/assets/user/boy.png";
import Style from "../styles/wishlist.module.scss";
import { toast } from "sonner";
import useAuth from "../../../hooks/useAuth";
import config from "../../../../config.json";
const COMPANY_ID = config.COMPANY_ID;
import ConfirmModal from "@/components/user/confirmModal";
import React from "react";

export default function Wishlist() {
  const router = useRouter();
  const { isAuthenticated, loading: authLoading } = useAuth();

  const { fetchData, wishlistData, isTokenExpired, profileData } = useGlobalState();
  const [wishlist, setWishlistItems] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [categorylist, setCategoryList] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true); // Set initial loading to true

  type WishlistResponse = {
    data: any[];
  };

  const fetchWishlist = async () => {
    try {
      setLoading(true); // Ensure loading is true at the start of the fetch
      const response = await api.get("/api/v1/products/getwishlist");

      const fetchedWishlist = (response.data as WishlistResponse)?.data ?? [];
      setWishlistItems(fetchedWishlist);
      setFilteredProducts(fetchedWishlist);
    } catch (err) {
      if ((err as any).response?.status === 200) {
        setWishlistItems([]);
        setFilteredProducts([]);
      } else {
        setError("Failed to fetch wishlist data");
        console.error(err);
      }
    } finally {
      setTimeout(() => {
        setLoading(false); // Set loading to false after fetch completes
      }, 0);
    }
  };

  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDeleteConfirmed = async () => {
    setIsModalOpen(false);
    try {
      await api.patch("/api/v1/deleteAcc", {});
      toast.success("Your account has been deleted!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      setTimeout(() => {
        toast("We are sorry to see you go!!", {
          duration: 2000,
          position: "top-center",
          icon: "😔",
        });
      }, 500);
      localStorage.clear();
      router.push("/login");
      Cookies.remove("token");
    } catch (err) {
      console.error("Account deletion error:", err);
    }
  };

  const deleteAccount = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to permanently delete your account? This action cannot be undone."
    );
    if (confirmed) {
      try {
        await api.patch("/api/v1/deleteAcc", {});
        toast("Your account has been deleted!", {
          duration: 2000,
          position: "top-center",
          icon: "👤",
        });
        setTimeout(() => {
          toast("We are sorry to see you go!!", {
            duration: 2000,
            position: "top-center",
            icon: "👤",
          });
        }, 500);
        setTimeout(() => {
          localStorage.clear();
          router.push("/login");
          Cookies.remove("token");
        }, 200);
      } catch (err) {
        if ((err as any).response?.status === 200) {
        } else {
          setError("Failed to delete your account");
          console.error(err);
        }
      }
    }
  };

  const handleRemoveFromWishlist = (removedProductId: string, removedShopId: string) => {
    setWishlistItems((prevWishlist) =>
      prevWishlist.filter(
        (product) =>
          product.product_id !== removedProductId || product.est_shop_id !== removedShopId
      )
    );
    setFilteredProducts((prevFiltered) =>
      prevFiltered.filter(
        (product) =>
          product.product_id !== removedProductId || product.est_shop_id !== removedShopId
      )
    );
    fetchData("wishlist");
  };

  const fetchCategories = async () => {
    try {
      const response = await api.get(
        `/api/v1/category/getCategory?company_id=${COMPANY_ID}`
      );
      const categoryList = (response.data as { data: any[] }).data || [];
      setCategoryList(categoryList);
    } catch (err) {
      setError("Failed to fetch category data");
      console.error(err);
    }
  };

  useEffect(() => {
    if (!isAuthenticated && !authLoading) {
      toast("Please log in to view your wishlist !!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      router.push("/login");
    } else {
      document.title = `My Wishlist (${wishlistData.totalProducts || 0})`;
      fetchWishlist();
    }
  }, [isAuthenticated, authLoading]);

  const handleFilterChange = (value: string) => {
    if (value === "All") {
      setFilteredProducts(wishlist);
    } else {
      const filtered = wishlist.filter((product) => product.category === value);
      setFilteredProducts(filtered);
    }
  };

  return (
    <div className={`w-[90%] mx-auto flex gap-10 text-sm my-10 ${Style.wishlistContainer}`}>
      <div className={`min-w-[250px] border shadow py-4 text-[#6a3a18] h-fit ${Style.wishlistLeftContainer}`}>
        <div className={`flex items-center gap-2 px-4 pb-4 border-b ${Style.profileImageAndNameContainer}`}>
          <Image
            src={UserImage}
            width={1000}
            height={1000}
            quality={100}
            alt=""
            loading="lazy"
            className="w-[50px] h-[50px] rounded-full"
          />
          <div className="flex flex-col">
            <span className="text-xs">
              Hello <span className="text-lg">🖐️</span>
            </span>
            <span className="font-bold">{profileData?.cust_cmp_name}</span>
          </div>
        </div>
        <div className={`flex flex-col gap-1 py-4 px-2 ${Style.navigateButtons}`}>
          <Link href={"/profile"} onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem("redirectAfterLogin", window.location.href);
                toast("Please log in to view your Profile", {
                  duration: 3000,
                  position: "top-center",
                  icon: "👤",
                });
                router.push("/login");
              }
            }}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <PiUserLight size={18} />
              <span>Personal Information</span>
            </div>
          </Link>
          <Link href={"/orders"} onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem("redirectAfterLogin", window.location.href);
                toast("Please log in to view your Orders", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📦",
                });
                router.push("/login");
              }
            }}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer text-[#6a3a18] hover:bg-[#f0ebe8] rounded-sm">
              <FiPackage size={18} />
              <span>My Orders</span>
            </div>
          </Link>
          <Link href={"/wishlist"}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer bg-[#6a3a18] text-white rounded-sm">
              <GoHeart size={18} />
              <span>My Wishlists</span>
            </div>
          </Link>
          <Link href={"/address"} onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem("redirectAfterLogin", window.location.href);
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer text-[#6a3a18] hover:bg-[#f0ebe8] rounded-sm">
              <GoLocation size={18} />
              <span>Manage Addresses</span>
            </div>
          </Link>
          <Link href={"/passwordChange"} onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem("redirectAfterLogin", window.location.href);
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoPasskeyFill size={18} />
              <span>Password Change</span>
            </div>
          </Link>
          <div onClick={() => setIsModalOpen(true)} className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
            <GoTrash size={18} />
            <span>Delete My Account</span>
          </div>
          <ConfirmModal
            isOpen={isModalOpen}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => setIsModalOpen(false)}
          />
          <div onClick={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("redirectAfterLogin");
              router.push("/login");
            }} className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
            <BiLogOut size={18} />
            <span>Logout</span>
          </div>
        </div>
      </div>
      <div className={`w-full mx-auto text-sm ${Style.wishlistRightContainer}`}>
        <div className="w-full my-6">
          {loading ? (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 lg:grid-cols-5 gap-3">
      {[...Array(5)].map((_, index) => (
        <div
          key={index}
          className="h-[300px] w-[200px] bg-gray-300 animate-pulse rounded-md p-4 flex flex-col justify-between"
        >
          {/* Image skeleton with small remove button */}
          <div className="relative h-[60%] bg-gray-400 rounded-md mb-4">
            <div className="absolute top-2 right-2 h-5 w-5 bg-gray-500"></div>
          </div>
    
          {/* Text skeletons */}
          <div className="flex flex-col items-center space-y-2 mb-4">
  <div className="h-4 bg-gray-400 rounded w-3/4"></div>
  <div className="h-4 bg-gray-400 rounded w-1/2"></div>
</div>

    
          {/* Full-width button skeleton at the bottom */}
          <div className="h-8 bg-gray-400 rounded w-full"></div>
        </div>
      ))}
    
   
    </div>
    
       
          ) : error ? (
            <div className="text-center text-red-500">{error}</div>
          ) : filteredProducts.length > 0 ? (
            <div className="flex flex-wrap flex-row items-stretch content-stretch">
              {filteredProducts.map((product) => (
                <JewelleryWishlistCard
                  key={product.product_id + product.est_shop_id}
                  product={product}
                  onRemoveFromWishlist={handleRemoveFromWishlist}
                />
              ))}
            </div>
          ) : (
            <div className="flex mx-auto flex-col items-center justify-center h-[300px] text-gray-500">
              <Heart size={50} className="text-gray-400 mb-3" />
              <span className="text-lg font-semibold">No products in wishlist</span>
              <p className="text-sm text-gray-400">Start adding your favorite items!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}