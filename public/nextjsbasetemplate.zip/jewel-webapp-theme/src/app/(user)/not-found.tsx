export default function PageNotFound() {
  return (
    <div className="w-full h-[100vh] bg-black flex justify-center items-center text-white">
      <div className="flex items-center gap-6">
        <div className="border-r border-slate-50 font-bold" style={{fontSize: "1.8rem", paddingRight: "25px"}}>404</div>
        <p>This page could not be found.</p>
      </div>
    </div>
  );
}
