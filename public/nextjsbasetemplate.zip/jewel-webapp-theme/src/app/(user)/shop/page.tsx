/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import { useState, useEffect } from "react";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Style from "../styles/shop.module.scss";
import { useRouter } from "next/navigation";

// Assets
import JewelleryCard from "@/components/user/jewelleryCard";
import { api } from "../../../../utils/api";
import { useGlobalState } from "@/context/GlobalStateContext";
import config from "../../../../config.json";

import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { HiArrowsRightLeft } from "react-icons/hi2";

import { Drawer, DrawerContent, DrawerTrigger } from "@/components/ui/drawer";
import React from "react";

const COMPANY_ID = config.COMPANY_ID;

export default function Store() {
  const router = useRouter();
  const { categoryList } = useGlobalState();
  const company_id = COMPANY_ID;

  const [productlist, setProducts] = useState<any[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState([0, 100000]);
  const [filteredProducts, setFilteredProducts] = useState(productlist);
  const { fetchData } = useGlobalState();
  const [loading, setLoading] = useState<boolean>(false);

  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, limit: 10 });
  const [hasMore, setHasMore] = useState(true); // Track if more products are available

  const SkeletonCard = () => {
    return (
      <div className="m-2 sm:w-60 w-full h-72 bg-gray-300 animate-pulse rounded-md">
        <div className="h-32 bg-gray-400 rounded-t-md"></div>
        <div className="p-4">
          <div className="h-6 bg-gray-400 rounded-md mb-2"></div>
          <div className="h-4 bg-gray-400 rounded-md"></div>
        </div>
      </div>
    );
  };

  // Fetch products with optional category_ids, page, and limit
  const fetchProducts = async (
    categoryIds: string[] = [],
    page = 1,
    limit = 10
  ) => {
    try {
      setLoading(true);
      const categoryParam = categoryIds.length > 0 ? categoryIds.join(",") : "";

      const url = `/api/v1/products/productList?category=&category_id=${categoryParam}&company_id=${company_id}&page=${page}&limit=${limit}`;

      const response = await api.get(url);
      if (response.data) {
        const newProducts = (response.data as { data: any[] }).data || [];
        setProducts((prev) =>
          page === 1 ? newProducts : [...prev, ...newProducts]
        );
        setFilteredProducts((prev) =>
          page === 1 ? newProducts : [...prev, ...newProducts]
        );

        // Check if more products are available
        if (newProducts.length < limit) {
          setHasMore(false);
        }
      } else {
        console.error("Error fetching products");
      }
    } catch (error) {
      console.error("API request failed:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    document.title = "Shop Products";
    fetchProducts([], pagination.page, pagination.limit);
  }, [pagination.page]);

  // Handle "Load More" click
  const handleLoadMore = () => {
    setPagination((prev) => ({ ...prev, page: prev.page + 1 }));
  };

  // Handle pagination
  const handleNextPage = () => {
    setPagination((prev) => ({ ...prev, page: prev.page + 1 }));
  };

  const handlePreviousPage = () => {
    setPagination((prev) => ({ ...prev, page: Math.max(prev.page - 1, 1) }));
  };

  // Handle sorting
  const handleSort = (value: string) => {
    const sortedProducts = [...filteredProducts];
    if (value === "Low to High") {
      sortedProducts.sort((a, b) => a.offer_price - b.offer_price);
    } else if (value === "High to Low") {
      sortedProducts.sort((a, b) => b.offer_price - a.offer_price);
    }
    setFilteredProducts(sortedProducts);
  };

  // Handle price slider change
  const handlePriceChange = (values: number[]) => {
    setPriceRange(values);

    const filtered = productlist.filter((product) => {
      const price = product.offer_price
        ? Number(product.offer_price)
        : product.exp_onlinesellprice_aft
        ? Number(product.exp_onlinesellprice_aft)
        : null;
    
      return price !== null && price >= values[0] && price <= values[1];
    });

    setFilteredProducts(filtered);
  };

  // Handle category click
  const handleCategoryClick = (category_id: string) => {
    setSelectedCategories((prev) => {
      let newSelected;
      if (prev.includes(category_id)) {
        // Remove category if already selected
        newSelected = prev.filter((id) => id !== category_id);
      } else {
        // Add category if not selected
        newSelected = [...prev, category_id];
      }

      // Update URL with selected categories
      const searchParams = new URLSearchParams(window.location.search);
      if (newSelected.length > 0) {
        searchParams.set("category_id", newSelected.join(","));
      } else {
        searchParams.delete("category_id");
      }
      const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
      window.history.pushState({}, "", newUrl);

      // Fetch products with new category selection
      fetchProducts(newSelected);

      return newSelected;
    });
  };

  // Initialize selected categories from URL on mount
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const categoryParam = searchParams.get("category_id");
    if (categoryParam) {
      const categories = categoryParam.split(",");
      setSelectedCategories(categories);
      fetchProducts(categories);
    }
  }, []);

  return (
    <div className={`w-[95%] flex gap-2 mx-auto ${Style.shopContainer}`}>
      <div
        className={`w-[250px] p-4 flex flex-col gap-8 ${Style.shopLeftContainer}`}
      >
        <div className="flex flex-col gap-4">
          <p className="font-semibold">Categories</p>
          <div className="flex flex-col gap-1 text-sm category-list">
            {categoryList.length > 0 ? (
              categoryList.map((category, index) => (
                <div
                  key={index}
                  className={`flex justify-between items-center cursor-pointer p-2 rounded ${
                    selectedCategories.includes(category.category_id)
                      ? "bg-gray-300 shadow-md"
                      : "hover:bg-gray-150"
                  }`}
                  onClick={() => handleCategoryClick(category.category_id)}
                >
                  <div className="flex items-center gap-2">
                    <p>{category.category_name}</p>
                    {selectedCategories.includes(category.category_id) && (
                      <CheckCircle className="text-green-500 w-4 h-4" />
                    )}
                  </div>
                  {/* <p className="bg-[#ececec] rounded-lg w-[50px] h-auto flex items-center justify-center text-sm px-2 py-1">
  {category.totalQuantity || 0}
</p> */}
                </div>
              ))
            ) : (
              <p>No categories available</p>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <p>Price</p>
          <div className={Style.sliderContainer}>
            <Slider
              defaultValue={priceRange}
              max={100000}
              step={100}
              onValueChange={handlePriceChange}
              // className="cursor-pointer"
            />
            <p className="text-sm mt-2">
              Range: ₹{priceRange[0]} - ₹{priceRange[1]}
            </p>
          </div>
        </div>
      </div>
      <div className={`w-[80%] p-4 ${Style.shopRightContainer}`}>
        <div className="w-[96%] mx-auto flex justify-between mb-4">
          <div>
            <p className="font-bold text-sm">All Jewellery</p>
            <p className="text-slate-400 text-sm">
              {filteredProducts.length} Products
            </p>
          </div>
          <div className="flex gap-2 items-center">
            <div className={Style.mobileFliterContainer}>
              <Drawer>
                <DrawerTrigger>
                  <div className="border py-[6] px-3 rounded-lg flex items-center gap-2">
                    <span>Fliter</span>
                    <HiArrowsRightLeft />
                  </div>
                </DrawerTrigger>
                <DrawerContent className="flex items-center">
                  <div className="w-[85%] my-10 flex gap-8 flex-col">
                    <div className="flex flex-col gap-4">
                      <p className="font-semibold">Categories</p>
                      <div className="flex flex-col gap-1 text-sm category-list">
                        {categoryList.length > 0 ? (
                          categoryList.map((category, index) => (
                            <div
                              key={index}
                              className={`flex justify-between items-center cursor-pointer p-2 rounded ${
                                selectedCategories.includes(
                                  category.category_id
                                )
                                  ? "bg-gray-300 shadow-md"
                                  : "hover:bg-gray-150"
                              }`}
                              onClick={() =>
                                handleCategoryClick(category.category_id)
                              }
                            >
                              <div className="flex items-center gap-2">
                                <p>{category.category_name}</p>
                                {selectedCategories.includes(
                                  category.category_id
                                ) && <span className="text-black">✔</span>}
                              </div>
                              <p className="bg-[#ececec] rounded-lg w-[30px] h-[30px] grid place-items-center text-sm p-1">
                                {category.totalQuantity || 0}
                              </p>
                            </div>
                          ))
                        ) : (
                          <p>No categories available</p>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col gap-4">
                      <p>Price</p>
                      <div className={Style.sliderContainer}>
                        <Slider
                          defaultValue={priceRange}
                          max={100000}
                          step={100}
                          onValueChange={handlePriceChange}
                        />
                        <p className="text-sm mt-2">
                          Range: ₹{priceRange[0]} - ₹{priceRange[1]}
                        </p>
                      </div>
                    </div>
                  </div>
                </DrawerContent>
              </Drawer>
            </div>
            <Select onValueChange={handleSort}>
              <SelectTrigger className="w-auto">
                <SelectValue placeholder="Sort By" className="text-sm" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Price</SelectLabel>
                  <SelectItem value="Low to High">Low to High</SelectItem>
                  <SelectItem value="High to Low">High to Low</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div
          className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 ${Style.productContainer}`}
        >
          {filteredProducts.length === 0 && productlist.length === 0 && loading
            ? Array.from({ length: 5 }).map((_, index) => (
                <SkeletonCard key={index} />
              ))
            : filteredProducts.map((product, index) => {
                const uniqueKey = `${product?.id}-${product?.est_shop_id}`;
                return <JewelleryCard key={uniqueKey} product={product} />;
              })}
        </div>

        {hasMore &&
          !loading &&
          (productlist.length > 0 || filteredProducts.length > 0) && (
            <div className="flex justify-center mt-4">
              <p
                className="text-pink-500 cursor-pointer text-sm font-medium"
                onClick={handleLoadMore}
              >
                Load More...
              </p>
            </div>
          )}
      </div>
    </div>
  );
}
