/* eslint-disable react-hooks/exhaustive-deps */
// "use client";
// import Image from "next/image";
// import UserImage from "../../../../public/assets/user/boy.png";
// import { PiUserLight } from "react-icons/pi";
// import { FiPackage } from "react-icons/fi";
// import { useEffect, useState } from "react";
// import { GoHeart } from "react-icons/go";
// import { useGlobalState } from "@/context/GlobalStateContext";
// import { GoLocation, GoTrash } from "react-icons/go";
// import { MdOutlineContactSupport } from "react-icons/md";
// import { BiLogOut } from "react-icons/bi";
// import { FaRegEdit } from "react-icons/fa";
// import { MapPin } from "lucide-react";
// import { useRouter } from "next/navigation";
// import { toast } from "sonner";
// import { Button } from "@/components/ui/button";
// import Link from "next/link";
// import { MdOutlineDelete } from "react-icons/md";
// import { api } from "../../../../utils/api";
// import Style from "../styles/address.module.scss";
// import { Input } from "@/components/ui/input";
// import ConfirmModal from "@/components/user/confirmModal";
// import {
//   Dialog,
//   DialogContent,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog";
// import Cookies from "js-cookie";
// import {
//   Select,
//   SelectContent,
//   SelectGroup,
//   SelectItem,
//   SelectLabel,
//   SelectTrigger,
//   SelectValue,
// } from "@/components/ui/select";
// import useAuth from "@/hooks/useAuth";
// import React from "react";

// // Define the Address type
// interface Address {
//   X: number;
//   id: number;
//   name: string;
//   cust_cmp_name: string;
//   address_line1: string;
//   address_line2: string;
//   city: string;
//   postal_code: string;
//   state: string;
//   country: string;
//   primary_address: boolean;
//   contact_no: string;
//   City: {
//     id: number;
//     city_name: string;
//     state_id: string;
//   };
//   State: {
//     id: number;
//     state_name: string;
//     country_id: string;
//   };
//   Country: {
//     id: number;
//     country_name: string;
//     phonecode: string;
//     sortname: string;
//   };
// }

// export default function Profile() {
//   const {
//     fetchData,
//     addressList,
//     countryList,
//     stateList,
//     cityList,
//     isTokenExpired,
//     profileData,
//   } = useGlobalState();
//   const [isDeleteDailogOpen, setIsDeleteDailogOpen] = useState(false);
//   const [isEditDailogOpen, setIsEditDailogOpen] = useState(false);
//   const [isAddDailogOpen, setIsAddDailogOpen] = useState(false);
//   const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);
//   const router = useRouter();
//   const [loadingProduct, setLoadingProduct] = useState<boolean>(true); // Track loading state
//   const { isAuthenticated, loading: authLoading } = useAuth(); // Extract loading from useAuth
//   const handleCountrySelect = async (country_id: string) => {
//     if (!country_id || localStorage.getItem("country_id") === country_id)
//       return;

//     localStorage.setItem("country_id", country_id);
//     fetchData("states");
//   };
//   const [filteredCountries, setFilteredCountries] = useState(countryList);
//   const [isEditingC, setIsEditingC] = useState(false);

//   const [filteredCountriesEdit, setFilteredCountriesEdit] =
//     useState(countryList);
//   const [isEditingCEdit, setIsEditingCEdit] = useState(false);

//   const [filteredStatesEdit, setFilteredStatesEdit] = useState(stateList);
//   const [isEditingSEdit, setIsEditingSEdit] = useState(false);

//   const [filteredStates, setFilteredStates] = useState(stateList);
//   const [isEditingS, setIsEditingS] = useState(false);

//   const [filteredCitiesEdit, setFilteredCitiesEdit] = useState(cityList);
//   const [isEditingCiEdit, setIsEditingCiEdit] = useState(false);

//   const [filteredCities, setFilteredCities] = useState(cityList);
//   const [isEditingCi, setIsEditingCi] = useState(false);
//   const handleAddAddress = async () => {
//     const newErrors = {
//       address_line1: "",
//       address_line2: "",
//       postal_code: "",
//       city: "",
//       state: "",
//       country: "",
//       name: "",
//       contact_no: "",
//     };

//     // Validate fields
//     if (!addAddressData?.address_line1)
//       newErrors.address_line1 = "Street Address 1 is required.";
//     if (!addAddressData?.name) newErrors.name = "Name is required";
//     if (!addAddressData?.contact_no) {
//       newErrors.contact_no = "Contact number is required.";
//     } else if (!/^\d{10}$/.test(addAddressData.contact_no)) {
//       newErrors.contact_no = "Contact number must be 10 digits.";
//     }
//     if (!addAddressData?.address_line2)
//       newErrors.address_line2 = "Street Address 2 is required.";
//     if (!addAddressData?.state) newErrors.state = "Please select a state.";
//     if (!addAddressData?.city) newErrors.city = "Please select a city";
//     if (!addAddressData?.country) newErrors.country = "Please select a country";

//     if (!addAddressData?.postal_code)
//       newErrors.postal_code = "Pincode is required.";
//     else if (addAddressData.postal_code.length !== 6)
//       newErrors.postal_code = "Pincode must be 6 digits.";

//     setAddErrors(newErrors);

//     // If there are validation errors, return early and don't proceed with API call
//     if (
//       newErrors.address_line1 ||
//       newErrors.address_line2 ||
//       newErrors.postal_code ||
//       newErrors.city ||
//       newErrors.state ||
//       newErrors.name ||
//       newErrors.contact_no
//     ) {
//       return; // Do not proceed if there are validation errors
//     }

//     newErrors.address_line1 = "";
//     newErrors.address_line2 = "";
//     newErrors.contact_no = "";
//     newErrors.postal_code = "";
//     newErrors.name = "";
//     newErrors.state = "";
//     newErrors.city = "";
//     newErrors.country = "";

//     try {
//       const response = await api.post("/api/v1/address/addAddress", {
//         address_line1: addAddressData.address_line1,
//         contact_no: addAddressData.contact_no,
//         address_line2: addAddressData.address_line2,
//         name: addAddressData.name,
//         state: addAddressData.state,
//         country: addAddressData.country,
//         city: addAddressData.city,
//         postal_code: addAddressData.postal_code,
//       });

//       if (response.status === 200) {
//         toast.success("Address added successfully");
//         fetchData("address");
//         setIsAddDailogOpen(false);
//         addAddressData.address_line1 = "";
//         addAddressData.name = "";
//         addAddressData.contact_no = "";
//         addAddressData.address_line2 = "";
//         addAddressData.postal_code = "";
//         addAddressData.state = "";
//         addAddressData.city = "";
//         addAddressData.country = "";
//       }
//     } catch (err) {
//       console.error("Failed to add product to cart:", err);
//       alert(
//         "An error occurred while adding the product to your cart. Please try again."
//       );
//     } finally {
//     }
//   };

//   const handleDeleteAddress = async (addressId: string) => {
//     try {
//       const response = await api.delete(
//         `/api/v1/address/removeAddress?id=${addressId}`
//       );

//       if (response.status === 203) {
//         toast.error("Primary address cannot be removed");
//       }

//       if (response.status === 200) {
//         toast.success("Address removed successfully");
//         fetchData("address");
//         setIsDeleteDailogOpen(false);
//       }
//     } catch (err) {
//       console.error("Failed to delete address", err);
//     } finally {
//     }
//   };

//   const markPrimaryAddress = async (addressId: number) => {
//     try {
//       const response = await api.patch(
//         `/api/v1/address/markPrimaryAddress?id=${addressId}`,
//         {}
//       );

//       if (response.status === 203) {
//         toast.error("Address could not be marked as primary");
//       }

//       if (response.status === 200) {
//         toast.success("Address marked as primary successfully");
//         fetchData("address");
//       }
//     } catch (err) {
//       console.error("Failed to mark as primary address", err);
//     } finally {
//     }
//   };
//   const [isModalOpen, setIsModalOpen] = useState(false);

//   const handleDeleteConfirmed = async () => {
//     setIsModalOpen(false);
//     try {
//       await api.patch("/api/v1/deleteAcc", {});

//       toast.success("Your account has been deleted!", {
//         duration: 2000,
//         position: "top-center",
//         icon: "👤",
//       });

//       setTimeout(() => {
//         toast("We are sorry to see you go!!", {
//           duration: 2000,
//           position: "top-center",
//           icon: "😔",
//         });
//       }, 500);

//       localStorage.clear();
//       router.push("/login");
//       Cookies.remove("token");
//     } catch (err) {
//       console.error("Account deletion error:", err);
//     } finally {
//     }
//   };
//   const deleteAccount = async () => {
//     // First, show confirmation dialog
//     const confirmed = window.confirm(
//       "Are you sure you want to permanently delete your account? This action cannot be undone."
//     );

//     // Only proceed if user confirms
//     if (confirmed) {
//       try {
//         const response = await api.patch("/api/v1/deleteAcc", {});

//         toast("Your account has been deleted!", {
//           duration: 2000,
//           position: "top-center",
//           icon: "👤",
//         });

//         setTimeout(() => {
//           toast("We are sorry to see you go!!", {
//             duration: 2000,
//             position: "top-center",
//             icon: "👤",
//           });
//         }, 500);

//         setTimeout(() => {
//           localStorage.clear();
//           router.push("/login");
//           Cookies.remove("token");
//         }, 200);
//       } catch (err) {
//         if ((err as any).response?.status === 200) {
//           // Success case already handled above
//         } else {
//           console.error(err);
//         }
//       } finally {
//         setTimeout(() => {}, 150);
//       }
//     }
//     // If not confirmed, function simply returns and nothing happens
//   };
//   const [errors, setErrors] = useState({
//     address_line1: "",
//     address_line2: "",
//     name: "",
//     contact_no: "",
//     postal_code: "",
//     state: "",
//     city: "",
//   });

//   const [errorsAdd, setAddErrors] = useState({
//     address_line1: "",
//     address_line2: "",
//     name: "",
//     contact_no: "",
//     postal_code: "",
//     state: "",
//     city: "",
//     country: "",
//   });

//   const handleUpdateAddress = async (addressId: string) => {
//     const newErrors = {
//       address_line1: "",
//       address_line2: "",
//       postal_code: "",
//       city: "",
//       state: "",
//       name: "101",
//       contact_no: "",
//     };

//     // Validate fields
//     if (!selectedAddress?.address_line1)
//       newErrors.address_line1 = "Street Address 1 is required.";
//     if (!selectedAddress?.name) newErrors.name = "Name is required.";
//     if (!selectedAddress?.contact_no)
//       newErrors.contact_no = "Contact number is required.";
//     else if (!/^\d{10}$/.test(selectedAddress.contact_no)) {
//       newErrors.contact_no = "Contact number must be 10 digits.";
//     }
//     if (!selectedAddress?.address_line2)
//       newErrors.address_line2 = "Street Address 2 is required.";
//     if (!selectedAddress?.state) newErrors.state = "Please select a state.";
//     if (!selectedAddress?.city) newErrors.city = "Please select a city";

//     if (!selectedAddress?.postal_code)
//       newErrors.postal_code = "Pincode is required.";
//     else if (selectedAddress.postal_code.length !== 6)
//       newErrors.postal_code = "Pincode must be 6 digits.";

//     setErrors(newErrors);

//     // If there are validation errors, return early and don't proceed with API call
//     if (
//       newErrors.address_line1 ||
//       newErrors.address_line2 ||
//       newErrors.postal_code ||
//       newErrors.city ||
//       newErrors.state ||
//       newErrors.name ||
//       newErrors.contact_no
//     ) {
//       return; // Do not proceed if there are validation errors
//     }

//     newErrors.address_line1 = "";
//     newErrors.name = "";
//     newErrors.address_line2 = "";
//     newErrors.contact_no = "";
//     newErrors.postal_code = "";
//     newErrors.state = "";
//     newErrors.city = "";

//     try {
//       // Call API to update address if no validation errors
//       const response = await api.patch(
//         `/api/v1/address/updateAddress?id=${addressId}`,
//         {
//           address_line1: selectedAddress?.address_line1,
//           contact_no: selectedAddress?.contact_no,
//           name: selectedAddress?.name,
//           address_line2: selectedAddress?.address_line2,
//           city: selectedAddress?.city,
//           state: selectedAddress?.state,
//           country: selectedAddress?.country,
//           postal_code: selectedAddress?.postal_code,
//         }
//       );

//       if (response.status === 200) {
//         const data = response.data as { status: string; message?: string };
//         if (data.status === "Success") {
//           toast.success("Address has been successfully updated!", {
//             duration: 5000,
//             position: "top-center",
//             style: {
//               backgroundColor: "#28a745",
//               color: "#fff",
//               fontSize: "16px",
//             },
//           });

//           fetchData("address");

//           // Close the dialog only after successful update
//           setIsEditDailogOpen(false);
//         } else {
//           console.error(
//             "Failed to update address",
//             data.message || "Unknown error"
//           );
//         }
//       } else {
//         console.error(
//           "Failed to update profile: Request failed with status",
//           response.status
//         );
//       }
//     } catch (error) {
//       console.error("API request failed:", error);
//     }
//   };

//   const handleStateSelect = async (state_id: string) => {
//     if (!state_id || localStorage.getItem("state_id") === state_id) return;

//     localStorage.setItem("state_id", state_id);
//     fetchData("cities");
//   };

//   const [addAddressData, setAddAddressData] = useState({
//     address_line1: "",
//     name: "",
//     address_line2: "",
//     country: "101",
//     contact_no: "",
//     state: "",
//     city: "",
//     postal_code: "",
//   });

//   const handleInputChange = (field: string, value: string) => {
//     setAddAddressData((prev) => ({
//       ...prev,
//       [field]: value,
//     }));
//   };

//   useEffect(() => {
//     setLoadingProduct(true);
//     document.title = "Address";
//     if (!isAuthenticated && !authLoading) {
//       router.push("/login");
//     }

//     setTimeout(() => {
//       setLoadingProduct(false);
//     }, 300);
//     return () => {};
//   }, [authLoading, isAuthenticated, router]);

//   if (!isAuthenticated || authLoading) {
//     return (
//       <div className="w-full h-screen p-6 space-y-6 bg-gray-100">
//         <div className="flex gap-6">
//           {/* Sidebar Skeleton */}
//           <div className="w-1/4 space-y-4">
//             <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
//             <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
//             <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
//             <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
//           </div>

//           {/* Main Content Skeleton */}
//           <div className="flex-1 space-y-6">
//             {/* Search Bar Skeleton */}
//             <div className="h-10 w-2/3 bg-gray-300 animate-pulse rounded-md"></div>

//             {/* Cards Skeleton */}
//             <div className="grid grid-cols-1 gap-6">
//               {[...Array(3)].map((_, index) => (
//                 <div
//                   key={index}
//                   className="h-[100px] bg-gray-300 animate-pulse rounded-md w-full"
//                 ></div>
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div
//       className={`w-[90%] mx-auto flex gap-10 text-sm my-10 ${Style.addressContainer}`}
//     >
//       <div
//         className={`min-w-[250px] border shadow py-4 text-[#6a3a18] h-fit ${Style.addressLeftContainer}`}
//       >
//         <div
//           className={`flex items-center gap-2 px-4 pb-4 border-b ${Style.profileImageAndNameContainer}`}
//         >
//           <Image
//             src={UserImage}
//             width={1000}
//             height={1000}
//             quality={100}
//             alt=""
//             loading="lazy"
//             className="w-[50px] h-[50px] rounded-full"
//           />
//           <div className="flex flex-col">
//             <span className="text-xs">
//               Hello <span className="text-lg">🖐️</span>
//             </span>
//             <span className="font-bold">{profileData?.cust_cmp_name}</span>
//           </div>
//         </div>
//         <div
//           className={`flex flex-col gap-1 py-4 px-2 ${Style.navigateButtons}`}
//         >
//           <Link
//             href={"/profile"}
//             onClick={(e) => {
//               const token = Cookies.get("token");
//               if (!token || isTokenExpired(token)) {
//                 // Check if token is missing or expired
//                 e.preventDefault(); // Prevent navigation
//                 localStorage.setItem(
//                   "redirectAfterLogin",
//                   window.location.href
//                 );
//                 toast("Please log in to view your Profile", {
//                   duration: 3000, // Duration of the toast
//                   position: "top-center", // Position of the toast
//                   icon: "👤", // Icon to show
//                 });
//                 router.push("/login"); // Redirect to login
//               }
//             }}
//           >
//             <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
//               <PiUserLight size={18} />
//               <span>Personal Information</span>
//             </div>
//           </Link>
//           <Link
//             href={"/orders"}
//             onClick={(e) => {
//               const token = Cookies.get("token");
//               if (!token || isTokenExpired(token)) {
//                 // Check if token is missing or expired
//                 e.preventDefault(); // Prevent navigation
//                 localStorage.setItem(
//                   "redirectAfterLogin",
//                   window.location.href
//                 );
//                 toast("Please log in to view your Orders", {
//                   duration: 3000, // Duration of the toast
//                   position: "top-center", // Position of the toast
//                   icon: "📦", // Icon to show
//                 });
//                 router.push("/login"); // Redirect to login
//               }
//             }}
//           >
//             <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
//               <FiPackage size={18} />
//               <span>My Orders</span>
//             </div>
//           </Link>
//           <Link
//             href={"/wishlist"}
//             onClick={(e) => {
//               const token = Cookies.get("token");
//               if (!token || isTokenExpired(token)) {
//                 // Check if token is missing or expired
//                 e.preventDefault(); // Prevent navigation
//                 localStorage.setItem(
//                   "redirectAfterLogin",
//                   window.location.href
//                 );
//                 toast("Please log in to view your Wishlist", {
//                   duration: 3000, // Duration of the toast
//                   position: "top-center", // Position of the toast
//                   icon: "❤️", // Heart emoji
//                 });
//                 router.push("/login"); // Redirect to login
//               }
//             }}
//           >
//             <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
//               <GoHeart size={18} />
//               <span>My Wishlists</span>
//             </div>
//           </Link>
//           <Link href={"/address"}>
//             <div className="flex items-center gap-3 py-2 px-2 cursor-pointer bg-[#6a3a18] text-white rounded-sm">
//               <GoLocation size={18} />
//               <span>Manage Addresses</span>
//             </div>
//           </Link>
//           <div
//             onClick={() => setIsModalOpen(true)}
//             className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
//           >
//             <GoTrash size={18} />
//             <span>Delete My Account</span>
//           </div>
//           <ConfirmModal
//             isOpen={isModalOpen}
//             onConfirm={handleDeleteConfirmed}
//             onCancel={() => setIsModalOpen(false)}
//           />
//           {/* <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
//             <MdOutlineContactSupport size={18} />
//             <span>Support</span>
//           </div> */}
//           <div
//             onClick={() => {
//               localStorage.removeItem("token");
//               localStorage.removeItem("redirectAfterLogin");
//               router.push("/login");
//             }}
//             className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
//           >
//             <BiLogOut size={18} />
//             <span>Logout</span>
//           </div>
//         </div>
//       </div>
//       <div className={`w-full ${Style.addressRightContainer}`}>
//         {loadingProduct ? (
//           // Skeleton loader using TailwindCSS
//           <div className="grid grid-cols-1 gap-6">
//             {[...Array(3)].map((_, index) => (
//               <div
//                 key={index}
//                 className="h-[100px] bg-gray-300 animate-pulse rounded-md w-full"
//               ></div>
//             ))}
//           </div>
//         ) : (
//           <div className="w-full flex gap-4 flex-col">
//             {addressList && addressList.length > 0 ? (
//               (addressList as unknown as Address[]).map((address, index) => (
//                 <div
//                   key={index}
//                   className="w-full flex gap-10 pb-4 border-b address-card border p-3 h-[107.9px] rounded-lg shadow"
//                 >
//                   <div className="w-full flex flex-col gap-2 justify-between">
//                     <div className="flex gap-2">
//                       <input
//                         type="radio"
//                         name="address"
//                         checked={address.primary_address} // Ensure only the primary address is checked
//                         onChange={() => markPrimaryAddress(address.id)} // Handle primary selection
//                       />
//                       <span>{address.name}</span>
//                       {address.primary_address && (
//                         <span
//                           className="text-gray-400"
//                           style={{ fontSize: "12px" }}
//                         >
//                           Primary Address
//                         </span> // Smaller and lighter text
//                       )}
//                     </div>

//                     <span>
//                       {`${address.address_line1}, ${address.address_line2}, ${address.City.city_name}, ${address.State.state_name}, ${address.Country.country_name} - ${address.postal_code}`}
//                     </span>
//                     <span>+91 {address.contact_no}</span>
//                   </div>
//                   <div className="flex flex-col gap-2">
//                     <Dialog
//                       open={isEditDailogOpen} // Open dialog based on the state
//                       onOpenChange={(open) => {
//                         // Handle the dialog open/close state change
//                         setIsEditDailogOpen(open);
//                       }}
//                     >
//                       <DialogTrigger asChild>
//                         <div className="flex justify-end">
//                           <Button
//                             className="bg-[#6a3a18] w-[100px]"
//                             onClick={() => {
//                               setSelectedAddress(address); // Set the selected address
//                               setIsEditDailogOpen(true); // Open dialog
//                               handleCountrySelect(address.country);
//                               handleStateSelect(address.state);
//                             }}
//                           >
//                             <FaRegEdit />
//                             Edit
//                           </Button>
//                         </div>
//                       </DialogTrigger>

//                       <DialogContent className="w-[400px] h-[80%] px-8 overflow-auto rounded-lg">
//                         <div className="text-sm flex flex-col gap-4">
//                           <div>
//                             <DialogTitle>
//                               <span className="font-bold text-lg">
//                                 Edit Address
//                               </span>
//                             </DialogTitle>
//                           </div>
//                           {selectedAddress && (
//                             <>
//                               <div className="flex flex-col gap-1">
//                                 <span>Name *</span>
//                                 <Input
//                                   type="text"
//                                   placeholder="Enter Name"
//                                   value={selectedAddress.name}
//                                   onChange={(e) => {
//                                     setSelectedAddress((prev) => ({
//                                       ...prev!,
//                                       name: e.target.value,
//                                     }));
//                                   }}
//                                 />
//                                 {errors.name && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.name}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>Street Address *</span>
//                                 <Input
//                                   type="text"
//                                   placeholder="Enter street address 2"
//                                   value={selectedAddress.address_line1}
//                                   onChange={(e) => {
//                                     setSelectedAddress((prev) => ({
//                                       ...prev!,
//                                       address_line1: e.target.value,
//                                     }));
//                                   }}
//                                 />
//                                 {errors.address_line1 && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.address_line1}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>Street Address 2 *</span>
//                                 <Input
//                                   type="text"
//                                   value={selectedAddress.address_line2}
//                                   placeholder="Enter street address 2"
//                                   onChange={(e) => {
//                                     setSelectedAddress((prev) => ({
//                                       ...prev!,
//                                       address_line2: e.target.value,
//                                     }));
//                                   }}
//                                 />
//                                 {errors.address_line2 && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.address_line2}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>Contact Number *</span>
//                                 <Input
//                                   type="tel"
//                                   value={selectedAddress.contact_no}
//                                   placeholder="Enter phone number"
//                                   onChange={(e) => {
//                                     setSelectedAddress((prev) => ({
//                                       ...prev!,
//                                       contact_no: e.target.value,
//                                     }));
//                                   }}
//                                 />
//                                 {errors.contact_no && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.contact_no}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>Country *</span>

//                                 <div className="relative">
//                                   {isEditingCEdit ? (
//                                     <input
//                                       autoFocus
//                                       className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
//                                       placeholder="Search countries..."
//                                       onBlur={() => setIsEditingCEdit(false)}
//                                       onChange={(e) => {
//                                         const searchInput =
//                                           e.target.value.toLowerCase();
//                                         setFilteredCountriesEdit(
//                                           countryList.filter((country) =>
//                                             country.country_name
//                                               .toLowerCase()
//                                               .includes(searchInput)
//                                           )
//                                         );
//                                       }}
//                                     />
//                                   ) : (
//                                     <div
//                                       className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
//                                       onClick={() => setIsEditingCEdit(true)}
//                                     >
//                                       {selectedAddress?.country
//                                         ? countryList.find(
//                                             (c) =>
//                                               c.id === selectedAddress.country
//                                           )?.country_name || "Select a Country"
//                                         : "Select a Country"}
//                                     </div>
//                                   )}

//                                   {isEditingCEdit && (
//                                     <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
//                                       {filteredCountriesEdit.map((country) => (
//                                         <div
//                                           key={country.id}
//                                           className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
//                                           onMouseDown={() => {
//                                             handleCountrySelect(country.id);
//                                             setSelectedAddress((prev) => ({
//                                               ...prev!,
//                                               country: country.id,
//                                               state: "",
//                                               city: "",
//                                             }));
//                                             setIsEditingCEdit(false);
//                                           }}
//                                         >
//                                           {country.country_name}
//                                         </div>
//                                       ))}
//                                     </div>
//                                   )}
//                                 </div>
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>State *</span>

//                                 <div className="relative">
//                                   {isEditingSEdit ? (
//                                     <input
//                                       autoFocus
//                                       className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
//                                       placeholder="Search states..."
//                                       onBlur={() => setIsEditingSEdit(false)}
//                                       onChange={(e) => {
//                                         const searchInput =
//                                           e.target.value.toLowerCase();
//                                         setFilteredStatesEdit(
//                                           stateList.filter((state) =>
//                                             state.state_name
//                                               .toLowerCase()
//                                               .includes(searchInput)
//                                           )
//                                         );
//                                       }}
//                                     />
//                                   ) : (
//                                     <div
//                                       className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
//                                       onClick={() => setIsEditingSEdit(true)}
//                                     >
//                                       {selectedAddress?.state
//                                         ? stateList.find(
//                                             (s) =>
//                                               s.id === selectedAddress.state
//                                           )?.state_name || "Select a State"
//                                         : "Select a State"}
//                                     </div>
//                                   )}

//                                   {isEditingSEdit && (
//                                     <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
//                                       {filteredStatesEdit.map((state) => (
//                                         <div
//                                           key={state.id}
//                                           className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
//                                           onMouseDown={() => {
//                                             handleStateSelect(state.id);
//                                             setSelectedAddress((prev) => ({
//                                               ...prev!,
//                                               state: state.id,
//                                               city: "",
//                                             }));
//                                             setIsEditingSEdit(false);
//                                           }}
//                                         >
//                                           {state.state_name}
//                                         </div>
//                                       ))}
//                                     </div>
//                                   )}
//                                 </div>

//                                 {errors?.state && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.state}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>City *</span>

//                                 <div className="relative">
//                                   {isEditingCiEdit ? (
//                                     <input
//                                       autoFocus
//                                       className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
//                                       placeholder="Search cities..."
//                                       onBlur={() => setIsEditingCiEdit(false)}
//                                       onChange={(e) => {
//                                         const searchInput =
//                                           e.target.value.toLowerCase();
//                                         setFilteredCitiesEdit(
//                                           cityList.filter((city) =>
//                                             city.city_name
//                                               .toLowerCase()
//                                               .includes(searchInput)
//                                           )
//                                         );
//                                       }}
//                                     />
//                                   ) : (
//                                     <div
//                                       className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
//                                       onClick={() => setIsEditingCiEdit(true)}
//                                     >
//                                       {selectedAddress?.city
//                                         ? cityList.find(
//                                             (c) => c.id === selectedAddress.city
//                                           )?.city_name || "Select a City"
//                                         : "Select a City"}
//                                     </div>
//                                   )}

//                                   {isEditingCiEdit && (
//                                     <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
//                                       {filteredCitiesEdit.map((city) => (
//                                         <div
//                                           key={city.id}
//                                           className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
//                                           onMouseDown={() => {
//                                             setSelectedAddress((prev) => ({
//                                               ...prev!,
//                                               city: city.id,
//                                             }));
//                                             setIsEditingCiEdit(false);
//                                           }}
//                                         >
//                                           {city.city_name}
//                                         </div>
//                                       ))}
//                                     </div>
//                                   )}
//                                 </div>

//                                 {errors?.city && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.city}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex flex-col gap-1">
//                                 <span>Pincode</span>
//                                 <Input
//                                   type="text"
//                                   placeholder="Enter your pincode"
//                                   value={selectedAddress.postal_code}
//                                   onChange={(e) => {
//                                     setSelectedAddress((prev) => ({
//                                       ...prev!,
//                                       postal_code: e.target.value,
//                                     }));
//                                   }}
//                                 />
//                                 {errors.postal_code && (
//                                   <span className="text-red-500 text-xs">
//                                     {errors.postal_code}
//                                   </span>
//                                 )}
//                               </div>
//                               <div className="flex justify-end mt-4">
//                                 <Button
//                                   className="bg-[#6a3a18] w-[90px] hover:bg-[#6a3a18]"
//                                   onClick={() => {
//                                     handleUpdateAddress(
//                                       selectedAddress.id.toString()
//                                     );
//                                     // Validate before proceeding
//                                   }}
//                                 >
//                                   Save
//                                 </Button>
//                               </div>
//                             </>
//                           )}
//                         </div>
//                       </DialogContent>
//                     </Dialog>

//                     <Dialog
//                       open={isDeleteDailogOpen}
//                       onOpenChange={setIsDeleteDailogOpen}
//                     >
//                       <DialogTrigger asChild>
//                         {!address.primary_address && ( // Only render the button if primary_address is false
//                           <div className="flex justify-end">
//                             <Button
//                               onMouseEnter={() => setSelectedAddress(address)}
//                               className="bg-[#f0ebe8] w-[100px] text-[#6a3a18]"
//                               onClick={() => {
//                                 setSelectedAddress(address); // Set the selected address
//                                 setIsDeleteDailogOpen(true); // Open dialog
//                               }}
//                             >
//                               <MdOutlineDelete /> Delete
//                             </Button>
//                           </div>
//                         )}
//                       </DialogTrigger>
//                       <DialogContent className="w-auto py-8 px-12 overflow-auto">
//                         <div className="text-sm">
//                           <DialogTitle>
//                             <span>
//                               Do you really want to remove this address?
//                             </span>
//                           </DialogTitle>
//                           <div className="mt-4 flex justify-center gap-4">
//                             <Button
//                               onClick={() => {
//                                 if (selectedAddress) {
//                                   handleDeleteAddress(
//                                     selectedAddress.id.toString()
//                                   );
//                                 }
//                               }}
//                             >
//                               Yes
//                             </Button>
//                             <Button
//                               className="bg-red-600 hover:bg-red-500"
//                               onClick={() => setIsDeleteDailogOpen(false)}
//                             >
//                               No
//                             </Button>
//                           </div>
//                         </div>
//                       </DialogContent>
//                     </Dialog>
//                   </div>
//                 </div>
//               ))
//             ) : (
//               <div className="flex mx-auto flex-col items-center justify-center h-[300px] text-gray-500">
//                 <MapPin size={50} className="text-gray-400 mb-3" />{" "}
//                 {/* Address Icon */}
//                 <span className="text-lg font-semibold">
//                   No saved addresses
//                 </span>
//                 <p className="text-sm text-gray-400">
//                   You haven&apos;t added any addresses yet.
//                 </p>
//               </div>
//             )}

//             {/* Add New Address */}
//             <Dialog
//               open={isAddDailogOpen} // Open dialog based on the state
//               onOpenChange={(open) => {
//                 // Handle the dialog open/close state change
//                 setIsAddDailogOpen(open);
//               }}
//             >
//               <DialogTrigger asChild>
//                 <div className="flex justify-end">
//                   <Button
//                     onClick={() => {
//                       setIsAddDailogOpen(true); // Open dialog
//                     }}
//                     className="bg-[#6a3a18]"
//                   >
//                     + Add New Address
//                   </Button>
//                 </div>
//               </DialogTrigger>
//               <DialogContent className="w-[400px] h-[80%] px-8 overflow-auto rounded-lg">
//                 <div className="text-sm flex flex-col gap-4">
//                   <div>
//                     <DialogTitle>
//                       <span className="font-bold text-lg">Add Address</span>
//                     </DialogTitle>
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>Name *</span>
//                     <Input
//                       type="text"
//                       placeholder="Enter Name"
//                       value={addAddressData.name}
//                       onChange={(e) =>
//                         handleInputChange("name", e.target.value)
//                       }
//                     />
//                     {errorsAdd.name && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.name}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>Street Address *</span>
//                     <Input
//                       type="text"
//                       placeholder="Enter Street Address 1"
//                       value={addAddressData.address_line1}
//                       onChange={(e) =>
//                         handleInputChange("address_line1", e.target.value)
//                       }
//                     />
//                     {errorsAdd.address_line1 && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.address_line1}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>Street Address 2 *</span>
//                     <Input
//                       type="text"
//                       placeholder="Enter Street Address 2"
//                       value={addAddressData.address_line2}
//                       onChange={(e) =>
//                         handleInputChange("address_line2", e.target.value)
//                       }
//                     />
//                     {errorsAdd.address_line2 && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.address_line2}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>Contact Number *</span>
//                     <Input
//                       type="tel"
//                       placeholder="Enter phone number"
//                       value={addAddressData.contact_no}
//                       onChange={(e) =>
//                         handleInputChange("contact_no", e.target.value)
//                       }
//                     />
//                     {errorsAdd.contact_no && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.contact_no}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>Country *</span>

//                     <div className="relative">
//                       {isEditingC ? (
//                         <input
//                           autoFocus
//                           className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
//                           placeholder="Search countries..."
//                           onBlur={() => setIsEditingC(false)}
//                           onChange={(e) => {
//                             const searchInput = e.target.value.toLowerCase();
//                             setFilteredCountries(
//                               countryList.filter((country) =>
//                                 country.country_name
//                                   .toLowerCase()
//                                   .includes(searchInput)
//                               )
//                             );
//                           }}
//                         />
//                       ) : (
//                         <div
//                           className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
//                           onClick={() => setIsEditingC(true)}
//                         >
//                           {addAddressData.country
//                             ? countryList.find(
//                                 (c) => c.id === addAddressData.country
//                               )?.country_name || "Select a Country"
//                             : "Select a Country"}
//                         </div>
//                       )}

//                       {isEditingC && (
//                         <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
//                           {filteredCountries.map((country) => (
//                             <div
//                               key={country.id}
//                               className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
//                               onMouseDown={() => {
//                                 handleInputChange("country", country.id);
//                                 handleCountrySelect(country.id);
//                                 setIsEditingC(false);
//                               }}
//                             >
//                               {country.country_name}
//                             </div>
//                           ))}
//                         </div>
//                       )}
//                     </div>

//                     {errorsAdd.country && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.country}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>State *</span>

//                     <div className="relative">
//                       {isEditingS ? (
//                         <input
//                           autoFocus
//                           className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
//                           placeholder="Search states..."
//                           onBlur={() => setIsEditingS(false)}
//                           onChange={(e) => {
//                             const searchInput = e.target.value.toLowerCase();
//                             setFilteredStates(
//                               stateList.filter((state) =>
//                                 state.state_name
//                                   .toLowerCase()
//                                   .includes(searchInput)
//                               )
//                             );
//                           }}
//                         />
//                       ) : (
//                         <div
//                           className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
//                           onClick={() => setIsEditingS(true)}
//                         >
//                           {addAddressData.state
//                             ? stateList.find(
//                                 (s) => s.id === addAddressData.state
//                               )?.state_name || "Select a State"
//                             : "Select a State"}
//                         </div>
//                       )}

//                       {isEditingS && (
//                         <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
//                           {filteredStates.map((state) => (
//                             <div
//                               key={state.id}
//                               className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
//                               onMouseDown={() => {
//                                 handleInputChange("state", state.id);
//                                 handleStateSelect(state.id);
//                                 setIsEditingS(false);
//                               }}
//                             >
//                               {state.state_name}
//                             </div>
//                           ))}
//                         </div>
//                       )}
//                     </div>

//                     {errorsAdd.state && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.state}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>City *</span>

//                     <div className="relative">
//                       {isEditingCi ? (
//                         <input
//                           autoFocus
//                           className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
//                           placeholder="Search cities..."
//                           onBlur={() => setIsEditingCi(false)}
//                           onChange={(e) => {
//                             const searchInput = e.target.value.toLowerCase();
//                             setFilteredCities(
//                               cityList.filter((city) =>
//                                 city.city_name
//                                   .toLowerCase()
//                                   .includes(searchInput)
//                               )
//                             );
//                           }}
//                         />
//                       ) : (
//                         <div
//                           className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
//                           onClick={() => setIsEditingCi(true)}
//                         >
//                           {addAddressData.city
//                             ? cityList.find((c) => c.id === addAddressData.city)
//                                 ?.city_name || "Select a City"
//                             : "Select a City"}
//                         </div>
//                       )}

//                       {isEditingCi && (
//                         <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
//                           {filteredCities.map((city) => (
//                             <div
//                               key={city.id}
//                               className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
//                               onMouseDown={() => {
//                                 handleInputChange("city", city.id);
//                                 setIsEditingCi(false);
//                               }}
//                             >
//                               {city.city_name}
//                             </div>
//                           ))}
//                         </div>
//                       )}
//                     </div>

//                     {errorsAdd.city && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.city}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex flex-col gap-1">
//                     <span>Pincode *</span>
//                     <Input
//                       type="text"
//                       placeholder="Enter your pincode"
//                       value={addAddressData.postal_code}
//                       onChange={(e) =>
//                         handleInputChange(
//                           "postal_code",
//                           e.target.value.slice(0, 6)
//                         )
//                       }
//                     />
//                     {errorsAdd.postal_code && (
//                       <span className="text-red-500 text-xs">
//                         {errorsAdd.postal_code}
//                       </span>
//                     )}
//                   </div>
//                   <div className="flex justify-end mt-4">
//                     <Button
//                       className="bg-[#6a3a18] w-[90px] hover:bg-[#6a3a18]"
//                       onClick={() => handleAddAddress()}
//                     >
//                       Save
//                     </Button>
//                   </div>
//                 </div>
//               </DialogContent>
//             </Dialog>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

"use client";
import Image from "next/image";
import UserImage from "../../../../public/assets/user/boy.png";
import { PiUserLight } from "react-icons/pi";
import { FiPackage } from "react-icons/fi";
import { useEffect, useState } from "react";
import { GoHeart, GoPasskeyFill } from "react-icons/go";
import { useGlobalState } from "@/context/GlobalStateContext";
import { GoLocation, GoTrash } from "react-icons/go";
import { MdOutlineContactSupport } from "react-icons/md";
import { BiLogOut } from "react-icons/bi";
import { FaRegEdit } from "react-icons/fa";
import { MapPin } from "lucide-react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { MdOutlineDelete } from "react-icons/md";
import { api } from "../../../../utils/api";
import Style from "../styles/address.module.scss";
import { Input } from "@/components/ui/input";
import ConfirmModal from "@/components/user/confirmModal";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import Cookies from "js-cookie";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import useAuth from "@/hooks/useAuth";
import React from "react";

// Define the Address type
interface Address {
  X: number;
  id: number;
  name: string;
  cust_cmp_name: string;
  address_line1: string;
  address_line2: string;
  city: string;
  postal_code: string;
  state: string;
  country: string;
  primary_address: boolean;
  contact_no: string;
  City: {
    id: number;
    city_name: string;
    state_id: string;
  };
  State: {
    id: number;
    state_name: string;
    country_id: string;
  };
  Country: {
    id: number;
    country_name: string;
    phonecode: string;
    sortname: string;
  };
}

// Define State type for clarity
interface State {
  id: string;
  state_name: string;
  country_id: string;
}

export default function Profile() {
  const {
    fetchData,
    addressList,
    countryList,
    stateList,
    cityList,
    isTokenExpired,
    profileData,
  } = useGlobalState();
  const [isDeleteDailogOpen, setIsDeleteDailogOpen] = useState(false);
  const [isEditDailogOpen, setIsEditDailogOpen] = useState(false);
  const [isAddDailogOpen, setIsAddDailogOpen] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);
  const router = useRouter();
  const [loadingProduct, setLoadingProduct] = useState<boolean>(true);
  const { isAuthenticated, loading: authLoading } = useAuth();

  const [filteredStates, setFilteredStates] = useState<State[]>([]);
  const [isEditingS, setIsEditingS] = useState(false);
  const [filteredCities, setFilteredCities] = useState(cityList);
  const [isEditingCi, setIsEditingCi] = useState(false);
  const [filteredStatesEdit, setFilteredStatesEdit] = useState<State[]>([]);
  const [isEditingSEdit, setIsEditingSEdit] = useState(false);
  const [filteredCitiesEdit, setFilteredCitiesEdit] = useState(cityList);
  const [isEditingCiEdit, setIsEditingCiEdit] = useState(false);

  // const handleCountrySelect = async (country_id: string) => {
  //   console.log(`handleCountrySelect called with country_id: ${country_id}`);
  //   try {
  //     const response = await api.get(
  //       `/api/v1/stateData?country_id=${country_id}`
  //     );
  //     console.log("State API response:", response.data);
  //     if (response.status === 200) {
  //       const states =
  //         response.data.data || response.data.states || response.data || [];
  //       console.log("Parsed states:", states);
  //       const filtered = states.filter(
  //         (state: State) => state.country_id === country_id
  //       );
  //       setFilteredStates(filtered);
  //       setFilteredStatesEdit(filtered);
  //       if (filtered.length === 0) {
  //         toast.warning("No states found for India.");
  //       }
  //     } else {
  //       throw new Error(`API returned status: ${response.status}`);
  //     }
  //   } catch (err) {
  //     console.error("Failed to fetch states:", err);
  //     toast.error("Failed to load states. Please try again.");
  //     setFilteredStates([]);
  //     setFilteredStatesEdit([]);
  //   }
  // };

  const handleCountrySelect = async (country_id: string) => {
    console.log(`handleCountrySelect called with country_id: ${country_id}`);
    try {
      // Define the expected response type
      interface State {
        id: string;
        state_name: string;
        country_id: string;
      }
  
      interface StateResponse {
        status: string;
        statusCode: number;
        message: string;
        data: State[];
      }
  
      // Ensure the API response is typed
      const response = await api.get<StateResponse>(
        `/api/v1/stateData?country_id=${country_id}`
      );
  
      console.log("State API response:", response.data);
      if (response.status === 200) {
        // Access the states directly from response.data.data
        const states = response.data?.data || [];
        console.log("Parsed states:", states);
        const filtered = states.filter(
          (state: State) => state.country_id === country_id
        );
        setFilteredStates(filtered);
        setFilteredStatesEdit(filtered);
        if (filtered.length === 0) {
          toast.warning("No states found for India.");
        }
      } else {
        throw new Error(`API returned status: ${response.status}`);
      }
    } catch (err) {
      console.error("Failed to fetch states:", err);
      toast.error("Failed to load states. Please try again.");
      setFilteredStates([]);
      setFilteredStatesEdit([]);
    }
  };

  const handleAddAddress = async () => {
    const newErrors = {
      address_line1: "",
      address_line2: "",
      postal_code: "",
      city: "",
      state: "",
      country: "",
      name: "",
      contact_no: "",
    };

    if (!addAddressData?.address_line1)
      newErrors.address_line1 = "Street Address 1 is required.";
    if (!addAddressData?.name) newErrors.name = "Name is required";
    if (!addAddressData?.contact_no) {
      newErrors.contact_no = "Contact number is required.";
    } else if (!/^\d{10}$/.test(addAddressData.contact_no)) {
      newErrors.contact_no = "Contact number must be 10 digits.";
    }
    if (!addAddressData?.address_line2)
      newErrors.address_line2 = "Street Address 2 is required.";
    if (!addAddressData?.state) newErrors.state = "Please select a state.";
    if (!addAddressData?.city) newErrors.city = "Please select a city";
    if (!addAddressData?.country) newErrors.country = "Country is required.";

    if (!addAddressData?.postal_code)
      newErrors.postal_code = "Pincode is required.";
    else if (addAddressData.postal_code.length !== 6)
      newErrors.postal_code = "Pincode must be 6 digits.";

    setAddErrors(newErrors);

    if (
      newErrors.address_line1 ||
      newErrors.address_line2 ||
      newErrors.postal_code ||
      newErrors.city ||
      newErrors.state ||
      newErrors.name ||
      newErrors.contact_no ||
      newErrors.country
    ) {
      return;
    }

    try {
      const response = await api.post("/api/v1/address/addAddress", {
        address_line1: addAddressData.address_line1,
        contact_no: addAddressData.contact_no,
        address_line2: addAddressData.address_line2,
        name: addAddressData.name,
        state: addAddressData.state,
        country: addAddressData.country,
        city: addAddressData.city,
        postal_code: addAddressData.postal_code,
      });

      if (response.status === 200) {
        toast.success("Address added successfully");
        fetchData("address");
        setIsAddDailogOpen(false);
        setAddAddressData({
          address_line1: "",
          name: "",
          contact_no: "",
          address_line2: "",
          postal_code: "",
          state: "",
          city: "",
          country: "101",
        });
      }
    } catch (err) {
      console.error("Failed to add address:", err);
      alert("An error occurred while adding the address. Please try again.");
    }
  };

  const handleDeleteAddress = async (addressId: string) => {
    try {
      const response = await api.delete(
        `/api/v1/address/removeAddress?id=${addressId}`
      );

      if (response.status === 203) {
        toast.error("Primary address cannot be removed");
      }

      if (response.status === 200) {
        toast.success("Address removed successfully");
        fetchData("address");
        setIsDeleteDailogOpen(false);
      }
    } catch (err) {
      console.error("Failed to delete address", err);
    }
  };

  const markPrimaryAddress = async (addressId: number) => {
    try {
      const response = await api.patch(
        `/api/v1/address/markPrimaryAddress?id=${addressId}`,
        {}
      );

      if (response.status === 203) {
        toast.error("Address could not be marked as primary");
      }

      if (response.status === 200) {
        toast.success("Address marked as primary successfully");
        fetchData("address");
      }
    } catch (err) {
      console.error("Failed to mark as primary address", err);
    }
  };

  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDeleteConfirmed = async () => {
    setIsModalOpen(false);
    try {
      await api.patch("/api/v1/deleteAcc", {});

      toast.success("Your account has been deleted!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });

      setTimeout(() => {
        toast("We are sorry to see you go!!", {
          duration: 2000,
          position: "top-center",
          icon: "😔",
        });
      }, 500);

      localStorage.clear();
      router.push("/login");
      Cookies.remove("token");
    } catch (err) {
      console.error("Account deletion error:", err);
    }
  };

  const deleteAccount = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to permanently delete your account? This action cannot be undone."
    );

    if (confirmed) {
      try {
        await api.patch("/api/v1/deleteAcc", {});

        toast("Your account has been deleted!", {
          duration: 2000,
          position: "top-center",
          icon: "👤",
        });

        setTimeout(() => {
          toast("We are sorry to see you go!!", {
            duration: 2000,
            position: "top-center",
            icon: "👤",
          });
        }, 500);

        setTimeout(() => {
          localStorage.clear();
          router.push("/login");
          Cookies.remove("token");
        }, 200);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const [errors, setErrors] = useState({
    address_line1: "",
    address_line2: "",
    name: "",
    contact_no: "",
    postal_code: "",
    state: "",
    city: "",
  });

  const [errorsAdd, setAddErrors] = useState({
    address_line1: "",
    address_line2: "",
    name: "",
    contact_no: "",
    postal_code: "",
    state: "",
    city: "",
    country: "",
  });

  const handleUpdateAddress = async (addressId: string) => {
    const newErrors = {
      address_line1: "",
      address_line2: "",
      postal_code: "",
      city: "",
      state: "",
      name: "",
      contact_no: "",
    };

    if (!selectedAddress?.address_line1)
      newErrors.address_line1 = "Street Address 1 is required.";
    if (!selectedAddress?.name) newErrors.name = "Name is required.";
    if (!selectedAddress?.contact_no)
      newErrors.contact_no = "Contact number is required.";
    else if (!/^\d{10}$/.test(selectedAddress.contact_no)) {
      newErrors.contact_no = "Contact number must be 10 digits.";
    }
    if (!selectedAddress?.address_line2)
      newErrors.address_line2 = "Street Address 2 is required.";
    if (!selectedAddress?.state) newErrors.state = "Please select a state.";
    if (!selectedAddress?.city) newErrors.city = "Please select a city";

    if (!selectedAddress?.postal_code)
      newErrors.postal_code = "Pincode is required.";
    else if (selectedAddress.postal_code.length !== 6)
      newErrors.postal_code = "Pincode must be 6 digits.";

    setErrors(newErrors);

    if (
      newErrors.address_line1 ||
      newErrors.address_line2 ||
      newErrors.postal_code ||
      newErrors.city ||
      newErrors.state ||
      newErrors.name ||
      newErrors.contact_no
    ) {
      return;
    }

    try {
      const response = await api.patch(
        `/api/v1/address/updateAddress?id=${addressId}`,
        {
          address_line1: selectedAddress?.address_line1,
          contact_no: selectedAddress?.contact_no,
          name: selectedAddress?.name,
          address_line2: selectedAddress?.address_line2,
          city: selectedAddress?.city,
          state: selectedAddress?.state,
          country: selectedAddress?.country,
          postal_code: selectedAddress?.postal_code,
        }
      );

      if (response.status === 200) {
        const data = response.data as { status: string; message?: string };
        if (data.status === "Success") {
          toast.success("Address has been successfully updated!", {
            duration: 5000,
            position: "top-center",
            style: {
              backgroundColor: "#28a745",
              color: "#fff",
              fontSize: "16px",
            },
          });

          fetchData("address");
          setIsEditDailogOpen(false);
        } else {
          console.error(
            "Failed to update address",
            data.message || "Unknown error"
          );
        }
      } else {
        console.error(
          "Failed to update profile: Request failed with status",
          response.status
        );
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  const handleStateSelect = async (state_id: string) => {
    if (!state_id || localStorage.getItem("state_id") === state_id) return;

    localStorage.setItem("state_id", state_id);
    try {
      await fetchData("cities");
      setFilteredCities(cityList.filter((city) => city.state_id === state_id));
    } catch (err) {
      console.error("Failed to fetch cities:", err);
      toast.error("Failed to load cities. Please try again.");
    }
  };

  const [addAddressData, setAddAddressData] = useState({
    address_line1: "",
    name: "",
    address_line2: "",
    country: "101",
    contact_no: "",
    state: "",
    city: "",
    postal_code: "",
  });

  const handleInputChange = (field: string, value: string) => {
    setAddAddressData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  useEffect(() => {
    setLoadingProduct(true);
    document.title = "Address";
    if (!isAuthenticated && !authLoading) {
      console.log('not logged in.. redirecting to login');
      toast("Please log in to view your Address")
      router.push("/login");
    }
    fetchData("address");
    handleCountrySelect("101");

    setTimeout(() => {
      setLoadingProduct(false);
    }, 0);
    return () => {};
  }, [authLoading, isAuthenticated, router]);

  // if (!isAuthenticated || authLoading) {
  //   return (
  //     <div className="w-full h-screen p-6 space-y-6 bg-gray-100">
  //       <div className="flex gap-6">
  //         <div className="w-1/4 space-y-4">
  //           <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
  //           <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
  //           <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
  //           <div className="h-10 bg-gray-300 animate-pulse rounded-md"></div>
  //         </div>
  //         <div className="flex-1 space-y-6">
  //           <div className="h-10 w-2/3 bg-gray-300 animate-pulse rounded-md"></div>
  //           <div className="grid grid-cols-1 gap-6">
  //             {[...Array(3)].map((_, index) => (
  //               <div
  //                 key={index}
  //                 className="h-[100px] bg-gray-300 animate-pulse rounded-md w-full"
  //               ></div>
  //             ))}
  //           </div>
  //         </div>
  //       </div>
  //     </div>
  //   );
  // }

  return (
    <div
      className={`w-[90%] mx-auto flex gap-10 text-sm my-10 ${Style.addressContainer}`}
    >
      <div
        className={`min-w-[250px] border shadow py-4 text-[#6a3a18] h-fit ${Style.addressLeftContainer}`}
      >
        <div
          className={`flex items-center gap-2 px-4 pb-4 border-b ${Style.profileImageAndNameContainer}`}
        >
          <Image
            src={UserImage}
            width={1000}
            height={1000}
            quality={100}
            alt=""
            loading="lazy"
            className="w-[50px] h-[50px] rounded-full"
          />
          <div className="flex flex-col">
            <span className="text-xs">
              Hello <span className="text-lg">🖐️</span>
            </span>
            <span className="font-bold">{profileData?.cust_cmp_name}</span>
          </div>
        </div>
        <div
          className={`flex flex-col gap-1 py-4 px-2 ${Style.navigateButtons}`}
        >
          <Link
            href={"/profile"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Profile", {
                  duration: 3000,
                  position: "top-center",
                  icon: "👤",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <PiUserLight size={18} />
              <span>Personal Information</span>
            </div>
          </Link>
          <Link
            href={"/orders"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Orders", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📦",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <FiPackage size={18} />
              <span>My Orders</span>
            </div>
          </Link>
          <Link
            href={"/wishlist"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Wishlist", {
                  duration: 3000,
                  position: "top-center",
                  icon: "❤️",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoHeart size={18} />
              <span>My Wishlists</span>
            </div>
          </Link>
          <Link href={"/address"}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer bg-[#6a3a18] text-white rounded-sm">
              <GoLocation size={18} />
              <span>Manage Addresses</span>
            </div>
          </Link>
          <Link
            href={"/passwordChange"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoPasskeyFill size={18} />
              <span>Password Change</span>
            </div>
          </Link>
          <div
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <GoTrash size={18} />
            <span>Delete My Account</span>
          </div>
          <ConfirmModal
            isOpen={isModalOpen}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => setIsModalOpen(false)}
          />
          <div
            onClick={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("redirectAfterLogin");
              router.push("/login");
            }}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <BiLogOut size={18} />
            <span>Logout</span>
          </div>
        </div>
      </div>
      <div className={`w-full ${Style.addressRightContainer}`}>
        {loadingProduct ? (
         <div className="grid grid-cols-1 gap-6">
         {[...Array(3)].map((_, index) => (
           <div
             key={index}
             className="relative h-[100px] bg-gray-300 animate-pulse rounded-md w-full p-4 flex flex-col justify-center space-y-2"
           >
             {/* Wider Button skeleton in top-right corner */}
             <div className="absolute top-2 right-2 h-6 w-16 bg-gray-400 rounded-md"></div>
       
             {/* Text skeletons */}
             <div className="h-4 bg-gray-400 rounded w-3/4"></div>
             <div className="h-4 bg-gray-400 rounded w-1/2"></div>
             <div className="h-3 bg-gray-400 rounded w-1/4"></div>
           </div>
         ))}
       
         {/* Button skeleton below third card, right-aligned */}
         <div className="flex justify-end">
           <div className="h-10 w-32 bg-gray-400 animate-pulse rounded-md"></div>
         </div>
       </div>
       
        ) : (
          <div className="w-full flex gap-4 flex-col">
            {addressList && addressList.length > 0 ? (
              (addressList as unknown as Address[]).map((address, index) => (
                <div
                  key={index}
                  className="w-full flex gap-10 pb-4 border-b address-card border p-3 h-auto rounded-lg shadow"
                >
                  <div className="w-full flex flex-col gap-2 justify-between">
                    <div className="flex gap-2 sm:flex-row flex-col items-start">
                      <div className="flex gap-2">

                      <input
                        type="radio"
                        name="address"
                        checked={address.primary_address}
                        onChange={() => markPrimaryAddress(address.id)}
                      />
                      <span>{address.name}</span>
                      </div>
                      {address.primary_address && (
                        <span
                          className="text-gray-400 whitespace-nowrap"
                          style={{ fontSize: "12px" }}
                        >
                          Primary Address
                        </span>
                      )}
                    </div>
                    <span>
                      {`${address.address_line1}, ${address.address_line2}, ${address.City.city_name}, ${address.State.state_name}, ${address.Country.country_name} - ${address.postal_code}`}
                    </span>
                    <span>+91 {address.contact_no}</span>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Dialog
                      open={isEditDailogOpen}
                      onOpenChange={(open) => {
                        setIsEditDailogOpen(open);
                      }}
                    >
                      <DialogTrigger asChild>
                        <div className="flex justify-end">
                          <Button
                            className="bg-[#6a3a18] w-[100px]"
                            onClick={() => {
                              setSelectedAddress({
                                ...address,
                                country: "101",
                              });
                              setIsEditDailogOpen(true);
                              handleCountrySelect("101");
                              handleStateSelect(address.state);
                            }}
                          >
                            <FaRegEdit />
                            Edit
                          </Button>
                        </div>
                      </DialogTrigger>
                      <DialogContent className="w-[400px] h-[80%] px-8 overflow-auto rounded-lg">
                        <div className="text-sm flex flex-col gap-4">
                          <div>
                            <DialogTitle>
                              <span className="font-bold text-lg">
                                Edit Address
                              </span>
                            </DialogTitle>
                          </div>
                          {selectedAddress && (
                            <>
                              <div className="flex flex-col gap-1">
                                <span>Name *</span>
                                <Input
                                  type="text"
                                  placeholder="Enter Name"
                                  value={selectedAddress.name}
                                  onChange={(e) => {
                                    setSelectedAddress((prev) => ({
                                      ...prev!,
                                      name: e.target.value,
                                    }));
                                  }}
                                />
                                {errors.name && (
                                  <span className="text-red-500 text-xs">
                                    {errors.name}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>Street Address *</span>
                                <Input
                                  type="text"
                                  placeholder="Enter street address 1"
                                  value={selectedAddress.address_line1}
                                  onChange={(e) => {
                                    setSelectedAddress((prev) => ({
                                      ...prev!,
                                      address_line1: e.target.value,
                                    }));
                                  }}
                                />
                                {errors.address_line1 && (
                                  <span className="text-red-500 text-xs">
                                    {errors.address_line1}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>Street Address 2 *</span>
                                <Input
                                  type="text"
                                  value={selectedAddress.address_line2}
                                  placeholder="Enter street address 2"
                                  onChange={(e) => {
                                    setSelectedAddress((prev) => ({
                                      ...prev!,
                                      address_line2: e.target.value,
                                    }));
                                  }}
                                />
                                {errors.address_line2 && (
                                  <span className="text-red-500 text-xs">
                                    {errors.address_line2}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>Contact Number *</span>
                                <Input
                                  type="tel"
                                  value={selectedAddress.contact_no}
                                  placeholder="Enter phone number"
                                  onChange={(e) => {
                                    setSelectedAddress((prev) => ({
                                      ...prev!,
                                      contact_no: e.target.value,
                                    }));
                                  }}
                                />
                                {errors.contact_no && (
                                  <span className="text-red-500 text-xs">
                                    {errors.contact_no}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>Country *</span>
                                <div className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-not-allowed">
                                  India
                                </div>
                                <input
                                  type="hidden"
                                  value="101"
                                  onChange={(e) => {
                                    setSelectedAddress((prev) => ({
                                      ...prev!,
                                      country: "101",
                                    }));
                                  }}
                                />
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>State *</span>
                                <div className="relative">
                                  {isEditingSEdit ? (
                                    <input
                                      autoFocus
                                      className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                                      placeholder="Search states..."
                                      onBlur={() => setIsEditingSEdit(false)}
                                      onChange={(e) => {
                                        const searchInput =
                                          e.target.value.toLowerCase();
                                        setFilteredStatesEdit(
                                          filteredStatesEdit.filter((state) =>
                                            state.state_name
                                              .toLowerCase()
                                              .includes(searchInput)
                                          )
                                        );
                                      }}
                                    />
                                  ) : (
                                    <div
                                      className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                                      onClick={() => {
                                        setIsEditingSEdit(true);
                                        handleCountrySelect("101");
                                      }}
                                    >
                                      {selectedAddress?.state
                                        ? filteredStatesEdit.find(
                                            (s) =>
                                              s.id === selectedAddress.state
                                          )?.state_name || "Select a State"
                                        : "Select a State"}
                                    </div>
                                  )}
                                  {isEditingSEdit && (
                                    <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                      {filteredStatesEdit.map((state) => (
                                        <div
                                          key={state.id}
                                          className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                                          onMouseDown={() => {
                                            handleStateSelect(state.id);
                                            setSelectedAddress((prev) => ({
                                              ...prev!,
                                              state: state.id,
                                              city: "",
                                            }));
                                            setIsEditingSEdit(false);
                                          }}
                                        >
                                          {state.state_name}
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                                {errors?.state && (
                                  <span className="text-red-500 text-xs">
                                    {errors.state}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>City *</span>
                                <div className="relative">
                                  {isEditingCiEdit ? (
                                    <input
                                      autoFocus
                                      className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                                      placeholder="Search cities..."
                                      onBlur={() => setIsEditingCiEdit(false)}
                                      onChange={(e) => {
                                        const searchInput =
                                          e.target.value.toLowerCase();
                                        setFilteredCitiesEdit(
                                          cityList.filter((city) =>
                                            city.city_name
                                              .toLowerCase()
                                              .includes(searchInput)
                                          )
                                        );
                                      }}
                                    />
                                  ) : (
                                    <div
                                      className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                                      onClick={() => setIsEditingCiEdit(true)}
                                    >
                                      {selectedAddress?.city
                                        ? cityList.find(
                                            (c) => c.id === selectedAddress.city
                                          )?.city_name || "Select a City"
                                        : "Select a City"}
                                    </div>
                                  )}
                                  {isEditingCiEdit && (
                                    <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                      {filteredCitiesEdit.map((city) => (
                                        <div
                                          key={city.id}
                                          className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                                          onMouseDown={() => {
                                            setSelectedAddress((prev) => ({
                                              ...prev!,
                                              city: city.id,
                                            }));
                                            setIsEditingCiEdit(false);
                                          }}
                                        >
                                          {city.city_name}
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                                {errors?.city && (
                                  <span className="text-red-500 text-xs">
                                    {errors.city}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col gap-1">
                                <span>Pincode</span>
                                <Input
                                  type="text"
                                  placeholder="Enter your pincode"
                                  value={selectedAddress.postal_code}
                                  onChange={(e) => {
                                    setSelectedAddress((prev) => ({
                                      ...prev!,
                                      postal_code: e.target.value,
                                    }));
                                  }}
                                />
                                {errors.postal_code && (
                                  <span className="text-red-500 text-xs">
                                    {errors.postal_code}
                                  </span>
                                )}
                              </div>
                              <div className="flex justify-end mt-4">
                                <Button
                                  className="bg-[#6a3a18] w-[90px] hover:bg-[#6a3a18]"
                                  onClick={() => {
                                    handleUpdateAddress(
                                      selectedAddress.id.toString()
                                    );
                                  }}
                                >
                                  Save
                                </Button>
                              </div>
                            </>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Dialog
                      open={isDeleteDailogOpen}
                      onOpenChange={setIsDeleteDailogOpen}
                    >
                      <DialogTrigger asChild>
                        {!address.primary_address && (
                          <div className="flex justify-end">
                            <Button
                              onMouseEnter={() => setSelectedAddress(address)}
                              className="bg-[#f0ebe8] w-[100px] text-[#6a3a18]"
                              onClick={() => {
                                setSelectedAddress(address);
                                setIsDeleteDailogOpen(true);
                              }}
                            >
                              <MdOutlineDelete /> Delete
                            </Button>
                          </div>
                        )}
                      </DialogTrigger>
                      <DialogContent className="w-auto py-8 px-12 overflow-auto">
                        <div className="text-sm">
                          <DialogTitle>
                            <span>
                              Do you really want to remove this address?
                            </span>
                          </DialogTitle>
                          <div className="mt-4 flex justify-center gap-4">
                            <Button
                              onClick={() => {
                                if (selectedAddress) {
                                  handleDeleteAddress(
                                    selectedAddress.id.toString()
                                  );
                                }
                              }}
                            >
                              Yes
                            </Button>
                            <Button
                              className="bg-red-600 hover:bg-red-500"
                              onClick={() => setIsDeleteDailogOpen(false)}
                            >
                              No
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              ))
            ) : (
              <div className="flex mx-auto flex-col items-center justify-center h-[300px] text-gray-500">
                <MapPin size={50} className="text-gray-400 mb-3" />
                <span className="text-lg font-semibold">
                  No saved addresses
                </span>
                <p className="text-sm text-gray-400">
                  You haven&apos;t added any addresses yet.
                </p>
              </div>
            )}
            <Dialog
              open={isAddDailogOpen}
              onOpenChange={(open) => {
                setIsAddDailogOpen(open);
                if (open) {
                  console.log(
                    "Add Address dialog opened, calling handleCountrySelect"
                  );
                  handleCountrySelect("101");
                }
              }}
            >
              <DialogTrigger asChild>
                <div className="flex justify-end">
                  <Button
                    onClick={() => {
                      setIsAddDailogOpen(true);
                    }}
                    className="bg-[#6a3a18]"
                  >
                    + Add New Address
                  </Button>
                </div>
              </DialogTrigger>
              <DialogContent className="w-[400px] h-[80%] px-8 overflow-auto rounded-lg">
                <div className="text-sm flex flex-col gap-4">
                  <div>
                    <DialogTitle>
                      <span className="font-bold text-lg">Add Address</span>
                    </DialogTitle>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Name *</span>
                    <Input
                      type="text"
                      placeholder="Enter Name"
                      value={addAddressData.name}
                      onChange={(e) =>
                        handleInputChange("name", e.target.value)
                      }
                    />
                    {errorsAdd.name && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.name}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Street Address *</span>
                    <Input
                      type="text"
                      placeholder="Enter Street Address 1"
                      value={addAddressData.address_line1}
                      onChange={(e) =>
                        handleInputChange("address_line1", e.target.value)
                      }
                    />
                    {errorsAdd.address_line1 && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.address_line1}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Street Address 2 *</span>
                    <Input
                      type="text"
                      placeholder="Enter Street Address 2"
                      value={addAddressData.address_line2}
                      onChange={(e) =>
                        handleInputChange("address_line2", e.target.value)
                      }
                    />
                    {errorsAdd.address_line2 && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.address_line2}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Contact Number *</span>
                    <Input
                      type="tel"
                      placeholder="Enter phone number"
                      value={addAddressData.contact_no}
                      onChange={(e) =>
                        handleInputChange("contact_no", e.target.value)
                      }
                    />
                    {errorsAdd.contact_no && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.contact_no}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Country *</span>
                    <div className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-not-allowed">
                      India
                    </div>
                    <input
                      type="hidden"
                      value="101"
                      onChange={(e) => handleInputChange("country", "101")}
                    />
                    {errorsAdd.country && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.country}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>State *</span>
                    <div className="relative">
                      {isEditingS ? (
                        <input
                          autoFocus
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                          placeholder="Search states..."
                          onBlur={() => setIsEditingS(false)}
                          onChange={(e) => {
                            const searchInput = e.target.value.toLowerCase();
                            setFilteredStates(
                              filteredStates.filter((state) =>
                                state.state_name
                                  .toLowerCase()
                                  .includes(searchInput)
                              )
                            );
                          }}
                        />
                      ) : (
                        <div
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                          onClick={() => {
                            console.log(
                              "State dropdown clicked, calling handleCountrySelect"
                            );
                            setIsEditingS(true);
                            handleCountrySelect("101");
                          }}
                        >
                          {addAddressData.state
                            ? filteredStates.find(
                                (s) => s.id === addAddressData.state
                              )?.state_name || "Select a State"
                            : "Select a State"}
                        </div>
                      )}
                      {isEditingS && (
                        <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                          {filteredStates.length === 0 ? (
                            <div className="px-3 py-2 text-gray-500">
                              No states available
                            </div>
                          ) : (
                            filteredStates.map((state) => (
                              <div
                                key={state.id}
                                className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                                onMouseDown={() => {
                                  console.log(
                                    `Selected state: ${state.state_name} (ID: ${state.id})`
                                  );
                                  handleInputChange("state", state.id);
                                  handleStateSelect(state.id);
                                  setIsEditingS(false);
                                }}
                              >
                                {state.state_name}
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                    {errorsAdd.state && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.state}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>City *</span>
                    <div className="relative">
                      {isEditingCi ? (
                        <input
                          autoFocus
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm"
                          placeholder="Search cities..."
                          onBlur={() => setIsEditingCi(false)}
                          onChange={(e) => {
                            const searchInput = e.target.value.toLowerCase();
                            setFilteredCities(
                              cityList.filter((city) =>
                                city.city_name
                                  .toLowerCase()
                                  .includes(searchInput)
                              )
                            );
                          }}
                        />
                      ) : (
                        <div
                          className="w-full rounded-md border border-input px-3 py-2 text-sm shadow-sm cursor-pointer"
                          onClick={() => setIsEditingCi(true)}
                        >
                          {addAddressData.city
                            ? cityList.find((c) => c.id === addAddressData.city)
                                ?.city_name || "Select a City"
                            : "Select a City"}
                        </div>
                      )}
                      {isEditingCi && (
                        <div className="absolute z-10 w-full bg-white border border-gray-300 mt-1 rounded-md shadow-lg max-h-60 overflow-y-auto">
                          {filteredCities.map((city) => (
                            <div
                              key={city.id}
                              className="px-3 py-2 hover:bg-gray-100 cursor-pointer"
                              onMouseDown={() => {
                                handleInputChange("city", city.id);
                                setIsEditingCi(false);
                              }}
                            >
                              {city.city_name}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    {errorsAdd.city && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.city}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <span>Pincode *</span>
                    <Input
                      type="text"
                      placeholder="Enter your pincode"
                      value={addAddressData.postal_code}
                      onChange={(e) =>
                        handleInputChange(
                          "postal_code",
                          e.target.value.slice(0, 6)
                        )
                      }
                    />
                    {errorsAdd.postal_code && (
                      <span className="text-red-500 text-xs">
                        {errorsAdd.postal_code}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button
                      className="bg-[#6a3a18] w-[90px] hover:bg-[#6a3a18]"
                      onClick={() => handleAddAddress()}
                    >
                      Save
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        )}
      </div>
    </div>
  );
}
