/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import Image from "next/image";
import { IoIosCall } from "react-icons/io";
import { MdMail } from "react-icons/md";
import { FaLocationDot, FaWhatsapp } from "react-icons/fa6";
import { Button } from "@/components/ui/button";
import Link from "next/link";

// assets
import img from "../../../../public/assets/user/Rectangle 3842.png";
import sendImage from "../../../../public/assets/user/letter_send 1.png";
import React, { useEffect } from "react";
import { useGlobalState } from "@/context/GlobalStateContext";

// 👇 Interface for companyDetail
interface CompanyDetail {
  id: number;
  company_name: string;
  address1: string;
  address_line2?: string;
  city: string | number;
  cmp_email: string;
  cmp_gst: string;
  cmp_pan: string;
  com_phone: string;
  country_code: string | number;
  pincode: string;
  state_code: string | number;
  City?: {
    id: number;
    city_name: string;
    state_id: string | number;
  };
  State?: {
    id: number;
    state_name: string;
    country_id: string | number;
  };
  Country?: {
    id: number;
    country_name: string;
  };
}

// 👇 Inline type assertion to fix TS errors
export default function ContactUs() {
  const { cmpLogo, companyDetail } = useGlobalState() as unknown as {
    cmpLogo: string;
    companyDetail: CompanyDetail | null;
  };

  useEffect(() => {
    console.log("Contact Us page loaded");
    console.log("company details:", companyDetail);
    document.title = `Contact Us - ${cmpLogo}`;
  }, [cmpLogo]);

  return (
    <div>
      <div className="w-full max-w-7xl mx-auto flex flex-col lg:flex-row gap-6 lg:gap-10 my-10 lg:my-20 px-4 sm:px-6 lg:px-8 justify-center">
        {/* Contact Info Section */}
        <div className="w-full lg:w-[1000px] relative rounded-xl overflow-hidden h-[500px] sm:h-[550px] lg:h-[600px]">
          <Image
            src={img}
            width={1000}
            height={1000}
            quality={100}
            alt="Contact background"
            loading="lazy"
            className="w-full h-full object-cover brightness-[40%]"
          />
          <div className="bg-[#9A602E] opacity-70 absolute top-0 w-full h-full"></div>
          <div className="absolute top-0 w-full h-full text-white p-6 sm:p-8 lg:p-10">
            <div className="text-lg sm:text-xl">
              <p>Contact Information</p>
              <p className="text-xs sm:text-sm mt-2">
                Say something to start a live chat!
              </p>
            </div>

            <div className="flex flex-col gap-4 mt-8 sm:mt-12 lg:mt-[5rem]">
              <div className="flex gap-4 sm:gap-6 items-center">
                <IoIosCall size={18} className="sm:w-5 sm:h-5" />
                <p className="text-sm sm:text-base">
                 +91 {companyDetail?.com_phone || "Not available"}
                </p>
              </div>

              <div className="flex gap-4 sm:gap-6 items-center">
                <FaWhatsapp size={18} className="sm:w-5 sm:h-5" />
                <Link
                  href={`https://api.whatsapp.com/send/?phone=${companyDetail?.com_phone || ""}&text&type=phone_number&app_absent=0`}
                  className="hover:underline text-sm sm:text-base"
                  target="_blank"
                >
                  +91 {companyDetail?.com_phone || "Not available"}
                </Link>
              </div>

              <div className="flex gap-4 sm:gap-6 items-center">
                <MdMail size={18} className="sm:w-5 sm:h-5" />
                <p className="text-sm sm:text-base">
                  {companyDetail?.cmp_email || "Not available"}
                </p>
              </div>

              <div className="flex gap-4 sm:gap-6 items-start">
                <FaLocationDot size={18} className="sm:w-5 sm:h-5 mt-1" />
                <p className="text-sm sm:text-base leading-relaxed">
                  {companyDetail?.company_name || ""},{" "}
                  {companyDetail?.address1 || ""}
                  {companyDetail?.address_line2 ? `, ${companyDetail.address_line2}` : ""}
                  {companyDetail?.City?.city_name ? `, ${companyDetail.City.city_name}` : ""}
                  {companyDetail?.State?.state_name ? `, ${companyDetail.State.state_name}` : ""}
                  {companyDetail?.pincode ? ` - ${companyDetail.pincode}` : ""}
                  {companyDetail?.Country?.country_name ? `, ${companyDetail.Country.country_name}` : ""}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Form Section (Hidden for now) */}
        <div className="w-full lg:w-1/2 text-sm flex flex-col gap-4 hidden">
          <div className="w-full flex flex-col sm:flex-row gap-4 sm:gap-6 lg:gap-10 py-6 lg:py-10">
            <div className="w-full sm:w-1/2">
              <p className="text-sm sm:text-base">First Name</p>
              <input
                type="text"
                className="border-b border-[#8D8D8D] w-full h-10 outline-none text-sm sm:text-base"
              />
            </div>
            <div className="w-full sm:w-1/2">
              <p className="text-sm sm:text-base">Last Name</p>
              <input
                type="text"
                className="border-b border-[#8D8D8D] w-full h-10 outline-none text-sm sm:text-base"
              />
            </div>
          </div>
          <div className="w-full flex flex-col sm:flex-row gap-4 sm:gap-6 lg:gap-10">
            <div className="w-full sm:w-1/2">
              <p className="text-sm sm:text-base">Email</p>
              <input
                type="email"
                className="border-b border-[#8D8D8D] w-full h-10 outline-none text-sm sm:text-base"
              />
            </div>
            <div className="w-full sm:w-1/2">
              <p className="text-sm sm:text-base">Phone Number</p>
              <input
                type="number"
                className="border-b border-[#8D8D8D] w-full h-10 outline-none text-sm sm:text-base"
              />
            </div>
          </div>
          <div className="w-full mt-6">
            <p className="mb-4 text-sm sm:text-base">Message</p>
            <textarea
              name="message"
              placeholder="Write your message.."
              className="w-full h-20 border-b border-[#8D8D8D] resize-none outline-none text-sm sm:text-base"
            ></textarea>
          </div>
          <div className="w-full flex justify-end mt-4">
            <Button className="h-12 bg-[#6a3a18] text-sm sm:text-base px-6">
              Send Message
            </Button>
          </div>
          <div className="w-full h-32 sm:h-40 lg:h-48 flex justify-end relative">
            <Image
              src={sendImage}
              width={1000}
              height={1000}
              quality={100}
              alt="Send icon"
              loading="lazy"
              className="w-32 sm:w-40 lg:w-48 h-full absolute right-0 sm:right-10 top-[-20px] sm:top-[-30px] object-contain"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
