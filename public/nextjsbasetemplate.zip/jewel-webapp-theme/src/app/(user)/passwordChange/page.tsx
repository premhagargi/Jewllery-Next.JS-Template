"use client";

import Image from "next/image";
import UserImage from "../../../../public/assets/user/boy.png";
import { PiUserLight } from "react-icons/pi";
import { FiPackage } from "react-icons/fi";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { GoHeart, GoLocation, GoTrash, GoPasskeyFill } from "react-icons/go";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useGlobalState } from "@/context/GlobalStateContext";
import { BiLogOut } from "react-icons/bi";
import { api } from "../../../../utils/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { toast } from "sonner";
import ConfirmModal from "@/components/user/confirmModal";
import Cookies from "js-cookie";
import React from "react";
import config from "../../../../config.json";
import Style from '../../(user)/styles/passwordChange.module.scss'
import { motion, AnimatePresence } from "framer-motion";

// Add this type
type InputOTPSlotProps = {
  char?: string;
  hasFocus?: boolean;
  isActive?: boolean;
};

export default function PasswordChange() {
  const router = useRouter();
  const { isTokenExpired } = useGlobalState();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Password states
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // New states for validation and forgot password
  const [inputErrors, setInputErrors] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [isForgotPasswordMode, setIsForgotPasswordMode] = useState(false);
  const [username, setUsername] = useState("");
  const [usernameError, setUsernameError] = useState("");

  // Add new states for OTP flow
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [showNewPasswordInputs, setShowNewPasswordInputs] = useState(false);
  const [resetPassword, setResetPassword] = useState("");
  const [resetConfirmPassword, setResetConfirmPassword] = useState("");
  const [profileData, setProfileData] = useState<any>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  // Add new states for reset password validation
  const [resetPasswordErrors, setResetPasswordErrors] = useState({
    password: "",
    confirmPassword: "",
  });

  // Add password match state
  const [passwordsMatch, setPasswordsMatch] = useState(true);

  // Add new state for success message
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  // Add new state variables for showing/hiding reset passwords
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [showResetConfirmPassword, setShowResetConfirmPassword] =
    useState(false);

  // Add new state for same password error
  const [isSamePassword, setIsSamePassword] = useState(false);

  useEffect(() => {
    document.title = "Change Password";
    setTimeout(() => {
      fetchProfileData();
    }, 1000);
  }, []);

  const validatePassword = (password: string, currentPwd: string) => {
    // if (password === currentPwd) {
    //   return "New password cannot be the same as current password";
    // }
    // if (password.length < 6) return "Password must be at least 6 characters";
    // if (!/[A-Z]/.test(password)) return "Must contain an uppercase letter";
    // if (!/[a-z]/.test(password)) return "Must contain a lowercase letter";
    // if (!/[0-9]/.test(password)) return "Must contain a number";
    // if (!/[!@#$%^&*]/.test(password)) return "Must contain a special character";
    return "";
  };

  const fetchProfileData = async () => {
    try {
      interface ProfileResponse {
        status: string;
        data: {
          cust_cmp_phone?: string;
          cust_cmp_email?: string;
        };
      }

      const response = await api.get<ProfileResponse>("/api/v1/getProfile");
      if (response.data && response.data.status === "Success") {
        const profileData = response.data.data;
        setProfileData(profileData);
        setPhoneNumber(profileData?.cust_cmp_phone || "");
        setEmail(profileData?.cust_cmp_email || "");
        console.log("profileData", profileData);
      }
    } catch (error) {
      console.error("Failed to fetch profile:", error);
      toast.error("Failed to load profile data");
    } finally {
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();

    // Reset errors
    setInputErrors({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });

    // Check if passwords are same
    if (currentPassword === newPassword) {
      setInputErrors((prev) => ({
        ...prev,
        newPassword: "",
      }));
      return;
    }

    // Validate new password
    const newPasswordError = validatePassword(newPassword, currentPassword);
    if (newPasswordError) {
      setInputErrors((prev) => ({ ...prev, newPassword: newPasswordError }));
      return;
    }

    if (newPassword !== confirmPassword) {
      setInputErrors((prev) => ({
        ...prev,
        confirmPassword: "Passwords don't match",
      }));
      return;
    }

    try {
      setLoading(true);
      interface ChangePasswordResponse {
        status: string;
        message?: string;
      }

      const response = await api.put<ChangePasswordResponse>(
        "/api/v1/changePassword",
        {
          username: profileData?.cust_cmp_phone || profileData?.cust_cmp_email,
          companyId: config.COMPANY_ID,
          oldPassword: currentPassword,
          newPassword: newPassword,
        }
      );

      if (response.data?.status === "Success") {
        toast.success("Password changed successfully!");
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
      } else {
        const data = response.data as { message?: string };
        toast.error(data.message || "Failed to change password");
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message || "Failed to change password";
      toast.error(errorMessage);
      if (errorMessage.toLowerCase().includes("current password")) {
        setInputErrors((prev) => ({
          ...prev,
          currentPassword: "Current password is incorrect",
        }));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleNewPasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setNewPassword(newValue);

    // Check if new password is same as current
    const isSame = newValue === currentPassword;
    setIsSamePassword(isSame);

    // Validate password
    const error = validatePassword(newValue, currentPassword);
    setInputErrors((prev) => ({
      ...prev,
      newPassword: error,
    }));
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setUsernameError("");

    if (!username) {
      setUsernameError("Please enter your email or phone number");
      return;
    }

    // Check if input matches registered email or phone
    if (username !== email && username !== phoneNumber) {
      setUsernameError("Please enter your registered email or phone number");
      return;
    }

    try {
      setLoading(true);
      interface ResetPasswordResponse {
        status: string;
      }

      const response = await api.post<ResetPasswordResponse>(
        "/api/v1/resetPassword",
        {
          username,
          companyId: config.COMPANY_ID,
        }
      );

      if (response.data?.status === "Success") {
        toast.success("OTP sent successfully!");
        setOtpSent(true);
      }
    } catch (error: any) {
      setUsernameError(error.response?.data?.message || "Failed to send OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (value: string) => {
    setOtp(value);
    if (value.length === 4) {
      try {
        setShowNewPasswordInputs(true);
      } catch (error) {
        toast.error("Invalid OTP");
      }
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!passwordsMatch) {
      setResetPasswordErrors((prev) => ({
        ...prev,
        confirmPassword: "Passwords don't match",
      }));
      return;
    }

    const passwordError = validatePassword(resetPassword, currentPassword);
    if (passwordError) {
      setResetPasswordErrors((prev) => ({
        ...prev,
        password: passwordError,
      }));
      return;
    }

    try {
      setLoading(true);
      interface ResetPasswordVerifyResponse {
        status: string;
      }

      const response = await api.put<ResetPasswordVerifyResponse>(
        "/api/v1/resetPasswordVerify",
        {
          username,
          companyId: config.COMPANY_ID,
          otp,
          newPassword: resetPassword,
        }
      );

      if (response.data?.status === "Success") {
        setShowSuccessMessage(true);
        setTimeout(() => {
          router.push("/login");
        }, 1300); // Redirect after 1.3 seconds
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message || "Failed to reset password";
      setResetPasswordErrors((prev) => ({
        ...prev,
        password: errorMessage,
      }));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConfirmed = async () => {
    setIsModalOpen(false);
    try {
      await api.patch("/api/v1/deleteAcc", {});
      toast.success("Your account has been deleted!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      setTimeout(() => {
        toast("We are sorry to see you go!!", {
          duration: 2000,
          position: "top-center",
          icon: "😔",
        });
      }, 500);
      localStorage.clear();
      router.push("/login");
      Cookies.remove("token");
    } catch (err) {
      console.error("Account deletion error:", err);
    }
  };

  const handleGoBack = () => {
    // Clear all input fields
    setUsername("");
    setOtp("");
    setResetPassword("");
    setResetConfirmPassword("");
    // Clear errors
    setUsernameError("");
    setResetPasswordErrors({
      password: "",
      confirmPassword: "",
    });
    // Reset states
    setIsForgotPasswordMode(false);
    setOtpSent(false);
    setShowNewPasswordInputs(false);
  };

  const deleteAccount = async () => {
    setIsModalOpen(true);
  };

  const renderResetPasswordInputs = () => (
    <div className="space-y-4 transition-all duration-300">
      <div className="space-y-2">
        <label className="text-sm font-medium">New Password</label>
        <div className="relative">
          <Input
            type={showResetPassword ? "text" : "password"}
            value={resetPassword}
            onChange={(e) => {
              setResetPassword(e.target.value);
              const error = validatePassword(e.target.value, currentPassword);
              setResetPasswordErrors((prev) => ({
                ...prev,
                password: error,
              }));
              setPasswordsMatch(e.target.value === resetConfirmPassword);
            }}
            className={`w-full pr-10 ${
              resetPasswordErrors.password
                ? "border-red-500 focus:ring-red-500"
                : "border-gray-300"
            }`}
            required
          />
          <button
            type="button"
            onClick={() => setShowResetPassword(!showResetPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm"
          >
            {showResetPassword ? "Hide" : "Show"}
          </button>
        </div>
        <ul className="text-xs space-y-1 mt-2">
          {[
            {
              test: (p: string) => p.length >= 6,
              text: "At least 6 characters",
            },
            {
              test: (p: string) => /[A-Z]/.test(p),
              text: "One uppercase letter",
            },
            {
              test: (p: string) => /[a-z]/.test(p),
              text: "One lowercase letter",
            },
            { test: (p: string) => /[0-9]/.test(p), text: "One number" },
            {
              test: (p: string) => /[!@#$%^&*]/.test(p),
              text: "One special character",
            },
          ].map((req, idx) => (
            <li
              key={idx}
              className={`flex items-center gap-2 ${
                req.test(resetPassword) ? "text-green-500" : "text-gray-500"
              }`}
            >
              {req.test(resetPassword) ? "✓" : "•"} {req.text}
            </li>
          ))}
        </ul>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Confirm Password</label>
        <div className="relative">
          <Input
            type={showResetConfirmPassword ? "text" : "password"}
            value={resetConfirmPassword}
            onChange={(e) => {
              setResetConfirmPassword(e.target.value);
              setPasswordsMatch(resetPassword === e.target.value);
            }}
            className={`w-full pr-10 ${
              !passwordsMatch && resetConfirmPassword
                ? "border-red-500 focus:ring-red-500"
                : "border-gray-300"
            }`}
            required
          />
          <button
            type="button"
            onClick={() =>
              setShowResetConfirmPassword(!showResetConfirmPassword)
            }
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm"
          >
            {showResetConfirmPassword ? "Hide" : "Show"}
          </button>
        </div>
        {!passwordsMatch && resetConfirmPassword && (
          <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
        )}
        {passwordsMatch && resetConfirmPassword && (
          <p className="text-xs text-green-500 mt-1">✓ Passwords match</p>
        )}
      </div>

      <Button
        onClick={handleResetPasswordSubmit}
        className="w-full bg-[#6a3a18] hover:bg-[#593114] text-white"
        disabled={loading || !passwordsMatch || !!resetPasswordErrors.password}
      >
        {loading ? "Resetting..." : "Reset Password"}
      </Button>
    </div>
  );

  return (
    <div
      className={`w-[90%] mx-auto flex gap-10 text-sm my-10 ${Style.profileContainer}`}
    >
      <div
        className={`min-w-[250px] border shadow py-4 text-[#6a3a18] h-fit ${Style.profileLeftContainer}`}
      >
        <div
          className={`flex items-center gap-2 px-4 pb-4 border-b ${Style.profileImageAndNameContainer}`}
        >
          <Image
            src={UserImage}
            width={1000}
            height={1000}
            quality={100}
            alt="User"
            loading="lazy"
            className="w-[50px] h-[50px] rounded-full"
          />
          <div className="flex flex-col">
            <span className="text-xs font-bold">
              Hello <span className="text-lg">🖐️</span>
            </span>
            <span className="font-bold">
              {profileData?.cust_cmp_name || ""}
            </span>
          </div>
        </div>
        <div
          className={`flex flex-col gap-1 py-4 px-2 ${Style.navigateButtons}`}
        >
          <Link href={"/profile"}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <PiUserLight size={18} />
              <span>Personal Information</span>
            </div>
          </Link>
          <Link
            href={"/orders"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Orders", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📦",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <FiPackage size={18} />
              <span>My Orders</span>
            </div>
          </Link>
          <Link
            href={"/wishlist"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Wishlist", {
                  duration: 3000,
                  position: "top-center",
                  icon: "❤️",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoHeart size={18} />
              <span>My Wishlists</span>
            </div>
          </Link>
          <Link
            href={"/address"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoLocation size={18} />
              <span>Manage Addresses</span>
            </div>
          </Link>
          <Link
            href={"/passwordChange"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer bg-[#6a3a18] text-white rounded-sm">
              <GoPasskeyFill size={18} />
              <span>Password Change</span>
            </div>
          </Link>
          <div
            onClick={deleteAccount}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <GoTrash size={18} />
            <span>Delete My Account</span>
          </div>
          <ConfirmModal
            isOpen={isModalOpen}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => setIsModalOpen(false)}
          />
          <div
            onClick={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("redirectAfterLogin");
              router.push("/login");
            }}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <BiLogOut size={18} />
            <span>Logout</span>
          </div>
        </div>
      </div>
      
      {/* Password Change/Reset Form */}
      <div className="flex-1 max-w-md relative">
        <AnimatePresence>
          {showSuccessMessage ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute inset-0 flex flex-col items-center justify-center text-center bg-white z-10"
            >
              <motion.h2
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                className="text-3xl font-bold text-[#6a3a18] mb-4"
              >
                Password Changed Successfully!
              </motion.h2>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-xl text-gray-600"
              >
                Please log in again with your new password.
              </motion.p>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ duration: 1.5 }}
                className="h-1 bg-[#6a3a18] mt-8"
              />
            </motion.div>
          ) : (
            <>
              {isForgotPasswordMode ? (
                <div className="space-y-4">
                  <div
                    className={`transition-opacity duration-300 ${
                      otpSent ? "opacity-0 h-0 overflow-hidden" : "opacity-100"
                    }`}
                  >
                    <form onSubmit={handleForgotPassword} className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Email or Phone Number
                        </label>
                        <Input
                          type="text"
                          value={username}
                          onChange={(e) => {
                            setUsername(e.target.value);
                            setUsernameError("");
                          }}
                          className={`w-full ${
                            usernameError
                              ? "border-red-500 focus:ring-red-500"
                              : username &&
                                (username === email || username === phoneNumber)
                              ? "border-green-500 focus:ring-green-500"
                              : ""
                          }`}
                          placeholder="Enter your registered email or phone number"
                          required
                          disabled={otpSent}
                        />
                        {usernameError && (
                          <p className="text-sm text-red-500 mt-1">
                            {usernameError}
                          </p>
                        )}
                        {(email || phoneNumber) && (
                          <div className="text-xs text-gray-500 mt-1">
                            <p>Please enter either:</p>

                            {email && (
                              <p>
                                • Your registered email:{" "}
                                {email.replace(/(.{2})(.*)(?=@)/, "$1****$2")}
                              </p>
                            )}

                            {phoneNumber && (
                              <p>
                                • Your registered phone:{" "}
                                {phoneNumber.replace(
                                  /(\d{2})(\d+)(\d{2})/,
                                  "$1****$3"
                                )}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                      <Button
                        type="submit"
                        className="w-full bg-[#6a3a18] hover:bg-[#593114] text-white"
                        disabled={loading}
                      >
                        {loading ? "Sending OTP..." : "Send OTP"}
                      </Button>
                    </form>
                  </div>

                  {otpSent && (
                    <div
                      className={`transition-all duration-300 ${
                        otpSent
                          ? "opacity-100 translate-y-0"
                          : "opacity-0 translate-y-4"
                      }`}
                    >
                      <div className="space-y-4">
                        <label className="text-sm font-medium">Enter OTP</label>
                        <div className="flex gap-2">
                          {Array.from({ length: 4 }).map((_, index) => (
                            <Input
                              key={index}
                              type="text"
                              maxLength={1}
                              className="w-12 h-12 text-center text-2xl"
                              value={otp[index] || ""}
                              onChange={(e) => {
                                const newOtp = otp.split("");
                                newOtp[index] = e.target.value;
                                const updatedOtp = newOtp.join("");
                                setOtp(updatedOtp);

                                // Auto-focus next input
                                if (e.target.value && index < 3) {
                                  const nextInput = document.querySelector(
                                    `input[name=otp-${index + 1}]`
                                  );
                                  if (nextInput) {
                                    (nextInput as HTMLInputElement).focus();
                                  }
                                }

                                // Check if OTP is complete
                                if (updatedOtp.length === 4) {
                                  handleVerifyOTP(updatedOtp);
                                }
                              }}
                              onKeyDown={(e) => {
                                // Handle backspace
                                if (
                                  e.key === "Backspace" &&
                                  !otp[index] &&
                                  index > 0
                                ) {
                                  const prevInput = document.querySelector(
                                    `input[name=otp-${index - 1}]`
                                  );
                                  if (prevInput) {
                                    (prevInput as HTMLInputElement).focus();
                                  }
                                }
                              }}
                              name={`otp-${index}`}
                              inputMode="numeric"
                              pattern="\d*"
                            />
                          ))}
                        </div>

                        {showNewPasswordInputs && renderResetPasswordInputs()}
                      </div>
                    </div>
                  )}

                  <Button
                    type="button"
                    variant="link"
                    onClick={handleGoBack}
                    className="w-full text-[#6a3a18] mt-4"
                  >
                    Go Back
                  </Button>
                </div>
              ) : (
                <form onSubmit={handlePasswordChange} className="space-y-4">
                  {/* Password inputs with validation feedback */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">
                      Current Password
                    </label>
                    <div className="relative">
                      <Input
                        type={showCurrentPassword ? "text" : "password"}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        className={`w-full pr-10 ${
                          inputErrors.currentPassword
                            ? "border-red-500 focus:ring-red-500"
                            : ""
                        }`}
                        required
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setShowCurrentPassword(!showCurrentPassword)
                        }
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm"
                      >
                        {showCurrentPassword ? "Hide" : "Show"}
                      </button>
                    </div>
                    {inputErrors.currentPassword && (
                      <p className="text-sm text-red-500">
                        {inputErrors.currentPassword}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">New Password</label>
                    <div className="relative">
                      <Input
                        type={showNewPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={handleNewPasswordChange}
                        className={`w-full pr-10 ${
                          inputErrors.newPassword || isSamePassword
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300"
                        }`}
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm"
                      >
                        {showNewPassword ? "Hide" : "Show"}
                      </button>
                    </div>
                    {isSamePassword && (
                      <p className="text-sm text-red-500 font-medium mt-1 flex items-center gap-1">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          <path
                            fillRule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                            clipRule="evenodd"
                          />
                        </svg>
                        New password must be different from current password
                      </p>
                    )}
                    {inputErrors.newPassword && (
                      <p className="text-sm text-red-500">
                        {inputErrors.newPassword}
                      </p>
                    )}
                    <ul className="text-xs space-y-1 mt-2">
                      {[
                        {
                          test: (p: string) => p.length >= 6,
                          text: "At least 6 characters",
                        },
                        {
                          test: (p: string) => /[A-Z]/.test(p),
                          text: "One uppercase letter",
                        },
                        {
                          test: (p: string) => /[a-z]/.test(p),
                          text: "One lowercase letter",
                        },
                        {
                          test: (p: string) => /[0-9]/.test(p),
                          text: "One number",
                        },
                        {
                          test: (p: string) => /[!@#$%^&*]/.test(p),
                          text: "One special character",
                        },
                      ].map((req, idx) => (
                        <li
                          key={idx}
                          className={`flex items-center gap-2 ${
                            req.test(newPassword)
                              ? "text-green-500"
                              : "text-gray-500"
                          }`}
                        >
                          {req.test(newPassword) ? "✓" : "•"} {req.text}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">
                      Confirm New Password
                    </label>
                    <div className="relative">
                      <Input
                        type={showConfirmPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className={`w-full pr-10 ${
                          inputErrors.confirmPassword
                            ? "border-red-500 focus:ring-red-500"
                            : ""
                        }`}
                        required
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm"
                      >
                        {showConfirmPassword ? "Hide" : "Show"}
                      </button>
                    </div>
                    {inputErrors.confirmPassword && (
                      <p className="text-sm text-red-500">
                        {inputErrors.confirmPassword}
                      </p>
                    )}
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[#6a3a18] hover:bg-[#593114] text-white"
                    disabled={loading}
                  >
                    {loading ? "Changing Password..." : "Change Password"}
                  </Button>

                  <Button
                    type="button"
                    variant="link"
                    onClick={() => setIsForgotPasswordMode(true)}
                    className="w-full text-[#6a3a18]"
                  >
                    Forgot Password?
                  </Button>
                </form>
              )}
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
