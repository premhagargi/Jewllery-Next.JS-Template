import type { Metadata } from "next";
import { Toaster } from "sonner";
import { GlobalStateProvider } from "@/context/GlobalStateContext";
import ClientLayout from "@/components/user/layout";
import localFont from "next/font/local";
import "../globals.css";

// Local Fonts
const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

// Metadata
export const metadata: Metadata = {
  title: "Maharana Silver",
  description: "Maharana Silver",
};

// Root Layout
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <GlobalStateProvider>
          <ClientLayout>{children}</ClientLayout>
        </GlobalStateProvider>

        {/* Toaster Notifications */}
        <Toaster position="top-center" />
      </body>
    </html>
  );
}
