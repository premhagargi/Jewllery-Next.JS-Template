"use client";
import React, { useState, useEffect, useCallback, useRef } from "react";
import Image from "next/image";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { motion, AnimatePresence } from "framer-motion";
import { REGEXP_ONLY_DIGITS } from "input-otp";
import Cookies from "js-cookie";
import LoginImage from "../../../../public/assets/user/login.png";
import { useRouter } from "next/navigation";
import { useGlobalState } from "@/context/GlobalStateContext";
import config from "../../../../config.json";
import Style from "../styles/login.module.scss";
import Link from "next/link";
import { FiEye } from "react-icons/fi";
import { FiEyeOff } from "react-icons/fi";
import { Eye, EyeOff } from "lucide-react";

const inputStyles =
  "focus:ring-0 focus:ring-offset-0 focus:outline-none focus-visible:ring-0 focus-visible:ring-offset-0";

interface PasswordRequirement {
  test: (password: string) => boolean;
  text: string;
}

const PASSWORD_REQUIREMENTS: PasswordRequirement[] = [
  { test: (p) => p.length >= 6, text: "At least 6 characters" },
  { test: (p) => /[A-Z]/.test(p), text: "One uppercase letter" },
  { test: (p) => /[a-z]/.test(p), text: "One lowercase letter" },
  { test: (p) => /[0-9]/.test(p), text: "One number" },
  { test: (p) => /[!@#$%^&*]/.test(p), text: "One special character" },
];

const BASE_URL = config.NEXT_PUBLIC_API_URL;
const COMPANY_ID = config.COMPANY_ID;

export default function Login() {
  const router = useRouter();
  const { checkLoggedIn, fetchData, setJustLoggedIn } = useGlobalState();
  const [activeTab, setActiveTab] = useState("signin");
  const [inputValue, setInputValue] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isContinueClicked, setIsContinueClicked] = useState(false);
  const [otp, setOtp] = useState("");
  const [placeholder, setPlaceholder] = useState("+91 9000000000");
  const [timer, setTimer] = useState(30);
  const [timerExpired, setTimerExpired] = useState(false);
  const [showpassword, setShowPassword] = useState(false);
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [showSignupConfirmPassword, setShowSignupConfirmPassword] =
    useState(false);
  const [isForgotPasswordMode, setIsForgotPasswordMode] = useState(false);
  const [isSignUpMode, setIsSignUpMode] = useState(true);
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState("");
  const [forgotPasswordOtp, setForgotPasswordOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newConfirmPassword, setNewConfirmPassword] = useState("");
  const [showForgotPasswordOtp, setShowForgotPasswordOtp] = useState(false);
  const [showNewPasswordInputs, setShowNewPasswordInputs] = useState(false);
  const [passwordsMatch, setPasswordsMatch] = useState(true);
  const [passwordRequirements, setPasswordRequirements] = useState<boolean[]>(
    new Array(PASSWORD_REQUIREMENTS.length).fill(false)
  );
  const [showNewResetPassword, setShowNewResetPassword] = useState(false);
  const [showConfirmResetPassword, setShowConfirmResetPassword] =
    useState(false);

  const inputValidationTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    document.title = "Login";
    const placeholders = ["+91 9000000000", "user@gmail.com"];
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % placeholders.length;
      setPlaceholder(placeholders[index]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const validateInput = useCallback((value: string) => {
    const isPhoneNumber = /^\d{10}$/.test(value);
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    return isPhoneNumber || isEmail;
  }, []);

  useEffect(() => {
    if (inputValidationTimeoutRef.current) {
      clearTimeout(inputValidationTimeoutRef.current);
    }

    inputValidationTimeoutRef.current = setTimeout(() => {
      if (inputValue && !validateInput(inputValue)) {
        setErrorMessage("Please enter a valid phone number or email");
      } else {
        setErrorMessage("");
      }
    }, 300);

    return () => {
      if (inputValidationTimeoutRef.current) {
        clearTimeout(inputValidationTimeoutRef.current);
      }
    };
  }, [inputValue, validateInput]);

  const validatePasswords = useCallback(
    (pwd: string, confirmPwd: string, showLengthError: boolean) => {
      if (activeTab === "signin") return true;
      if (pwd.length < 6 && showLengthError) return false;
      if (activeTab === "signup" && confirmPwd && pwd !== confirmPwd)
        return false;
      return true;
    },
    [activeTab]
  );

  useEffect(() => {
    if (activeTab === "signup") {
      const newRequirements = PASSWORD_REQUIREMENTS.map((req) =>
        req.test(password)
      );
      setPasswordRequirements(newRequirements);

      const isValid = newRequirements.every(Boolean);
      if (!isValid) {
        setErrorMessage("Please meet all password requirements");
      } else if (confirmPassword && password !== confirmPassword) {
        setErrorMessage("Passwords do not match");
      } else {
        setErrorMessage("");
      }
    }
  }, [password, confirmPassword, activeTab]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isContinueClicked && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            setTimerExpired(true);
            clearInterval(interval);
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isContinueClicked, timer]);

  function storeToken(token: string | undefined) {
    const isSecure = window.location.protocol === "https:";
    if (!token) return;
    Cookies.set("token", token, {
      expires: 7,
      sameSite: "Lax",
      secure: isSecure,
      path: "/",
    });
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
  };

  const handleConfirmPasswordChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setConfirmPassword(e.target.value);
  };

  const handleTabChange = (value: string) => {
    // Reset all states when changing tabs
    setActiveTab(value);
    setInputValue("");
    setPassword("");
    setConfirmPassword("");
    setErrorMessage("");
    // Reset forgot password states
    setIsForgotPasswordMode(false);
    setForgotPasswordEmail("");
    setForgotPasswordOtp("");
    setShowForgotPasswordOtp(false);
    setShowNewPasswordInputs(false);
    setNewPassword("");
    setNewConfirmPassword("");
  };

  const handleContinue = async () => {
    if (!validateInput(inputValue)) {
      toast.info("Please enter a valid phone number or email", {
        duration: 2000,
      });
      return;
    }

    if (!validatePasswords(password, confirmPassword, activeTab === "signup")) {
      toast.info(errorMessage, { duration: 2000 });
      return;
    }

    try {
      const endpoint =
        activeTab === "signin" ? "/api/v1/login" : "/api/v1/register";
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: inputValue,
          password: password,
          companyId: COMPANY_ID,
        }),
      });

      const result = await response.json();

      if (activeTab === "signin") {
        if (response.status === 200) {
          toast.success("Login Successful!");
          storeToken(result.data.token);
          await fetchData("profile");
          setJustLoggedIn(true); // Set justLoggedIn to true
          const redirectUrl = localStorage.getItem("redirectAfterLogin");
          checkLoggedIn();
          fetchData();

          if (redirectUrl) {
            router.push(redirectUrl);
            localStorage.removeItem("redirectAfterLogin");
          } else {
            router.push("/");
          }
        } else {
          toast.error(result.message || "Login failed");
        }
      } else {
        if (response.status === 200) {
          toast.success("OTP sent successfully!");
          setIsContinueClicked(true);
          setTimer(30);
          setTimerExpired(false);
        } else {
          toast.error(result.message || `Failed to send OTP for ${activeTab}`);
        }
      }
    } catch (error) {
      console.error(`Error during ${activeTab}:`, error);
      toast.error(`An error occurred during ${activeTab}`);
    }
  };

  const handleVerify = async () => {
    if (otp.length !== 4) {
      toast.info("Please enter a valid 4-digit OTP", { duration: 2000 });
      return;
    }

    try {
      const response = await fetch(`${BASE_URL}/api/v1/verifyOtpData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: inputValue,
          companyId: COMPANY_ID,
          otp,
        }),
      });

      const result = await response.json();

      if (response.status === 200) {
        toast.success("Sign Up successful!");
        storeToken(result.data.token);
        await fetchData("profile");
        setJustLoggedIn(true); // Set justLoggedIn to true
        const redirectUrl = localStorage.getItem("redirectAfterLogin");
        checkLoggedIn();
        fetchData();

        if (redirectUrl) {
          router.push(redirectUrl);
          localStorage.removeItem("redirectAfterLogin");
        } else {
          router.push("/");
        }
      } else {
        toast.error(result.message || "OTP verification failed");
      }
    } catch (error) {
      console.error("Error during OTP verification:", error);
      toast.error("An error occurred during OTP verification");
    }
  };

  const handleOtpChange = (value: string) => {
    setOtp(value);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes < 10 ? "0" : ""}${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateInput(forgotPasswordEmail)) return;

    try {
      const response = await fetch(`${BASE_URL}/api/v1/resetPassword`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: forgotPasswordEmail,
          companyId: COMPANY_ID,
        }),
      });

      const result = await response.json();

      if (result.status === "Success") {
        toast.success("OTP sent successfully!");
        setShowForgotPasswordOtp(true);
      } else if (result.status === "Failed") {
        // Handle known failure responses from API
        toast.error(result.message || "Failed to send OTP.");
      } else {
        // Fallback for unexpected responses
        toast.error("Unexpected response from server.");
      }
    } catch (error: any) {
      console.error("Network or server error:", error);
      toast.error("Something went wrong. Please try again.");
    }
  };

  const handleResetPassword = async () => {
    if (!passwordsMatch) {
      toast.error("Passwords do not match");
      return;
    }

    try {
      const response = await fetch(`${BASE_URL}/api/v1/resetPasswordVerify`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: forgotPasswordEmail,
          companyId: COMPANY_ID,
          otp: forgotPasswordOtp,
          newPassword: newPassword,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        // Try to show the message from the response, fallback to status-based defaults
        const errorMessage =
          result?.message ||
          ({
            400: "OTP invalid or expired",
            403: "OTP invalid or expired.",
            404: "User not found.",
            500: "Internal server error. Please try again later.",
          }[response.status] || "Failed to reset password.");

        toast.error(errorMessage);
        return;
      }

      if (result.status === "Success") {
        toast.success("Password reset successful!");
        setIsForgotPasswordMode(false);
        setShowForgotPasswordOtp(false);
        setShowNewPasswordInputs(false);
      } else {
        toast.error(result.message || "Failed to reset password.");
      }
    } catch (error: any) {
      toast.error(error.message || "An unexpected error occurred.");
    }
  };

  return (
    <div className={`${Style.loginContainer}`}>
      <div
        className={`w-full h-[100vh] p-8 flex justify-center items-center gap-10 ${Style.loginInnerContainer}`}
      >
        <Image
          src={LoginImage}
          width={1000}
          height={1000}
          quality={100}
          alt=""
          loading="lazy"
          className="w-[42%] h-[100%]"
        />
        <div
          className={`w-[30%] h-full flex flex-col justify-center items-start ${Style.loginInputContainer}`}
        >
          {isContinueClicked ? (
            <div className="h-full w-full flex flex-col justify-center items-center gap-[3rem]">
              <h2 className="font-bold text-[1.2rem]">Enter OTP</h2>
              <div className="text-sm w-full flex flex-col items-center justify-center">
                <p className="mb-1">
                  Code is sent to{" "}
                  <span className="text-[#707070]">{inputValue}</span>
                </p>
                <InputOTP
                  maxLength={4}
                  pattern={REGEXP_ONLY_DIGITS}
                  onChange={handleOtpChange}
                  className={inputStyles}
                >
                  <InputOTPGroup className="flex gap-4 mt-3 mb-3">
                    <InputOTPSlot
                      index={0}
                      className={`${inputStyles} shadow-md rounded-lg`}
                    />
                    <InputOTPSlot
                      index={1}
                      className={`${inputStyles} shadow-md rounded-lg`}
                    />
                    <InputOTPSlot
                      index={2}
                      className={`${inputStyles} shadow-md rounded-lg`}
                    />
                    <InputOTPSlot
                      index={3}
                      className={`${inputStyles} shadow-md rounded-lg`}
                    />
                  </InputOTPGroup>
                </InputOTP>
                <p className="mt-2 text-xs cursor-pointer text-gray-500">
                  {timerExpired ? (
                    <span
                      className="text-red-600 cursor-pointer"
                      onClick={handleContinue}
                    >
                      Resend OTP
                    </span>
                  ) : (
                    <span>{formatTime(timer)}</span>
                  )}
                </p>
              </div>
              <div className="w-full">
                <Button className="w-full mt-2 h-[40px]" onClick={handleVerify}>
                  Verify
                </Button>
              </div>
            </div>
          ) : (
            <div className="h-full w-full flex flex-col justify-center items-center">
              <Tabs
                defaultValue="signin"
                className={`w-full border-2 p-4 pt-6 rounded-t-xl border-b-0 ${
                  !isForgotPasswordMode ? "pb-12" : ""
                }`}
                onValueChange={handleTabChange}
              >
                <TabsList className="grid w-full grid-cols-2 mb-6 bg-slate-100">
                  <TabsTrigger value="signin">Sign In</TabsTrigger>
                  <TabsTrigger
                    value="signup"
                    onClick={() => {
                      handleTabChange("signup"); // This will reset all states
                      setIsSignUpMode(true);
                    }}
                  >
                    Sign Up
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="signin">
                  <AnimatePresence mode="wait">
                    {isForgotPasswordMode ? (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.2 }}
                        className="text-sm w-full mt-4"
                      >
                        <AnimatePresence mode="wait">
                          {!showForgotPasswordOtp ? (
                            <motion.div
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              transition={{ duration: 0.2 }}
                            >
                              <p className="mb-1">
                                Enter your registered email or mobile number
                              </p>
                              <Input
                                type="text"
                                value={forgotPasswordEmail}
                                onChange={(e) =>
                                  setForgotPasswordEmail(e.target.value)
                                }
                                placeholder="Enter email or mobile"
                                className={`${inputStyles} mt-2 focus:outline-none focus:ring-0 ${
                                  !validateInput(forgotPasswordEmail) &&
                                  forgotPasswordEmail
                                    ? "border-red-500 shadow-red"
                                    : "shadow-md"
                                }`}
                              />

                              <div className="flex gap-2 mt-4">
                                <Button
                                  variant="outline"
                                  onClick={() => {
                                    setIsForgotPasswordMode(false);
                                    setIsSignUpMode(true);
                                  }}
                                  className="flex-1"
                                >
                                  Cancel
                                </Button>
                                <Button
                                  onClick={handleForgotPassword}
                                  className="flex-1"
                                  disabled={!validateInput(forgotPasswordEmail)}
                                >
                                  Send OTP
                                </Button>
                              </div>
                            </motion.div>
                          ) : (
                            <motion.div
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              transition={{ duration: 0.2 }}
                              className="space-y-4"
                            >
                              <div className="flex flex-col items-center">
                                <p className="mb-1">Enter OTP</p>
                                <InputOTP
                                  maxLength={4}
                                  value={forgotPasswordOtp}
                                  onChange={(value) => {
                                    setForgotPasswordOtp(value);
                                    if (value.length === 4) {
                                      setShowNewPasswordInputs(true);
                                    }
                                  }}
                                  className={inputStyles}
                                >
                                  <InputOTPGroup className="gap-2 justify-center">
                                    <InputOTPSlot
                                      index={0}
                                      className={`${inputStyles} shadow-md rounded-lg`}
                                    />
                                    <InputOTPSlot
                                      index={1}
                                      className={`${inputStyles} shadow-md rounded-lg`}
                                    />
                                    <InputOTPSlot
                                      index={2}
                                      className={`${inputStyles} shadow-md rounded-lg`}
                                    />
                                    <InputOTPSlot
                                      index={3}
                                      className={`${inputStyles} shadow-md rounded-lg`}
                                    />
                                  </InputOTPGroup>
                                </InputOTP>
                              </div>
                              <AnimatePresence>
                                {showNewPasswordInputs && (
                                  <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: "auto" }}
                                    exit={{ opacity: 0, height: 0 }}
                                    className="space-y-4"
                                  >
                                    <div>
                                      <p className="mb-1">New Password</p>
                                      <div className="relative">
                                        <Input
                                          type={
                                            showNewResetPassword
                                              ? "text"
                                              : "password"
                                          }
                                          value={newPassword}
                                          onChange={(e) => {
                                            setNewPassword(e.target.value);
                                            setPasswordsMatch(
                                              e.target.value ===
                                                newConfirmPassword
                                            );
                                          }}
                                          className={inputStyles}
                                        />
                    {showNewResetPassword ? (
                        <FiEye
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowNewResetPassword(false);
                          }}
                        />
                      ) : (
                        <FiEyeOff
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowNewResetPassword(true);
                          }}
                        />
                      )}
                                      </div>
                                    </div>
                                    <div>
                                      <p className="mb-1">Confirm Password</p>
                                      <div className="relative">
                                        <Input
                                          type={
                                            showConfirmResetPassword
                                              ? "text"
                                              : "password"
                                          }
                                          value={newConfirmPassword}
                                          onChange={(e) => {
                                            setNewConfirmPassword(
                                              e.target.value
                                            );
                                            setPasswordsMatch(
                                              newPassword === e.target.value
                                            );
                                          }}
                                          className={`${inputStyles} ${
                                            !passwordsMatch
                                              ? "border-red-500"
                                              : ""
                                          }`}
                                        />
                          {showConfirmResetPassword ? (
                        <FiEye
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowConfirmResetPassword(false);
                          }}
                        />
                      ) : (
                        <FiEyeOff
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowConfirmResetPassword(true);
                          }}
                        />
                      )}
                                      </div>
                                      {!passwordsMatch && (
                                        <p className="text-xs text-red-500 mt-1">
                                          Passwords do not match
                                        </p>
                                      )}
                                    </div>
                                    <Button
                                      onClick={handleResetPassword}
                                      className="w-full"
                                      disabled={
                                        !passwordsMatch || !newPassword
                                      }
                                    >
                                      Reset Password
                                    </Button>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    ) : (
                      <motion.div className="text-sm w-full mt-4">
                        <p className="mb-1">Enter your Mobile Number or Email</p>
                        <Input
                          type="text"
                          placeholder={placeholder}
                          onChange={handleInputChange}
                          value={inputValue}
                          autoFocus
                          className={`${inputStyles} mt-2`}
                        />
                        <div className="w-full flex items-center relative">
                          <Input
                            type={showpassword ? "text" : "password"}
                            placeholder="Password"
                            onChange={handlePasswordChange}
                            value={password}
                            className={`${inputStyles} mt-2 w-full`}
                          />
                          {showpassword ? (
                            <FiEye
                              className="absolute right-[10px] bottom-[10px] cursor-pointer"
                              onClick={() => {
                                setShowPassword(false);
                              }}
                            />
                          ) : (
                            <FiEyeOff
                              className="absolute right-[10px] bottom-[10px] cursor-pointer"
                              onClick={() => {
                                setShowPassword(true);
                              }}
                            />
                          )}
                        </div>
                        {errorMessage && (
                          <p className="text-red-600 text-xs mt-1">
                            {errorMessage}
                          </p>
                        )}
                        <button
                          onClick={() => {
                            setIsForgotPasswordMode(true);
                            setIsSignUpMode(false);
                          }}
                          className="text-sm text-[#6a3a18] hover:underline mt-2"
                        >
                          Forgotten your password?
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </TabsContent>
                <TabsContent value="signup">
                  <div className="text-sm w-full mt-4">
                    <p className="mb-1">Enter your Mobile Number or Email</p>
                    <Input
                      type="text"
                      placeholder={placeholder}
                      onChange={handleInputChange}
                      value={inputValue}
                      autoFocus
                      className={`${inputStyles} mt-2`}
                    />
                    <div className="flex items-center relative">
                      <Input
                        type={showSignupPassword ? "text" : "password"}
                        placeholder="Password"
                        onChange={handlePasswordChange}
                        value={password}
                        className={`${inputStyles} mt-2`}
                      />
                      {showSignupPassword ? (
                        <FiEye
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowSignupPassword(false);
                          }}
                        />
                      ) : (
                        <FiEyeOff
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowSignupPassword(true);
                          }}
                        />
                      )}
                    </div>

                    <div className="flex items-center relative mt-2">
                      <Input
                        type={showSignupConfirmPassword ? "text" : "password"}
                        placeholder="Confirm Password"
                        onChange={handleConfirmPasswordChange}
                        value={confirmPassword}
                        className={`${inputStyles} ${
                          confirmPassword && password !== confirmPassword
                            ? "border-red-500"
                            : ""
                        }`}
                      />
                      {showSignupConfirmPassword ? (
                        <FiEye
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowSignupConfirmPassword(false);
                          }}
                        />
                      ) : (
                        <FiEyeOff
                          className="absolute right-[10px] bottom-[10px] cursor-pointer"
                          onClick={() => {
                            setShowSignupConfirmPassword(true);
                          }}
                        />
                      )}
                    </div>
                    {/* Password requirements checklist */}
                    <div className="mt-2 space-y-1">
                      {PASSWORD_REQUIREMENTS.map((req, index) => (
                        <div
                          key={index}
                          className={`text-xs flex items-center gap-2 transition-colors ${
                            passwordRequirements[index]
                              ? "text-green-500"
                              : "text-gray-500"
                          }`}
                        >
                          {passwordRequirements[index] ? "✓" : "•"} {req.text}
                        </div>
                      ))}
                    </div>
                    {confirmPassword && password !== confirmPassword && (
                      <p className="text-xs text-red-500 mt-1"></p>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
              <div className="w-full border-2 p-4 pb-6 rounded-b-xl border-t-0">
                {/* Show when either in signup tab OR in signin tab but not in forgot password mode */}
                {(activeTab === "signup" ||
                  (activeTab === "signin" && !isForgotPasswordMode)) && (
                  <div>
                    <p className="text-xs">
                      By continuing, I agree to{" "}
                      <Link href={"/terms&condition"}>
                        <span className="text-red-600 hover:underline">
                          Terms of use
                        </span>
                      </Link>{" "}
                      and{" "}
                      <Link href={"/privacyPolicy"}>
                        <span className="text-red-600 hover:underline">
                          Privacy Policy
                        </span>
                      </Link>{" "}
                      Continue.
                    </p>
                    <Button
                      className="w-full mt-2 h-[40px]"
                      disabled={!!errorMessage}
                      onClick={handleContinue}
                    >
                      Continue
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}