/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import Image from "next/image";
import UserImage from "../../../../public/assets/user/boy.png";
import { PiUserLight } from "react-icons/pi";
import { FiPackage } from "react-icons/fi";
import { toast } from "sonner";
import { GoHeart, GoPasskeyFill } from "react-icons/go";
import { GoLocation, GoTrash } from "react-icons/go";
import { useGlobalState } from "@/context/GlobalStateContext";
import { MdOutlineContactSupport } from "react-icons/md";
import { BiLogOut } from "react-icons/bi";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useState, useEffect } from "react";
import Style from "../styles/profile.module.scss";
import { BadgeCheck, Pen, PenOff } from "lucide-react";
import { api } from "../../../../utils/api";
import { useRouter } from "next/navigation";
import useAuth from "@/hooks/useAuth";
import Cookies from "js-cookie";
import ConfirmModal from "@/components/user/confirmModal";
import VerificationPopup from "@/components/user/verificationPopup";

export default function Profile() {
  const { isTokenExpired, fetchData } = useGlobalState();
  const router = useRouter();
  const [isEditingPersonalInfo, setIsEditingPersonalInfo] = useState(false);
  const [isVerificationOpen, setIsVerificationOpen] = useState(false);
  const [verificationType, setVerificationType] = useState<"mobile" | "email" | null>(null);
  const [isVerificationMode, setIsVerificationMode] = useState(false);
  const [changesMade, setChangesMade] = useState(false);
  const auth = useAuth();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [profileData, setProfileData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");

  const fetchProfileData = async () => {
    try {
      
      interface ProfileResponse {
        status: string;
        data: {
          cust_cmp_name?: string;
          cust_cmp_phone?: string;
          cust_cmp_email?: string;
        };
      }

      const response = await api.get<ProfileResponse>("/api/v1/getProfile");
      if (response.data && response.data.status === "Success") {
        const profileData = response.data.data;
        setProfileData(profileData);
        setFirstName(profileData?.cust_cmp_name?.split(" ")[0] || "");
        setLastName(profileData?.cust_cmp_name?.split(" ").slice(1).join(" ") || "");
        setPhoneNumber(profileData?.cust_cmp_phone || "");
        setEmail(profileData?.cust_cmp_email || "");
      }

      if (!profileData?.cust_cmp_name) {
        fetchData("profile");
      }
      setTimeout(() => {
        setIsInitialLoading(false);
      }, 0);    
    } catch (error) {
      console.error("Failed to fetch profile:", error);
      toast.error("Failed to load profile data");
    } 
  };

  useEffect(() => {
    document.title = "Profile";
    if (!isAuthenticated && !authLoading) {
      console.log("User is not authenticated, redirecting to login page");
      toast("Please log in to view your profile !!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      router.push("/login");
      return;
    }

    fetchProfileData();
  }, [isAuthenticated, authLoading]);

  useEffect(() => {
    if (
      profileData &&
      (firstName !== profileData?.cust_cmp_name?.split(" ")[0] ||
        lastName !== profileData?.cust_cmp_name?.split(" ").slice(1).join(" ") ||
        phoneNumber !== profileData?.cust_cmp_phone ||
        email !== profileData?.cust_cmp_email)
    ) {
      setChangesMade(true);
    } else {
      setChangesMade(false);
    }
  }, [firstName, lastName, phoneNumber, email, profileData]);

  const handleUpdate = async () => {
    try {
      const response = await api.patch("/api/v1/updateProfile", {
        cust_name: `${firstName} ${lastName}`.trim(),
        cust_cmp_phone: phoneNumber,
        cust_cmp_email: email,
      });

      if (response.status === 200) {
        const data = response.data as { status: string; message?: string };
        if (data.status === "Success") {
          toast.success("Profile has been updated!", {
            duration: 5000,
            position: "top-center",
            style: {
              backgroundColor: "#28a745",
              color: "#fff",
              fontSize: "16px",
            },
          });
          setIsEditingPersonalInfo(false);
          fetchProfileData();
        } else {
          toast.error(data.message || "Failed to update profile");
        }
      } else {
        toast.error("Failed to update profile");
      }
    } catch (error) {
      console.error("API request failed:", error);
      toast.error("An error occurred while updating profile");
    }
  };

  const validatePhoneNumber = (value: string) => {
    const regex = /^[0-9]{10}$/;
    return regex.test(value);
  };

  const validateEmail = (value: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(value);
  };

  const handleDeleteConfirmed = async () => {
    setIsModalOpen(false);
    try {
      await api.patch("/api/v1/deleteAcc", {});
      toast.success("Your account has been deleted!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      setTimeout(() => {
        toast("We are sorry to see you go!!", {
          duration: 2000,
          position: "top-center",
          icon: "😔",
        });
      }, 500);
      localStorage.clear();
      Cookies.remove("token");
      router.push("/login");
    } catch (err) {
      console.error("Account deletion error:", err);
      toast.error("Failed to delete account");
    }
  };

  const deleteAccount = async () => {
    setIsModalOpen(true);
  };

  const canChangeMobile = profileData?.email_verified && profileData?.cust_cmp_email;
  const canChangeEmail = profileData?.mobile_verified && profileData?.cust_cmp_phone;

  const handleChangeClick = (type: "mobile" | "email") => {
    if (type === "mobile" && !canChangeMobile) {
      toast.error("Please verify your email before changing your mobile number", {
        duration: 3000,
        position: "top-center",
      });
      return;
    }
    if (type === "email" && !canChangeEmail) {
      toast.error("Please verify your mobile number before changing your email", {
        duration: 3000,
        position: "top-center",
      });
      return;
    }
    setVerificationType(type);
    setIsVerificationMode(false);
    setIsVerificationOpen(true);
  };

  const handleVerifyClick = (type: "mobile" | "email") => {
    if (type === "mobile" && !validatePhoneNumber(phoneNumber)) {
      toast.error("Please enter a valid mobile number to verify", {
        duration: 3000,
        position: "top-center",
      });
      return;
    }
    if (type === "email" && !validateEmail(email)) {
      toast.error("Please enter a valid email address to verify", {
        duration: 3000,
        position: "top-center",
      });
      return;
    }
    setVerificationType(type);
    setIsVerificationMode(true);
    setIsVerificationOpen(true);
  };

  const ProfileSkeleton = () => (
    <div className="animate-pulse space-y-6">
      <div className="flex items-center gap-3 mb-2">
        {/* <div className="w-[60px] h-[60px] rounded-full bg-gray-200"></div> */}
      </div>
      <div className="space-y-4">
        <div className="h-7 w-48 bg-gray-200 rounded"></div>
        <div className="space-y-2">
          <div className="h-5 w-24 bg-gray-200 rounded"></div>
          <div className="flex gap-4">
            <div className="h-10 flex-1 bg-gray-200 rounded"></div>
            <div className="h-10 flex-1 bg-gray-200 rounded"></div>
          </div>
        </div>
        <div className="flex justify-end">
          <div className="h-10 w-32 bg-gray-200 rounded"></div>
        </div>
      </div>
      <div className="space-y-4">
        <div className="h-7 w-48 bg-gray-200 rounded"></div>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="h-10 flex-1 bg-gray-200 rounded"></div>
            <div className="h-5 w-5 bg-gray-200 rounded"></div>
          </div>
          <div className="flex items-center gap-4">
            <div className="h-10 flex-1 bg-gray-200 rounded"></div>
            <div className="h-5 w-5 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div
      className={`w-[90%] mx-auto flex gap-10 text-sm my-10 ${Style.profileContainer}`}
    >
      <div
        className={`min-w-[250px] border shadow py-4 text-[#6a3a18] h-fit ${Style.profileLeftContainer}`}
      >
        <div
          className={`flex items-center gap-2 px-4 pb-4 border-b ${Style.profileImageAndNameContainer}`}
        >
          <Image
            src={UserImage}
            width={1000}
            height={1000}
            quality={100}
            alt="User"
            loading="lazy"
            className="w-[50px] h-[50px] rounded-full"
          />
          <div className="flex flex-col">
            <span className="text-xs font-bold">
              Hello <span className="text-lg">🖐️</span>
            </span>
            <span className="font-bold">
              {profileData?.cust_cmp_name || ""}
            </span>
          </div>
        </div>
        <div
          className={`flex flex-col gap-1 py-4 px-2 ${Style.navigateButtons}`}
        >
          <Link href={"/profile"}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer bg-[#6a3a18] text-white rounded-sm">
              <PiUserLight size={18} />
              <span>Personal Information</span>
            </div>
          </Link>
          <Link
            href={"/orders"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Orders", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📦",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <FiPackage size={18} />
              <span>My Orders</span>
            </div>
          </Link>
          <Link
            href={"/wishlist"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Wishlist", {
                  duration: 3000,
                  position: "top-center",
                  icon: "❤️",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoHeart size={18} />
              <span>My Wishlists</span>
            </div>
          </Link>
          <Link
            href={"/address"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoLocation size={18} />
              <span>Manage Addresses</span>
            </div>
          </Link>
          <Link
            href={"/passwordChange"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoPasskeyFill size={18} />
              <span>Password Change</span>
            </div>
          </Link>
          <div
            onClick={deleteAccount}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <GoTrash size={18} />
            <span>Delete My Account</span>
          </div>
          <ConfirmModal
            isOpen={isModalOpen}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => setIsModalOpen(false)}
          />
          <div
            onClick={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("redirectAfterLogin");
              router.push("/login");
            }}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <BiLogOut size={18} />
            <span>Logout</span>
          </div>
        </div>
      </div>
      <div className={`w-[600px] ${Style.profileRightContainer}`}>
        {isInitialLoading ? (
          <ProfileSkeleton />
        ) : (
          <>
            <div className="flex items-center gap-3 mb-2">
              <Image
                src={UserImage}
                width={1000}
                height={1000}
                quality={100}
                alt="User"
                loading="lazy"
                className="w-[60px] h-[60px] rounded-full"
              />
            </div>
            <h2 className="text-xl font-semibold mb-4">Personal Information</h2>
            <div className="w-full flex flex-col gap-4">
              {isEditingPersonalInfo ? (
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="w-full md:w-1/2 flex flex-col gap-1">
                    <label htmlFor="firstName" className="text-sm font-medium text-gray-700">
                      First Name
                    </label>
                    <Input
                      id="firstName"
                      placeholder="Enter first name"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      disabled={!isEditingPersonalInfo}
                      className="w-full border rounded-md px-3 py-2 bg-white"
                    />
                  </div>
                  <div className="w-full md:w-1/2 flex flex-col gap-1">
                    <label htmlFor="lastName" className="text-sm font-medium text-gray-700">
                      Last Name
                    </label>
                    <Input
                      id="lastName"
                      placeholder="Enter last name"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      disabled={!isEditingPersonalInfo}
                      className="w-full border rounded-md px-3 py-2 bg-white"
                    />
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-1">
                  <label htmlFor="fullName" className="text-sm font-medium text-gray-700">
                    Name
                  </label>
                  <Input
                    id="fullName"
                    value={`${firstName} ${lastName}`.trim() || "--"}
                    disabled
                    className="w-full border rounded-md px-3 py-2 bg-gray-100 cursor-not-allowed text-gray-700"
                  />
                </div>
              )}
              <div className="flex justify-end gap-3">
                {isEditingPersonalInfo ? (
                  <>
                    <Button
                      variant="outline"
                      className="border border-gray-300 text-gray-700 hover:bg-gray-100"
                      onClick={() => setIsEditingPersonalInfo(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      className="bg-[#6a3a18] hover:bg-[#5a2f12] text-white"
                      onClick={handleUpdate}
                      disabled={!changesMade}
                    >
                      Save Changes
                    </Button>
                  </>
                ) : (
                  <Button
                    className="bg-[#6a3a18] hover:bg-[#5a2f12] text-white"
                    onClick={() => setIsEditingPersonalInfo(true)}
                  >
                    Edit Personal Info
                  </Button>
                )}
              </div>
            </div>

            <h2 className="text-lg font-semibold my-4">Contact Information</h2>
            <div className="w-full flex flex-col gap-2">
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="Phone Number"
                    value={phoneNumber}
                    disabled
                    className="w-full bg-gray-100 cursor-not-allowed"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    {profileData?.mobile_verified && validatePhoneNumber(phoneNumber) && (
                      <BadgeCheck size={20} className="text-green-500" />
                    )}
                    {!profileData?.mobile_verified && phoneNumber && validatePhoneNumber(phoneNumber) && (
                      <span
                        className="text-[#6a3a18] hover:text-[#5a2f12] text-sm font-medium cursor-pointer"
                        onClick={() => handleVerifyClick("mobile")}
                      >
                        Verify
                      </span>
                    )}
          
                  </div>
                </div>
                {canChangeMobile ? (
                  <Pen
                    size={20}
                    className="text-[#6a3a18] hover:text-[#5a2f12] cursor-pointer"
                    onClick={() => handleChangeClick("mobile")}
                  />
                ) : (
                  <PenOff
                    size={20}
                    className="text-gray-400 cursor-not-allowed"
                    onClick={() => handleChangeClick("mobile")}
                  />
                )}
              </div>
              <div className="flex items-center gap-4 mt-2">
                <div className="relative flex-1">
                  <Input
                    type="email"
                    placeholder="Email"
                    value={email}
                    disabled
                    className="w-full bg-gray-100 cursor-not-allowed"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    {profileData?.email_verified && validateEmail(email) && (
                      <BadgeCheck size={20} className="text-green-500" />
                    )}
                    {!profileData?.email_verified && email && validateEmail(email) && (
                      <span
                        className="text-[#6a3a18] hover:text-[#5a2f12] text-sm font-medium cursor-pointer"
                        onClick={() => handleVerifyClick("email")}
                      >
                        Verify
                      </span>
                    )}
           
                  </div>
                </div>
                {canChangeEmail ? (
                  <Pen
                    size={20}
                    className="text-[#6a3a18] hover:text-[#5a2f12] cursor-pointer"
                    onClick={() => handleChangeClick("email")}
                  />
                ) : (
                  <PenOff
                    size={20}
                    className="text-gray-400 cursor-not-allowed"
                    onClick={() => handleChangeClick("email")}
                  />
                )}
              </div>
            </div>
          </>
        )}
      </div>
      <VerificationPopup
        open={isVerificationOpen}
        onOpenChange={setIsVerificationOpen}
        type={verificationType || "mobile"}
        initialValue={verificationType === "mobile" ? phoneNumber : email}
        verified={verificationType === "mobile" ? profileData?.mobile_verified : profileData?.email_verified}
        isVerificationMode={isVerificationMode}
        onVerified={() => {
          fetchProfileData();
        }}
      />
    </div>
  );
}