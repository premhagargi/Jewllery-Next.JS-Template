/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @next/next/no-img-element */
"use client";

import { useState, Suspense } from "react";
import Image from "next/image";
import dummyImage from "../../../../public/assets/user/product.png";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../../utils/api";
import { useGlobalState } from "@/context/GlobalStateContext";
import config from "../../../../config.json";
import fallbackImage from "../../../../public/assets/user/product-placeholder.jpg";

interface PaymentMode {
  id: number;
  payment_method: string;
}

interface OrderItem {
  order_item_id: number;
  company_id: string;
  est_shop_id: number;
  order_id: number;
  product_id: number;
  quantity: number;
  price: string;
  total_price: string;
  created_at: string;
  ProductMaster?: { product_name: string };
  EstShopInventories?: { image_path: string }[];
}

interface OrderDataType {
  company_id: string;
  id: number;
  order_id: string;
  est_shop_id: number;
  user_id: number;
  address_id: number;
  total_price: string;
  payment_method_id: number;
  payment_status: string;
  order_status: string;
  delivery_status: string;
  created_at: string;
  updated_at: string;
  jw_payment_mode: PaymentMode;
  jw_order_items: OrderItem[];
}

function OrderConfirm() {
  const { fetchData, addressList } = useGlobalState();
  const [showMore, setShowMore] = useState(false);
  const router = useRouter();

  const [orderDetails, setOrderDetails] = useState<any>(null);
  const [address, setAddress] = useState<any>(null);
  const [orderItems, setOrderItems] = useState<any[]>([]);

  const handleContinueShop = () => {
    router.push("/"); // Redirect to home page
  };

  useEffect(() => {
    fetchData("cart");
    try {
      // Retrieve order details
      const storedOrderDetails = sessionStorage.getItem("orderDetails");
      if (!storedOrderDetails) {
        console.error("No order details found in sessionStorage");
        return;
      }
      const orderData = JSON.parse(storedOrderDetails);
      setOrderDetails(orderData[0]);
      setOrderItems(orderData[0].jw_order_items || []); // Set order items

      // Retrieve address details
      const storedAddress = sessionStorage.getItem("orderAddress");
      if (storedAddress) {
        const addressData = JSON.parse(storedAddress);
        setAddress(addressData);
        console.log(addressData)
      }
    } catch (error) {
      console.error("Error fetching order details:", error);
    }
  }, []);

    useEffect(() => {
      
    console.log("Leaving the order confirmation page")
      return () => {
        sessionStorage.removeItem("orderDetails");
        sessionStorage.removeItem("orderAddress");
      }
    }, [])

  const displayedItems = showMore
    ? orderItems ?? []
    : (orderItems ?? []).slice(0, 2);

    const getImagePath = (item: OrderItem) => {
      try {
        // Get the list of images from the first inventory item
        const inventories = item?.EstShopInventories || [];
        
        // Loop through each inventory and get the image path
        for (let i = 0; i < inventories.length; i++) {
          const rawPath = inventories[i]?.image_path;
          if (rawPath) {
            const parsedImages = JSON.parse(rawPath);
            if (Array.isArray(parsedImages) && parsedImages[0]?.src) {
              return `${config.NEXT_PUBLIC_API_URL}/${parsedImages[0].src}`;
            }
          }
        }
        
        // If no valid image found, return fallback image
        return fallbackImage.src;
      } catch (error) {
        console.error("Error parsing image_path for item:", item, error);
        return fallbackImage.src;
      }
    };
    

  return (
    <div>
      <div className="w-[90%] h-auto mx-auto my-10">
        <div className="flex gap-6 text-sm">
          <div className="w-[50%] flex flex-col gap-14 px-6 py-10">
            <div className="flex flex-col gap-3">
              <span className="text-lg font-bold">Thanks you for purchase</span>
              <span>
                Your order will be processed within 2 working days. We will
                notify you by email once your order has been shipped.
              </span>
            </div>
            <div className="flex flex-col gap-4 w-full">
              <span>Billing Details</span>
              <div className="w-[60%] flex flex-col gap-2">
                <div className="w-full flex justify-between">
                  <span className="font-bold">Name</span>
                  <span>{address?.name}</span>
                </div>
                <div className="w-full flex justify-between">
                  <span className="font-bold">Address</span>
                  <span className="text-right">
                    {address?.address_line1 + " " + address?.address_line2}
                  </span>
                </div>
                <div className="w-full flex justify-between">
                  <span className="font-bold">Phone</span>
                  <span>+91 {address?.contact_no}</span>
                </div>
                <Button className="mt-8">Track Your Order</Button>
                <Button
                  onClick={handleContinueShop}
                  className="mt-3 bg-[#9a602e] hover:bg-[#814d24] border"
                >
                  Continue Shopping
                </Button>
              </div>
            </div>
          </div>
          <div className="w-[50%] overflow-hidden text-slate-100">
            <div className="w-[70%] bg-[#9a602e] mx-auto rounded-lg py-6 flex flex-col justify-center items-center">
              <div className="w-full px-8">
                <div className="border-b w-full pb-3 mb-4">
                  <span className="text-lg">Order Summary</span>
                </div>
                <div className="flex justify-between">
                  <div className="flex flex-col text-left">
                    <span className="text-xs">Date</span>
                    <span>
                      {orderDetails?.created_at
                        ? new Date(orderDetails.created_at).toLocaleDateString(
                            "en-GB",
                            {
                              day: "2-digit",
                              month: "short",
                              year: "numeric",
                            }
                          )
                        : "N/A"}
                    </span>
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs">Order Number</span>
                    <span>{orderDetails?.order_id}</span>
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs">Payment Method</span>
                    <span>{orderDetails?.jw_payment_mode?.payment_method}</span>
                  </div>
                </div>
              </div>
              <div className="w-[106%] flex justify-between items-center mt-10">
                <div className="bg-white w-[25px] h-[25px] rounded-full"></div>
                <div
                  className="border-b w-[80%] border-dashed h-[1px]"
                  style={{ borderSpacing: "5px" }}
                ></div>
                <div className="bg-white w-[25px] h-[25px] rounded-full"></div>
              </div>
              <div className="w-full px-8 my-8 flex flex-col gap-3">
                {(displayedItems ?? []).map((item, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center"
                  >
                    <div className="flex gap-2">
                      <img
                        src={getImagePath(item)}
                        alt={
                          item?.ProductMaster?.product_name || "Product Image"
                        }
                        loading="lazy"
                        className="w-[80px] h-[80px] object-cover rounded-xl"
                        width={80}
                        height={80}
                        onError={(e) => {
                          e.currentTarget.src = fallbackImage.src;
                        }}
                      />
                      <div className="flex flex-col gap-1">
                        <span>{item?.ProductMaster?.product_name}</span>
                        <span>Qty: {item.quantity}</span>
                      </div>
                    </div>
                    <div className="">
                      <span className="font-medium">
                        ₹
                        {item.total_price
                          ? new Intl.NumberFormat("en-IN", {
                              maximumFractionDigits: 2,
                            }).format(Number(item.total_price))
                          : "0"}
                      </span>
                    </div>
                  </div>
                ))}
                {orderItems?.length > 2 && (
                  <button
                    className="text-xs underline text-right"
                    onClick={() => setShowMore(!showMore)}
                  >
                    {showMore ? "Show Less" : "Show More"}
                  </button>
                )}
              </div>
              <div className="w-full px-8">
                <div className="border-y py-4">
                  <div className="w-full flex justify-between">
                    <span>SUB TOTAL</span>
                    <span>
                      ₹
                      {orderDetails?.total_price
                        ? new Intl.NumberFormat("en-IN", {
                            maximumFractionDigits: 2,
                          }).format(Number(orderDetails.total_price))
                        : "0"}
                    </span>
                  </div>
                </div>
                <div className="w-full flex justify-between py-4">
                  <span>ORDER TOTAL</span>
                  <span>
                    ₹
                    {orderDetails?.total_price
                      ? new Intl.NumberFormat("en-IN", {
                          maximumFractionDigits: 2,
                        }).format(Number(orderDetails.total_price))
                      : "0"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Wrap the OrderConfirm component with Suspense
export default function OrderConfirmPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <OrderConfirm />
    </Suspense>
  );
}
