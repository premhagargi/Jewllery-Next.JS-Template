// /* eslint-disable react-hooks/exhaustive-deps */
// "use client";
// import { useState } from "react";
// import { useRouter } from "next/navigation";
// import Image from "next/image";
// import Style from "./styles/app.module.scss";

// // components
// import JewelleryCard from "@/components/user/jewelleryCard";
// import HeroSwiper from "@/components/user/heroSwiper";
// import HeroGrid from "@/components/user/heroGrid";
// import Heading from "@/components/user/heading";
// import Link from "next/link";
// import CategorySwiper from "@/components/user/categorySwiper";
// import Banner from "@/components/user/banner";
// import CardSwiper from "@/components/user/productCardSwiper";
// import WebInfo from "@/components/user/webInfo";
// import Tabs from "@/components/user/tabs";
// import Testimonial from "@/components/user/testimonial";
// import { useEffect } from "react";
// import { useGlobalState } from "@/context/GlobalStateContext";
// import { api } from "../../../utils/api";

// //assets
// import ProductImage from "../../../public/assets/user/product.png";
// import ProductImage1 from "../../../public/assets/user/product1.png";
// import ProductImage2 from "../../../public/assets/user/product2.png";
// import ProductImage3 from "../../../public/assets/user/product3.png";
// import config from "../../../config.json";
// import React from "react";
// const COMPANY_ID = config.COMPANY_ID;

// export default function Home() {
//   const company_id = COMPANY_ID;

//   const router = useRouter();
//   const { categoryList } = useGlobalState();
//   const [productlist, setProducts] = useState<any[]>([]);
//   const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
//   const [loading, setLoading] = useState(false);
//   const [hasMore, setHasMore] = useState(true);
//   // Product array
//   const fetchProducts = async (
//     categoryIds: string[] = [],
//     page = 1,
//     limit = 10
//   ) => {
//     try {
//       setLoading(true);
//       const categoryParam = categoryIds.length > 0 ? categoryIds.join(",") : "";

//       const url = `/api/v1/products/productList?category=&category_id=${categoryParam}&company_id=${company_id}&page=${page}&limit=${limit}`;

//       const response = await api.get(url);
//       if (response.data) {
//         const newProducts = (response.data as { data: any[] }).data || [];
//         setProducts((prev) =>
//           page === 1 ? newProducts : [...prev, ...newProducts]
//         );
//         setFilteredProducts((prev) =>
//           page === 1 ? newProducts : [...prev, ...newProducts]
//         );

//         // Check if more products are available
//         if (newProducts.length < limit) {
//           setHasMore(false);
//         }
//       } else {
//         console.error("Error fetching products");
//       }
//     } catch (error) {
//       console.error("API request failed:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     setTimeout(() => {
//       fetchProducts();
//     }, 0);
//     return () => {};
//   }, []);

//   const productsArray = [
//     {
//       product_id: "1",
//       product_name: "Silver Earrings",
//       price: 1000,
//       est_shop_id: "101",
//       name: "Silver Earrings",
//       discountPrice: 500,
//       actualPrice: 1000,
//       savedPrice: 500,
//       discount: "50% OFF",
//       image: ProductImage,
//     },
//     {
//       product_id: "2",
//       product_name: "Gold Necklace",
//       price: 4000,
//       est_shop_id: "102",
//       name: "Gold Necklace",
//       discountPrice: 2000,
//       actualPrice: 4000,
//       savedPrice: 2000,
//       discount: "50% OFF",
//       image: ProductImage1,
//     },
//     // other products...
//   ];

//   const categories = [
//     {
//       id: 1,
//       name: "Rings",
//       image: ProductImage1,
//     },
//     {
//       id: 2,
//       name: "Necklaces",
//       image: ProductImage2,
//     },
//     {
//       id: 3,
//       name: "Earrings",
//       image: ProductImage3,
//     },
//     {
//       id: 4,
//       name: "Bracelets",
//       image: ProductImage,
//     },
//     {
//       id: 5,
//       name: "Pendants",
//       image: ProductImage1,
//     },
//     {
//       id: 6,
//       name: "Rings",
//       image: ProductImage1,
//     },
//     {
//       id: 7,
//       name: "Necklaces",
//       image: ProductImage2,
//     },
//     {
//       id: 8,
//       name: "Earrings",
//       image: ProductImage3,
//     },
//     {
//       id: 9,
//       name: "Bracelets",
//       image: ProductImage,
//     },
//     {
//       id: 10,
//       name: "Pendants",
//       image: ProductImage1,
//     },
//   ];

//   useEffect(() => {
//     document.title = "Home";
//   }, []);

//   return (
//     <div className={Style.mainContainer}>
//       <HeroSwiper />
//       <HeroGrid />
//      <div className="w-[90%] mx-auto flex flex-col justify-center items-center my-20">
//         <Heading message="Shop By Category" />
//         <Link href={"/shop"} className="text-xs text-[#9a602e] mt-2">
//           VIEW ALL
//         </Link>
//         <CategorySwiper categories={categoryList} />
//       </div>
//       <div className="flex flex-col justify-center items-center">
//         <Heading message="Everyday Elegance" />
//         <Link href={"/shop"} className="text-xs text-[#9a602e] mt-2">
//           VIEW ALL
//         </Link>
//         {loading ? (
//           <div className="w-[90%] h-[350px] flex gap-6 my-10 mt-8">
//             {Array.from({ length: 5 }).map((_, index) => (
//               <div
//                 key={index}
//                 className="w-[230px] h-[250px] bg-gray-200 rounded-md animate-pulse"
//               >
//                 <div className="w-full h-[70%] bg-gray-300 rounded-t-md"></div>
//                 <div className="w-full h-[30%] p-4 flex flex-col gap-2">
//                   <div className="w-3/4 h-4 bg-gray-400 rounded"></div>
//                   <div className="w-1/2 h-4 bg-gray-400 rounded"></div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         ) : (
//           <CardSwiper products={productlist} />
//         )}
//       </div>
//       <Banner />
//       <div className={`w-[95%] mx-auto my-20 ${Style.featureProductContainer}`}>
//         {/* <Heading message="Feature Products" /> */}
//         {/* <div
//           className={`w-full h-[580px] flex my-8 gap-6 ${Style.featureProductInnerContainer}`}
//         >
//           <div
//             className={`w-[30%] h-full relative ${Style.featureProductIamgeContainer}`}
//           >
//             <Image
//               src={gridImage1}
//               width={1000}
//               height={1000}
//               quality={100}
//               alt=""
//               loading="lazy"
//               className="w-full h-full object-cover"
//             />
//             <div className="w-full h-full absolute top-0 flex justify-center items-end">
//               <div className="flex flex-col text-center tracking-widest leading-[35px] mb-8">
//                 <p className="">NEW ARRIVAL</p>
//                 <p className="text-[#9a602e] text-[2.6rem]">10%</p>
//                 <p>OFF</p>
//               </div>
//             </div>
//           </div>
//           <div
//             className={`w-[70%] h-full grid grid-cols-4 place-items-start overflow-scroll overflow-x-hidden ${Style.featureProductCardContainer}`}
//           >

//           </div>
//         </div> */}
//       </div>
//       <Tabs />
//       <div
//         className={`w-[95%] mx-auto my-20 ${Style.BestSellingProductContainer}`}
//       >
//         {/* <Heading message="Best Selling Products" /> */}
//         {/* <div
//           className={`w-full h-[580px] flex my-8 gap-6 ${Style.BestSellingProductInnerContainer}`}
//         >
//           <div
//             className={`w-[70%] h-full grid grid-cols-4 place-items-start overflow-scroll overflow-x-hidden ${Style.BestSellingProductCardContainer}`}
//           >
//           </div>
//           <div
//             className={`w-[30%] h-full relative ${Style.BestSellingProductIamgeContainer}`}
//           >
//             <Image
//               src={gridImage2}
//               width={1000}
//               height={1000}
//               quality={100}
//               alt=""
//               loading="lazy"
//               className="w-full h-full object-cover"
//             />
//             <div className="w-full h-full absolute top-0 flex justify-center items-end">
//               <div className="flex flex-col text-center tracking-widest leading-[35px] mb-8">
//                 <p className="">NEW ARRIVAL</p>
//                 <p className="text-[#9a602e] text-[2.6rem]">30%</p>
//                 <p>OFF</p>
//               </div>
//             </div>
//           </div>
//         </div> */}
//       </div>
//       <WebInfo />
//       <Testimonial />
//     </div>
//   );
// }


// pages/Home.tsx
/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Style from "./styles/app.module.scss";
import { useGlobalState } from "@/context/GlobalStateContext";
import VerificationPopup from "@/components/user/verifyer";

// components
import JewelleryCard from "@/components/user/jewelleryCard";
import HeroSwiper from "@/components/user/heroSwiper";
import HeroGrid from "@/components/user/heroGrid";
import Heading from "@/components/user/heading";
import Link from "next/link";
import CategorySwiper from "@/components/user/categorySwiper";
import Banner from "@/components/user/banner";
import CardSwiper from "@/components/user/productCardSwiper";
import WebInfo from "@/components/user/webInfo";
import Tabs from "@/components/user/tabs";
import Testimonial from "@/components/user/testimonial";
import { api } from "../../../utils/api";

// assets
import ProductImage from "../../../public/assets/user/product.png";
import ProductImage1 from "../../../public/assets/user/product1.png";
import ProductImage2 from "../../../public/assets/user/product2.png";
import ProductImage3 from "../../../public/assets/user/product3.png";
import config from "../../../config.json";
import themeConfig from "../../../theme.config.json";

const COMPANY_ID = config.COMPANY_ID;

export default function Home() {
  const company_id = COMPANY_ID;
  const router = useRouter();
  const { categoryList, profileData, fetchData, justLoggedIn, setJustLoggedIn } = useGlobalState();
  const [productlist, setProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [showMobileVerification, setShowMobileVerification] = useState(false);
  const [showEmailVerification, setShowEmailVerification] = useState(false);
    // Theme Logic
    const THEME_ID = themeConfig.activeTheme;
    const isLuxury = THEME_ID === "luxury";
  
  // Product array
  const fetchProducts = async (
    categoryIds: string[] = [],
    page = 1,
    limit = 10
  ) => {
    try {
      setLoading(true);
      const categoryParam = categoryIds.length > 0 ? categoryIds.join(",") : "";

      const url = `/api/v1/products/productList?category=&category_id=${categoryParam}&company_id=${company_id}&page=${page}&limit=${limit}`;

      const response = await api.get(url);
      if (response.data) {
        const newProducts = (response.data as { data: any[] }).data || [];
        setProducts((prev) =>
          page === 1 ? newProducts : [...prev, ...newProducts]
        );
        setFilteredProducts((prev) =>
          page === 1 ? newProducts : [...prev, ...newProducts]
        );

        // Check if more products are available
        if (newProducts.length < limit) {
          setHasMore(false);
        }
      } else {
        console.error("Error fetching products");
      }
    } catch (error) {
      console.error("API request failed:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setTimeout(() => {
      fetchProducts();
      fetchData("profile");
      fetchData("company");
    }, 0);
    return () => {};
  }, []);

  // useEffect(() => {
  //   document.title = "Home";
  //   console.log(justLoggedIn, profileData);
    
  //   if (justLoggedIn && profileData) {
  //     // Show popup only on fresh login
  //     if (
  //       !profileData.mobile_verified &&
  //       profileData.cust_cmp_phone !== undefined &&
  //       profileData.cust_cmp_phone !== null
  //     ) {
  //       setShowMobileVerification(true);
  //     } else if (
  //       !profileData.email_verified &&
  //       profileData.cust_cmp_email !== undefined &&
  //       profileData.cust_cmp_email !== null
  //     ) {
  //       setShowEmailVerification(true);
  //     }
  //     setJustLoggedIn(false); // Reset justLoggedIn after checking
  //   } else {
  //     // Prevent popups on refresh or when not just logged in
  //     setShowMobileVerification(false);
  //     setShowEmailVerification(false);
  //   }
  // }, [profileData, justLoggedIn, setJustLoggedIn]);

  useEffect(() => {
  const timer = setTimeout(() => {
    document.title = "Home";
    // console.log(justLoggedIn, profileData);

    if (justLoggedIn && profileData) {
      // Show popup only on fresh login
      if (profileData.mobile_verified == false) {
        setShowMobileVerification(true);
      } else if (profileData.email_verified == false) {
        setShowEmailVerification(true);
      }
      setJustLoggedIn(false); // Reset justLoggedIn after checking
    } else {
      // Prevent popups on refresh or when not just logged in
      setShowMobileVerification(false);
      setShowEmailVerification(false);
    }

  }, 3000); // Delay by 3 seconds

  return () => clearTimeout(timer); // Cleanup timer on unmount or dependency change
}, []);

  const handleVerificationSuccess = async (type: "mobile" | "email") => {
    await fetchData("profile"); // Refetch profile to update verification status
    setShowMobileVerification(false);
    setShowEmailVerification(false);
  };

  const productsArray = [
    {
      product_id: "1",
      product_name: "Silver Earrings",
      price: 1000,
      est_shop_id: "101",
      name: "Silver Earrings",
      discountPrice: 500,
      actualPrice: 1000,
      savedPrice: 500,
      discount: "50% OFF",
      image: ProductImage,
    },
    {
      product_id: "2",
      product_name: "Gold Necklace",
      price: 4000,
      est_shop_id: "102",
      name: "Gold Necklace",
      discountPrice: 2000,
      actualPrice: 4000,
      savedPrice: 2000,
      discount: "50% OFF",
      image: ProductImage1,
    },
    // other products...
  ];

  const categories = [
    {
      id: 1,
      name: "Rings",
      image: ProductImage1,
    },
    {
      id: 2,
      name: "Necklaces",
      image: ProductImage2,
    },
    {
      id: 3,
      name: "Earrings",
      image: ProductImage3,
    },
    {
      id: 4,
      name: "Bracelets",
      image: ProductImage,
    },
    {
      id: 5,
      name: "Pendants",
      image: ProductImage1,
    },
    {
      id: 6,
      name: "Rings",
      image: ProductImage1,
    },
    {
      id: 7,
      name: "Necklaces",
      image: ProductImage2,
    },
    {
      id: 8,
      name: "Earrings",
      image: ProductImage3,
    },
    {
      id: 9,
      name: "Bracelets",
      image: ProductImage,
    },
    {
      id: 10,
      name: "Pendants",
      image: ProductImage1,
    },
  ];


return (
  <div className={Style.mainContainer}>
    <HeroSwiper />

    {/* ✅ Basic theme keeps HeroGrid at the top */}
    {!isLuxury && <HeroGrid />}

    {/* Other components */}
    <div className="flex flex-col justify-center items-center">
<div className={`${isLuxury ? "font-abril" : ""}`}>
  <Heading message="Everyday Elegance" />
</div>
      <Link href={"/shop"} className="text-xs text-[#9a602e] mt-2">
        VIEW ALL
      </Link>
      {loading ? (
        <div className="w-[90%] h-[350px] flex gap-6 my-10 mt-8">
          {Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="w-[230px] h-[250px] bg-gray-200 rounded-md animate-pulse"
            >
              <div className="w-full h-[70%] bg-gray-300 rounded-t-md"></div>
              <div className="w-full h-[30%] p-4 flex flex-col gap-2">
                <div className="w-3/4 h-4 bg-gray-400 rounded"></div>
                <div className="w-1/2 h-4 bg-gray-400 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <CardSwiper products={productlist} />
      )}
    </div>

    <Banner />
    <div className={`w-[95%] mx-auto my-20 ${Style.featureProductContainer}`}>
      {/* Optional: Feature products */}
    </div>

    <Tabs />
    <div className={`w-[95%] mx-auto my-20 ${Style.BestSellingProductContainer}`}>
      {/* Optional: Best selling */}
    </div>

        {/* ✅ Luxury theme puts HeroGrid at the bottom */}
    {isLuxury && <HeroGrid />}
    <WebInfo />
    <Testimonial />



    {/* Verification Popups */}
    {profileData && (
      <>
        <VerificationPopup
          open={showMobileVerification}
          onOpenChange={setShowMobileVerification}
          type="mobile"
          onVerified={() => handleVerificationSuccess("mobile")}
        />
        <VerificationPopup
          open={showEmailVerification}
          onOpenChange={setShowEmailVerification}
          type="email"
          onVerified={() => handleVerificationSuccess("email")}
        />
      </>
    )}
  </div>
);

}