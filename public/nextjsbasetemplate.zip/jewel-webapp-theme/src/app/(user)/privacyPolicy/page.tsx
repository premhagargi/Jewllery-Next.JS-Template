import React from "react";
import Head from "next/head";

export default function PrivacyPolicy() {
  return (
    <>
      <Head>
        <title>Privacy Policy | Maharana</title>
        <meta
          name="description"
          content="Learn how Maharana collects, uses, and protects your personal data."
        />
      </Head>
      <main className="px-4 sm:px-8 md:px-16 lg:px-48 py-12 bg-white text-gray-800">
        <h1 className="text-3xl font-bold mb-6 text-center">Privacy Policy</h1>

        <section className="mb-10">
          <p className="text-lg">
            At <strong>Maharana</strong>, your privacy is our priority. This
            Privacy Policy explains how we collect, use, and protect your
            personal information when you interact with our website.
          </p>
        </section>

        <hr className="mb-10 border-gray-300" />

        <section className="mb-10">
          <h2 className="text-2xl font-semibold mb-4">
            1. Information We Collect
          </h2>
          <p>
            To provide you with a secure and personalized experience, we collect
            information such as:
          </p>
          <ul className="list-disc ml-6 mt-2 space-y-1">
            <li>Phone number (used for login)</li>
            <li>Full name</li>
            <li>Email address</li>
            <li>Contact number</li>
            <li>Gender</li>
            <li>Birth date</li>
            <li>Shipping address</li>
          </ul>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-semibold mb-4">
            2. How We Use Your Information
          </h2>
          <p>We use the information you provide to:</p>
          <ul className="list-disc ml-6 mt-2 space-y-1">
            <li>Create and manage your account securely</li>
            <li>Process and deliver your orders</li>
            <li>Personalize your shopping experience</li>
            <li>Send you updates, offers, and event invites</li>
            <li>Improve our products, services, and website</li>
            <li>Comply with legal obligations and prevent fraud</li>
          </ul>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-semibold mb-4">3. Data Security</h2>
          <p>
            Your trust means everything to us. We use industry-standard security
            measures to safeguard your personal information against unauthorized
            access, misuse, or disclosure.
          </p>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-semibold mb-4">
            4. Sharing of Information
          </h2>
          <p>
            We do not sell or rent your personal data. Your information may be
            shared with:
          </p>
          <ul className="list-disc ml-6 mt-2 space-y-1">
            <li>
              Trusted service partners (e.g., delivery services, payment
              gateways) – only as needed to complete your orders
            </li>
            <li>
              Legal authorities, if required by applicable law or legal process
            </li>
          </ul>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-semibold mb-4">
            5. Cookies and Tracking
          </h2>
          <p>
            Maharana uses cookies and similar technologies to enhance your
            browsing experience and gather analytics to continuously improve our
            offerings.
          </p>
        </section>

        <section className="mb-10">
          <h2 className="text-2xl font-semibold mb-4">6. Policy Updates</h2>
          <p>
            This Privacy Policy may be updated from time to time. Any changes
            will be posted here with the updated date. We recommend reviewing
            this page periodically.
          </p>
        </section>

        {/* <footer className="text-center text-sm text-gray-500 mt-12">
          © {new Date().getFullYear()} Maharana. All rights reserved.
        </footer> */}
      </main>
    </>
  );
}
