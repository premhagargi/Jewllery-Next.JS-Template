/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import React, { Suspense, useEffect, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { api } from "../../../../utils/api";
import dummyImage from "../../../../public/assets/user/product-placeholder.jpg";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/effect-fade";
import { toast } from "sonner";
import { Pagination, EffectFade } from "swiper/modules";
import Image from "next/image";
import { Button } from "../../../components/ui/button";
import { GoHeart } from "react-icons/go";
import Heading from "../../../components/user/heading";
import CardSwiper from "../../../components/user/productCardSwiper";
import { useGlobalState } from "../../../context/GlobalStateContext";
import error from "next/error";
import config from "../../../../config.json";
import Style from "../styles/product.module.scss";
import "./page.css";
import { useQuery } from "@tanstack/react-query";
const COMPANY_ID = config.COMPANY_ID;
import Cookies from "js-cookie";
import ZoomImage from "../../../components/user/zoomedImage";

function Product() {
  const router = useRouter();
  const { fetchData, loading } = useGlobalState();
  const searchParams = useSearchParams();
  let encodedProductId = searchParams.get("id");
  let encodedCatId = searchParams.get("cat");
  let shopId = searchParams.get("shopId");
  const company_id = COMPANY_ID;
  let token: string | null = null;

  if (typeof window !== "undefined") {
    token = Cookies.get("token");
  }
  let product_name = "";
  let product_desc = "";
  const [isShaking, setIsShaking] = useState(false);
  const [productData, setProductData] = useState<any>(null);
  const [quantity, setQuantity] = useState<number>(1); // Track quantity
  const [addedToBag, setAddedToBag] = useState<boolean>(false); // Track if the product is added to the bag
  const [addedToWishlist, setAddedToWishlist] = useState<boolean>(false); // Track if the product is added to the bag
  const [loadingProduct, setLoadingProduct] = useState<boolean>(true); // Track loading state
  const [showAllReviews, setShowAllReviews] = useState(false);
  const reviewsRef = useRef<HTMLDivElement>(null);
  const [productlist, setProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);

  // Function to decode the Base64 encoded string
  const decodeParam = (param: string): string => {
    try {
      return atob(decodeURIComponent(param));
    } catch (error) {
      console.error("Error decoding parameter:", error);
      return "";
    }
  };

  try {
    if (typeof encodedProductId === "string") {
      encodedProductId = decodeParam(encodedProductId);
    }
    if (typeof shopId === "string") {
      shopId = decodeParam(shopId);
    }
    if (typeof encodedCatId === "string") {
      encodedCatId = decodeParam(encodedCatId);
    }
  } catch (error) {
    console.error("Error decoding parameters:", error);
  }

  const filterSimilarProducts = (products: any[], currentProductId: string | null) => {
    if (!currentProductId) return products; // Return unfiltered products if currentProductId is null
    return products.filter(product => product.id !== parseInt(currentProductId));
  };

  const fetchProducts = async (categoryParam: any, page: any, limit: any) => {
    try {
      const url = `/api/v1/products/productList?category=&category_id=${categoryParam}&company_id=${company_id}&page=${page}&limit=${limit}`;
      const response = await api.get(url);
      if (response.data) {
        const newProducts = (response.data as { data: any[] }).data || [];
        setProducts((prev) =>
          page === 1 ? newProducts : [...prev, ...newProducts]
        );
        setFilteredProducts((prev) =>
          page === 1
            ? filterSimilarProducts(newProducts, encodedProductId)
            : [...prev, ...filterSimilarProducts(newProducts, encodedProductId)]
        );
      } else {
        console.error("Error fetching products");
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  useEffect(() => {
    if (encodedProductId && shopId) {
      fetchProductData();
    }
    if (encodedCatId) {
      fetchProducts(encodedCatId, 1, 10);
    }
    const storedParams = localStorage.getItem("addToCartParams");
    if (storedParams) {
      const { product_id, quantity, est_shop_id } = JSON.parse(storedParams);
      if (product_id && quantity && est_shop_id) {
        addToCart(product_id, quantity, est_shop_id);
      }
      localStorage.removeItem("addToCartParams");
    }
    setFilteredProducts(filterSimilarProducts(productlist, encodedProductId));
  }, []);

  const fetchProductData = async () => {
    try {
      const url = `/api/v1/products/product-details?product_id=${encodedProductId}&est_shop_id=${shopId}&company_id=${company_id}`;
      const response = await api.get(url);
      if (response.data && ((response.data as { data: any[] }).data || [])) {
        setTimeout(() => {
          setProductData((response.data as { data: any[] }).data || []);
        }, 150);
        // console.log(productData)
        product_name = (response.data as any)?.data?.ProductMaster?.product_name;
        product_desc = (response.data as any)?.data?.ProductMaster?.product_desc;
        document.title = `${product_name}`;
      } else {
        console.error("No product data found");
      }
      // console.log(response.data);
    } catch (error) {
      console.error("API request failed:", error);
    } finally {
      setLoadingProduct(false);
    }
  };

  const calculateAverageRating = (): number => {
    const ratings = productData?.jw_product_ratings || [];
    if (ratings.length === 0) return 0;
    const total = ratings.reduce(
      (sum: number, rating: { product_rating: number }) =>
        sum + rating.product_rating,
      0
    );
    return parseFloat((total / ratings.length).toFixed(1));
  };

  const handleScrollToReviews = () => {
    if (reviewsRef.current) {
      reviewsRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleClick = () => {
    if (productData?.jw_wishlist != null) {
      removeFromWishlist(encodedProductId, shopId);
    } else {
      setIsShaking(true);
      setTimeout(() => {
        addToWishlist(encodedProductId, shopId);
        setIsShaking(false);
      }, 500);
    }
  };

  const addToCart = async (
    product_id: any,
    quantity: number,
    est_shop_id: any
  ) => {
    console.log(product_id, quantity, est_shop_id);
    try {
      if (!token) {
        toast("Please Log In to Add to Cart", {
          duration: 3000,
          position: "top-center",
          icon: "🛒",
        });
        localStorage.setItem("redirectAfterLogin", window.location.href);
        localStorage.setItem(
          "addToCartParams",
          JSON.stringify({ product_id, quantity, est_shop_id })
        );
        router.push("/login");
        return;
      }
      const response = await api.post("/api/v1/cart/addtocart", {
        product_id: productData?.id,
        quantity,
        est_shop_id,
      });
      if (
        response.data &&
        (response.data as { status: string }).status === "Success"
      ) {
        fetchProductData();
        fetchData("cart");
        toast.success("Item has been added to cart!", {
          duration: 5000,
          position: "top-center",
          icon: "🛒",
          style: {
            backgroundColor: "#28a745",
            color: "#fff",
            fontSize: "16px",
          },
        });
      } else {
        console.error("Failed to add product to cart");
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  const removeCartItem = async (cart_id: any) => {
    try {
      if (!token) {
        toast("Please Log In to Add to Cart", {
          duration: 3000,
          position: "top-center",
          icon: "🛒",
        });
        localStorage.setItem("redirectAfterLogin", window.location.href);
        router.push("/login");
        return;
      }
      const response = await api.delete(
        `/api/v1/cart/removecart?id=${cart_id}`
      );
      if (
        response.data &&
        (response.data as { status: string }).status === "Success"
      ) {
        toast.success("Item has been removed from cart!", {
          duration: 5000,
          position: "top-center",
          icon: "🛒",
          style: {
            backgroundColor: "#fff",
            color: "#000",
            fontSize: "16px",
          },
        });
        fetchProductData();
        fetchData("cart");
      } else {
        console.error("Failed to add product to cart");
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  const updateQuantity = async (cart_id: number, quantity: number) => {
    if (!token) {
      toast("Please log in to view your cart", {
        duration: 3000,
        position: "top-center",
        icon: "🛒",
      });
      localStorage.setItem("redirectAfterLogin", window.location.href);
      router.push("/login");
      return;
    }

    setProductData((prev: any) => ({
      ...prev,
      AddToCart: {
        ...prev.AddToCart,
        quantity: quantity
      }
    }));

    try {
      const response = await api.put("/api/v1/cart/updatequantity ", {
        id: cart_id,
        quantity,
      });
      if (
        response.data &&
        (response.data as { status: string }).status === "Success"
      ) {
        toast.success("Quantity updated in cart!", {
          duration: 3000,
          position: "top-center",
          icon: "✅",
          style: {
            backgroundColor: "#28a745",
            color: "#fff",
            fontSize: "16px",
            borderRadius: "8px",
            padding: "10px 20px",
          },
        });
        fetchData("cart");
      } else {
        console.error("Failed to update quantity");
        fetchProductData();
      }
    } catch (error) {
      console.error("API request failed:", error);
      fetchProductData();
    }
  };

  const addToWishlist = async (product_id: any, est_shop_id: any) => {
    console.log(product_id);
    console.log(est_shop_id);
    try {
      if (!token) {
        toast("Please Log In to Add to Wishlist", {
          duration: 3000,
          position: "top-center",
          icon: "❤️",
        });
        localStorage.setItem("redirectAfterLogin", window.location.href);
        localStorage.setItem(
          "addToWishlistParams",
          JSON.stringify({ product_id, est_shop_id })
        );
        router.push("/login");
        return;
      }
      const response = await api.post("/api/v1/products/addtowishlist", {
        product_id,
        est_shop_id,
      });
      if (
        response.data &&
        (response.data as { message: string }).message ===
          "Product is already in your wishlist."
      ) {
        toast.info("Product is already in wishlist!", {
          duration: 3000,
          position: "top-center",
          style: {
            backgroundColor: "skyblue",
            color: "#fff",
            fontSize: "16px",
          },
        });
        return;
      }
      if (
        response.data &&
        (response.data as { status: string }).status === "success"
      ) {
        fetchProductData();
        toast.success("Item has been added to wishlist!", {
          duration: 3000,
          position: "top-center",
          icon: "❤️",
          style: {
            backgroundColor: "#28a745",
            color: "#fff",
            fontSize: "16px",
          },
        });
        fetchData("wishlist");
      } else {
        console.error("Failed to add product to wishlist");
        toast.error("Failed to add product to wishlist", {
          duration: 3000,
          position: "top-center",
        });
      }
    } catch (error) {
      const errorMessage =
        (error as any)?.response?.data?.message ||
        (error as any).message ||
        "An error occurred";
      toast.error(errorMessage, {
        duration: 3000,
        position: "top-center",
      });
      console.error("API request failed:", errorMessage);
    }
  };

  const stripHtml = (html?: string) => {
    if ((!html || typeof html !== "string") && html !== "") {
      console.log("Warning: 'html' is undefined or not a string", html);
      return "";
    }
    const text = html.replace(/<[^>]*>/g, "");
    const parser = new DOMParser();
    return parser.parseFromString(text, "text/html").body.textContent || "";
  };

  function formatIndianCurrency(num: any) {
    return num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  const removeFromWishlist = async (product_id: any, est_shop_id: any) => {
    try {
      if (!token) {
        toast("Please Log In to Add to Wishlist", {
          duration: 3000,
          position: "top-center",
          icon: "❤️",
        });
        localStorage.setItem("redirectAfterLogin", window.location.href);
        router.push("/login");
        return;
      }
      const response = await api.delete(
        `/api/v1/products/removefromwishlist?product_id=${product_id}&est_shop_id=${est_shop_id}`
      );
      if (
        response.data &&
        (response.data as { status: string }).status === "Success"
      ) {
        fetchProductData();
        toast.success("Item has been removed from wishlist!", {
          duration: 3000,
          position: "top-center",
          icon: "❤️",
          style: {
            backgroundColor: "#28a745",
            color: "#fff",
            fontSize: "16px",
          },
        });
        fetchData();
      } else {
        console.error("Failed to add product to wishlist");
        toast((error as any)?.error?.message || "An error occurred", {
          duration: 3000,
          position: "top-center",
        });
      }
    } catch (error) {
      console.error("API request failed:", error);
    }
  };

  const handleIncreaseQuantity = () => {
    if (productData?.AddToCart) {
      const updatedQuantity = productData.AddToCart.quantity + 1;
      updateQuantity(productData.AddToCart.id, updatedQuantity);
      setProductData((prev: any) => ({
        ...prev,
        AddToCart: {
          ...prev.AddToCart,
          quantity: updatedQuantity,
        },
      }));
    }
  };

  const handleDecreaseQuantity = () => {
    if (productData?.AddToCart?.quantity > 1) {
      const updatedQuantity = productData.AddToCart.quantity - 1;
      updateQuantity(productData.AddToCart.id, updatedQuantity);
      setProductData((prev: any) => ({
        ...prev,
        AddToCart: {
          ...prev.AddToCart,
          quantity: updatedQuantity,
        },
      }));
    } else if (
      productData?.AddToCart &&
      productData.AddToCart.quantity === 1
    ) {
      removeCartItem(productData.AddToCart.id);
    }
  };

  useEffect(() => {
    if (encodedProductId && shopId) {
      fetchProductData();
    }
    if (encodedCatId) {
      fetchProducts(encodedCatId, 1, 10);
    }
    const storedParams = localStorage.getItem("addToCartParams");
    if (storedParams) {
      const { product_id, quantity, est_shop_id } = JSON.parse(storedParams);
      if (product_id && quantity && est_shop_id) {
        addToCart(product_id, quantity, est_shop_id);
      }
      localStorage.removeItem("addToCartParams");
    }
  }, [encodedProductId, shopId, encodedCatId]);

  const sizeArray = ["XS", "S", "M", "L", "XL", "XXL"];

  const imagePaths = productData?.image_path
    ? (() => {
        try {
          const parsedImages = JSON.parse(productData?.image_path);
          return Array.isArray(parsedImages)
            ? parsedImages.map((img) => img.src)
            : [];
        } catch (error) {
          console.error("Error parsing image_path:", error);
          return [];
        }
      })()
    : [];

  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
  const [isFullScreenImageOpen, setIsFullScreenImageOpen] = useState(false);

  const handleImageClick1 = (src: string) => {
    setIsFullScreenImageOpen(true);
    setFullscreenImage(`${config.NEXT_PUBLIC_API_URL}/${src}`);
  };

  const handleClose = () => {
    setIsFullScreenImageOpen(false);
    setFullscreenImage(null);
  };

  useEffect(() => {
    if (isFullScreenImageOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto'; // reset
    }
  
    // Clean up when component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isFullScreenImageOpen]);

  return (
    <div className={Style.productPageContainer}>
      <div
        className={`w-[90%] py-4 mx-auto flex gap-6 text-sm ${Style.productPageInnerContainer}`}
      >
        <div
          className={`w-[50%] h-[550px] relative ${Style.productImageContainer}`}
        >
          <Swiper
            effect="fade"
            fadeEffect={{ crossFade: true }}
            pagination={{
              dynamicBullets: true,
              clickable: true,
            }}
            modules={[Pagination, EffectFade]}
            className="mySwiper w-full h-full"
          >
            {imagePaths.length > 0 ? (
              imagePaths.map((src, index) => (
                <SwiperSlide key={index} className="pb-10 cursor-pointer">
                  <Image
                    src={`${config.NEXT_PUBLIC_API_URL}/${src}`}
                    alt={`Product Image ${index + 1}`}
                    width={1000}
                    height={1000}
                    quality={100}
                    className="w-full h-full object-cover"
                    onClick={() => handleImageClick1(src)}
                    onError={(e) => {
                      e.currentTarget.src = dummyImage.src;
                    }}                  />
                </SwiperSlide>
              ))
            ) : (
              <SwiperSlide className="pb-10">
                <div className="w-full h-full flex items-center justify-center text-gray-500 text-lg">
                  <div className="w-full h-full bg-gray-300 animate-pulse rounded-sm" />
                </div>
              </SwiperSlide>
            )}
            {fullscreenImage && (
              <div className="fixed inset-0 bg-black bg-opacity-80 z-[1000] flex justify-center items-center p-4">
                <button
                  onClick={handleClose}
                  className="absolute top-0 right-0 sm:top-4 sm:right-4 text-white text-2xl sm:text-3xl font-bold hover:text-gray-300 transition-colors z-[1001]"
                >
                  ×
                </button>
                <div className="relative w-full max-w-5xl h-auto max-h-[90vh] flex justify-center items-center">
                  <Image
                    src={fullscreenImage}
                    alt="Full Screen Product"
                    width={1200}
                    height={800}
                    className="object-contain w-full h-auto max-h-[90vh] rounded-lg z-[1000]"
                  />
                </div>
              </div>
            )}
          </Swiper>
        </div>
        <div
          className={`w-[40%] flex flex-col gap-2 ${Style.productDataContainer} ${isFullScreenImageOpen ? 'z-[-10]' : ''}`}
        >
          <div className="border-b-1">
            {productData ? (
              <>
                <p className="text-3xl font-semibold mb-2">
                  {productData?.ProductMaster?.product_name}
                </p>
                {/* <p className="text-[#7a7c88]">
                  {stripHtml(productData?.ProductMaster?.product_desc)}
                </p> */}
              </>
            ) : (
              <div>
                <div className="w-full h-6 bg-gray-300 animate-pulse rounded-md mb-2"></div>
                <div className="w-3/4 h-6 bg-gray-300 animate-pulse rounded-md mb-2"></div>
                <div className="w-1/2 h-6 bg-gray-300 animate-pulse rounded-md"></div>
              </div>
            )}
          </div>
          <div className="mt-0 mb-2">
            {productData ? (
              (() => {
                const offerPrice = parseFloat(productData?.offer_price) || 0;
                const originalPrice =
                  parseFloat(
                    productData?.exp_onlinesellprice_aft ??
                      productData?.exp_onlinesellprice_bft
                  ) || 0;
                if (offerPrice > 0 && offerPrice !== originalPrice) {
                  return (
                    <p className="font-bold flex items-center space-x-2">
                      <span className="text-xl">
                        ₹{formatIndianCurrency(offerPrice)}
                      </span>
                      <del className="text-[#7a7c88] font-normal">
                        ₹{formatIndianCurrency(originalPrice)}
                      </del>
                      <span className="text-red-600 font-semibold text-lg">
                        ({((1 - offerPrice / originalPrice) * 100).toFixed(2)}%
                        OFF)
                      </span>
                    </p>
                  );
                } else {
                  return (
                    <p className="font-bold flex items-center space-x-2">
                      <span className="text-lg">
                        ₹{formatIndianCurrency(offerPrice || originalPrice)}
                      </span>
                    </p>
                  );
                }
              })()
            ) : (
              <div className="w-1/2 h-6 bg-gray-300 animate-pulse rounded-md"></div>
            )}
          </div>
          <div className="flex flex-col gap-2 border-b-2 pb-6">
  {!productData ? (
    <div className="flex gap-2 h-[50px]">
      {/* Skeleton Button 1 */}
      <div className="animate-pulse bg-gray-300 rounded w-[50%] h-full" />
      {/* Skeleton Button 2 */}
      <div className="animate-pulse bg-gray-300 rounded w-[35%] h-full" />
    </div>
  ) : (
    <div className="flex gap-2 h-[50px]">
      {productData?.AddToCart ? (
        <div className="flex gap-2">
                  <Button
                    className="w-[30%] h-full border"
                    onClick={handleDecreaseQuantity}
                  >
                    -
                  </Button>
                  <p className="w-[40%] h-full grid place-items-center">
                    {productData.AddToCart.quantity}
                  </p>
                  <Button
                    className="w-[30%] h-full border"
                    onClick={handleIncreaseQuantity}
                  >
                    +
                  </Button>
                </div>
      ) : productData?.quantity === "0" || productData?.quantity === null ? (
        <Button
          className="w-[50%] h-full bg-[#9a602e] hover:bg-[#9a602e] border"
          disabled
        >
          OUT OF STOCK
        </Button>
      ) : (
        <Button
          className="w-[50%] h-full bg-[#9a602e] hover:bg-[#9a602e] border"
          onClick={() => addToCart(encodedProductId, quantity, shopId)}
        >
          ADD TO BAG
        </Button>
      )}
      
      <Button
        className={`w-[35%] h-full bg-white text-black border hover:bg-white ${
          isShaking ? "shake" : ""
        }`}
        onClick={handleClick}
      >
        {productData?.jw_wishlist != null ? (
          <>
            ❤️ <span>WISHLISTED</span>
          </>
        ) : (
          <>
            <GoHeart /> <span>WISHLIST</span>
          </>
        )}
      </Button>
    </div>
  )}
</div>

          <div className="mt-2 flex flex-col gap-6">
  {!productData ? (
    // Loading skeleton UI
    <>
      {[...Array(3)].map((_, i) => (
        <div key={i} className="animate-pulse space-y-2">
          <div className="h-4 bg-gray-300 rounded w-1/3" />
          <div className="h-4 bg-gray-200 rounded w-1/2" />
          <div className="h-4 bg-gray-200 rounded w-[70%]" />
        </div>
      ))}
    </>
  ) : (
    // Actual content
    <>
      <div>
        <p className="font-bold mb-1">PRODUCT DETAILS</p>
        {productData?.purity != 0 && productData?.purity != null && (
          <p>Purity: {parseFloat(productData.purity).toFixed(2).replace(/\.00$/, '')}</p>
        )}
        {productData?.carat_value != 0 && productData?.carat_value != null && (
          <p>Carat Value: {parseFloat(productData.carat_value).toFixed(2).replace(/\.00$/, '')}</p>
        )}
        <p>Weight: {parseFloat(productData?.weight).toFixed(2).replace(/\.00$/, '')}</p>
        <p>Net Weight: {parseFloat(productData?.netweight).toFixed(2).replace(/\.00$/, '')}</p>
        <p>Stone Weight: {parseFloat(productData?.stone_weight).toFixed(2).replace(/\.00$/, '')}</p>
      </div>

      <div>
        <p className="font-bold mb-1">SIZE & FIT</p>
        <p>One Size</p>
      </div>

      <div>
        <p className="font-bold mb-1">MANUFACTURE</p>
        <p>Brand: {productData?.ProductMaster?.Brand?.brand_name || "Not Available"}</p>
        <p>Info: {productData?.ProductMaster?.Brand?.brand_desc || "Not Available"}</p>
      </div>

      <div>
        <p className="font-bold mb-1">DESCRIPTION</p>
        <p>{stripHtml(productData?.ProductMaster?.product_desc)}</p>
      </div>
    </>
  )}
</div>

        </div>
      </div>
      <div
        className={`my-20 flex flex-col items-center ${Style.similarProduct}`}
      >
        <Heading message="Similar Products" />
        <CardSwiper products={filteredProducts} />
      </div>
      {productData?.jw_product_ratings?.length > 0 && (
        <div className=" w-[90%] py-6 mx-auto" ref={reviewsRef}>
          <div className="mb-10 p-8 bg-white">
            <h3 className="text-[#9a602e] font-bold mb-4 text-xl border-b pb-3">
              Ratings & Reviews
            </h3>
            <div className="grid md:grid-cols-[35%_65%] grid-cols-1 gap-8">
              <div className="pr-4 border-r border-gray-200">
                <div className="flex items-center mb-4">
                  <h2 className="text-5xl font-bold text-gray-800 mr-3">
                    {(
                      productData?.jw_product_ratings.reduce(
                        (sum: number, rating: any) =>
                          sum + rating.product_rating,
                        0
                      ) / productData?.jw_product_ratings.length
                    ).toFixed(1)}
                  </h2>
                  <svg
                    className="w-8 h-8 text-yellow-400"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </div>
                <p className="text-gray-600 text-lg mb-6 font-medium">
                  {productData?.jw_product_ratings.length} Verified Buyers
                </p>
                <div className="mt-6 mb-10">
                  {[5, 4, 3, 2, 1].map((star) => {
                    const count = productData?.jw_product_ratings.filter(
                      (rating: any) => rating.product_rating === star
                    ).length;
                    const percentage =
                      (count / productData?.jw_product_ratings.length) * 100;
                    return (
                      <div key={star} className="flex items-center mb-3">
                        <span className="w-12 text-gray-700 font-medium text-lg">
                          {star}★
                        </span>
                        <div className="w-72 bg-gray-200 rounded-full h-5 overflow-hidden">
                          <div
                            className="h-5 bg-gradient-to-r from-green-400 rounded-lg to-green-500 transition-all duration-300"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                        <span className="ml-4 text-gray-700 text-sm font-medium">
                          {count} reviews
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="pl-4">
                <h3 className="text-[#9a602e] text-xl border-b pb-3 mb-6">
                  Customers are saying..
                </h3>
                <div className="space-y-6">
                  {productData?.jw_product_ratings
                    .slice(0, 2)
                    .map((rating: any, index: number) => (
                      <div
                        key={index}
                        className="border-b pb-6 mb-2 bg-gray-50 p-4 rounded-lg"
                      >
                        <div className="flex gap-1 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <svg
                              key={i}
                              className={`w-5 h-5 ${
                                i < rating.product_rating
                                  ? "text-yellow-400"
                                  : "text-gray-300"
                              }`}
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                          ))}
                          <span className="ml-2 text-sm text-gray-500">
                            Verified Buyer
                          </span>
                        </div>
                        <p className="mt-2 text-gray-700 font-medium">
                          {rating.comment || "No review comment provided"}
                        </p>
                      </div>
                    ))}
                </div>
                {productData?.jw_product_ratings.length > 2 && (
                  <>
                    <div
                      className={`space-y-6 overflow-hidden transition-all duration-500 ease-in-out ${
                        showAllReviews
                          ? "max-h-screen opacity-100 mt-6"
                          : "max-h-0 opacity-0"
                      }`}
                    >
                      {productData?.jw_product_ratings
                        .slice(2)
                        .map((rating: any, index: number) => (
                          <div
                            key={index + 2}
                            className="border-b pb-6 bg-gray-50 p-4 rounded-lg transform transition-transform duration-300"
                            style={{
                              animationDelay: `${index * 150}ms`,
                              transform: showAllReviews
                                ? "translateY(0)"
                                : "translateY(20px)",
                            }}
                          >
                            <div className="flex gap-1 mb-2">
                              {[...Array(5)].map((_, i) => (
                                <svg
                                  key={i}
                                  className={`w-5 h-5 ${
                                    i < rating.product_rating
                                      ? "text-yellow-400"
                                      : "text-gray-300"
                                  }`}
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              ))}
                              <span className="ml-2 text-sm text-gray-500">
                                Verified Buyer
                              </span>
                            </div>
                            <p className="mt-2 text-gray-700 font-medium">
                              {rating.comment || "No review comment provided"}
                            </p>
                          </div>
                        ))}
                    </div>
                    {showAllReviews ? (
                      <>
                        <Button
                          variant="outline"
                          className="mt-6 w-full py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
                          onClick={() => setShowAllReviews(!showAllReviews)}
                        >
                          Collapse Reviews
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="outline"
                          className="mt-6 w-full py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
                          onClick={() => setShowAllReviews(!showAllReviews)}
                        >
                          View All Reviews (
                          {productData?.jw_product_ratings.length})
                        </Button>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function product() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Product />
    </Suspense>
  );
}
