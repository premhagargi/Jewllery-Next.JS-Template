/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import { Button } from "@/components/ui/button";
import Image, { StaticImageData } from "next/image";
import { useRouter } from "next/navigation";
import { api } from "../../../../utils/api";
import { useEffect, useState, memo, useCallback } from "react";
import { X, ShoppingCart } from "lucide-react";
import { toast } from "sonner";
import { useGlobalState } from "@/context/GlobalStateContext";
import useAuth from "@/hooks/useAuth";
import Cookies from "js-cookie";
import config from "../../../../config.json";
import React from "react";
import ImageNotFound from "../../../../public/assets/user/product-placeholder.jpg";
// Memoized CartItemImage Component
const CartItemImage: React.FC<{ imagePath: string; productName: string }> = memo(
  ({ imagePath, productName }) => {
    const [isLoading, setIsLoading] = useState(true);
    const [hasError, setHasError] = useState(false);

    let imageSrc = "/placeholder-image.png";
    if (imagePath) {
      try {
        const images = JSON.parse(imagePath);
        if (Array.isArray(images) && images.length > 0 && images[0]?.src) {
          imageSrc = images[0].src.startsWith("http")
            ? images[0].src
            : `${config.NEXT_PUBLIC_API_URL}/${images[0].src}`;
        }
      } catch (error) {
        console.error("Error parsing imagePath:", error);
      }
    }

    return (
      <div className="relative w-[80px] h-[60px] sm:w-[100px] sm:h-[80px] md:w-[120px] md:h-[90px] lg:w-[140px] lg:h-[100px] rounded-md overflow-hidden">
        {isLoading && !hasError && (
          <div className="absolute inset-0 bg-gradient-to-r from-gray-200 to-gray-300 rounded-md" />
        )}
        <img
  src={
    hasError || !imageSrc
      ? (ImageNotFound as StaticImageData).src
      : typeof imageSrc === "string"
        ? imageSrc
        : (imageSrc as StaticImageData).src
  }
  width={100}
  height={100}
  alt={productName}
  loading="lazy"
  className={`w-full h-full object-cover rounded-md transition-opacity duration-300 ${
    isLoading ? "opacity-0" : "opacity-100"
  }`}
  onLoad={() => setIsLoading(false)}
  onError={() => {
    setHasError(true);
    setIsLoading(false);
  }}
/>

      </div>
    );
  }
);
CartItemImage.displayName = "CartItemImage";

// Memoized CartItem Component
interface CartItemProps {
  item: any;
  updateCartQuantity: (
    productId: string,
    newQuantity: number,
    shopId: any,
    cartId: any
  ) => Promise<void>;
  removeItemFromCart: (
    cartId: string,
    productId: string,
    shopId: string
  ) => Promise<void>;
  index: number;
  totalItems: number;
}

const CartItem: React.FC<CartItemProps> = memo(
  ({ item, updateCartQuantity, removeItemFromCart, index, totalItems }) => {
    
  function formatIndianCurrency(num: any) {
    return num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  function stripHtml(html?: string) {
    if (!html || typeof html !== "string") {
      console.warn("Warning: 'html' is undefined or not a string", html);
      return "";
    }
    const text = html.replace(/<[^>]*>/g, "");
    const parser = new DOMParser();
    return parser.parseFromString(text, "text/html").body.textContent || "";
  }
    return (
      <div
        id={`cart-item-${item.id}`}
        className={`relative flex flex-col sm:grid p-2 sm:p-3 md:p-4 py-3 sm:py-4 md:py-5 bg-white transition-all duration-300 ease-in-out overflow-x-auto ${
          index !== totalItems - 1 ? "border-b border-gray-300" : ""
        }`}
        style={{ gridTemplateColumns: "4fr 1.5fr 2.5fr" }}
      >
        {/* Product Image and Details */}
        <div className="flex gap-2 items-center justify-between">
          <div className="flex gap-2 items-center">
            <CartItemImage
              imagePath={item.EstShopInventory.image_path}
              productName={item.EstShopInventory?.ProductMaster?.product_name}
            />
            <div className="flex flex-col justify-center">
              <span className="font-bold text-sm sm:text-base m-1">
                {item.EstShopInventory?.ProductMaster.product_name}
              </span>
              <span className="text-xs sm:text-sm text-gray-600 m-1 line-clamp-2">
                {stripHtml(item.EstShopInventory?.ProductMaster?.product_desc)}
              </span>
            </div>
          </div>
          <button
            onClick={() =>
              removeItemFromCart(item.id, item.product_id, item.est_shop_id)
            }
            className="absolute top-2 sm:top-3 right-2 sm:right-3 text-gray-500 hover:text-red-600 transition-colors"
          >
            <X size={14} />
          </button>
        </div>
        {/* Quantity Controls */}
        <div className="grid place-items-center mt-2 w-[10%] sm:mt-0">
          {item.EstShopInventory.quantity === "0" ? (
            <span className="text-red-500 font-semibold text-xs text-nowrap sm:text-sm">
              Out of Stock
            </span>
          ) : (
            <div className="flex gap-1 sm:gap-2 items-center border rounded-lg px-2 sm:px-3 py-1">
              <Button
                className="bg-white shadow-none text-black hover:bg-[#e6e6e6] text-xs sm:text-sm p-1 sm:p-2"
                onClick={() =>
                  updateCartQuantity(
                    item.product_id,
                    item.quantity - 1,
                    item.est_shop_id,
                    item.id
                  )
                }
                disabled={item.quantity <= 1}
              >
                -
              </Button>
              <span className="text-xs sm:text-sm">{item.quantity}</span>
              <Button
                className="bg-white shadow-none text-black hover:bg-[#e6e6e6] text-xs sm:text-sm p-1 sm:p-2"
                onClick={() =>
                  updateCartQuantity(
                    item.product_id,
                    item.quantity + 1,
                    item.est_shop_id,
                    item.id
                  )
                }
              >
                +
              </Button>
            </div>
          )}
        </div>
        {/* Price Details */}
        <div className="flex flex-col place-items-end justify-center gap-1 flex-wrap mt-2 sm:mt-0">
          {item.EstShopInventory.offer_price > 0 ? (
            <>
            <div className="flex gap-2">

              <span className="text-sm sm:text-md font-semibold">
                ₹{formatIndianCurrency(Number(item.EstShopInventory.offer_price))}
              </span>
              <span className="line-through text-gray-500 text-xs sm:text-sm">
                ₹{formatIndianCurrency(
                  Number(item.EstShopInventory.exp_onlinesellprice_aft)
                )}
              </span>
                </div>
              <div>

              <span className="text-green-500 text-xs sm:text-sm">
                (
                {Math.round(
                  ((Number(item.EstShopInventory.exp_onlinesellprice_aft) -
                  Number(item.EstShopInventory.offer_price)) /
                  Number(item.EstShopInventory.exp_onlinesellprice_aft)) *
                  100
                )}
                % OFF)
              </span>
                </div>
            </>
          ) : (
            <span className="text-sm sm:text-md font-semibold mx-auto">
              MRP: ₹
              {formatIndianCurrency(
                Number(item.EstShopInventory.exp_onlinesellprice_aft)
              )}
            </span>
          )}
        </div>
      </div>
    );
  }
);
CartItem.displayName = "CartItem";

export default function Cart() {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [outOfStockItems, setOutOfStockItems] = useState<any[]>([]);
  const [cartData, setCartData] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isFirstFetch, setIsFirstFetch] = useState(true);
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const { fetchData, isTokenExpired } = useGlobalState();
  const { isAuthenticated, loading: authLoading } = useAuth();

  const checkCartAvailability = useCallback(async () => {
    try {
      const response = await api.get("/api/v1/cart/cartdata");
      return (
        (response.data as { data: { cartItems: any[] } }).data.cartItems || []
      );
    } catch (err) {
      console.error("Failed to check cart availability:", err);
      return [];
    }
  }, []);

  const calculateDiscount = () => {
    return cartItems
      .reduce((total, item) => {
        const originalPrice = Number(
          item.EstShopInventory?.exp_onlinesellprice_aft || 0
        );
        const offerPrice = Number(item.EstShopInventory?.offer_price || 0);
        const quantity = Number(item.quantity || 1);
        return total + (originalPrice - offerPrice) * quantity;
      }, 0)
      .toFixed(2);
  };

  const calculateDiscountPercentage = () => {
    const totalOriginalPrice = cartItems.reduce((total, item) => {
      const originalPrice = Number(
        item.EstShopInventory?.exp_onlinesellprice_aft || 0
      );
      const quantity = Number(item.quantity || 1);
      return total + originalPrice * quantity;
    }, 0);

    const totalDiscount = Number(calculateDiscount());
    if (totalOriginalPrice === 0) return "0";
    return ((totalDiscount / totalOriginalPrice) * 100).toFixed(2);
  };

  function formatIndianCurrency(num: any) {
    return num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  let cartCount = "";

  const fetchCartData = async () => {
    try {
      setLoading(true);
      const response = await api.get("/api/v1/cart/cartdata");
      const cartItemsData =
        (response.data as { data: { cartItems: any[] } }).data.cartItems || [];
      setCartItems(cartItemsData);
      setCartData((response.data as { data: any }).data || {});
      cartCount = (response.data as any)?.data?.totalProducts;
      document.title = `Cart (${cartCount || 0})`;
      const outOfStock = cartItemsData.filter(
        (item) => item.EstShopInventory?.quantity === "0"
      );
      setOutOfStockItems(outOfStock);
      if (outOfStock.length > 0) {
        toast.info("Some items are out of stock! Please remove them to proceed.");
      }
      setIsFirstFetch(false);
    } catch (err) {
      setError("Failed to fetch cart data");
      console.error(err);
    } finally {
      if (isFirstFetch) setLoading(false);
    }
  };

  useEffect(() => {
    if (!isAuthenticated && !authLoading) {
      toast("Please log in to view your cart!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      router.push("/login");
    }
    fetchCartData();
  }, []);

  const updateCartQuantity = async (
    productId: string,
    newQuantity: number,
    shopId: any,
    cartId: any
  ) => {
    try {
      setIsUpdating(true);
      const currentItem = cartItems.find(
        (item) => item.product_id === productId && item.est_shop_id === shopId
      );
      if (!currentItem) throw new Error("Cart item not found");

      if (newQuantity > currentItem.quantity) {
        const maxQuantity = parseInt(currentItem.EstShopInventory.quantity, 10);
        if (newQuantity > maxQuantity) {
          toast.info(
            `Cannot add more than ${maxQuantity} items due to inventory availability`
          );
          return;
        }
      }

      const response = await api.put("/api/v1/cart/updatequantity", {
        product_id: productId,
        quantity: newQuantity,
        est_shop_id: shopId,
        id: cartId,
      });

      if (response.status === 200) {
        setCartItems((prev) =>
          prev.map((item) =>
            item.product_id === productId && item.est_shop_id === shopId
              ? { ...item, quantity: newQuantity }
              : item
          )
        );
        const updatedCartData = await api.get("/api/v1/cart/cartdata");
        setCartData((updatedCartData.data as { data: any }).data || {});
      }
    } catch (err) {
      console.error("Failed to update quantity:", err);
    } finally {
      setIsUpdating(false);
    }
  };

  const removeItemFromCart = async (
    cartId: string,
    productId: string,
    shopId: string
  ) => {
    try {
      const userChoice = await new Promise<string | null>((resolve) => {
        const toastId = toast(
          <div className="flex flex-col space-y-3 p-4">
            <p className="text-base sm:text-lg font-semibold text-center text-gray-800">
              What would you like to do with this item?
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-3">
              <button
                className="bg-green-500 hover:bg-green-600 text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-green-400 text-sm sm:text-base"
                onClick={() => {
                  toast.dismiss(toastId);
                  resolve("wishlist");
                }}
              >
                Move to Wishlist
              </button>
              <button
                className="bg-red-500 hover:bg-red-600 text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-red-400 text-sm sm:text-base"
                onClick={() => {
                  toast.dismiss(toastId);
                  resolve("remove");
                }}
              >
                Remove from Cart
              </button>
            </div>
          </div>,
          {
            duration: Infinity,
            className: "w-full max-w-xs sm:max-w-md",
            action: {
              label: "Cancel",
              onClick: () => {
                toast.dismiss(toastId);
                resolve(null);
              },
            },
          }
        );
      });

      if (userChoice === "wishlist") {
        const element = document.getElementById(`cart-item-${cartId}`);
        if (element) {
          element.style.transition = "all 0.5s ease-in-out";
          element.classList.add("opacity-0", "scale-95", "overflow-hidden");
        }
        await new Promise((resolve) => setTimeout(resolve, 300));

        await api.post(`/api/v1/products/addtowishlist`, {
          product_id: productId,
          est_shop_id: shopId,
        });
        await api.delete(`/api/v1/cart/removecart?id=${cartId}`);
        setCartItems((prev) => prev.filter((item) => item.id !== cartId));

        const cartDataResponse = await api.get("/api/v1/cart/cartdata");
        setCartData((cartDataResponse.data as { data: any }).data || {});
        const cartItemsData =
          (cartDataResponse.data as { data: { cartItems: any[] } }).data
            .cartItems || [];
        cartCount = (cartDataResponse.data as any)?.data?.totalProducts;
        setOutOfStockItems(
          cartItemsData.filter((item) => item.EstShopInventory?.quantity === "0")
        );
        toast.success("Item moved to Wishlist!");
        fetchData("wishlist");
        fetchData("cart");
      } else if (userChoice === "remove") {
        setIsUpdating(true);
        const element = document.getElementById(`cart-item-${cartId}`);
        if (element) {
          element.style.transition = "all 0.5s ease-in-out";
          element.classList.add("opacity-0", "scale-95", "overflow-hidden");
        }
        await new Promise((resolve) => setTimeout(resolve, 300));

        await api.delete(`/api/v1/cart/removecart?id=${cartId}`);
        setCartItems((prev) => prev.filter((item) => item.id !== cartId));

        const cartDataResponse = await api.get("/api/v1/cart/cartdata");
        setCartData((cartDataResponse.data as { data: any }).data || {});
        const cartItemsData =
          (cartDataResponse.data as { data: { cartItems: any[] } }).data
            .cartItems || [];
        cartCount = (cartDataResponse.data as any)?.data?.totalProducts;
        setOutOfStockItems(
          cartItemsData.filter((item) => item.EstShopInventory?.quantity === "0")
        );
        toast.success("Item removed from cart!");
        fetchData("cart");
      } else {
        toast.info("Action cancelled");
      }
    } catch (err) {
      console.error("Failed to process request:", err);
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsUpdating(false);
    }
  };

  const clearCart = async () => {
    try {
      setIsUpdating(true);
      const response = await api.delete("/api/v1/cart/clearcart");
      if (response.status === 200) {
        toast.success("Cart items have been cleared!");
        setCartItems([]);
        setCartData({});
        fetchData("cart");
      }
    } catch (err) {
      console.error("Failed to clear cart:", err);
    } finally {
      setIsUpdating(false);
    }
  };

  function stripHtml(html?: string) {
    if (!html || typeof html !== "string") {
      console.warn("Warning: 'html' is undefined or not a string", html);
      return "";
    }
    const text = html.replace(/<[^>]*>/g, "");
    const parser = new DOMParser();
    return parser.parseFromString(text, "text/html").body.textContent || "";
  }

  if (!isAuthenticated || authLoading) {
    return (
      <div className="w-full min-h-screen p-4 sm:p-6 space-y-4 sm:space-y-6 bg-gray-100">
        <div className="h-10 sm:h-12 w-full bg-gray-300 animate-pulse rounded-md" />
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
          <div className="w-full sm:w-1/4 space-y-4">
            <div className="h-8 sm:h-10 bg-gray-300 animate-pulse rounded-md" />
            <div className="h-8 sm:h-10 bg-gray-300 animate-pulse rounded-md" />
            <div className="h-8 sm:h-10 bg-gray-300 animate-pulse rounded-md" />
            <div className="h-8 sm:h-10 bg-gray-300 animate-pulse rounded-md" />
          </div>
          <div className="flex-1 space-y-4 sm:space-y-6">
            <div className="h-8 sm:h-10 w-full sm:w-2/3 bg-gray-300 animate-pulse rounded-md" />
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
              <div className="h-32 sm:h-40 bg-gray-300 animate-pulse rounded-md" />
              <div className="h-32 sm:h-40 bg-gray-300 animate-pulse rounded-md" />
              <div className="h-32 sm:h-40 bg-gray-300 animate-pulse rounded-md" />
            </div>
            <div className="space-y-3">
              <div className="h-6 w-full bg-gray-300 animate-pulse rounded-md" />
              <div className="h-6 w-4/5 bg-gray-300 animate-pulse rounded-md" />
              <div className="h-6 w-3/5 bg-gray-300 animate-pulse rounded-md" />
            </div>
          </div>
        </div>
      </div> 
    );
  }

  return (
    <div className="min-h-screen">
      <div className="w-[95%] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-10">
        <div className="w-full flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 sm:mb-6">
          <div className="font-medium text-lg">
            Shopping Cart
          </div>
          {/* {cartItems.length > 0 && (
            <Button
              className="bg-red-500 text-white text-sm sm:text-base px-3 sm:px-4 py-1.5 sm:py-2"
              onClick={clearCart}
              disabled={isUpdating}
            >
              Clear Cart
            </Button>
          )} */}
        </div>
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 text-xs sm:text-sm">
          <div className="border w-full h-fit rounded-lg overflow-hidden">
            <div
              className="grid bg-[#9a602e] p-2 sm:p-3 text-white text-xs sm:text-sm"
              style={{ gridTemplateColumns: "4fr 1.5fr 2.5fr" }}
            >
              <div>Product</div>
              <div className="grid place-items-center">Quantity</div>
              <div className="grid place-items-center">Price</div>
            </div>
            {loading && isFirstFetch ? (
              Array.from({ length: 3 }).map((_, index) => (
                <div
                  key={index}
                  className="grid p-2 sm:p-3 py-3 sm:py-4"
                  style={{ gridTemplateColumns: "4fr 1.5fr 2.5fr" }}
                >
                  <div className="flex gap-2 items-center">
                    <div className="bg-gray-300 rounded-lg w-[80px] h-[60px] sm:w-[100px] sm:h-[80px]" />
                    <div className="bg-gray-300 w-[150px] sm:w-[200px] h-[16px] sm:h-[20px]" />
                  </div>
                  <div className="grid place-items-center">
                    <div className="bg-gray-300 w-[40px] sm:w-[50px] h-[16px] sm:h-[20px]" />
                  </div>
                  <div className="grid place-items-center">
                    <div className="bg-gray-300 w-[40px] sm:w-[50px] h-[16px] sm:h-[20px]" />
                  </div>
                </div>
              ))
            ) : cartItems.length === 0 ? (
              <div className="flex mx-auto flex-col items-center justify-center h-[200px] sm:h-[250px] lg:h-[300px] text-gray-500">
<ShoppingCart className="text-gray-400 mb-3 w-10 h-10 sm:w-12 sm:h-12" />
<span className="text-base sm:text-lg font-semibold">
                  Your cart is empty
                </span>
                <p className="text-xs sm:text-sm text-gray-400">
                  Add items to your cart to start shopping!
                </p>
              </div>
            ) : (
              cartItems.map((item, index) => (
                <CartItem
                  key={item.id}
                  item={item}
                  updateCartQuantity={updateCartQuantity}
                  removeItemFromCart={removeItemFromCart}
                  index={index}
                  totalItems={cartItems.length}
                />
              ))
            )}
          </div>
          <div className="border w-full lg:w-[500px] h-fit rounded-lg overflow-hidden pb-4 bg-white">
            <div className="w-full mb-6 sm:mb-8 bg-[#9a602e] p-3 sm:p-4 py-2 sm:py-3 text-white text-sm sm:text-base">
              Cart Total
            </div>
            <div className="flex flex-col gap-3 sm:gap-4 p-3 sm:p-4 py-0">
              <div className="flex justify-between text-gray-800 text-xs sm:text-sm">
                <p>Total MRP</p>
                <p>
                  {loading && isFirstFetch
                    ? "..."
                    : `₹ ${formatIndianCurrency(
                        cartItems.reduce(
                          (total, item) =>
                            total +
                            (Number(
                              item.EstShopInventory.exp_onlinesellprice_aft
                            ) || 0) *
                              (item.quantity || 1),
                          0
                        )
                      )}`}
                </p>
              </div>
              <div className="flex justify-between text-gray-800 text-xs sm:text-sm">
                <p>Discount</p>
                <p className="text-green-600">
                  {loading && isFirstFetch
                    ? "..."
                    : `-₹ ${formatIndianCurrency(calculateDiscount())} `}
                  <span>({calculateDiscountPercentage()}%)</span>
                </p>
              </div>
              <hr className="my-1 border-t border-gray-300" />
              <div className="flex justify-between text-black font-bold text-sm sm:text-base">
                <p>Total Amount</p>
                <p>
                  {loading && isFirstFetch
                    ? "..."
                    : `₹ ${formatIndianCurrency(Number(cartData.totalPrice || 0))}`}
                </p>
              </div>
              {cartItems.length >= 1 && (
                <Button
                  className={`mt-2 font-normal flex items-center justify-center gap-2 text-sm sm:text-sm px-3 sm:px-4 py-1.5 sm:py-2 ${
                    outOfStockItems.length > 0 || isCheckingOut
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-[#9a602e] hover:bg-[#8a5026]"
                  }`}
                  disabled={outOfStockItems.length > 0 || isCheckingOut}
                  onClick={async (e) => {
                    if (outOfStockItems.length > 0) return;
                    setIsCheckingOut(true);
                    try {
                      const freshCartItems = await checkCartAvailability();

                      const notForSaleItems = freshCartItems.filter(
                        (item) => item.EstShopInventory?.onlineshop === false
                      );
                      if (notForSaleItems.length > 0) {
                        toast.error(
                          "Some items are not available for online purchase. Please remove them to proceed.",
                          { duration: 5000, position: "top-center" }
                        );
                        return;
                      }

                      const invalidQuantityItems = freshCartItems.filter(
                        (item) => {
                          const available = parseInt(
                            item.EstShopInventory?.quantity,
                            10
                          ) || 0;
                          const selected = Number(item.quantity || 0);
                          return (
                            available === 0 ||
                            selected <= 0 ||
                            selected > available
                          );
                        }
                      );
                      if (invalidQuantityItems.length > 0) {
                        toast.error(
                          "Some items have invalid quantities or insufficient stock. Please update or remove them.",
                          { duration: 5000, position: "top-center" }
                        );
                        return;
                      }

                      const token = Cookies.get("token");
                      if (!token || isTokenExpired(token)) {
                        e.preventDefault();
                        localStorage.setItem(
                          "redirectAfterLogin",
                          window.location.href
                        );
                        toast("Please log in to manage Addresses", {
                          duration: 3000,
                          position: "top-center",
                          icon: "📍",
                        });
                        router.push("/login");
                        return;
                      }

                      router.push("/checkout");
                    } catch (err) {
                      console.error("Failed to validate cart:", err);
                      toast.error("Something went wrong. Please try again.");
                    } finally {
                      setIsCheckingOut(false);
                    }
                  }}
                >
                  {isCheckingOut ? (
                    <>
                      <span className="animate-spin inline-block w-[16px] sm:w-[20px] h-[16px] sm:h-[20px] border-2 border-t-transparent border-white rounded-full" />
                    </>
                  ) : (
                    "Proceed To Checkout"
                  )}
                </Button>
              )}
              {cartItems.length > 0 && (
            <Button
              className="bg-red-500 text-white text-sm sm:text-base px-3 sm:px-4 py-1.5 sm:py-2"
              onClick={clearCart}
              disabled={isUpdating}
            >
              Clear Cart
            </Button>
          )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}