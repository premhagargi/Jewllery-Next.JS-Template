import React from "react";
import Head from "next/head";

export default function ReturnAndExchanges() {
  return (
    <>
      <Head>
        <title>Refund & Exchange Policy | Maharana Silver</title>
        <meta
          name="description"
          content="Review Maharana Silver's official refund and exchange policy before making a purchase."
        />
      </Head>

      <main className="px-4 sm:px-8 md:px-16 lg:px-48 py-12 bg-white text-gray-800">
        <h1 className="text-3xl font-bold mb-6 text-center">Refund & Exchange Policy</h1>

        <section className="mb-10 space-y-4 text-lg">
          <p>
            Thank you for shopping with us. We take great pride in the quality and craftsmanship of our jewellery. Please read our policy carefully before making a purchase.
          </p>

          <h2 className="text-xl font-semibold mt-6">No Refunds or Exchanges</h2>
          <p>
            We do <strong>not</strong> offer refunds or exchanges for any orders once placed. All sales are final.
          </p>

          <h2 className="text-xl font-semibold mt-6">Faulty or Damaged Items</h2>
          <p>
            In the rare event that you receive a faulty or damaged product, please contact us within <strong>24 hours of delivery</strong> via WhatsApp at <strong>+91 7400233605</strong>.
          </p>
          <ul className="list-disc ml-6 space-y-2 mt-2">
            <li>Include your order number, clear images of the item, and a description of the issue.</li>
            <li>Our team will review your case as per our <strong>strict internal guidelines</strong>.</li>
            <li>Refunds or replacements (if any) will be offered <strong>only at our sole discretion</strong> based on our
            internal assessment.</li>
          </ul>

          <h2 className="text-xl font-semibold mt-6">Important Notes</h2>
          <ul className="list-disc ml-6 space-y-2">
            <li>Claims made after 24 hours of delivery will not be considered.</li>
            <li>The decision of our team regarding refunds or exchanges will be final..</li>
            <li>We are unable to entertain requests for refunds or exchanges for reasons such as change
            of mind, incorrect size selection, or personal preferences.</li>
          </ul>

          <h2 className="text-xl font-semibold mt-6">Legal Disclaimer</h2>
          <p>
          By purchasing from our website, you agree to abide by this Refund &amp; Exchange Policy. We
reserve the right to modify or update this policy at any time without prior notice. Any such
changes will be effective immediately upon posting on our website.          </p>
          <p>
          All decisions regarding refunds or exchanges are final and binding. We shall not be liable for any
direct, indirect, incidental, or consequential damages that may arise from the use of, or the
inability to use, our products.          </p>
        </section>
      </main>
    </>
  );
}
