"use client";
import Image from "next/image";
import { BiSupport } from "react-icons/bi";
import { BsBoxSeam } from "react-icons/bs";
import { FaRegFolder } from "react-icons/fa";
import { SlBadge } from "react-icons/sl";
import { LuUsers } from "react-icons/lu";
import { PiScooterBold } from "react-icons/pi";

// assets
import Image1 from "../../../../public/assets/user/about1.png";
import Image2 from "../../../../public/assets/user/about2.png";
import gridImage1 from "../../../../public/assets/user/aboutGrid1.png";
import gridImage2 from "../../../../public/assets/user/aboutGrid2.png";
import gridImage3 from "../../../../public/assets/user/aboutGrid3.png";
import Style from "../styles/aboutUs.module.scss";
import { JSX } from "react";

export default function AboutUs() {
  return (
    <div>
      {/* About Section */}
      <div
        className={`w-[90%] mx-auto flex gap-10 my-10 ${Style.aboutContainer}`}
      >
        <div className="w-[40%] flex flex-col gap-4">
          <p className="text-lg font-semibold">About Us</p>
          <p className="text-3xl font-semibold">Get to Know Maharana Silver</p>
          <p className="mb-4 text-sm">
            Maharana Silver is a trusted name in premium handcrafted silver
            jewelry and artifacts. With a legacy of precision, elegance, and
            customer satisfaction, we strive to deliver excellence through our
            authentic designs and high-quality craftsmanship.
          </p>
        </div>
        <div className="w-[50%]">
          <Image
            src={Image1}
            width={1000}
            height={1000}
            quality={100}
            alt="About Maharana Silver"
            loading="lazy"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* History Section */}
      <div
        className={`w-[80%] mx-auto flex items-center justify-center gap-10 my-10 ${Style.historyContainer}`}
      >
        <div className="w-[35%] h-full relative">
          <Image
            src={Image2}
            width={1000}
            height={1000}
            quality={100}
            alt="Our History"
            loading="lazy"
            className="w-full h-full object-cover"
          />
          <div className="w-full h-full border-2 absolute top-[20px] border-[#ccb162] rounded-t-[45%] left-[20px]"></div>
        </div>
        <div className="w-[50%]">
          <p className="text-xl font-semibold mb-2">Our Journey</p>
          <p className="text-sm">
            Founded with a passion for timeless silver artistry, Maharana Silver
            has grown into a symbol of purity and trust. Our journey began with
            a commitment to offer beautifully crafted silver products that
            reflect both tradition and innovation. Over the years, we have
            continued to expand our collection while upholding the values that
            make us stand out in the industry.
          </p>
        </div>
      </div>

      {/* Why Choose Us */}
      <div
        className={`w-[80%] mx-auto my-10 mt-20 flex flex-col justify-center items-center gap-10 ${Style.whyChooseUs}`}
      >
        <div
          className={`w-[40%] mx-auto text-center ${Style.whyChooseUsHeading}`}
        >
          <p className="font-black mb-2 text-2xl">Why Choose Maharana Silver</p>
          <p className="text-sm">
            We believe in quality, reliability, and customer-first service.
            Here&apos;s why thousands trust Maharana Silver.
          </p>
        </div>
        <div className={`grid grid-cols-3 gap-10 mt-6 ${Style.grid}`}>
          <Feature
            icon={<BiSupport size={25} color="#9a602e" />}
            title="Support Team"
            desc="Our dedicated support ensures a seamless experience from order to delivery."
          />
          <Feature
            icon={<BsBoxSeam size={25} color="#9a602e" />}
            title="Creative Products"
            desc="Each item is uniquely crafted with modern design sensibilities."
          />
          <Feature
            icon={<PiScooterBold size={25} color="#9a602e" />}
            title="Easy Shipping"
            desc="Fast and reliable shipping to ensure timely delivery."
          />
          <Feature
            icon={<FaRegFolder size={25} color="#9a602e" />}
            title="Quality Control"
            desc="Strict quality checks for every product before it reaches you."
          />
          <Feature
            icon={<SlBadge size={25} color="#9a602e" />}
            title="Premium Material"
            desc="We use only high-grade silver to ensure long-lasting beauty."
          />
          <Feature
            icon={<LuUsers size={25} color="#9a602e" />}
            title="Client Management"
            desc="Building lasting relationships through transparency and care."
          />
        </div>
      </div>

      {/* Image Grid Section */}
      <div
        className={`w-[50%] h-[400px] mx-auto my-[8rem] flex gap-8 ${Style.imageContainer}`}
      >
        <Image
          src={gridImage1}
          width={1000}
          height={1000}
          quality={100}
          alt="Showcase 1"
          loading="lazy"
          className="w-[33%] rounded-3xl object-cover"
        />
        <div
          className={`w-[40%] h-full rounded-3xl relative ${Style.relativeImageContainer}`}
        >
          <Image
            src={gridImage2}
            width={1000}
            height={1000}
            quality={100}
            alt="Showcase 2"
            loading="lazy"
            className="w-full h-full rounded-3xl object-cover absolute top-[60px]"
          />
        </div>
        <Image
          src={gridImage3}
          width={1000}
          height={1000}
          quality={100}
          alt="Showcase 3"
          loading="lazy"
          className="w-[33%] rounded-3xl object-cover"
        />
      </div>
    </div>
  );
}

// Reusable Feature Block
function Feature({
  icon,
  title,
  desc,
}: {
  icon: JSX.Element;
  title: string;
  desc: string;
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        {icon}
        <p className="font-bold">{title}</p>
      </div>
      <p className="text-sm">{desc}</p>
    </div>
  );
}
