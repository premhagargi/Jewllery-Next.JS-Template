/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import Image from "next/image";
import UserImage from "../../../../public/assets/user/boy.png";
import ImageNotFound from "../../../../public/assets/user/product-placeholder.jpg";
import { PiUserLight } from "react-icons/pi";
import { FiPackage } from "react-icons/fi";
import { GoHeart, GoPasskeyFill } from "react-icons/go";
import { SetStateAction, useEffect, useState } from "react";
import { GoLocation, GoTrash } from "react-icons/go";
import { useRouter } from "next/navigation";
import { useGlobalState } from "@/context/GlobalStateContext";
import { ShoppingBag } from "lucide-react";
import { MdOutlineContactSupport } from "react-icons/md";
import Cookies from "js-cookie";
import ConfirmModal from "@/components/user/confirmModal";
import useAuth from "@/hooks/useAuth";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
  DialogHeader,
  DialogFooter,
} from "@/components/ui/dialog";
import { BiLogOut } from "react-icons/bi";
import OrderDetails from "@/components/user/orderDetails";
import { api } from "../../../../utils/api";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Star } from "lucide-react";
import Style from "../styles/order.module.scss";
import { toast } from "sonner";
import config from "../../../../config.json";
import React from "react";

export default function Profile() {
  const router = useRouter();
  const { isTokenExpired, profileData } = useGlobalState();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [loading, setLoading] = useState<boolean>(true);
  const [reviewText, setReviewText] = useState("");
  const [ratings, setRatings] = useState<{ [key: string]: number }>({});
  const [dialogRating, setDialogRating] = useState<number>(0);
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<{
    jw_order_items: any;
    id: string;
  } | null>(null);
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);

  const [orderlist, setOrders] = useState<any[]>([]);
  const [isOrderDetailsOpen, setIsOrderDetailsOpen] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [hasMore, setHasMore] = useState(false);

  function formatIndianCurrency(num: any) {
    return num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  const parseImagePath = (imagePath: string): string => {
    try {
      const parsed = JSON.parse(imagePath);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].src) {
        return `${config.NEXT_PUBLIC_API_URL}/${parsed[0].src}`;
      }
      return ImageNotFound.src;
    } catch (error) {
      console.error("Error parsing image_path:", error);
      return ImageNotFound.src;
    }
  };

  const fetchOrders = async (
    page = currentPage,
    limit = itemsPerPage,
    merge = false,
    silent = false
  ) => {
    try {
      if (!silent) setLoading(true);
  
      const url = `/api/v1/order/orderHistory?page=${page}&limit=${limit}`;
      const response = await api.get(url);
  
      if (response.data) {
        const fetchedOrders = (response.data as { data: any[] }).data || [];
  
        if (merge) {
          // Merge updated orders based on unique identifier
          setOrders((prevOrders) => {
            const updatedMap = new Map(fetchedOrders.map((order) => [order.id, order]));
            return prevOrders.map((order) =>
              updatedMap.has(order.id) ? updatedMap.get(order.id) : order
            );
          });
        } else {
          setOrders((prevOrders) =>
            page === 1 ? fetchedOrders : [...prevOrders, ...fetchedOrders]
          );
        }
  
        setHasMore(fetchedOrders.length === itemsPerPage);
      } else {
        console.error("Error fetching orders");
      }
    } catch (error) {
      console.error("API request failed:", error);
    } finally {
      if (!silent) {
        setTimeout(() => setLoading(false), 0);
      }
    }
  };
  

  const handleViewMoreOrders = () => {
    setCurrentPage((prevPage) => prevPage + 1);
    fetchOrders(currentPage + 1);
  };

  const handleRating = async (
    productId: any,
    rating: number,
    inventoryId: any,
    orderId: any,
    order: any
  ) => {
    setSelectedOrder(order);
    setRatings((prev) => ({ ...prev, [orderId]: rating }));

    const existingRating = order.jw_order_items[0]?.jw_product_ratings?.[0];
    const payload = {
      reviewId: existingRating?.id || null,
      productId,
      inventoryProductId: inventoryId,
      rating,
      comment: existingRating?.comment || null,
    };

    try {
      const method = existingRating?.id ? 'patch' : 'post';
      const response = await api[method](`/api/v1/products/productRating`, payload);

      if (response.data) {
        toast.success(`Rating ${existingRating?.id ? 'updated' : 'submitted'} successfully`);
        
        // Update the local state with new rating data
        setOrders((prev) =>
          prev.map((o) =>
            o.id === orderId
              ? {
                  ...o,
                  jw_order_items: o.jw_order_items.map(
                    (item: { product_id: any; jw_product_ratings: any[] }) =>
                      item.product_id === productId
                        ? {
                            ...item,
                            jw_product_ratings: [{
                              id: (response.data as { data: { id: string } }).data?.id || existingRating?.id,
                              product_rating: rating,
                              comment: existingRating?.comment || null,
                              created_at: new Date().toISOString(),
                              updated_at: new Date().toISOString(),
                            }],
                          }
                        : item
                  ),
                }
              : o
          )
        );
      }
    } catch (error) {
      console.error("API request failed:", error);
      toast.error("Failed to update rating");
    }
  };

  const handleSubmitReview = async (orderId: any, productId: any) => {
    if (!selectedOrder) return;

    const rating = dialogRating;
    if (rating === 0) {
      toast.error("Please select a rating before submitting");
      return;
    }

    const existingRating = selectedOrder.jw_order_items[0]?.jw_product_ratings?.[0];
    const payload = {
      reviewId: existingRating?.id || null,
      productId,
      inventoryProductId: selectedOrder.jw_order_items[0]?.inventory_id,
      rating,
      comment: reviewText,
    };

    try {
      const url = `/api/v1/products/productRating`;
      const method = existingRating?.id ? 'patch' : 'post';
      const response = await api[method](url, payload);

      if (response.data) {
        toast.success(`Review ${existingRating?.id ? 'updated' : 'submitted'} successfully`);
        
        // Update the local state with new rating data
        setOrders((prev) =>
          prev.map((o) =>
            o.id === orderId
              ? {
                  ...o,
                  jw_order_items: o.jw_order_items.map(
                    (item: { product_id: any; jw_product_ratings: any[] }) =>
                      item.product_id === productId
                        ? {
                            ...item,
                            jw_product_ratings: [{
                              id: (response.data as { data: { id: string } }).data?.id || existingRating?.id,
                              product_rating: rating,
                              comment: reviewText,
                              created_at: new Date().toISOString(),
                              updated_at: new Date().toISOString(),
                            }],
                          }
                        : item
                  ),
                }
              : o
          )
        );

        setReviewText("");
        setDialogRating(0);
        setIsReviewDialogOpen(false);
      }
    } catch (error) {
      console.error("API request failed:", error);
      toast.error("Failed to submit review. Try again!");
    }
  };

  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDeleteConfirmed = async () => {
    setIsModalOpen(false);
    try {
      await api.patch("/api/v1/deleteAcc", {});
      toast.success("Your account has been deleted!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      setTimeout(() => {
        toast("We are sorry to see you go!!", {
          duration: 2000,
          position: "top-center",
          icon: "😔",
        });
      }, 500);
      localStorage.clear();
      router.push("/login");
      Cookies.remove("token");
    } catch (err) {
      console.error("Account deletion error:", err);
    }
  };

  const deleteAccount = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to permanently delete your account? This action cannot be undone."
    );
    if (confirmed) {
      try {
        const response = await api.patch("/api/v1/deleteAcc", {});
        toast("Your account has been deleted!", {
          duration: 2000,
          position: "top-center",
          icon: "👤",
        });
        setTimeout(() => {
          toast("We are sorry to see you go!!", {
            duration: 2000,
            position: "top-center",
            icon: "👤",
          });
        }, 500);
        setTimeout(() => {
          localStorage.clear();
          router.push("/login");
          Cookies.remove("token");
        }, 200);
      } catch (err) {
        if ((err as any).response?.status === 200) {
        } else {
          console.error(err);
        }
      }
    }
  };

  const openReviewDialog = (order: { jw_order_items: any; id: string } | null) => {
    setSelectedOrder(order);
    const existingRating = order?.jw_order_items[0]?.jw_product_ratings?.[0];
    
    if (existingRating) {
      // If there's an existing rating, set both the rating and review text
      setDialogRating(existingRating.product_rating || 0);
      setReviewText(existingRating.comment || "");
      setRatings((prev) => ({
        ...prev,
        [order?.id || ""]: existingRating.product_rating || 0
      }));
    } else {
      // For new reviews, use the rating from the list view if exists, otherwise 0
      const listViewRating = ratings[order?.id || ""] || 0;
      setDialogRating(listViewRating);
      setReviewText("");
    }
  };

  useEffect(() => {
    if (!isAuthenticated && !authLoading) {
      console.log("User is not authenticated, redirecting to login page");
      toast("Please log in to view your orders !!", {
        duration: 2000,
        position: "top-center",
        icon: "👤",
      });
      router.push("/login");
      return;
    }
    document.title = "Your Orders";
    fetchOrders(1);
  }, [isAuthenticated, authLoading]);

  useEffect(() => {
    if (!isOrderDetailsOpen) {
      fetchOrders(currentPage, itemsPerPage, true, true); // merge = true, silent = true
    }
    console.log(isOrderDetailsOpen ? "Order details open" : "Order details closed");
  }, [isOrderDetailsOpen]);
  
  

  return (
    <div
      className={`w-[90%] mx-auto flex gap-10 text-sm my-10 ${Style.orderContainer}`}
    >
      <div
        className={`min-w-[250px] border shadow py-4 text-[#6a3a18] h-fit ${Style.orderLeftContainer}`}
      >
        <div
          className={`flex items-center gap-2 px-4 pb-4 border-b ${Style.profileImageAndNameContainer}`}
        >
          <Image
            src={UserImage}
            width={1000}
            height={1000}
            quality={100}
            alt=""
            loading="lazy"
            className="w-[50px] h-[50px] rounded-full transition-opacity duration-500"
          />
          <div className="flex flex-col">
            <span className="text-xs">
              Hello <span className="text-lg">🖐️</span>
            </span>
            <span className="font-bold">{profileData?.cust_cmp_name}</span>
          </div>
        </div>
        <div
          className={`flex flex-col gap-1 py-4 px-2 ${Style.navigateButtons}`}
        >
          <Link
            href={"/profile"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Profile", {
                  duration: 3000,
                  position: "top-center",
                  icon: "👤",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <PiUserLight size={18} />
              <span>Personal Information</span>
            </div>
          </Link>
          <Link href={"/orders"}>
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer bg-[#6a3a18] text-white rounded-sm">
              <FiPackage size={18} />
              <span>My Orders</span>
            </div>
          </Link>
          <Link
            href={"/wishlist"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view your Wishlist", {
                  duration: 3000,
                  position: "top-center",
                  icon: "❤️",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoHeart size={18} />
              <span>My Wishlists</span>
            </div>
          </Link>
          <Link
            href={"/address"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoLocation size={18} />
              <span>Manage Addresses</span>
            </div>
          </Link>
          <Link
            href={"/passwordChange"}
            onClick={(e) => {
              const token = Cookies.get("token");
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to view manage Addresses", {
                  duration: 3000,
                  position: "top-center",
                  icon: "📍",
                });
                router.push("/login");
              }
            }}
          >
            <div className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm">
              <GoPasskeyFill size={18} />
              <span>Password Change</span>
            </div>
          </Link>
          <div
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <GoTrash size={18} />
            <span>Delete My Account</span>
          </div>
          <ConfirmModal
            isOpen={isModalOpen}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => setIsModalOpen(false)}
          />
          <div
            onClick={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("redirectAfterLogin");
              router.push("/login");
            }}
            className="flex items-center gap-3 py-2 px-2 cursor-pointer hover:bg-[#f0ebe8] rounded-sm"
          >
            <BiLogOut size={18} />
            <span>Logout</span>
          </div>
        </div>
      </div>
      {loading ? (
        <div className="grid grid-cols-1 gap-6 w-full mt-4">
          {[...Array(4)].map((_, index) => (
            <div
              key={index}
              className="h-[130px]  bg-gray-300 rounded-lg flex items-center px-4 space-x-4 border border-gray-300 p-3"
            >
              <div className="w-[50px] h-[50px] bg-gray-400 animate-pulse rounded-sm"></div>
              <div className="flex-1 px-4 space-y-3">
                <div className="h-5 w-3/4 bg-gray-400 animate-pulse rounded-sm"></div>
                <div className="h-5 w-2/4 bg-gray-400 animate-pulse rounded-sm"></div>
                <div className="h-5 w-1/3 bg-gray-400 animate-pulse rounded-sm"></div>
              </div>
              <div className="flex flex-col gap-3">
                <div className="h-9 w-[90px] bg-gray-400 animate-pulse rounded-sm"></div>
                <div className="h-9 w-[90px] bg-gray-400 animate-pulse rounded-sm"></div>
              </div>
            </div>
          ))}
        </div>
      ) : orderlist.length === 0 && !loading ? (
        <div className="flex mx-auto flex-col items-center justify-center h-[300px] text-gray-500">
          <ShoppingBag size={50} className="text-gray-400 mb-3" />
          <span className="text-lg font-semibold">No orders found</span>
          <p className="text-sm text-gray-400">Your order list is empty.</p>
        </div>
      ) : isOrderDetailsOpen ? (
        <OrderDetails
          onClose={() => setIsOrderDetailsOpen(false)}
          orderId={selectedOrderId ?? 0}
        />
      ) : (
        <div className={`w-full ${Style.orderRightContainer}`}>
          {orderlist.map((order, index) => (
            <div
              key={index}
              className="rounded-lg border shadow-sm p-4 mb-6 bg-white animate-fadeIn"
            >
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-start gap-3">
                  <span className="text-sm font-medium">Order #{order.id}</span>
                  <span
                    className={`text-xs px-3 py-1 rounded-full ${
                      order.payment_status === "Paid"
                        ? "bg-green-100 text-green-600"
                        : "bg-yellow-100 text-yellow-600"
                    }`}
                  >
                    {order.payment_status}
                  </span>
                  <span className="text-sm text-gray-600">
                    Status: {order.order_status}
                  </span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs border-[#6a3a18] text-#6a3a18 hover:bg-[#6a3a18] hover:text-white transition-colors"
                  onClick={() => {
                    setSelectedOrderId(order.id);
                    setIsOrderDetailsOpen(true);
                  }}
                >
                  View Order Details
                </Button>
              </div>
              <div className="flex gap-6">
                <div
                  className={`relative w-[120px] h-[120px] overflow-hidden rounded-md shadow-sm grid 
          ${
            order.jw_order_items.length === 1
              ? "grid-cols-1"
              : "grid-cols-2 grid-rows-2 gap-1"
          }`}
                >
                  {order.jw_order_items
                    .slice(0, 4)
                    .map((item: any, i: number) => {
                      const imageSrc =
                        item.EstShopInventories?.[0]?.image_path
                          ? parseImagePath(item.EstShopInventories[0].image_path)
                          : ImageNotFound.src;

                      return (
                        <div
                          key={i}
                          className={`relative w-full h-full ${
                            order.jw_order_items.length === 3 && i === 0
                              ? "col-span-2 row-span-2"
                              : ""
                          }`}
                        >
                          <img
                            src={imageSrc}
                            width={order.jw_order_items.length === 1 ? 120 : 60}
                            height={
                              order.jw_order_items.length === 1 ? 120 : 60
                            }
                            alt={`Product image ${i + 1}`}
                            className="object-cover w-full h-full rounded-sm"
                          />
                          {i === 3 && order.jw_order_items.length > 4 && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white font-bold text-sm rounded-sm transition-opacity duration-500">
                              +{order.jw_order_items.length - 4}
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-bold text-lg">
                        {order.jw_order_items.length === 1 ? (
                          order.jw_order_items[0]?.ProductMaster?.product_name
                        ) : order.jw_order_items.length === 2 ? (
                          `${order.jw_order_items[0]?.ProductMaster?.product_name}, ${order.jw_order_items[1]?.ProductMaster.product_name}`
                        ) : (
                          <>
                            {
                              order.jw_order_items[0]?.ProductMaster
                                ?.product_name
                            }
                            ,{" "}
                            {
                              order.jw_order_items[1]?.ProductMaster
                                ?.product_name
                            }
                            <span className="text-sm font-normal text-gray-600">
                              {" "}
                              +{order.jw_order_items.length - 2} more
                            </span>
                          </>
                        )}
                      </h3>
                      <div className="text-sm text-gray-600 mt-1">
                        <p>Quantity: {order.jw_order_items?.[0].quantity}</p>
                        <p>
                          Ordered on:{" "}
                          {new Date(order.created_at).toLocaleDateString(
                            "en-US",
                            {
                              day: "2-digit",
                              month: "long",
                              year: "numeric",
                            }
                          )}{" "}
                          at{" "}
                          {new Date(order.created_at).toLocaleTimeString(
                            "en-US",
                            {
                              hour: "2-digit",
                              minute: "2-digit",
                              hour12: true,
                            }
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="text-xl font-bold text-[#6a3a18]">
                      ₹{formatIndianCurrency(Number(order.total_price))}
                    </div>
                  </div>
                  {order.jw_order_items.length === 1 && (
                    <div className="mt-4">
                      <p className="text-sm font-medium mb-2">
                        Rate this product:
                      </p>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => {
                          const productRating =
                            order.jw_order_items[0].jw_product_ratings?.length >
                            0
                              ? order.jw_order_items[0].jw_product_ratings[0]
                                  .product_rating
                              : ratings[order.id] || 0;

                          return (
                            <button
                              key={star}
                              onClick={() =>
                                handleRating(
                                  order.jw_order_items[0]?.product_id,
                                  star,
                                  order.jw_order_items[0]?.inventory_id,
                                  order.id,
                                  order
                                )
                              }
                              className="focus:outline-none transition-transform hover:scale-110"
                            >
                              <Star
                                fill={
                                  productRating >= star ? "#FFD700" : "none"
                                }
                                color={
                                  productRating >= star ? "#FFD700" : "#D1D5DB"
                                }
                                size={24}
                              />
                            </button>
                          );
                        })}
                        <Dialog
                          open={isReviewDialogOpen}
                          onOpenChange={setIsReviewDialogOpen}
                        >
                          <DialogTrigger asChild>
                            <button
                              className="ml-3 text-sm text-[#6a3a18] font-medium hover:underline transition-colors hover:text-[#593114]"
                              onClick={() => {
                                openReviewDialog(order);
                                setIsReviewDialogOpen(true);
                              }}
                            >
                              {order.jw_order_items[0]?.jw_product_ratings?.[0]?.id ? "Edit Review" : "Write a Review"}
                            </button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-md border-0 shadow-lg rounded-xl overflow-hidden p-0">
                            <div className="bg-gradient-to-br from-[#6a3a18] to-[#a05c2c] text-white">
                              <DialogHeader className="p-6 pb-4">
                                <DialogTitle className="text-xl font-bold text-white">
                                  Share Your Experience
                                </DialogTitle>
                              </DialogHeader>
                              <div className="flex items-center gap-4 mb-4 px-6">
                                <div className="relative w-20 h-20 overflow-hidden rounded-md border-2 border-white/30 shadow-md">
                                  <img
                                    src={
                                      order.jw_order_items[0]
                                        .EstShopInventories?.[0]?.image_path
                                        ? parseImagePath(
                                            order.jw_order_items[0]
                                              .EstShopInventories[0].image_path
                                          )
                                        : ImageNotFound.src
                                    }
                                    width={80}
                                    height={80}
                                    alt="Product image"
                                    className="object-cover w-full h-full"
                                  />
                                </div>
                                <div>
                                  <h3 className="font-bold text-white">
                                    {
                                      order.jw_order_items[0].ProductMaster
                                        .product_name
                                    }
                                  </h3>
                                  <p className="text-sm text-white/80">
                                    Order #{selectedOrder?.id}
                                  </p>
                                  <p className="text-sm text-white/80">
                                    Ordered on:{" "}
                                    {new Date(order.created_at).toLocaleDateString(
                                      "en-US",
                                      {
                                        day: "2-digit",
                                        month: "long",
                                        year: "numeric",
                                      }
                                    )}{" "}
                                    at{" "}
                                    {new Date(order.created_at).toLocaleTimeString(
                                      "en-US",
                                      {
                                        hour: "2-digit",
                                        minute: "2-digit",
                                        hour12: true,
                                      }
                                    )}
                                  </p>
                                </div>
                              </div>
                              <div className="px-6 pb-6">
                                <p className="text-sm font-medium mb-2 text-white/90">
                                  Your Rating:
                                </p>
                                <div className="flex gap-1">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <button
                                      key={star}
                                      // onClick={() =>
                                      //   handleDialogRating(
                                      //     star,
                                      //     order.id,
                                      //     order.jw_order_items[0]?.product_id
                                      //   )
                                      // }
                                      className="focus:outline-none transition-transform hover:scale-110"
                                    >
                                      <Star
                                        fill={dialogRating >= star ? "#FFD700" : "none"}
                                        color={dialogRating >= star ? "#FFD700" : "#D1D5DB"}
                                        size={24}
                                      />
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </div>
                            <div className="p-6 bg-white">
                              <div className="space-y-2">
                                <label
                                  htmlFor="review"
                                  className="text-sm font-medium text-gray-800"
                                >
                                  Your Review:
                                </label>
                                <textarea
                                  id="review"
                                  className="w-full p-3 border rounded-md text-sm focus:ring-2 focus:ring-[#6a3a18]/30 focus:border-[#6a3a18] transition-all"
                                  rows={4}
                                  placeholder="Share your thoughts about this product..."
                                  value={reviewText}
                                  onChange={(e) =>
                                    setReviewText(e.target.value)
                                  }
                                ></textarea>
                              </div>
                              <DialogFooter className="mt-4 flex justify-end">
                                <Button
                                  className="bg-[#6a3a18] text-white hover:bg-[#593114] transition-colors shadow-md hover:shadow-lg"
                                  onClick={() =>
                                    handleSubmitReview(
                                      order.id,
                                      order.jw_order_items[0]?.product_id
                                    )
                                  }
                                >
                                  Submit Review
                                </Button>
                              </DialogFooter>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          {hasMore && !loading && (
            <div className="flex justify-center mt-4">
              <Button
                variant="outline"
                size="sm"
                className="text-xs border-[#6a3a18] text-[#6a3a18] hover:bg-[#6a3a18] hover:text-white transition-colors"
                onClick={handleViewMoreOrders}
              >
                View More Orders
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}