/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import * as React from "react";
import toast, { Toaster } from "react-hot-toast";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import Cookies from "js-cookie";
import axios from "axios";
import { ChevronDown, Pencil } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState, useRef } from "react";
import config from "../../../../config.json";

export type ButtonSetting = {
  company_id: string;
  button_id: number;
  button_name: string;
  button_period: string;
  button_status: boolean;
};

const CustomToggle = ({
  checked,
  onCheckedChange,
}: {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) => {
  return (
    <div
      className="flex justify-center items-center h-full"
      onClick={() => onCheckedChange(!checked)}
    >
      <div
        className={`relative w-12 h-6 flex items-center rounded-full cursor-pointer transition-all ${
          checked ? "bg-green-500" : "bg-gray-400"
        }`}
      >
        <div
          className={`absolute w-5 h-5 bg-white rounded-full transition-all shadow-md ${
            checked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </div>
    </div>
  );
};

// Component for Button Period Cell
const ButtonPeriodCell = ({
  row,
  updateButtonSettings,
}: {
  row: any;
  updateButtonSettings: (
    buttonId: string,
    buttonPeriod: string,
    buttonStatus: boolean
  ) => Promise<void>;
}) => {
  const buttonSetting = row.original;
  const [period, setPeriod] = useState(buttonSetting.button_period);
  const [isEditing, setIsEditing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handlePeriodChange = async () => {
    if (period === buttonSetting.button_period || !period) {
      setIsEditing(false);
      return;
    }

    try {
      await updateButtonSettings(
        buttonSetting.button_id.toString(),
        period,
        buttonSetting.button_status
      );
      setIsEditing(false);
    } catch (error) {
      setPeriod(buttonSetting.button_period); // Revert on error
      setIsEditing(false);
    }
  };

  return (
    <div className="text-center">
      {isEditing ? (
        <div className="flex items-center justify-center gap-2">
          <Input
            type="number"
            min="1"
            step="1"
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="w-20 border-0 border-b-2 border-gray-300 focus:outline-none focus:ring-0 focus:border-blue-500 focus:text-center text-left [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none [-moz-appearance:textfield]"
            onBlur={handlePeriodChange}
            onKeyDown={(e) => {
              if (e.key === "Enter") handlePeriodChange();
            }}
            ref={inputRef}
            onFocus={(e) => e.target.select()}
            autoFocus
          />
        </div>
      ) : (
        <div
          className="cursor-pointer hover:bg-gray-100 p-1 rounded flex items-center justify-center gap-1"
          onClick={() => setIsEditing(true)}
        >
          {period}
          <Pencil className="h-3 w-3 text-gray-400" />
        </div>
      )}
    </div>
  );
};

// Component for Button Status Cell
const ButtonStatusCell = ({
  row,
  updateButtonSettings,
}: {
  row: any;
  updateButtonSettings: (
    buttonId: string,
    buttonPeriod: string,
    buttonStatus: boolean
  ) => Promise<void>;
}) => {
  const buttonSetting = row.original;
  const [status, setStatus] = useState(buttonSetting.button_status);

  const handleStatusToggle = async () => {
    const newStatus = !status;
    if (newStatus && parseInt(buttonSetting.button_period) === 0) {
      toast.error("Button period must be greater than 0.");
      return;
    }

    try {
      await updateButtonSettings(
        buttonSetting.button_id.toString(),
        buttonSetting.button_period,
        newStatus
      );
      setStatus(newStatus);
    } catch (error) {
      // Error is handled in updateButtonSettings
    }
  };

  return (
    <div className="text-center">
      <CustomToggle checked={status} onCheckedChange={handleStatusToggle} />
    </div>
  );
};

const columns = (
  updateButtonSettings: (
    buttonId: string,
    buttonPeriod: string,
    buttonStatus: boolean
  ) => Promise<void>
): ColumnDef<ButtonSetting>[] => [
  {
    id: "serial_no",
    header: () => <div className="text-center">Sl No</div>,
    cell: ({ row }) => (
      <div className="text-center">{row.index + 1}</div>
    ),
  },
  {
    accessorKey: "button_name",
    header: () => <div className="text-center">Button Name</div>,
    cell: ({ row }) => (
      <div className="text-center">{row.original.button_name}</div>
    ),
  },
  {
    accessorKey: "button_period",
    header: () => <div className="text-center">Period (Days)</div>,
    cell: ({ row }) => (
      <ButtonPeriodCell row={row} updateButtonSettings={updateButtonSettings} />
    ),
  },
  {
    accessorKey: "button_status",
    header: () => <div className="text-center">Status</div>,
    cell: ({ row }) => (
      <ButtonStatusCell row={row} updateButtonSettings={updateButtonSettings} />
    ),
  },

];

export default function ButtonSettings() {
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 8 });
  const [buttonSettings, setButtonSettings] = useState<ButtonSetting[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchButtonSettings = async (page: number, limit: number) => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      return [];
    }

    try {
      const { data } = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/buttonSettings?page=${page}&limit=${limit}`,
        {
          headers: {
            adminauth: authToken,
          },
        }
      );
      return data.data;
    } catch (error) {
      console.error("Error fetching button settings:", error);
      toast.error("Failed to fetch button settings. Please try again.");
      return [];
    }
  };

  const updateButtonSettings = async (
    buttonId: string,
    buttonPeriod: string,
    buttonStatus: boolean
  ) => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      throw new Error("No auth token");
    }

    try {
      await axios.patch(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updateButtonSettings`,
        {
          buttonId,
          buttonPeriod,
          buttonStatus,
        },
        {
          headers: {
            adminauth: authToken,
          },
        }
      );
      toast.success("Button settings updated successfully!");
      // Update local state for immediate feedback
      setButtonSettings((prev) =>
        prev.map((item) =>
          item.button_id.toString() === buttonId
            ? { ...item, button_period: buttonPeriod, button_status: buttonStatus }
            : item
        )
      );
    } catch (error) {
      console.error("Error updating button settings:", error);
      toast.error("Failed to update button settings. Please try again.");
      throw error;
    }
  };

  const loadButtonSettings = async () => {
    setIsLoading(true);
    try {
      const data = await fetchButtonSettings(
        pagination.pageIndex + 1,
        pagination.pageSize
      );
      setButtonSettings(data);
    } catch (error) {
      console.error("Error loading button settings:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadButtonSettings();
  }, [pagination.pageIndex, pagination.pageSize]);

  const table = useReactTable({
    data: buttonSettings,
    columns: columns(updateButtonSettings),
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      pagination,
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
    onPaginationChange: setPagination,
    manualPagination: true,
    pageCount: Math.ceil(buttonSettings.length / pagination.pageSize) || 1,
  });

  return (
    <>
      <Toaster position="top-center" />
      <div className="p-3 flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <span className="text-xl font-bold">Button Settings</span>
        </div>
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-center justify-end py-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div>
            <Table>
              <TableHeader
                className="border-b-2"
                style={{ borderColor: "#D3D6E8" }}
              >
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      return (
                        <TableHead key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </TableHead>
                      );
                    })}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={columns(updateButtonSettings).length}
                      className="h-24 text-center"
                    >
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && "selected"}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns(updateButtonSettings).length}
                      className="h-24 text-center"
                    >
                      No results.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground"></div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex - 1,
                  }));
                }}
                disabled={pagination.pageIndex === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex + 1,
                  }));
                }}
                disabled={buttonSettings.length < pagination.pageSize}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}