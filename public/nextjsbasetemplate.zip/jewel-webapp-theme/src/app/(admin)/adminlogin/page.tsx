"use client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import useAuthStore from "../stores/userAuthStore";
import { useRouter } from "next/navigation";
import axios from "axios";
import { useMutation } from "@tanstack/react-query";
import config from "../../../../config.json";
import toast, { Toaster } from "react-hot-toast";
import Cookies from "js-cookie";
import React from "react";

export default function Login() {
  const router = useRouter();
  const { login, isAuthenticated, initializeAuth } = useAuthStore();
  function storeToken(token: string) {
    Cookies.set("authToken", token);
  }
  const [email, setEmail] = useState("");
  const [companyID, setCompanyID] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({
    email: "",
    companyID: "",
    password: "",
  });

  useEffect(() => {
    setCompanyID(config.COMPANY_ID);
    initializeAuth();
  }, [initializeAuth]);

  useEffect(() => {
    if (isAuthenticated) {
      router.push("/admin");
    }
  }, [isAuthenticated, router]);

  // Validation functions
  const validateEmail = (email: any) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) return "Email is required";
    if (!emailRegex.test(email)) return "Please enter a valid email address";
    return "";
  };

  const validateCompanyID = (id: any) => {
    if (!id) return "Company ID is required";
    if (id.length < 3) return "Company ID must be at least 3 characters";
    return "";
  };

  const validatePassword = (password: any) => {
    if (!password) return "Password is required";
    if (password.length < 6) return "Password must be at least 6 characters";
    return "";
  };

  // Handle form validation
  const validateForm = () => {
    const newErrors = {
      email: validateEmail(email),
      companyID: validateCompanyID(companyID),
      password: validatePassword(password),
    };

    setErrors(newErrors);
    return !Object.values(newErrors).some((error) => error !== "");
  };

  const loginMutation = useMutation({
    mutationFn: async () => {
      if (!validateForm()) {
        throw new Error("Validation failed");
      }

      // First, login request
      const loginResponse = await axios.post(`${config.NEXT_PUBLIC_API_URL}/api/v1/admin/login`, {
        username: email,
        companyId: companyID,
        password,
      });

      // Then, get company details
      const companyResponse = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getCompanyDetail?companyId=${companyID}`
      );

      return {
        loginData: loginResponse.data,
        companyData: companyResponse.data,
      };
    },

onSuccess: (data) => {
  const token = data.loginData.data.token;
  const cmp_logo_raw = data.companyData.data.cmp_logo;

  // Parse stringified array and extract the first src
  let logoSrc = null;
  try {
    const parsedLogo = JSON.parse(cmp_logo_raw); // this is now an array
    logoSrc = parsedLogo[0]?.src || null;
  } catch (error) {
    console.error("Error parsing cmp_logo:", error);
  }

  // Store token, email, and logoSrc in Zustand store
  login(token, email, logoSrc);

  toast.success("Login Successful! 🎉");
  sessionStorage.setItem("username", email);
  router.push("/admin");
},


    onError: (error) => {
      if (error.message !== "Validation failed") {
        if (axios.isAxiosError(error) && error.response?.status === 404) {
          toast.error(error.response.data.message || "Password is Incorrect");
        } else {
          toast.error("Login failed. Please try again.");
        }
      }
    },
  });

  // Handle input changes with validation
  const handleEmailChange = (e: any) => {
    const value = e.target.value;
    setEmail(value);
    setErrors((prev) => ({
      ...prev,
      email: validateEmail(value),
    }));
  };

  const handleCompanyIDChange = (e: any) => {
    const value = e.target.value;
    setCompanyID(value);
    setErrors((prev) => ({
      ...prev,
      companyID: validateCompanyID(value),
    }));
  };

  const handlePasswordChange = (e: any) => {
    const value = e.target.value;
    setPassword(value);
    setErrors((prev) => ({
      ...prev,
      password: validatePassword(value),
    }));
  };

  return (
    <>
      <Toaster position="top-center" />
      <div className="w-full h-[100vh] flex justify-center items-center">
        <div className="w-[350px] shadow-lg rounded-lg flex flex-col justify-center items-center text-[#5A607F] bg-white p-8 gap-6 py-10">
          <div className="w-full text-center mb-4">
            <span className="text-2xl font-bold">Sign In</span>
          </div>
          <div className="w-full flex flex-col gap-4">
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <Label htmlFor="email" className="text-black">
                Email
              </Label>
              <Input
                type="email"
                id="email"
                placeholder="Enter Email Address"
                className={`w-full ${errors.email ? "border-red-500" : ""}`}
                value={email}
                onChange={handleEmailChange}
              />
              {errors.email && (
                <span className="text-red-500 text-sm">{errors.email}</span>
              )}
            </div>

            <div className="grid w-full max-w-sm items-center gap-1.5">
              <Label htmlFor="password" className="text-black">
                Password
              </Label>
              <Input
                type="password"
                id="password"
                placeholder="Enter Password"
                className={`w-full ${errors.password ? "border-red-500" : ""}`}
                value={password}
                onChange={handlePasswordChange}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    loginMutation.mutate();
                  }
                }}
              />
              {errors.password && (
                <span className="text-red-500 text-sm">{errors.password}</span>
              )}
            </div>
          </div>

          <Button
            className="w-full bg-[#1e2753] hover:bg-[#1e2753]"
            onClick={() => loginMutation.mutate()}
            disabled={loginMutation.isPending}
          >
            {loginMutation.isPending ? "Logging in..." : "Continue"}
          </Button>
        </div>
      </div>
    </>
  );
}