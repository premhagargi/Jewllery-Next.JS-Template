
/* eslint-disable react-hooks/rules-of-hooks */
"use client";

import * as React from "react";
import toast, { Toaster } from "react-hot-toast";
import TablePDF from "../../../components/admin/TablePDF";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "../../../components/admin/PDFWrapper";
import dynamic from "next/dynamic";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"; // Adjust based on your Tooltip implementation
import { Copy } from "lucide-react"; // or any other icon

const PDFDownloadLink = dynamic(
  () =>
    import("../../../components/admin/PDFWrapper").then(
      (mod) => mod.PDFDownloadLink
    ),
  { ssr: false }
);

const copyToClipboard = async (text: string) => {
  try {
    await navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  } catch (err) {
    console.error("Failed to copy!", err);
    toast.error("Failed to copy");
  }
};

import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import useAuthStore from "../stores/userAuthStore";
import { motion } from "framer-motion";
import axios from "axios";
import { useQuery, useQueryClient } from "@tanstack/react-query"; // Import useQueryClient
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import {
  ChevronDown,
  ChevronUp,
  MoreHorizontal,
  Plus,
  Minus,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import Cookies from "js-cookie";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";
// import { base_url } from "@/app/(admin)/config";
import config from '../../../../config.json'

import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type Payment = {
  company_id: string;
  id: number;
  name: string;
  order_id: string;
  est_shop_id: number;
  payment_reference_id: string;
  user_id: number;
  address_id: number | null;
  total_price: string;
  payment_method_id: number;
  payment_status: "Pending" | "Paid" | "Failed";
  order_status: "Pending" | "Delivered" | "Undelivered";
  delivery_status: "Order Confirm" | "Dispatched" | "In Transit" | "Delivered";
  created_at: string;
  updated_at: string;
  jw_payment_mode: {
    id: number;
    payment_method: string;
  };
  mi_shop_est: {
    est_shop_name: string;
  }
  jw_order_items: {
    order_item_id: number;
    company_id: string;
    est_shop_id: number;
    order_id: number;
    product_id: number;
    quantity: number;
    price: string;
    total_price: string;
    created_at: string;
    ProductMaster: {
      product_name: string;
    };
  }[];
  jw_invoice_items: {
    id: number;
    est_shop_id: string;
    quantity: number;
    total_price: string;
    mi_shop_est: {
      id: number;
      est_shop_name: string;
      address1: string;
      address2: string;
    };
  }[];
  mi_customer: {
    id: number;
    cust_cmp_name: string;
  };
  jw_customer_address: null | {
    street: string;
    name: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
    address_line1: string;
    address_line2: string;
    contact_no: string;
    City: {
      id: number;
      city_name: string;
    };
    State: {
      state_name: string;
      id: number;
    };
    Country: {
      country_name: string;
      id: number;
    };
  };
};

// Status Dropdown Component
interface StatusDropdownProps {
  currentStatus: string;
  statusOptions: string[];
  onStatusChange: (newStatus: string) => void;
}

const StatusDropdown: React.FC<StatusDropdownProps> = ({
  currentStatus,
  statusOptions,
  onStatusChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={`p-2 rounded-sm text-xs ${ // Added text-xs
            currentStatus.toLowerCase() === "pending" // Pending
              ? "bg-slate-300 text-slate-800"
              : currentStatus.toLowerCase() === "undelivered" // Undelivered
              ? "bg-slate-300 text-slate-800"
              : currentStatus.toLowerCase() === "order confirm" // Order Confirm
              ? "bg-slate-300 text-slate-800"
              : currentStatus.toLowerCase() === "dispatched" // Dispatched
              ? "bg-orange-300 text-orange-800"
              : currentStatus.toLowerCase() === "in transit" // In Transit
              ? "bg-orange-300 text-orange-800"
              : currentStatus.toLowerCase() === "delivered" // Delivered
              ? "bg-green-300 text-green-800"
              : currentStatus.toLowerCase() === "paid" // Paid
              ? "bg-green-300 text-green-800"
              : currentStatus.toLowerCase() === "failed" // Failed
              ? "bg-red-300 text-red-800"
              : ""
          }`}
        >
          {currentStatus} {isOpen ? <ChevronUp /> : <ChevronDown />}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {statusOptions.map((status) => (
          <DropdownMenuItem key={status} onClick={() => onStatusChange(status)} className="text-xs">
            {status}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

// Status Update Functions
const updateOrderStatus = async (orderId: number, orderStatus: string) => {
  const authToken = Cookies.get("authToken");
  if (!authToken) {
    toast.error("Please login to proceed!");
    
  }

  try {
    const { data } = await axios.patch(
      `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updateOrderStatus`,
      { orderId, orderStatus },
      {
        headers: {
          adminauth: authToken,
        },
      }
    );
    return data.data;
  } catch (error) {
    console.error("Error updating order status:", error);
    throw error;
  }
};

const updatePaymentStatus = async (orderId: number, paymentStatus: string) => {
  const authToken = Cookies.get("authToken");
  if (!authToken) {
    toast.error("Please login to proceed!");
    
  }

  try {
    const { data } = await axios.patch(
      `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updatePaymentStatus`,
      { orderId, paymentStatus },
      {
        headers: {
          adminauth: authToken,
        },
      }
    );
    return data.data;
  } catch (error) {
    console.error("Error updating payment status:", error);
    throw error;
  }
};

const updateDeliveryStatus = async (
  orderId: number,
  deliveryStatus: string
) => {
  const authToken = Cookies.get("authToken");
  if (!authToken) {
    toast.error("Please login to proceed!");
    
  }

  try {
    const { data } = await axios.patch(
      `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updateDeliveryStatus`,
      { orderId, deliveryStatus },
      {
        headers: {
          adminauth: authToken,
        },
      }
    );
    return data.data;
  } catch (error) {
    console.error("Error updating delivery status:", error);
    throw error;
  }
};

// Table Columns
const getColumns = ({ 
  pageIndex, 
  orderStatusOptions, 
  paymentStatusOptions, 
  deliveryStatusOptions 
}: { 
  pageIndex: number;
  orderStatusOptions: string[];
  paymentStatusOptions: string[];
  deliveryStatusOptions: string[];
}): ColumnDef<Payment>[] => [
  {
    accessorKey: "expand",
    header: () => <div className="w-auto"></div>,
    cell: ({ row }) => (
      <div className="text-blue-500 font-bold text-center">
        {row.getIsExpanded() ? "-" : "+"}
      </div>
    ),
  },
  {
    accessorKey: "order_id",
    header: () => <div className="w-auto">Order ID</div>,
    cell: ({ row }) => <div className="w-auto">{row.original.order_id}</div>,
  },
  {
    accessorKey: "Customer Name",
    header: () => <div className="w-auto text-center">Customer Name</div>,
    cell: ({ row }) => {
      const customerName = row?.original?.mi_customer?.cust_cmp_name || 'N/A';
      return <div className="w-auto text-center">{customerName}</div>;
    },
  },  
  {
  accessorKey: "created_at",
  header: () => <div className="w-auto text-center">Date</div>,
  cell: ({ row }) => {
    const createdAt = row?.original?.created_at;
    const formattedDate = createdAt
      ? new Date(createdAt).toLocaleString("en-IN", {
          day: "2-digit",
          month: "short",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "N/A";
    return <div className="w-auto text-center">{formattedDate}</div>;
  },
},

  {
    accessorKey: "Shop Name",
    header: () => <div className="w-auto text-center">Shop Name</div>,
    cell: ({ row }) => (
      <div className="w-auto text-center">
        {row.original.mi_shop_est.est_shop_name}
      </div>
    ),
  },
  {
    accessorKey: "Payment Mode",
    header: () => <div className="w-auto text-center">Payment Mode</div>,
    cell: ({ row }) => (
      <div className="text-center">
        {row.original.jw_payment_mode.payment_method}
      </div>
    ),
  },
  {
    accessorKey: "Amount",
    header: () => <div className="text-center">Amount</div>,
    cell: ({ row }) => {
      const amount = row.original.total_price ? parseFloat(row.original.total_price) : null;
      if (amount === null || isNaN(amount)) return <div className="text-center">-</div>;
      const formatted =
        amount % 1 === 0
          ? new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount)
          : new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount);
      return <div className="text-center font-medium">{formatted}</div>;
    },
  },
  {
    accessorKey: "Order Status",
    header: () => <div className="w-auto text-center">Order Status</div>,
    cell: ({ row }) => {
      const queryClient = useQueryClient();
  
      const handleOrderStatusChange = async (newStatus: string) => {
        const previousData = queryClient.getQueryData<Payment[]>(["orderList", pageIndex]);
  
        toast((t) => (
          <div>
            <p>Are you sure you want to update the order status to <b>{newStatus}</b>?</p>
            <div className="flex justify-center gap-2 mt-2">
              <button className="px-3 py-1 bg-green-500 text-white rounded" onClick={async () => {
                toast.dismiss(t.id);
                try {
                  await updateOrderStatus(row.original.id, newStatus);
                  toast.success("Order status updated successfully!");
                  queryClient.invalidateQueries({ queryKey: ["orderList"] });
                } catch (error) {
                  if (previousData) {
                    queryClient.setQueryData(["orderList", pageIndex], previousData);
                  }
                  toast.error("Failed to update order status. Please try again.");
                }
              }}>
                Confirm
              </button>
              <button className="px-3 py-1 bg-red-500 text-white rounded" onClick={() => toast.dismiss(t.id)}>Cancel</button>
            </div>
          </div>
        ), { duration: Infinity });
      };
  
      return (
        <div className="capitalize w-auto text-center" onClick={(e) => e.stopPropagation()}>
          <StatusDropdown
            currentStatus={row.original.order_status}
            statusOptions={orderStatusOptions}  // Using extracted options
            onStatusChange={handleOrderStatusChange}
          />
        </div>
      );
    },
  },
  
  {
    accessorKey: "Payment Status",
    header: () => <div className="w-auto text-center">Payment Status</div>,
    cell: ({ row }) => {
      const queryClient = useQueryClient();
  
      const handlePaymentStatusChange = async (newStatus: string) => {
        const previousData = queryClient.getQueryData<Payment[]>(["orderList", pageIndex]);
  
        toast((t) => (
          <div>
            <p>Are you sure you want to update the payment status to <b>{newStatus}</b>?</p>
            <div className="flex justify-center gap-2 mt-2">
              <button className="px-3 py-1 bg-green-500 text-white rounded" onClick={async () => {
                toast.dismiss(t.id);
                try {
                  await updatePaymentStatus(row.original.id, newStatus);
                  toast.success("Payment status updated successfully!");
                  queryClient.invalidateQueries({ queryKey: ["orderList"] });
                } catch (error) {
                  if (previousData) {
                    queryClient.setQueryData(["orderList", pageIndex], previousData);
                  }
                  toast.error("Failed to update payment status. Please try again.");
                }
              }}>
                Confirm
              </button>
              <button className="px-3 py-1 bg-red-500 text-white rounded" onClick={() => toast.dismiss(t.id)}>Cancel</button>
            </div>
          </div>
        ), { duration: Infinity });
      };
  
      return (
        <div className="capitalize text-center" onClick={(e) => e.stopPropagation()}>
          <StatusDropdown
            currentStatus={row.original.payment_status}
            statusOptions={paymentStatusOptions}  // Using extracted options
            onStatusChange={handlePaymentStatusChange}
          />
        </div>
      );
    },
  },
  
  {
    accessorKey: "Delivery Status",
    header: () => <div className="w-auto text-center">Delivery Status</div>,
    cell: ({ row }) => {
      const queryClient = useQueryClient();
  
      const handleDeliveryStatusChange = async (newStatus: string) => {
        const previousData = queryClient.getQueryData<Payment[]>(["orderList", pageIndex]);
  
        toast((t) => (
          <div>
            <p>Are you sure you want to update the delivery status to <b>{newStatus}</b>?</p>
            <div className="flex justify-center gap-2 mt-2">
              <button className="px-3 py-1 bg-green-500 text-white rounded" onClick={async () => {
                toast.dismiss(t.id);
                try {
                  await updateDeliveryStatus(row.original.id, newStatus);
                  toast.success("Delivery status updated successfully!");
                  queryClient.invalidateQueries({ queryKey: ["orderList"] });
                } catch (error) {
                  if (previousData) {
                    queryClient.setQueryData(["orderList", pageIndex], previousData);
                  }
                  toast.error("Failed to update delivery status. Please try again.");
                }
              }}>
                Confirm
              </button>
              <button className="px-3 py-1 bg-red-500 text-white rounded" onClick={() => toast.dismiss(t.id)}>Cancel</button>
            </div>
          </div>
        ), { duration: Infinity });
      };
  
      return (
        <div className="w-fit text-center mx-auto" onClick={(e) => e.stopPropagation()}>
          <StatusDropdown
            currentStatus={row.original.delivery_status}
            statusOptions={deliveryStatusOptions}  // Using extracted options
            onStatusChange={handleDeliveryStatusChange}
          />
        </div>
      );
    },
  },
    {
    accessorKey: "Shipping Address",
    header: () => <div className="text-center w-[170px]">Shipping Address</div>,
    cell: ({ row }) => {
      const addr = row.original.jw_customer_address;
      const name = addr?.name || "N/A";
      const contact = addr?.contact_no || "N/A";
      const fullAddress = `${addr?.address_line1 || ""}${addr?.address_line2 ? ", " + addr.address_line2 : ""}, ${addr?.City?.city_name || ""}, ${addr?.State?.state_name || ""}, ${addr?.Country?.country_name || ""}, ${addr?.postal_code || ""}`.trim() || "N/A";
  
      const preview = `${name}, ${contact}, ${fullAddress}`;
  
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="truncate cursor-help max-w-[200px] select-none">
              {preview}
            </div>
          </TooltipTrigger>
          <TooltipContent className="space-y-1.5 max-w-[300px] px-2 py-1.5">
  {/* Name */}
  <div className="flex items-center justify-between gap-2">
    <div className="text-xs flex-1 truncate">
      <span className="font-medium">Name:</span> {name}
    </div>
    <Button
      size="icon"
      variant="ghost"
      onClick={(e) => {
        e.stopPropagation();
        copyToClipboard(name);
      }}
    >
      <Copy className="w-4 h-4" />
    </Button>
  </div>

  {/* Contact */}
  <div className="flex items-center justify-between gap-2">
    <div className="text-xs flex-1 truncate">
      <span className="font-medium">Contact:</span> {contact}
    </div>
    <Button
      size="icon"
      variant="ghost"
      onClick={(e) => {
        e.stopPropagation();
        copyToClipboard(contact);
      }}
    >
      <Copy className="w-4 h-4" />
    </Button>
  </div>

  {/* Address (multiline) */}
  <div className="flex items-start justify-between gap-2">
    <div className="text-xs flex-1 whitespace-pre-wrap">
      <span className="font-medium">Address:</span> {fullAddress}
    </div>
    <Button
      size="icon"
      variant="ghost"
      onClick={(e) => {
        e.stopPropagation();
        copyToClipboard(fullAddress);
      }}
    >
      <Copy className="w-4 h-4" />
    </Button>
  </div>
</TooltipContent>


        </Tooltip>
      );
    },
  }
  
];

// Expandable Row Component
const ExpandedRow = ({ row }: { row: Payment }) => {
  return (
    <div className="p-4 bg-white shadow-md border border-gray-100">
      <h3 className="text-xl font-semibold text-gray-900 mb-3">Order Items</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full border-separate border-spacing-0">
          <thead className="bg-gradient-to-r from-gray-50 to-gray-100 text-gray-600">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-semibold uppercase tracking-wider rounded-tl-lg">
                Product Name
              </th>
              <th className="px-4 py-2 text-center text-xs font-semibold uppercase tracking-wider">
                Quantity
              </th>
              <th className="px-4 py-2 text-right text-xs font-semibold uppercase tracking-wider">
                Item Price
              </th>
              <th className="px-4 py-2 text-right text-xs font-semibold uppercase tracking-wider rounded-tr-lg">
                Total Amount
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {row.jw_order_items.map((item, index) => {
              const price = parseFloat(item.price);
              const totalPrice = parseFloat(item.total_price);
              const isEven = index % 2 === 0;

              return (
                <tr
                  key={item.order_item_id}
                  className={`${
                    isEven ? "bg-gray-50" : "bg-white"
                  } hover:bg-indigo-50 transition-colors duration-100 ease-in-out`}
                >
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="text-xs font-medium text-gray-800 truncate max-w-xs">
                      {item.ProductMaster.product_name}
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-center">
                    <div className="text-xs text-gray-700 font-semibold bg-gray-200/50 rounded-lg px-3 py-1 inline-block">
                      {item.quantity}
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-right">
  <div className="text-xs text-indigo-600 font-semibold">
    {price % 1 === 0
      ? new Intl.NumberFormat("en-IN", {
          style: "currency",
          currency: "INR",
          maximumFractionDigits: 0, // No decimals if whole number
        }).format(price)
      : new Intl.NumberFormat("en-IN", {
          style: "currency",
          currency: "INR",
          minimumFractionDigits: 2, // Show 2 decimals if needed
          maximumFractionDigits: 2,
        }).format(price)}
  </div>
</td>

<td className="px-4 py-3 whitespace-nowrap text-right">
  <div className="text-xs font-bold text-indigo-800 bg-indigo-100/50 rounded px-2 py-1 inline-block">
    {totalPrice % 1 === 0
      ? new Intl.NumberFormat("en-IN", {
          style: "currency",
          currency: "INR",
          maximumFractionDigits: 0, // No decimals if whole number
        }).format(totalPrice)
      : new Intl.NumberFormat("en-IN", {
          style: "currency",
          currency: "INR",
          minimumFractionDigits: 2, // Show 2 decimals if needed
          maximumFractionDigits: 2,
        }).format(totalPrice)}
  </div>
</td>

                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default function Orders() {
  const [statusList, setStatusList] = useState<string[]>([]);
  const [orderStatusOptions, setOrderStatusOptions] = useState<string[]>([]);
  const [deliveryStatusOptions, setDeliveryStatusOptions] = useState<string[]>([]);
  const [paymentStatusOptions, setPaymentStatusOptions] = useState<string[]>([]);
  
  const [selectedFilter, setSelectedFilter] = React.useState("order_id");
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [expandedRows, setExpandedRows] = React.useState<
    Record<string, boolean>
  >({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 8 });

  const queryClient = useQueryClient();

  const fetchStatusList = async () => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      
    }

    try {
      const { data } = await axios.get(`${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getStatusList`, {
        headers: { adminauth: authToken },
      });

      // Extract and store the status values
      setOrderStatusOptions(data.data.orderStatus.map((item: any) => item.status));
      setDeliveryStatusOptions(data.data.deliverystatus.map((item: any) => item.status));
      setPaymentStatusOptions(data.data.paymentstatus.map((item: any) => item.status));
    } catch (error) {
      console.error("Error fetching status list:", error);
      toast.error("Failed to fetch status list. Please try again.");
    }
  };

  useEffect(() => {
    fetchStatusList();
  }, []);

  const columns = React.useMemo(
    () => getColumns({ pageIndex: pagination.pageIndex, 
      orderStatusOptions, 
      paymentStatusOptions, 
      deliveryStatusOptions 
    }),
    [pagination.pageIndex, orderStatusOptions, paymentStatusOptions, deliveryStatusOptions]
  );

  const fetchOrders = async (page: number, limit: number) => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      
    }

    try {
      const { data } = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getOrderList?page=${page}&limit=${limit}`,
        {
          headers: {
            adminauth: authToken,
          },
        }
      );
      return data.data;
    } catch (error) {
      console.error("Error fetching orders:", error);
      toast.error("Failed to fetch order list. Please try again.");
      throw error;
    }
  };
  const { logoutSignal } = useAuthStore();
  const {
    data: orderList = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<Payment[]>({
    queryKey: ["orderList", pagination.pageIndex],
    queryFn: () => fetchOrders(pagination.pageIndex + 1, pagination.pageSize),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchInterval: 5 * 60 * 1000,
  });
// Optional: Log for debugging
React.useEffect(() => {
  if (logoutSignal > 0) {
    console.log("Logout signal detected in AdminOrders:", logoutSignal);
  }
}, [logoutSignal]);
  const table = useReactTable({
    data: orderList ?? [],
    columns: columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    getRowCanExpand: (row) => row.original.jw_order_items.length > 1,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
    onPaginationChange: setPagination,
    manualPagination: true,
  });
  const exportToExcel = (orderList: any[]) => {
    if (!orderList || orderList.length === 0) {
      toast.error("No data available to export.");
      return;
    }

    // Map orderList to match Excel structure
    const mappedData = orderList.map((order) => ({
      "Order ID": order?.order_id,
      "Customer Name": order?.jw_customer_address?.name,
      "Products Ordered": order?.jw_order_items.map((item: { ProductMaster: { product_name: any; }; }) => item.ProductMaster.product_name).join(", "),
      "Customer Contact": order?.jw_customer_address?.contact_no,
      "Total Amount": order?.total_price,
      "Payment Method": order?.jw_payment_mode?.payment_method,
      "Status": order?.order_status,
      "Date": new Date(order.created_at).toLocaleDateString(),
    }));
  
    // Create worksheet and workbook
    const ws = XLSX.utils.json_to_sheet(mappedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Orders");
  
    // Generate Excel file
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  
    // Trigger download
    saveAs(data, "Orders-Maharana-Silver.xlsx");
    toast.success("Export started! Your Excel file will be ready soon.");
  };
  
  const ExportExcelButton = ({ orderList }: { orderList: any[] }) => {
    return (
      <Button onClick={() => exportToExcel(orderList)}>Export Data</Button>
    );
  };
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null);

  return (
    <>
      <Toaster position="top-center" />
      <div className="p-3 flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <span className="text-xl font-bold">Orders</span>
          <Button onClick={() => exportToExcel(orderList)}>Export Data</Button>

        </div>
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-center justify-between py-4">
            <div className="flex gap-2">
              <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="order_id">Order ID</SelectItem>
                    <SelectItem value="user_id">User ID</SelectItem>
                    <SelectItem value="date">Date</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
              <Input
                placeholder={`Filter by ${
                  selectedFilter === "order_id"
                    ? "Order Id"
                    : selectedFilter == "user_id"
                    ? "User Id"
                    : "Date"
                }...`}
                value={
                  (table
                    .getColumn(selectedFilter)
                    ?.getFilterValue() as string) ?? ""
                }
                onChange={(event) =>
                  table
                    .getColumn(selectedFilter)
                    ?.setFilterValue(event.target.value)
                }
                className="max-w-sm"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div>
          <Table>
  <TableHeader
    className="border-b-2"
    style={{ borderColor: "#D3D6E8" }}
  >
    {table.getHeaderGroups().map((headerGroup) => (
      <TableRow key={headerGroup.id} className="text-xs">
        {headerGroup.headers.map((header) => {
          return (
            <TableHead key={header.id} className="text-xs">
              {header.isPlaceholder
                ? null
                : flexRender(
                    header.column.columnDef.header,
                    header.getContext()
                  )}
            </TableHead>
          );
        })}
      </TableRow>
    ))}
  </TableHeader>
  <TableBody>
    {isLoading ? (
      <TableRow className="text-xs">
        <TableCell colSpan={table.getAllColumns().length} className="h-24 text-center text-xs">
          Loading...
        </TableCell>
      </TableRow>
    ) : table.getRowModel().rows.length > 0 ? (
      table.getRowModel().rows.map((row) => {
        const isExpanded = expandedRowId === row.id;
        return (
          <React.Fragment key={row.id}>
            <TableRow 
              data-state={row.getIsSelected() && "selected"}
              onClick={() => {
                setExpandedRowId(isExpanded ? null : row.id);
              }}
              className={`cursor-pointer hover:bg-gray-50 ${isExpanded ? "bg-gray-100" : ""} text-xs`} 
            >
              {row.getVisibleCells().map((cell) => {
                if (cell.column.id === "expand") {
                  return (
                    <TableCell key={cell.id} className="text-xs">
                      <div className="text-blue-500 font-bold text-center">
                        {isExpanded ? "-" : "+"}
                      </div>
                    </TableCell>
                  );
                }
                return (
                  <TableCell key={cell.id} className="text-xs">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </TableCell>
                );
              })}
            </TableRow>
            {isExpanded && (
              <TableRow className="text-xs">
                <TableCell colSpan={table.getAllColumns().length} className="p-0 w-full text-xs">
                  <div className="w-full">
                    <ExpandedRow row={row.original} />
                  </div>
                </TableCell>
              </TableRow>
            )}
          </React.Fragment>
        );
      })
    ) : (
      <TableRow className="text-xs">
        <TableCell colSpan={table.getAllColumns().length} className="h-24 text-center text-xs">
          No results.
        </TableCell>
      </TableRow>
    )}
  </TableBody>
</Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {/* {table.getFilteredSelectedRowModel().rows.length} of{" "}
              {table.getFilteredRowModel().rows.length} row(s) selected. */}
            </div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex - 1,
                  }));
                  refetch();
                }}
                disabled={pagination.pageIndex === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex + 1,
                  }));
                  refetch();
                }}
                disabled={orderList.length < pagination.pageSize}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
