/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import * as React from "react";
import toast, { Toaster } from "react-hot-toast";
import TablePDF from "../../../components/admin/customerListPDF";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "../../../components/admin/PDFWrapper";
import useAuthStore from "../stores/userAuthStore";
import dynamic from "next/dynamic";
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"; // or your tooltip component path

const PDFDownloadLink = dynamic(
  () =>
    import("../../../components/admin/PDFWrapper").then(
      (mod) => mod.PDFDownloadLink
    ),
  { ssr: false }
);
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import Cookies from "js-cookie";

import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import axios from "axios";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";
import  config  from "../../../../config.json";

export type Payment = {
  customer_id: string;
  cust_cmp_name: string;
  cust_cmp_phone: string;
  cust_cmp_email: boolean;
  address1: string;
  address2: string;
  city: string;
  state_code: string;
  country_code: string;
  id: number;
  pincode: string;
};
// interface ProductOptionsDialogProps {
//   productId: number;
//   initialStatus: boolean;
//   initialOnlinePrice: number;
//   initialOfferPrice: number;
// }
// const base_url = config.baseUrl;
// const ProductOptionsDialog: React.FC<ProductOptionsDialogProps> = ({
//   productId,
//   initialStatus,
//   initialOnlinePrice,
//   initialOfferPrice,
// }) => {
//   const queryClient = useQueryClient();
//   const [checked, setChecked] = useState(initialStatus);
//   const [onlinePrice, setOnlinePrice] = useState(initialOnlinePrice);
//   const [offerPrice, setOfferPrice] = useState(initialOfferPrice);
//   const [open, setOpen] = useState(false);

//   // Update Prices API
//   // const updatePricesMutation = useMutation({
//   //   mutationFn: async () => {
//   //     if (!authToken) {
//   //       toast.error("Please login to proceed!");
//   //       
//   //     }

//   //     if (onlinePrice <= 0) {
//   //       toast.error("Online price must be greater than 0");
//   //       return;
//   //     }

//   //     if (onlinePrice < offerPrice && offerPrice !== 0) {
//   //       toast.error("Online price must be greater than the offer price.");
//   //       return;
//   //     }

//   //     // Ensure offerPrice is at least the same as onlinePrice if it's 0
//   //     const finalOfferPrice = offerPrice === 0 ? onlinePrice : offerPrice;

//   //     try {
//   //       const { data } = await axios.patch(
//   //         `${base_url}/api/v1/admin/updateOnlineSellingPrice`,
//   //         {
//   //           envtoryproductId: productId,
//   //           productPrice: onlinePrice,
//   //           offerPrice: finalOfferPrice, // Updated offerPrice value
//   //         },
//   //         { headers: { adminauth: authToken } }
//   //       );

//   //       if (data.status === "Failed") {
//   //         toast.error(data.message || "Update failed. Please try again.");
//   //         throw new Error(data.message || "API request failed");
//   //       }

//   //       toast.success("Product details updated successfully!");
//   //       setOpen(false);

//   //       // Preserve the row positions
//   //       queryClient.setQueryData(["customerList"], (oldData: any) => {
//   //         if (!oldData) return oldData;

//   //         const orderMap = new Map(
//   //           oldData.map((item: any, index: number) => [item.id, index])
//   //         );

//   //         queryClient
//   //           .invalidateQueries({ queryKey: ["customerList"] })
//   //           .then(() => {
//   //             queryClient.setQueryData(["customerList"], (newData: any) => {
//   //               if (!newData) return newData;

//   //               // Sort the updated data based on the original order
//   //               return [...newData].sort((a: any, b: any) => {
//   //                 return (
//   //                   (Number(orderMap.get(a.id)) || 0) -
//   //                   (Number(orderMap.get(b.id)) || 0)
//   //                 );
//   //               });
//   //             });
//   //           });

//   //         return oldData;
//   //       });

//   //       return true;
//   //     } catch (error: any) {
//   //       console.error("Error updating product:", error);
//   //       toast.error(error.response?.data?.message || "Something went wrong!");
//   //       return false;
//   //     }
//   //   },
//   // });

//   // Toggle Availability API
//   const toggleAvailabilityMutation = useMutation({
//     mutationFn: async (newStatus: boolean) => {
//       if (!authToken) {
//         toast.error("Please login to proceed!");
//         
//       }

//       try {
//         const { data } = await axios.patch(
//           `${base_url}/api/v1/admin/markProductOnline`,
//           { envtoryproductId: productId },
//           { headers: { adminauth: authToken } }
//         );

//         if (data.status === "Failed") {
//           toast.error(data.message || "Failed to update availability.");
//           throw new Error(data.message || "API request failed");
//         }

//         toast.success("Product availability updated successfully!");

//         // Update only this product instead of invalidating the entire list
//         queryClient.setQueryData(["customerList"], (oldData: any) => {
//           if (!oldData) return oldData;
//           return oldData.map((product: any) =>
//             product.id === productId
//               ? { ...product, online: newStatus }
//               : product
//           );
//         });

//         return true;
//       } catch (error: any) {
//         console.error("Error marking product online:", error);
//         toast.error(error.response?.data?.message || "Something went wrong!");
//         return false;
//       }
//     },
//   });

//   // Handle Toggle Availability
//   const handleToggle = async () => {
//     // if (toggleAvailabilityMutation.isLoading) {
//     //   return; // Prevent toggling while API call is in progress
//     // }

//     const newStatus = !checked;

//     // Toggle availability
//     const isToggled = await toggleAvailabilityMutation.mutateAsync(newStatus);
//     if (isToggled) {
//       setChecked(newStatus); // Ensure state updates properly
//     }
//   };

//   return (
//     <Dialog open={open} onOpenChange={setOpen}>
//       <DialogTrigger asChild>
//         <Button variant="ghost" className="h-8 w-8 p-0">
//           <MoreHorizontal />
//         </Button>
//       </DialogTrigger>
//       <DialogContent className="p-4 max-w-sm">
//         {" "}
//         {/* Reduced size */}
//         <DialogTitle className="text-lg font-semibold">
//           Product Options
//         </DialogTitle>
//         {/* Available Online Toggle */}
//         <div className="flex justify-between items-center my-1">
//           <span className="text-sm font-medium">Available Online</span>
//           <div
//             className={`relative w-12 h-6 flex items-center rounded-full cursor-pointer transition-all ${
//               checked ? "bg-green-500" : "bg-gray-400"
//             }`}
//             onClick={handleToggle}
//           >
//             <div
//               className={`absolute w-5 h-5 bg-white rounded-full transition-all shadow-md ${
//                 checked ? "translate-x-6" : "translate-x-1"
//               }`}
//             />
//           </div>
//         </div>
//         {/* Online Price Input */}
//         <div>
//           <label className="text-sm font-medium">Online Price</label>
//           <Input
//             type="number"
//             value={onlinePrice}
//             onChange={(e) => setOnlinePrice(parseFloat(e.target.value))}
//             className="mt-1"
//           />
//         </div>
//         {/* Offer Price Input */}
//         <div>
//           <label className="text-sm font-medium">Offer Price</label>
//           <Input
//             type="number"
//             value={offerPrice}
//             onChange={(e) => setOfferPrice(parseFloat(e.target.value))}
//             className="mt-1"
//           />
//         </div>
//         {/* Update Button */}
//         <Button
//           className="w-full mt-3"
//           onClick={() => updatePricesMutation.mutate()}
//         >
//           Update
//         </Button>
//       </DialogContent>
//     </Dialog>
//   );
// };

const columns: ColumnDef<Payment>[] = [
  {
    accessorKey: "Customer Name",
    header: () => <div className="w-[175px] text-left">Customer Name</div>,
    cell: ({ row }) => {
      const name = row.original?.cust_cmp_name || "N/A";
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="w-[175px] truncate text-left cursor-help">
              {name}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="max-w-[300px] whitespace-pre-wrap">{name}</p>
          </TooltipContent>
        </Tooltip>
      );
    },
  },
  {
    accessorKey: "Contact Number",
    header: () => <div className="w-[150px] text-left">Contact Number</div>,
    cell: ({ row }) => (
      <div className="w-[150px] truncate text-left">
        +91 {row.original?.cust_cmp_phone || "N/A"}
      </div>
    ),
  },
  {
    accessorKey: "Email",
    header: () => <div className="w-[200px] text-left">Email</div>,
    cell: ({ row }) => {
      const email = row.original?.cust_cmp_email || "N/A";
      return (
        <div className="w-[200px] text-left">
          {email}
        </div>
      );
    },
  },  
  {
    accessorKey: "Address",
    header: () => <div className="w-[250px] text-left">Address</div>,
    cell: ({ row }) => {
      const { address1, address2 } = row.original;
      const hasAddress = address1 || address2;
      const fullAddress = hasAddress
        ? `${address1 || ""}${address2 ? ", " + address2 : ""}`
        : "N/A";

      return (
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="w-[250px] truncate text-left cursor-help">
              {fullAddress}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="max-w-[300px] whitespace-pre-wrap">{fullAddress}</p>
          </TooltipContent>
        </Tooltip>
      );
    },
  },
];

export default function Orders() {
  // const [selectedFilter, setSelectedFilter] = React.useState("date");
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});

  const [orderListState, setOrderListState] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCustomer = async (page: number, limit: number) => {
    const authToken = Cookies.get("authToken"); // Retrieve token from localStorage
    if (!authToken) {
      toast.error("Please login to proceed!"); // Show error toast
      
    }

    try {
      const { data } = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/customerList?page=${page}&limit=${limit}`,
        {
          headers: {
            adminauth: authToken, // Include token in headers
          },
        }
      );

      return data.data; // Assuming API returns `data.data`
    } catch (error) {
      console.error("Error fetching customers:", error);
      toast.error("Failed to fetch customer list. Please try again.");
      throw error; // Ensure React Query catches the error
    }
  };

  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 10 });
  const { logoutSignal } = useAuthStore();
  const {
    data: customerList = [], // Default to empty array if no data
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<Payment[]>({
    queryKey: ["customerList", pagination.pageIndex],
    queryFn: () => fetchCustomer(pagination.pageIndex + 1, pagination.pageSize),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: true,
    refetchInterval: 5 * 60 * 1000,
  });

  React.useEffect(() => {
    if (logoutSignal > 0) {
      console.log("Logout signal detected in AdminOrders:", logoutSignal);
    }
  }, [logoutSignal]);
  
  useEffect(() => {
    fetchCustomer(pagination.pageIndex + 1, pagination.pageSize);
    return () => {};
  }, [customerList]);

  const table = useReactTable({
    data: customerList ?? [], // Use orderList instead of static data
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    // initialState: {
    // pagination: {
    // pageSize: 10, // Set the initial number of rows per page
    // },
    // },
    onPaginationChange: setPagination,
    manualPagination: true,
  });
  const exportCustomerToExcel = (customerList: any[]) => {
    if (!customerList || customerList.length === 0) {
      toast.error("No customer data available to export.");
      return;
    }
  
    // Map customerList to match Excel structure
    const mappedData = customerList.map((customer) => ({
      "Customer ID": customer.id,
      "Name": customer?.cust_cmp_name,
      "Email": customer?.cust_cmp_email,
      "Phone": customer?.cust_cmp_phone,
      "Address": customer?.address1 + customer?.address2,
    }));
  
    // Create worksheet and workbook
    const ws = XLSX.utils.json_to_sheet(mappedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Customers");
  
    // Generate Excel file
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  
    // Trigger download
    saveAs(data, "Customers-Maharana-Silver.xlsx");
    toast.success("Customer list export started! Your Excel file will be ready soon.");
  };
  return (
    <>
      <Toaster position="top-center" />
      <div className="p-3 flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <span className="text-xl font-bold">Orders</span>
    <Button onClick={() => exportCustomerToExcel(customerList)}>Export Data</Button>

        </div>
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-center justify-between py-4">
            {/* <div className="flex gap-2">
            <Select value={selectedFilter} onValueChange={setSelectedFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="user_id">User ID</SelectItem>
                  <SelectItem value="date">Date</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
            <Input
              placeholder={`Filter by ${
                selectedFilter === "user_id"
                  ? "User Id"
                  
                  : "date"
              }...`}
              value={
                (table.getColumn(selectedFilter)?.getFilterValue() as string) ??
                ""
              }
              onChange={(event) =>
                table
                  .getColumn(selectedFilter)
                  ?.setFilterValue(event.target.value)
              }
              className="max-w-sm"
            />
          </div> */}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div>
            <Table>
              <TableHeader
                className="border-b-2"
                style={{ borderColor: "#D3D6E8" }}
              >
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      return (
                        <TableHead key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </TableHead>
                      );
                    })}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
  {isLoading ? ( // Show loading state
    <TableRow>
      <TableCell colSpan={columns.length} className="h-24 text-center">
        Loading...
      </TableCell>
    </TableRow>
  ) : table.getRowModel().rows.length > 0 ? ( // Render table rows when data is available
    table.getRowModel().rows.map((row) => (
      <TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
        {row.getVisibleCells().map((cell) => (
          <TableCell key={cell.id}>
            {flexRender(cell.column.columnDef.cell, cell.getContext())}
          </TableCell>
        ))}
      </TableRow>
    ))
  ) : (
    <TableRow>
      <TableCell colSpan={columns.length} className="h-24 text-center">
        No results.
      </TableCell>
    </TableRow>
  )}
</TableBody>

            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {/* {table.getFilteredSelectedRowModel().rows.length} of{" "}
              {table.getFilteredRowModel().rows.length} row(s) selected. */}
            </div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex - 1,
                  }));
                  refetch();
                }}
                disabled={pagination.pageIndex === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex + 1,
                  }));
                  refetch();
                }}
                disabled={customerList.length < pagination.pageSize}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
