"use client";

import { useState, useEffect } from "react";
import { RecentTransaction } from "@/components/admin/recentTransaction";
import { RecentSalesEstimate } from "@/components/admin/recentSalesEstimate";
import DashbaordChart from "@/components/admin/dashBoardAreaChart";
import DashbaordOveriew from "@/components/admin/dashBoardOverview";
import Cookies from "js-cookie";
import axios from "axios";
import toast from "react-hot-toast";
import config from '../../../../config.json'
// const BASE_URL = config.NEXT_PUBLIC_API_URL;


// Define the Payment type (same as in Orders screen)
export type Payment = {
  company_id: string;
  id: number;
  order_id: string;
  est_shop_id: number;
  payment_reference_id: string;
  user_id: number;
  address_id: number | null;
  total_price: string;
  payment_method_id: number;
  payment_status: "Pending" | "Paid" | "Failed";
  order_status: "Pending" | "Delivered" | "Undelivered";
  delivery_status: "Order Confirm" | "Dispatched" | "In Transit" | "Delivered";
  created_at: string;
  updated_at: string;
  jw_payment_mode: {
    id: number;
    payment_method: string;
  };
  jw_order_items: {
    order_item_id: number;
    company_id: string;
    est_shop_id: number;
    order_id: number;
    product_id: number;
    quantity: number;
    price: string;
    total_price: string;
    created_at: string;
    ProductMaster: {
      product_name: string;
    };
  }[];
  jw_invoice_items: {
    id: number;
    est_shop_id: string;
    quantity: number;
    total_price: string;
    mi_shop_est: {
      id: number;
      est_shop_name: string;
      address1: string;
      address2: string;
    };
  }[];
  mi_customer: {
    id: number;
    cust_cmp_name: string;
  };
  jw_customer_address: null | {
    street: string;
    city: string;
    state: string;
    zip_code: string;
    country: string;
  };
};

interface ChartData {
  date: string;
  sales: number;
}

export default function Home() {
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [salesEstimateData, setSalesEstimateData] = useState<any[]>([]);
  const [orderData, setOrderData] = useState<Payment[]>([]); // New state for orders
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState<"7d" | "1m" | "3m">("7d");

  // Fetch chart data based on time range
  useEffect(() => {
    const fetchChartData = async () => {
      const authToken = Cookies.get("authToken");
      if (!authToken) {
        toast.error("Please login to proceed!");
        setError("No authentication token found");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const limit = 10;
        let page = 1;
        let allOrders: Payment[] = [];
        const cutoffDate = new Date();

        switch (timeRange) {
          case "7d":
            cutoffDate.setDate(cutoffDate.getDate() - 7);
            break;
          case "1m":
            cutoffDate.setMonth(cutoffDate.getMonth() - 1);
            break;
          case "3m":
            cutoffDate.setMonth(cutoffDate.getMonth() - 3);
            break;
        }

        while (true) {
          const { data } = await axios.get(
            `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getOrderList?page=${page}&limit=${limit}`,
            {
              headers: { adminauth: authToken },
            }
          );

          if (!data.data || data.data.length === 0) break;

          allOrders = [...allOrders, ...data.data];

          const oldestOrderDate = new Date(
            data.data[data.data.length - 1].created_at
          );
          if (oldestOrderDate < cutoffDate) {
            allOrders = allOrders.filter(
              (order) => new Date(order.created_at) >= cutoffDate
            );
            break;
          }

          if (data.data.length < limit || page * limit >= data.total) break;
          page++;
        }

        if (allOrders.length > 0) {
          const processedChartData = processChartData(allOrders);
          setChartData(processedChartData);
          
          // Ensure we have unique order_id values to prevent key conflicts
          const uniqueOrders = deduplicateOrders(allOrders.slice(0, 5));
          setOrderData(uniqueOrders);
        } else {
          setError(
            `No orders found in the last ${
              timeRange === "7d"
                ? "7 days"
                : timeRange === "1m"
                ? "month"
                : "3 months"
            }`
          );
        }
      } catch (error) {
        console.error("Error fetching orders:", error);
        setError("Failed to fetch order list. Please try again.");
        toast.error("Failed to fetch order list. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchChartData();
  }, [timeRange]);

  // Helper function to deduplicate orders by order_id
  const deduplicateOrders = (orders: Payment[]): Payment[] => {
    const uniqueOrderMap = new Map<string, Payment>();
    
    orders.forEach((order) => {
      // If we haven't seen this order_id yet, or if this instance has a higher id, keep it
      if (!uniqueOrderMap.has(order.order_id) || 
          uniqueOrderMap.get(order.order_id)!.id < order.id) {
        uniqueOrderMap.set(order.order_id, order);
      }
    });
    
    return Array.from(uniqueOrderMap.values());
  };

  // Fetch sales estimate data (unchanged)
  useEffect(() => {
    const fetchSalesEstimateData = async () => {
      const authToken = Cookies.get("authToken");
      if (!authToken) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const limit = 10;
        let page = 1;
        let allOrders: Payment[] = [];
        const cutoffDate = new Date();
        cutoffDate.setMonth(cutoffDate.getMonth() - 3);

        while (true) {
          const { data } = await axios.get(
            `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getOrderList?page=${page}&limit=${limit}`,
            {
              headers: { adminauth: authToken },
            }
          );

          if (!data.data || data.data.length === 0) break;

          allOrders = [...allOrders, ...data.data];

          const oldestOrderDate = new Date(
            data.data[data.data.length - 1].created_at
          );
          if (oldestOrderDate < cutoffDate) {
            allOrders = allOrders.filter(
              (order) => new Date(order.created_at) >= cutoffDate
            );
            break;
          }

          if (data.data.length < limit || page * limit >= data.total) break;
          page++;
        }

        if (allOrders.length > 0) {
          const processedSalesData = processSalesEstimateData(allOrders);
          setSalesEstimateData(processedSalesData);
        }
      } catch (error) {
        console.error("Error fetching sales data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSalesEstimateData();
  }, []);

  // const processChartData = (orders: Payment[]): ChartData[] => {
  //   const dailyData: { [key: string]: ChartData } = {};
  //   orders.forEach((order) => {
  //     const orderDate = new Date(order.created_at);
  //     const dayKey = orderDate.toLocaleDateString("en-US", {
  //       month: "short",
  //       day: "numeric",
  //     });
  //     if (!dailyData[dayKey]) {
  //       dailyData[dayKey] = { date: dayKey, sales: 0 };
  //     }
  //     const price = parseFloat(order.total_price) || 0;
  //     dailyData[dayKey].sales += price;
  //   });
  //   return Object.values(dailyData).sort(
  //     (a, b) => Number(new Date(a.date)) - Number(new Date(b.date))
  //   );
  // };

  const processChartData = (orders: Payment[]): ChartData[] => {
    const dailyData: { [key: string]: ChartData } = {};
    const today = new Date(); // Current date: April 11, 2025
    const earliestDate = orders.length > 0 ? new Date(orders[0].created_at) : today;
  
    // Aggregate sales data from orders
    orders.forEach((order) => {
      const orderDate = new Date(order.created_at);
      const dayKey = orderDate.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
      if (!dailyData[dayKey]) {
        dailyData[dayKey] = { date: dayKey, sales: 0 };
      }
      const price = parseFloat(order.total_price) || 0;
      dailyData[dayKey].sales += price;
    });
  
    // Extend data to include all days up to today
    const currentDate = new Date(earliestDate);
    while (currentDate <= today) {
      const dayKey = currentDate.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
      if (!dailyData[dayKey]) {
        dailyData[dayKey] = { date: dayKey, sales: 0 };
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }
  
    return Object.values(dailyData).sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
  };

  const processSalesEstimateData = (orders: Payment[]) => {
    const monthlyData: { [key: string]: number } = {};
    const currentDate = new Date();

    orders.forEach((order) => {
      const orderDate = new Date(order.created_at);
      if (
        orderDate >= new Date(currentDate.setMonth(currentDate.getMonth() - 3))
      ) {
        const monthKey = orderDate.toLocaleString("en-US", { month: "long" });
        monthlyData[monthKey] =
          (monthlyData[monthKey] || 0) + (parseFloat(order.total_price) || 0);
      }
    });

    const lastThreeMonths = Array.from({ length: 3 }, (_, i) => {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      return date.toLocaleString("en-US", { month: "long" });
    }).reverse();

    return lastThreeMonths.map((month) => ({
      month,
      desktop: Math.round(monthlyData[month] || 0),
    }));
  };

  return (
    <div className="p-4 flex flex-col gap-4">
      <span className="text-xl font-bold">Dashboard</span>
      <div>
        <DashbaordOveriew />
      </div>
      <div className="w-full h-[400px] flex gap-4">
        <div className="w-[100%]">
          <DashbaordChart
            data={chartData}
            loading={loading}
            error={error}
            timeRange={timeRange}
            setTimeRange={setTimeRange}
          />
        </div>
      </div>
      <div className="w-full flex gap-4">
        <div className="w-[100%]">
          <RecentTransaction data={orderData} />
        </div>
      </div>
    </div>
  );
}