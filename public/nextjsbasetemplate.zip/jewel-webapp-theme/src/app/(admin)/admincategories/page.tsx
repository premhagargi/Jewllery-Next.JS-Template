/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */

"use client";

import * as React from "react";
import toast, { Toaster } from "react-hot-toast";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import Cookies from "js-cookie";
import TablePDF from "../../../components/admin/ProductPDF";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "../../../components/admin/PDFWrapper";
import dynamic from "next/dynamic";
import { Upload, Image, X, Loader2, Pencil } from 'lucide-react';

const PDFDownloadLink = dynamic(
  () =>
    import("../../../components/admin/PDFWrapper").then(
      (mod) => mod.PDFDownloadLink
    ),
  { ssr: false }
);

import axios from "axios";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import Compressor from "compressorjs";

import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
  DialogHeader,
  DialogFooter,
} from "@/components/ui/dialog";import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState, useRef } from "react";
// import { base_url } from "@/app/(admin)/config";
import config from '../../../../config.json'

export type Payment = {
  id: number,
  regcity_code: string,
  company_id: string,
  category_id: string,
  category_desc: string,
  category_name: string,
  image_path: string,
  display_status: boolean,
  totalQuantity: string,
  offer_percentage: string

};

interface ProductOptionsDialogProps {
  productId: number;
  initialStatus: boolean;
  initialOnlinePrice: number;
  initialOfferPrice: number;
  productname: string;
  caratvalue: string;
  netweight: string;
  weight: string;
  pricepergram: string;
  cgst: string;
  sgst: string;
  igst: string;
  makingcharges: string;
  wastage: string;
  stoneweight: string;
  stoneprice: string;
  category: string

}

// const ProductOptionsDialog: React.FC<ProductOptionsDialogProps> = ({
//   productId,
//   initialStatus,
//   initialOnlinePrice,
//   initialOfferPrice,
//   weight,
//   netweight,
//   makingcharges,
//   stoneprice,
//   caratvalue,
//   stoneweight,
//   wastage,
//   cgst,
//   sgst,
//   igst,
//   productname,
//   pricepergram,
//   category,
// }) => {
//   const queryClient = useQueryClient();
//   const [checked, setChecked] = useState(initialStatus);
//   const [onlinePrice, setOnlinePrice] = useState(initialOnlinePrice);
//   const [productName, setProductName] = useState(productname);
//   const [offerPrice, setOfferPrice] = useState(initialOfferPrice);
//   const [grossWeight, setGrossWeight] = useState(weight);
//   const [caratValue, setCaratValue] = useState(caratvalue);
//   const [stoneWeight, setStoneWeight] = useState(stoneweight);
//   const [netWeight, setNetWeight] = useState(netweight);
//   const [numPieces, setNumPieces] = useState(1);
//   const [wastagE, setWastage] = useState(wastage);
//   const [stonePrice, setStonePrice] = useState(stoneprice);
//   const [makingCharges, setMakingCharges] = useState(makingcharges);
//   const [SGST, setSgst] = useState(sgst);
//   const [CGST, setCgst] = useState(cgst);
//   const [pricePerGram, setPricePerGram] = useState(pricepergram);
//   const [IGST, setIgst] = useState(igst);
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [open, setOpen] = useState(false);
//   const [discountPercentage, setDiscountPercentage] = useState(0);
//   const [categoryState, setCategory] = useState(category || "");

//   // Sync categoryState with prop changes
//   useEffect(() => {
//     setCategory(category || "");
//   }, [category]);

//   // Log category for debugging
//   useEffect(() => {
//     console.log("Category Prop:", category);
//     console.log("Category State:", categoryState);
//   }, [category, categoryState]);

//   // Determine if the product is silver
//   const isSilver = typeof categoryState === "string" && categoryState.toLowerCase() === "silver";
//   console.log("isSilver:", isSilver);

//   const calculatePrice = () => {
//     // Provide fallback values to avoid NaN or 0
//     const netWeightNum = Number(netWeight) || 0;
//     const wastageNum = Number(wastagE) || 0;
//     const pricePerGramNum = Number(pricePerGram) || 0;
//     const stonePriceNum = Number(stonePrice) || 0;
//     const makingChargesNum = Number(makingCharges) || 0;
//     const discountPercentageNum = Number(discountPercentage) || 0;
//     const SGSTNum = Number(SGST) || 0;
//     const CGSTNum = Number(CGST) || 0;
//     const IGSTNum = Number(IGST) || 0;

//     // Log inputs for debugging
//     console.log("calculatePrice inputs:", {
//       netWeightNum,
//       wastageNum,
//       pricePerGramNum,
//       stonePriceNum,
//       makingChargesNum,
//       discountPercentageNum,
//       SGSTNum,
//       CGSTNum,
//       IGSTNum,
//     });

//     let totalPrice, discountedPrice, taxAmountAftDiscount, taxAmountBefDiscount, finalOnlinePriceBefDis, finalOnlinePriceAftDis;

//     if (isSilver) {
//       // For silver, use only pricePerGram and apply taxes
//       totalPrice = pricePerGramNum;
//       discountedPrice = totalPrice * (1 - discountPercentageNum / 100);

//       taxAmountAftDiscount =
//         IGSTNum > 0
//           ? (IGSTNum / 100) * discountedPrice
//           : ((SGSTNum + CGSTNum) / 100) * discountedPrice;

//       taxAmountBefDiscount =
//         IGSTNum > 0
//           ? (IGSTNum / 100) * totalPrice
//           : ((SGSTNum + CGSTNum) / 100) * totalPrice;

//       finalOnlinePriceBefDis = totalPrice + taxAmountBefDiscount;
//       finalOnlinePriceAftDis = discountedPrice + taxAmountAftDiscount;
//     } else {
//       // Standard calculation for non-silver products
//       totalPrice = ((netWeightNum) * pricePerGramNum) + stonePriceNum + makingChargesNum; // remove wastagenum inclusion to netweightnum because netewight from db includes wastage
      
//       discountedPrice = totalPrice * (1 - discountPercentageNum / 100);

//       taxAmountAftDiscount =
//         IGSTNum > 0
//           ? (IGSTNum / 100) * discountedPrice
//           : ((SGSTNum + CGSTNum) / 100) * discountedPrice;

//       taxAmountBefDiscount =
//         IGSTNum > 0
//           ? (IGSTNum / 100) * totalPrice
//           : ((SGSTNum + CGSTNum) / 100) * totalPrice;

//       finalOnlinePriceBefDis = totalPrice + taxAmountBefDiscount;
//       finalOnlinePriceAftDis = discountedPrice + taxAmountAftDiscount;
//     }

//     // Log calculated prices
//     console.log("Calculated Prices:", {
//       totalPrice,
//       discountedPrice,
//       taxAmountBefDiscount,
//       taxAmountAftDiscount,
//       finalOnlinePriceBefDis,
//       finalOnlinePriceAftDis,
//     });

//     setOnlinePrice(finalOnlinePriceBefDis);
//     setOfferPrice(finalOnlinePriceAftDis);
//   };

//   useEffect(() => {
//     calculatePrice();
//   }, [netWeight, stonePrice, wastagE, pricePerGram, makingCharges, discountPercentage, SGST, CGST, IGST]);

//   const updatePricesMutation = useMutation({
//     mutationFn: async () => {
//       const authToken = Cookies.get("authToken");
//       if (!authToken) {
//         toast.error("Please login to proceed!");
//         throw new Error("No auth token");
//       }

//       const { data } = await axios.patch(
//         `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updateOnlineSellingPrice`,
//         {
//           envtoryproductId: productId,
//           productPrice: onlinePrice,
//           offerPrice: offerPrice,
//           makingCharges: makingCharges,
//           wastage: wastagE,
//           stonePrice: stonePrice,
//           productUnitCost: pricePerGram,
//         },
//         { headers: { adminauth: authToken } }
//       );

//       if (data.status === "Failed") {
//         toast.error(data.message || "Update failed. Please try again.");
//         throw new Error(data.message || "API request failed");
//       }

//       return data;
//     },
//     onSuccess: (data) => {
//       toast.success("Product details updated successfully!");
//       setOpen(false);

//       // Update the cache immediately
//       queryClient.setQueriesData({ queryKey: ["productList"] }, (oldData: any) => {
//         if (!oldData) return oldData;
        
//         // If oldData is an array, map through it
//         if (Array.isArray(oldData)) {
//           return oldData.map((product) =>
//             product.id === productId
//               ? {
//                   ...product,
//                   exp_onlinesellprice_aft: onlinePrice.toString(),
//                   offer_price: offerPrice.toString(),
//                   making_charges: makingCharges.toString(),
//                   wastage: wastagE.toString(),
//                   stone_price: stonePrice.toString(),
//                   product_unit_cost: pricePerGram.toString(),
//                 }
//               : product
//           );
//         }
        
//         // If oldData has a data property (common API response structure)
//         if (oldData.data) {
//           return {
//             ...oldData,
//             data: oldData.data.map((product: any) =>
//               product.id === productId
//                 ? {
//                     ...product,
//                     exp_onlinesellprice_aft: onlinePrice.toString(),
//                     offer_price: offerPrice.toString(),
//                     making_charges: makingCharges.toString(),
//                     wastage: wastagE.toString(),
//                     stone_price: stonePrice.toString(),
//                     product_unit_cost: pricePerGram.toString(),
//                   }
//                 : product
//             ),
//           };
//         }

//         return oldData;
//       });

//       // Optionally, refetch to ensure sync with server
//       queryClient.invalidateQueries({ queryKey: ["productList"] });
//     },
//     onError: (error: any) => {
//       console.error("Error updating product:", error);
//       toast.error(error.response?.data?.message || "Something went wrong!");
//     },
//   });

//   const toggleAvailabilityMutation = useMutation({
//     mutationFn: async (newStatus: boolean) => {
//       const authToken = Cookies.get("authToken");
//       if (!authToken) {
//         toast.error("Please login to proceed!");
//         throw new Error("No auth token");
//       }

//       const { data } = await axios.patch(
//         `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/markProductOnline`,
//         { envtoryproductId: productId },
//         { headers: { adminauth: authToken } }
//       );

//       if (data.status === "Failed") {
//         toast.error(data.message || "Failed to update availability.");
//         throw new Error(data.message || "API request failed");
//       }

//       toast.success("Product availability updated successfully!");

//       queryClient.setQueryData<Payment[]>(
//         ["productList", Math.floor(productId / 8)],
//         (oldData) => {
//           if (!oldData) return oldData;
//           return oldData.map((product) =>
//             product.id === productId
//               ? { ...product, onlineshop: newStatus }
//               : product
//           );
//         }
//       );

//       return true;
//     },
//     onError: (error: any) => {
//       console.error("Error marking product online:", error);
//       toast.error(error.response?.data?.message || "Something went wrong!");
//     },
//   });

//   const handleToggle = async () => {
//     const newStatus = !checked;
//     const isToggled = await toggleAvailabilityMutation.mutateAsync(newStatus);
//     if (isToggled) {
//       setChecked(newStatus);
//     }
//   };

//   const handleSubmit = async () => {
//     const newStatus = !checked;
//     const isToggled = await toggleAvailabilityMutation.mutateAsync(newStatus);
//     if (isToggled) {
//       setChecked(newStatus);
//     }
//   };

//   // Determine the label for Price/gram and className for isSilver inputs
//   const priceLabel = isSilver ? "Price/Quantity" : "Price/gram";
//   const inputClassName = isSilver 
//     ? "w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//     : "w-32 border-gray-300 rounded-md appearance-none";

//   // Show IGST only if SGST and CGST are not both positive
//   const showIGST = !(Number(SGST) > 0 && Number(CGST) > 0);

//   return (
//     <Dialog open={open} onOpenChange={setOpen}>
// <DialogTrigger asChild>
//   <Button size="icon" className="p-0">
//     {images.length > 0 ? (
//       <img
//         src={row.original.image_path[0]}
//         alt={`Thumbnail for ${productName}`}
//         className="h-4 w-4 object-cover rounded"
//       />
//     ) : (
//       <Image className="h-4 w-4" />
//     )}
//   </Button>
// </DialogTrigger>
//       <DialogContent className="p-6 max-w-[900px] w-full">
//         <DialogTitle className="text-lg font-semibold mb-4">
//           Product Options: {productname}
//         </DialogTitle>

//         <div className="grid grid-cols-3 gap-x-6 gap-y-4">
//           {!isSilver && (
//             <div className="flex items-center gap-2">
//               <label className="text-sm font-medium w-28">Carat</label>
//               <Input
//                 type="number"
//                 value={Number(caratValue)}
//                 readOnly
//                 className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//               />
//             </div>
//           )}

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Gross Weight</label>
//             <Input
//               type="number"
//               value={Number(grossWeight)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Stone Weight</label>
//             <Input
//               type="number"
//               value={Number(stoneWeight)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Net Weight</label>
//             <Input
//               type="number"
//               value={Number(netWeight)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Wastage (gm)</label>
//             <Input
//               type="number"
//               value={wastagE}
//               onChange={(e) => setWastage((e.target.value))}
//               className={inputClassName}
//               readOnly={isSilver}
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">{priceLabel}</label>
//             <Input
//               type="number"
//               value={pricePerGram}
//               onChange={(e) => setPricePerGram((e.target.value))}
//               className="w-32 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Stone Price</label>
//             <Input
//               type="number"
//               value={stonePrice}
//               onChange={(e) => setStonePrice((e.target.value))}
//               className={inputClassName}
//               readOnly={isSilver}
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Making Charges</label>
//             <Input
//               type="number"
//               value={makingCharges}
//               onChange={(e) => setMakingCharges((e.target.value))}
//               className={inputClassName}
//               readOnly={isSilver}
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">CGST %</label>
//             <Input
//               type="number"
//               value={Number(CGST)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">SGST %</label>
//             <Input
//               type="number"
//               value={Number(SGST)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           {showIGST && (
//             <div className="flex items-center gap-2">
//               <label className="text-sm font-medium w-28">IGST %</label>
//               <Input
//                 type="number"
//                 value={Number(IGST)}
//                 readOnly
//                 className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//               />
//             </div>
//           )}

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Online Price</label>
//             <Input
//               type="number"
//               value={Number(onlinePrice)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Discount (%)</label>
//             <Input
//               type="number"
//               value={discountPercentage}
//               onChange={(e) => setDiscountPercentage(Number(Number(e.target.value)))}
//               className="w-32 border-gray-300 rounded-md appearance-none"
//             />
//           </div>

//           <div className="flex items-center gap-2">
//             <label className="text-sm font-medium w-28">Offer Price</label>
//             <Input
//               type="number"
//               value={Number(offerPrice)}
//               readOnly
//               className="w-32 bg-gray-100 text-gray-600 border-gray-300 rounded-md appearance-none"
//             />
//           </div>
//         </div>

//         <Button
//           className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-md"
//           onClick={() => updatePricesMutation.mutate()}
//           disabled={updatePricesMutation.isPending}
//         >
//           {updatePricesMutation.isPending ? "Updating..." : "Update"}
//         </Button>

//         {/* Custom CSS to ensure stepper arrows are removed in all browsers */}
//         <style jsx>{`
//           input[type="number"]::-webkit-inner-spin-button,
//           input[type="number"]::-webkit-outer-spin-button {
//             -webkit-appearance: none;
//             margin: 0;
//           }
//           input[type="number"] {
//             -moz-appearance: textfield;
//           }
//         `}</style>
//       </DialogContent>
//     </Dialog>
//   );
// };




const ProductImageModal = ({
  productId,
  productName,
  existingImages,
}: {
  productId: number;
  existingImages: string[];
  productName: string;
}) => {
  const queryClient = useQueryClient();

  const parseImages = (images: string[]) => {
    if (!images) return [];
    try {
      const imagesArray = Array.isArray(images) ? images : [images];
      return imagesArray.flatMap((img) => {
        if (typeof img === 'string') {
          try {
            // Parse JSON if needed
            const parsed = JSON.parse(img);
            const imageSources = Array.isArray(parsed)
              ? parsed.map((item: { src: string }) => item.src)
              : [];

            // Prepend base URL if the image URL is relative
            return imageSources.map((src) =>
              src.startsWith('http')
                ? src
                : `${config.NEXT_PUBLIC_API_URL}/${src}`
            );
          } catch (error) {
            // If not JSON, assume it's a direct image path
            return img.startsWith('http')
              ? [img]
              : [`${config.NEXT_PUBLIC_API_URL}/${img}`];
          }
        }
        return [];
      });
    } catch (error) {
      console.error('Unexpected error processing images:', error);
      return [];
    }
  };

  const [images, setImages] = useState<string[]>(parseImages(existingImages));
  const [newImages, setNewImages] = useState<File[]>([]);
  const [isCompressing, setIsCompressing] = useState(false);

  useEffect(() => {
    setImages(parseImages(existingImages));
  }, [existingImages]);

  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
      const originalSizeKB = (file.size / 1024).toFixed(2);
      console.log(`📂 Original Image: ${file.name}, Size: ${originalSizeKB} KB`);

      const SKIP_COMPRESSION_THRESHOLD = 500 * 1024;
      if (file.size < SKIP_COMPRESSION_THRESHOLD) {
        console.log(`⏩ Skipping compression for ${file.name} (already small)`);
        resolve(file);
        return;
      }

      new Compressor(file, {
        quality: 0.8,
        mimeType: 'image/webp',
        success(result) {
          const compressedFile = new File(
            [result],
            file.name.replace(/\.[^.]+$/, '.webp'),
            {
              type: 'image/webp',
            }
          );
          const compressedSizeKB = (compressedFile.size / 1024).toFixed(2);
          console.log(
            `✅ Compressed Image: ${compressedFile.name}, Size: ${compressedSizeKB} KB`
          );
          console.log(
            `📉 Reduction: ${(
              ((file.size - compressedFile.size) / file.size) *
              100
            ).toFixed(2)}%`
          );
          resolve(compressedFile);
        },
        error(err) {
          console.error('❌ Compression Error:', err);
          reject(err);
        },
      });
    });
  };

  const imageUploadMutation = useMutation({
    mutationFn: async () => {
      const authToken = Cookies.get('authToken');
      if (!authToken) {
        toast.error('Please login to proceed!');
        throw new Error('No token found');
      }

      const formData = new FormData();
      setIsCompressing(true);

      const compressedImages = await Promise.all(newImages.map(compressImage));
      setIsCompressing(false);

      compressedImages.forEach((file) => {
        formData.append('image', file);
      });
      formData.append('categoryId', productId.toString());

      const { data } = await axios.post(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/uploadCategoryImages`,
        formData,
        {
          headers: {
            adminauth: authToken,
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      if (data.status !== 'Success') {
        toast.error(data.message || 'Failed to upload images');
        throw new Error(data.message || 'API request failed');
      }

      toast.success('Images uploaded successfully!');
      queryClient.invalidateQueries({ queryKey: ['productList'] });

      return data;
    },
    onError: (error: any) => {
      setIsCompressing(false);
      console.error('❌ Error updating product:', error);
      if (axios.isAxiosError(error) && error.response) {
        toast.error(error.response.data?.message || 'Something went wrong!');
      } else {
        toast.error('Something went wrong!');
      }
    },
    onSuccess: () => {
      setNewImages([]);
    },
  });

  const imageRemovalMutation = useMutation({
    mutationFn: async (imageUrl: string) => {
      const authToken = Cookies.get('authToken');
      if (!authToken) {
        toast.error('Please login to proceed!');
        throw new Error('No token found');
      }

      const filename = imageUrl.split('/').pop();

      const { data } = await axios.delete(
        `${config.NEXT_PUBLIC_API_URL}/removeProductImage`,
        {
          headers: { adminauth: authToken },
          data: {
            productId,
            imageUrl: filename,
          },
        }
      );

      if (data.status === 'Failed') {
        toast.error(data.message || 'Failed to remove image');
        throw new Error(data.message || 'API request failed');
      }

      toast.success('Image removed successfully!');
      queryClient.invalidateQueries({ queryKey: ['productList'] });

      return data;
    },
    onError: (error: any) => {
      console.error('Error updating product:', error);
      if (axios.isAxiosError(error) && error.response) {
        toast.error(error.response.data?.message || 'Something went wrong!');
      } else {
        toast.error('Something went wrong!');
      }
    },
  });

  const MAX_FILE_SIZE = 2 * 1024 * 1024;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];

      if (file.size > MAX_FILE_SIZE) {
        toast.error(`${file.name} exceeds 2MB limit!`, {
          duration: 4000,
          position: 'top-center',
        });
        event.target.value = '';
        return;
      }

      if (!['image/jpeg', 'image/png'].includes(file.type)) {
        toast.error(
          `${file.name} is not a supported format (JPG, JPEG, PNG only)!`,
          {
            duration: 4000,
            position: 'top-center',
          }
        );
        event.target.value = '';
        return;
      }

      setNewImages([file]);
      toast.success('Image added successfully!', {
        duration: 3000,
        position: 'top-center',
      });
    }
  };

  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const removeNewImage = (index: number) => {
    setNewImages((prev) => prev.filter((_, i) => i !== index));
  };

  const removeExistingImage = (imageUrl: string) => {
    imageRemovalMutation.mutate(imageUrl);
  };

  const uploadImages = () => {
    imageUploadMutation.mutate();
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" className="p-0">
          {images.length > 0 ? (
            <img
              src={images[0]}
              alt={`Thumbnail for ${productName}`}
              className="h-10 w-10 object-cover rounded"
            />
          ) : (
            <Image className="h-6 w-6" />
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>
            <span className="text-lg font-bold">{productName}</span>
          </DialogTitle>
        </DialogHeader>

        <div>
          <h3 className="text-sm mb-2">Existing Images</h3>
          <div className="grid grid-cols-4 gap-2">
            {images.map((imgSrc, index) => (
              <div key={index} className="relative">
                <img
                  src={imgSrc}
                  alt={`Category ${productId} - Image ${index + 1}`}
                  className="w-full h-24 object-cover rounded cursor-pointer"
                  onClick={() => setSelectedImage(imgSrc)}
                />
                <button
                  onClick={() => removeExistingImage(imgSrc)}
                  disabled={imageRemovalMutation.isPending}
                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                >
                  {imageRemovalMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <X className="h-4 w-4" />
                  )}
                </button>
              </div>
            ))}
          </div>

          {selectedImage && (
            <div
              className="fixed inset-0 bg-gray-300 bg-opacity-60 flex justify-center items-center z-50"
              onClick={() => setSelectedImage(null)}
            >
              <div className="relative">
                <img
                  src={selectedImage}
                  alt="Enlarged Product Image"
                  className="max-w-[90vw] max-h-[90vh] rounded-lg shadow-lg"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-3 right-3 bg-red-500 text-white rounded-full p-2"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>
          )}
        </div>

        <div>
          <h3 className="text-sm mb-2">Upload New Images</h3>
          <div className="border-2 border-dashed p-4 text-center">
            <input
              type="file"
              accept=".jpg,.jpeg,.png"
              onChange={handleImageUpload}
              className="hidden"
              id={`image-upload-${productId}`}
            />
            <label
              htmlFor={`image-upload-${productId}`}
              className="flex flex-col items-center cursor-pointer"
            >
              <Upload className="h-10 w-10 text-gray-400 mb-2" />
              <p className="text-gray-600">Click to select images or drag and drop</p>
              <p className="text-gray-500 text-sm mt-1">
                Max 2MB per image. Formats: JPG, JPEG, PNG
              </p>
            </label>
          </div>

          {newImages.length > 0 && (
            <div className="mt-4">
              <h4 className="text-md font-medium mb-2">New Images to Upload</h4>
              <div className="grid grid-cols-4 gap-2">
                {newImages.map((file, index) => (
                  <div key={index} className="relative">
                    <img
                      src={URL.createObjectURL(file)}
                      alt={`New Image ${index + 1}`}
                      className="w-full h-24 object-cover rounded"
                    />
                    <button
                      onClick={() => removeNewImage(index)}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {newImages.length > 0 && (
            <div className="mt-4 text-center">
              <Button
                onClick={uploadImages}
                disabled={imageUploadMutation.isPending || isCompressing}
              >
                {isCompressing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Compressing...
                  </>
                ) : imageUploadMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  `Upload ${newImages.length} Image${newImages.length > 1 ? 's' : ''}`
                )}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

const ToggleOnlineShop = ({ row }: { row: any }) => {
  const queryClient = useQueryClient();
  const [checked, setChecked] = React.useState(row.original.display_status);
  const [loading, setLoading] = React.useState(false);

  // Helper to get the latest count of displayed categories
  const getDisplayedCount = () => {
    const queries = queryClient
      .getQueryCache()
      .findAll({ queryKey: ["productList"] })
      .map((q) => q.state.data)
      .filter(Boolean)
      .flat();
    return queries.filter((cat: any) => cat.display_status).length;
  };

  const toggleAvailabilityMutation = useMutation({
    mutationFn: async (newStatus: boolean) => {
      const authToken = Cookies.get("authToken");
      if (!authToken) {
        toast.error("Please login to proceed!");
        throw new Error("No token found");
      }

      const { data } = await axios.patch(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/markCategoryDisplay`,
        { categoryId: row.original.id },
        { headers: { adminauth: authToken } }
      );

      if (data.status === "Failed") {
        throw new Error(data.message || "API request failed");
      }

      return { newStatus, categoryId: row.original.id };
    },
    onSuccess: (result) => {
      setChecked(result.newStatus);
      toast.success("Category visibility updated successfully!");
      // Always refetch all pages to ensure correct count/order
      queryClient.invalidateQueries({ queryKey: ["productList"] });
    },
    onError: (error: any) => {
      if (error.message === "Display limit reached") return;
      toast.error(error.response?.data?.message || "Something went wrong!");
    },
  });

  const handleToggle = async () => {
    setLoading(true);
    // Refetch all categories to get the latest state
    await queryClient.invalidateQueries({ queryKey: ["productList"] });
    setTimeout(() => {
      // Give time for refetch to complete (or use a better sync if possible)
      const displayedCount = getDisplayedCount();
      const newStatus = !checked;
      const wouldBeCount = newStatus
        ? displayedCount + 1
        : displayedCount - 1;

      // If turning ON and already 3 are ON, block
      if (!checked && displayedCount >= 3) {
        toast.error("You can only display up to 3 categories at a time.");
        setLoading(false);
        return;
      }

      toggleAvailabilityMutation.mutate(newStatus, {
        onSettled: () => setLoading(false),
      });
    }, 300); // Wait for cache to update (adjust if needed)
  };

  return (
    <div className="flex justify-center items-center h-full">
      <div
        className={`relative w-12 h-6 flex items-center rounded-full cursor-pointer transition-all ${
          checked ? "bg-green-500" : "bg-gray-400"
        }`}
        onClick={loading ? undefined : handleToggle}
      >
        <div
          className={`absolute w-5 h-5 bg-white rounded-full transition-all shadow-md ${
            checked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </div>
    </div>
  );
};

const columns: ColumnDef<Payment>[] = [
  {
    accessorKey: "Sl No.",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Sl No.</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.index + 1}
      </div>
    ),
  },
  {
    accessorKey: "Category Name",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Category Name</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.original.category_name}
      </div>
    ),
  },
  {
    accessorKey: "Description",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Description</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.original.category_desc}
      </div>
    ),
  },

  {
    accessorKey: "Category Discount",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">
        Category Discount
      </div>
    ),
    cell: ({ row }) => {
      const [isEditing, setIsEditing] = useState(false);
      const [value, setValue] = useState(row.original.offer_percentage || 0);
      const [loading, setLoading] = useState(false);
      const inputRef = useRef<HTMLInputElement>(null);
  
      const handleSave = async () => {
        if (loading) return;
        setLoading(true);
        try {
          const res = await fetch(`${config.NEXT_PUBLIC_API_URL}/api/v1/admin/uploadCategoryImages`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              adminauth: Cookies.get("authToken") || "",
            },
            body: JSON.stringify({
              categoryId: row.original.id,
              offerPercentage: value,
            }),
          });
  
          if (!res.ok) throw new Error("Failed to update discount");
        } catch (err) {
          console.error("Error updating discount:", err);
        } finally {
          setLoading(false);
          setIsEditing(false);
        }
      };
  
      useEffect(() => {
        if (isEditing && inputRef.current) {
          inputRef.current.focus();
        }
      }, [isEditing]);
  
      return (
<div className="flex justify-center items-center w-full text-center gap-2">
  {isEditing ? (
 <input
 ref={inputRef}
 type="text"
 inputMode="decimal" // Support decimal keyboard on mobile
 pattern="[0-9]*[.,]?[0-9]*"
 className="w-20 border border-gray-300 px-4 py-1 text-sm text-center outline-none focus:border-b-2 focus:border-gray-400 focus:border-l-0 focus:border-t-0 focus:border-r-0"
 value={value}
 onFocus={(e) => e.target.select()}
 onChange={(e) => {
   const val = e.target.value;
   // Allow only one dot and valid float structure
   if (/^\d*\.?\d*$/.test(val)) {
     setValue(val);
   }
 }}
 onBlur={() => {

    toast.success(`Category Discount updated to ${value}%`);

  
  handleSave();
}}
 onKeyDown={(e) => {
   if (e.key === "Enter") {
     inputRef.current?.blur(); // Trigger blur to save
   }
   if (e.key === "Escape") {
     setIsEditing(false);
   }
 }}
 disabled={loading}
/>
  ) : (
    <div className="flex items-center gap-4">
      <span className="text-sm min-w-[2.5rem] text-center">{value}%</span>
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      ) : (
        <Pencil
          className="h-4 w-4 cursor-pointer text-muted-foreground hover:text-primary"
          onClick={() => setIsEditing(true)}
        />
      )}
    </div>
  )}
</div>
      );
    },
  },
  {
    accessorKey: "Online Shop",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Show on Shop</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        <ToggleOnlineShop row={row} />
      </div>
    ),
  },
  {
    accessorKey: "Images",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Images</div>
    ),
    cell: ({ row }) => {
      const parseImagesForColumn = (imagePath: string | null): string[] => {
        if (!imagePath || imagePath === 'null') return [];
        if (typeof imagePath === 'string' && !imagePath.startsWith('[')) {
          return imagePath.startsWith('http') 
            ? [imagePath] 
            : [`${config.NEXT_PUBLIC_API_URL}/${imagePath}`];
        }
        try {
          const parsed = JSON.parse(imagePath);
          if (!Array.isArray(parsed)) return [];
          return parsed
            .filter((img: any) => img && typeof img.src === 'string')
            .map((img: { src: string }) => 
              img.src.startsWith('http') 
                ? img.src 
                : `${config.NEXT_PUBLIC_API_URL}/${img.src}`
            );
        } catch (error) {
          console.error("Error parsing image_path in column:", error);
          return imagePath.startsWith('http') 
            ? [imagePath] 
            : [`${config.NEXT_PUBLIC_API_URL}/${imagePath}`];
        }
      };

      return (
        <div className="flex justify-center items-center w-full text-center">
          <ProductImageModal
            productId={row.original.id}
            productName={row.original.category_name}
            existingImages={
              Array.isArray(row.original.image_path)
                ? row.original.image_path.map((img: { src: string }) => img.src)
                : JSON.parse(row.original.image_path || "[]").map((img: { src: string }) => img.src)
            }           />
        </div>
      );
    },
  },
];


export default function Orders() {
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 8 });

  const queryClient = useQueryClient();

  const fetchOrders = async (page: number, limit: number) => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      
    }

    try {
      const { data } = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getCategory?page=${page}&limit=${limit}`,
        {
          headers: {
            adminauth: authToken,
          },
        }
      );
      return data.data;
    } catch (error) {
      console.error("Error fetching orders:", error);
      toast.error("Failed to fetch order list. Please try again.");
      throw error;
    }
  };

  const {
    data: productList = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<Payment[]>({
    queryKey: ["productList", pagination.pageIndex, "sorted"],
    queryFn: () => fetchOrders(pagination.pageIndex + 1, pagination.pageSize),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchInterval: 5 * 60 * 1000,
  });

  const table = useReactTable({
    data: productList,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
      pagination,
    },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    onPaginationChange: setPagination,
    manualPagination: true,
    pageCount: Math.ceil(productList.length / pagination.pageSize) || 1,
  });

  // Optional: Debug productList updates
  useEffect(() => {
  }, [productList]);

  return (
    <>
      <Toaster position="top-center" />
      <div className="p-3 flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <span className="text-xl font-bold">Categories</span>
          {/* <PDFDownloadLink
            key={JSON.stringify(productList)}
            document={<TablePDF data={productList} />}
            fileName="Product-List-Maharana-Silver.pdf"
          >
            {({ loading }) => (
              <Button
                onClick={() =>
                  toast.success("Export started! Your PDF will be ready soon.")
                }
                disabled={loading}
              >
                {loading ? "Generating..." : "Export Data"}
              </Button>
            )}
          </PDFDownloadLink> */}
        </div>
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-center justify-between py-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => (
                    <DropdownMenuCheckboxItem
                      key={column.id}
                      className="capitalize"
                      checked={column.getIsVisible()}
                      onCheckedChange={(value) =>
                        column.toggleVisibility(!!value)
                      }
                    >
                      {column.id}
                    </DropdownMenuCheckboxItem>
                  ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div>
            <Table>
              <TableHeader
                className="border-b-2"
                style={{ borderColor: "#D3D6E8" }}
              >
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <TableHead key={header.id}>
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    ))}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && "selected"}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      No results.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {table.getFilteredSelectedRowModel().rows.length} of{" "}
              {table.getFilteredRowModel().rows.length} row(s) selected.
            </div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex - 1,
                  }));
                  refetch();
                }}
                disabled={pagination.pageIndex === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex + 1,
                  }));
                  refetch();
                }}
                disabled={productList.length < pagination.pageSize}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
