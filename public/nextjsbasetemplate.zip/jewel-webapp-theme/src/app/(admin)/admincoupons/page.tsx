"use client";

import * as React from "react";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import CreateCoupon from "@/components/admin/createCoupon";

const data: Payment[] = [
  {
    id: "C001",
    couponCode: "SAVE10",
    couponDescription: "Get 10% off on all items.",
    discountType: "Percentage",
    discountValue: 10,
    minOrderValue: 100,
    usage: "50",
    redeemed: "45",
    status: "Active",
    date: "2024-02-01 to 2024-02-10",
  },
  {
    id: "C002",
    couponCode: "FREESHIP",
    couponDescription: "Free shipping on orders above $50.",
    discountType: "Flat",
    discountValue: 0,
    minOrderValue: 50,
    usage: "20",
    redeemed: "18",
    status: "Inactive",
    date: "2024-02-05 to 2024-02-15",
  },
  {
    id: "C003",
    couponCode: "WELCOME20",
    couponDescription: "20% off for first-time users.",
    discountType: "Percentage",
    discountValue: 20,
    minOrderValue: 0,
    usage: "100",
    redeemed: "90",
    status: "Inactive",
    date: "2024-02-10 to 2024-02-28",
  },
  {
    id: "C004",
    couponCode: "SPRING15",
    couponDescription: "15% off on all spring collection items.",
    discountType: "Percentage",
    discountValue: 15,
    minOrderValue: 75,
    usage: "30",
    redeemed: "25",
    status: "Active",
    date: "2024-03-01 to 2024-03-15",
  },
  {
    id: "C005",
    couponCode: "FLASH5",
    couponDescription: "Extra $5 off on flash sale items.",
    discountType: "Flat",
    discountValue: 5,
    minOrderValue: 25,
    usage: "150",
    redeemed: "120",
    status: "Expired",
    date: "2024-01-15 to 2024-01-25",
  },
  {
    id: "C006",
    couponCode: "SUMMER25",
    couponDescription: "25% off on summer collection.",
    discountType: "Percentage",
    discountValue: 25,
    minOrderValue: 80,
    usage: "70",
    redeemed: "65",
    status: "Active",
    date: "2024-06-01 to 2024-06-30",
  },
  {
    id: "C007",
    couponCode: "BF50",
    couponDescription: "50% off Black Friday special.",
    discountType: "Percentage",
    discountValue: 50,
    minOrderValue: 150,
    usage: "200",
    redeemed: "190",
    status: "Expired",
    date: "2023-11-24 to 2023-11-26",
  },
  {
    id: "C008",
    couponCode: "CYBER30",
    couponDescription: "Cyber Monday exclusive: 30% off.",
    discountType: "Percentage",
    discountValue: 30,
    minOrderValue: 100,
    usage: "95",
    redeemed: "85",
    status: "Inactive",
    date: "2023-11-27 to 2023-11-30",
  },
  {
    id: "C009",
    couponCode: "HOLIDAY20",
    couponDescription: "20% off on holiday special gifts.",
    discountType: "Percentage",
    discountValue: 20,
    minOrderValue: 50,
    usage: "80",
    redeemed: "75",
    status: "Inactive",
    date: "2024-12-10 to 2024-12-25",
  },
  {
    id: "C010",
    couponCode: "STUDENT15",
    couponDescription: "15% off for students with valid ID.",
    discountType: "Percentage",
    discountValue: 15,
    minOrderValue: 0,
    usage: "30",
    redeemed: "25",
    status: "Active",
    date: "2024-09-01 to 2024-12-31",
  },
  {
    id: "C011",
    couponCode: "EASTER20",
    couponDescription: "20% off on Easter-themed items.",
    discountType: "Percentage",
    discountValue: 20,
    minOrderValue: 60,
    usage: "40",
    redeemed: "35",
    status: "Active",
    date: "2024-04-10 to 2024-04-20",
  },
  {
    id: "C012",
    couponCode: "HALLOWEEN10",
    couponDescription: "10% off on spooky items.",
    discountType: "Percentage",
    discountValue: 10,
    minOrderValue: 30,
    usage: "55",
    redeemed: "50",
    status: "Expired",
    date: "2023-10-20 to 2023-10-31",
  },
  {
    id: "C013",
    couponCode: "BIRTHDAY25",
    couponDescription: "Exclusive birthday deal: 25% off!",
    discountType: "Percentage",
    discountValue: 25,
    minOrderValue: 50,
    usage: "15",
    redeemed: "10",
    status: "Active",
    date: "2024-01-01 to 2024-12-31",
  },
  {
    id: "C014",
    couponCode: "MOTHERSDAY30",
    couponDescription: "30% off on Mother's Day gifts.",
    discountType: "Percentage",
    discountValue: 30,
    minOrderValue: 80,
    usage: "35",
    redeemed: "30",
    status: "Inactive",
    date: "2024-05-01 to 2024-05-15",
  },
  {
    id: "C015",
    couponCode: "NEWYEAR50",
    couponDescription: "50% off to celebrate the New Year!",
    discountType: "Percentage",
    discountValue: 50,
    minOrderValue: 100,
    usage: "250",
    redeemed: "240",
    status: "Expired",
    date: "2023-12-31 to 2024-01-02",
  },
];

export type Payment = {
  id: string;
  couponCode: string;
  couponDescription: string;
  discountType: string;
  discountValue: number;
  minOrderValue: number;
  usage: string;
  redeemed: string;
  status: string;
  date: string;
};

const columns: ColumnDef<Payment>[] = [
  {
    accessorKey: "id",
    header: () => <div className="w-[100px]">ID</div>,
    cell: ({ row }) => (
      <div className="w-[100px]">{row.getValue("id")}</div>
    ),
  },
  {
    accessorKey: "couponCode",
    header: () => <div className="ml-2">Coupon Code</div>,
    cell: ({ row }) => {
      const { couponCode, couponDescription } = row.original;
      return (
        <div className="ml-2">
          <p className=" uppercase">{couponCode}</p>
          <p>{couponDescription}</p>
        </div>
      );
    },
  },
  {
    accessorKey: "discountType",
    header: () => <div className="w-[100px]">Discount Type</div>,
    cell: ({ row }) => (
      <div className="w-[100px]">{row.getValue("discountType")}</div>
    ),
  },
  {
    accessorKey: "usage",
    header: () => <div className="text-center">Redeemed</div>,
    cell: ({ row }) => {
      const { usage, redeemed } = row.original;
      return (
        <div className="text-center">
          {redeemed}/{usage}
        </div>
      );
    },
  },
  {
    accessorKey: "discountValue",
    header: () => <div className="text-center">Discount Value</div>,
    cell: ({ row }) => (
      <div className="text-center">₹{row.getValue("discountValue")}</div>
    ),
  },
  {
    accessorKey: "minOrderValue",
    header: () => <div className="text-center">Min Value</div>,
    cell: ({ row }) => (
      <div className="text-center">₹{row.getValue("minOrderValue")}</div>
    ),
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) =>
      row.getValue("status") == "Active" ? (
        <div className="capitalize">
          <span className="bg-green-300 p-2 rounded-xl text-green-800">
            {row.getValue("status")}
          </span>
        </div>
      ) : row.getValue("status") == "Inactive" ? (
        <div className="capitalize">
          <span className="bg-slate-300 p-2 rounded-xl text-slate-800">
            {row.getValue("status")}
          </span>
        </div>
      ) : (
        <div className="capitalize">
          <span className="bg-red-300 p-2 rounded-xl text-red-800">
            {row.getValue("status")}
          </span>
        </div>
      ),
  },
  {
    accessorKey: "date",
    header: () => <div className="">Date</div>,
    cell: ({ row }) => <div className="">{row.getValue("date")}</div>,
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const payment = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem
              onClick={() => navigator.clipboard.writeText(payment.id)}
            >
              Copy payment ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>View customer</DropdownMenuItem>
            <DropdownMenuItem>View payment details</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];

export default function Coupons() {
  const [selectedFilter, setSelectedFilter] = React.useState("id");
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});

  const [isCreateCouponOpen, setIsCreateCouponOpen] = React.useState(false);

  const table = useReactTable({
    data,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
    initialState: {
      pagination: {
        pageIndex: 0,
        pageSize: 8,
      },
    },
  });

  return (
    <div className="p-3 flex flex-col gap-4">
      <div className="flex justify-between items-end">
        <span className="text-xl font-bold">Coupons</span>
        <Button
          variant={"outline"}
          onClick={() => {
            setIsCreateCouponOpen(!isCreateCouponOpen);
          }}
        >
          {!isCreateCouponOpen ? "Create Coupon" : "Cancle"}
        </Button>
      </div>
      {isCreateCouponOpen ? (
        <CreateCoupon onClose={() => setIsCreateCouponOpen(false)} />
      ) : (
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-center justify-between py-4">
            <div className="flex gap-2">
              <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="id">Booking Id</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="customerName">Name</SelectItem>
                    <SelectItem value="date">Date</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
              <Input
                placeholder={`Filter by ${
                  selectedFilter === "id"
                    ? "booking Id"
                    : selectedFilter == "email"
                    ? "email"
                    : selectedFilter == "customerName"
                    ? "customerName"
                    : "date"
                }...`}
                value={
                  (table
                    .getColumn(selectedFilter)
                    ?.getFilterValue() as string) ?? ""
                }
                onChange={(event) =>
                  table
                    .getColumn(selectedFilter)
                    ?.setFilterValue(event.target.value)
                }
                className="max-w-sm"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div>
            <Table>
          <TableHeader className="border-b-2" style={{ borderColor: "#D3D6E8" }}>  
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      return (
                        <TableHead key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </TableHead>
                      );
                    })}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && "selected"}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      No results.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {table.getFilteredSelectedRowModel().rows.length} of{" "}
              {table.getFilteredRowModel().rows.length} row(s) selected.
            </div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
