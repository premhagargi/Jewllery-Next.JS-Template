/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import * as React from "react";
import toast, { Toaster } from "react-hot-toast";
import TablePDF from "../../../components/admin/InvoiceListPDF";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "../../../components/admin/PDFWrapper";
import dynamic from "next/dynamic";
import InvoicePDF from "@/components/admin/InvoiceAdminPDF";
import { pdf } from '@react-pdf/renderer';
import useAuthStore from "../stores/userAuthStore";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

const PDFDownloadLink = dynamic(
  () =>
    import("../../../components/admin/PDFWrapper").then(
      (mod) => mod.PDFDownloadLink
    ),
  { ssr: false }
);

import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import Cookies from "js-cookie";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import axios from "axios";
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState } from "react";
import config from "../../../../config.json";

export type Payment = {
  invoice_no: string;
  order_id: number;
  user_id: number;
  jw_customer_address: {
    name: string;
  };
  mi_shop_est: {
    id: number;
    est_shop_name: string;
    address1: string;
    address2: string;
  };
  company_id: string;
  est_shop_id: string;
  invoice_amount: string;
  invoice_amount_aft_tax: string;
  address_id: string;
  payment_mode: string;
  payment_status: string;
  jw_invoice_items: {
    id: number;
    invoice_id: number;
    order_id: number;
    total_price: string;
    unit_price: string;
    ProductMaster: {
      id: number;
      product_name: string;
      address1: string;
      address2: string;
      TaxxRate: {
        tax_id: string;
        tax_name: string;
        tax_cgst: string;
        tax_sgst: string;
        tax_igst: string;
      };
    };
  }[];
};

const columns: ColumnDef<Payment>[] = [
  {
    accessorKey: "Invoice Number",
    header: () => <div className=" text-center">Invoice Number</div>,
    cell: ({ row }) => (
      <div className=" text-center">{row.original.invoice_no}</div>
    ),
  },

  {
    accessorKey: "Invoive Amount",
    header: () => <div className="w-[75px] text-left">Invoice Amount</div>,
    cell: ({ row }) => (
      <div className="w-[75px]">₹{row.original.invoice_amount}</div>
    ),
  },
  {
    accessorKey: "Invoive Amount After Tax",
    header: () => (
      <div className="w-[100px] text-left">Final Invoice Amount</div>
    ),
    cell: ({ row }) => (
      <div className="w-[100px]">₹{row.original.invoice_amount_aft_tax}</div>
    ),
  },
  {
    accessorKey: "Customer Name",
    header: () => <div className="w-[150px] text-center">Customer Name</div>,
    cell: ({ row }) => (
      <div className="w-[150px] text-center">
        {row.original?.jw_customer_address?.name}
      </div>
    ),
  },
  {
    accessorKey: "Shop Name",
    header: () => <div className="w-[270px] text-center">Shop Name</div>,
    cell: ({ row }) => (
      <div className="w-[270px] text-center">
        {row.original.mi_shop_est.est_shop_name}
      </div>
    ),
  },
  {
    accessorKey: "Payment Status",
    header: () => <div className="w-[75px] text-center">Payment Status</div>,
    cell: ({ row }) => (
      <div className="w-[75px] text-center">{row.original.payment_status}</div>
    ),
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const invoice = row.original;

      const handleViewDetails = async () => {
        try {
          if (!invoice) {
            console.error("Invoice data is missing.");
            return;
          }

          // Generate the PDF
          const blob = await pdf(<InvoicePDF invoice={invoice} />).toBlob();

          // Create the object URL
          const blobUrl = URL.createObjectURL(blob);

          // Open in a new tab only
          window.open(blobUrl, "_blank");

          // Clean up the blob URL after some time
          setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
        } catch (error) {
          console.error("Error generating PDF", error);
          alert("There was an error generating the PDF. Please try again later.");
        }
      };

      return (
        <Button
          variant="ghost"
          className="h-8 w-auto px-3 py-1 text-blue-400 hover:text-blue-600"
          onClick={handleViewDetails}
        >
          View Invoice
        </Button>
      );
    },
  },
];

export default function Orders() {
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 8 });

  const fetchInvoices = async (page: number, limit: number) => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      return [];
    }

    try {
      const { data } = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getInvoiceList?page=${page}&limit=${limit}`,
        {
          headers: {
            adminauth: authToken,
          },
        }
      );
      return data.data;
    } catch (error) {
      console.error("Error fetching invoices:", error);
      toast.error("Failed to fetch invoice list. Please try again.");
      return [];
    }
  };

  const [invoiceList, setInvoiceList] = useState<Payment[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadInvoices = async () => {
    setIsLoading(true);
    try {
      const data = await fetchInvoices(
        pagination.pageIndex + 1,
        pagination.pageSize
      );
      setInvoiceList(data);
    } catch (error) {
      console.error("Error loading invoices:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, [pagination.pageIndex, pagination.pageSize]);

  const table = useReactTable({
    data: invoiceList,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      pagination,
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
    onPaginationChange: setPagination,
    manualPagination: true,
    pageCount: Math.ceil(invoiceList.length / pagination.pageSize) || 1,
  });

  const exportInvoiceToExcel = (invoiceList: any[]) => {
    if (!invoiceList || invoiceList.length === 0) {
      toast.error("No invoice data available to export.");
      return;
    }

    const mappedData = invoiceList.map((invoice) => {
      const invoiceAmount = Number(invoice?.invoice_amount) || 0;
      const taxCgst =
        invoice?.jw_invoice_items?.[0]?.ProductMaster?.TaxRate?.tax_cgst || 0;
      const taxSgst =
        invoice?.jw_invoice_items?.[0]?.ProductMaster?.TaxRate?.tax_sgst || 0;

      const totalTax =
        (invoiceAmount * (Number(taxCgst) + Number(taxSgst))) / 100;
      const totalAmountAfterTax = invoiceAmount + totalTax;
      return {
        "Invoice ID": invoice?.invoice_no,
        "Customer Name": invoice?.jw_customer_address?.name,
        "Amount": invoiceAmount,
        "Amount After Tax": totalAmountAfterTax,
        "Payment Status": invoice?.payment_status,
        "Ordered Items":
          invoice?.jw_invoice_items?.[0]?.ProductMaster?.product_name,
        "Item Price": invoice?.jw_invoice_items?.[0]?.unit_price,
        "Order Date": new Date(invoice.createdAt).toLocaleDateString(),
      };
    });

    const ws = XLSX.utils.json_to_sheet(mappedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Invoices");

    const excelBuffer = XLSX.write(wb, {
      bookType: "xlsx",
      type: "array",
    });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    saveAs(data, "Invoices-Maharana-Silver.xlsx");
    toast.success(
      "Invoice export started! Your Excel file will be ready soon."
    );
  };

  return (
    <>
      <Toaster position="top-center" />
      <div className="p-3 flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <span className="text-xl font-bold">Invoices</span>
          <Button onClick={() => exportInvoiceToExcel(invoiceList)}>
            Export Data
          </Button>
        </div>
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-center justify-end py-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div>
            <Table>
              <TableHeader
                className="border-b-2"
                style={{ borderColor: "#D3D6E8" }}
              >
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      return (
                        <TableHead key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </TableHead>
                      );
                    })}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && "selected"}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      No results.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground"></div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex - 1,
                  }));
                }}
                disabled={pagination.pageIndex === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex + 1,
                  }));
                }}
                disabled={invoiceList.length < pagination.pageSize}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
