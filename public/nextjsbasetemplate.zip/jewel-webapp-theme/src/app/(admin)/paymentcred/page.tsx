"use client";

import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../../../../config.json";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2, Eye, EyeOff } from "lucide-react";
import toast, { Toaster } from "react-hot-toast";
import Cookies from "js-cookie";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import useAuthStore from "../stores/userAuthStore";
// Component to manage Cashfree API credentials in a professional admin dashboard style
export default function PaymentCredPage() {
    const email = useAuthStore((state) => state.email);
  // State management for form inputs, loading, submission status, and visibility toggle
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [initialClientId, setInitialClientId] = useState("");
  const [initialClientSecret, setInitialClientSecret] = useState("");
  const [showSecret, setShowSecret] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({ clientId: "", clientSecret: "" });
  const [adminPassword, setAdminPassword] = useState("");
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [pendingCredentials, setPendingCredentials] = useState<any>(null);
  const authToken = Cookies.get("authToken");

  // Track if form has changes
  const hasChanges = clientId !== initialClientId || clientSecret !== initialClientSecret;

  // Fetch existing credentials on component mount
  useEffect(() => {
    const fetchCreds = async () => {
      try {
        const response = await axios.get(
          `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getCashfreeCred`,
          {
            headers: {
              adminauth: authToken,
            },
          }
        );

        const credData = response.data?.data;
        if (credData) {
          setClientId(credData.client_id || "");
          setClientSecret(credData.client_secret || "");
          setInitialClientId(credData.client_id || "");
          setInitialClientSecret(credData.client_secret || "");
        }
      } catch (err) {
        console.error("Failed to fetch credentials:", err);
        toast.error("Failed to load credentials. Please try again.", {
          duration: 4000,
          position: "top-center",
          style: {
            background: "#fef2f2",
            color: "#dc2626",
            border: "1px solid #dc2626",
          },
        });
      } finally {
        setLoading(false);
      }
    };

    if (authToken) {
      fetchCreds();
    } else {
      setLoading(false);
      toast.error("Authentication token missing. Please log in.", {
        duration: 4000,
        position: "top-center",
      });
    }
  }, [authToken]);

  // Validate form inputs
  const validateForm = () => {
    const newErrors = { clientId: "", clientSecret: "" };
    let isValid = true;

    if (!clientId.trim()) {
      newErrors.clientId = "Client ID is required";
      isValid = false;
    }
    if (!clientSecret.trim()) {
      newErrors.clientSecret = "Client Secret is required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const validateAdminPassword = async (credentials: any) => {
    try {
      // const username = sessionStorage.getItem("username");
      const response = await axios.post(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/login`,
        {
          //move to global state username
          username: email,
          companyId: config.COMPANY_ID,
          password: adminPassword,
        }
      );

      if (response.status === 200) {
        // Password validated, proceed with updating credentials
        updateCredentials(credentials);
        setIsPasswordDialogOpen(false);
        setAdminPassword("");
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Invalid password");
    }
  };

  const handleUpdateCredentials = (newCredentials: any) => {
    setPendingCredentials(newCredentials);
    setIsPasswordDialogOpen(true);
  };

  const updateCredentials = async (credentials: any) => {
    try {
      setIsSubmitting(true);
      const toastId = toast.loading("Saving credentials...", {
        position: "top-center",
        style: {
          background: "#f0f0f0",
          color: "#374151",
        },
      });

      const response = await axios.patch(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updateCashfreeCred`,
        {
          clientId: credentials.clientId,
          clientSecret: credentials.clientSecret,
          companyId: config.COMPANY_ID,
        },
        {
          headers: {
            adminauth: authToken,
          },
        }
      );

      if (response.data.status === "Success" && response.status === 200) {
        toast.success(response.data.message || "Credentials saved successfully", {
          id: toastId,
          duration: 4000,
          position: "top-center",
          style: {
            background: "#f0fff4",
            color: "#15803d",
            border: "1px solid #15803d",
          },
        });
        setInitialClientId(credentials.clientId);
        setInitialClientSecret(credentials.clientSecret);
      } else {
        throw new Error("Unexpected response status");
      }
    } catch (err) {
      console.error("Failed to update credentials:", err);
      toast.error("Failed to save credentials. Please try again.", {
        duration: 4000,
        position: "top-center",
        style: {
          background: "#fef2f2",
          color: "#dc2626",
          border: "1px solid #dc2626",
        },
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle form cancellation (reset to initial values)
  const handleCancel = () => {
    setClientId(initialClientId);
    setClientSecret(initialClientSecret);
    setErrors({ clientId: "", clientSecret: "" });
    setShowSecret(false);
    toast("Form reset to original values", {
      duration: 3000,
      position: "top-center",
      style: {
        background: "#f0f0f0",
        color: "#374151",
      },
    });
  };

  // Toggle visibility of client secret
  const toggleShowSecret = () => {
    setShowSecret((prev) => !prev);
  };

  return (
    <div className="bg-gray-100 py-4 px-4 sm:px-6 lg:px-8 flex justify-center">
      {/* Toaster component for react-hot-toast notifications */}
      <Toaster />
      {/* Form Container */}
      <div className="w-full max-w-3xl">
        <div className="mb-3">
          <p className="mt-1 text-sm text-gray-600">
            Configure your Cashfree API credentials to enable payment processing.
          </p>
        </div>

        <div className="bg-white shadow-sm rounded-lg border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Cashfree API Credentials</h2>
          </div>
          <div className="p-6">
            {loading ? (
              <div className="flex justify-center items-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600" aria-label="Loading" />
              </div>
            ) : (
              <>
                <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
                  {/* Client ID Field */}
                  <div className="space-y-2">
                    <Label
                      htmlFor="clientId"
                      className="text-sm font-medium text-gray-700"
                    >
                      Client ID <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="clientId"
                      value={clientId}
                      onChange={(e) => setClientId(e.target.value)}
                      placeholder="Enter Cashfree Client ID"
                      className={`w-full ${errors.clientId ? "border-red-600 focus:ring-red-600" : ""}`}
                      aria-invalid={!!errors.clientId}
                      aria-describedby={errors.clientId ? "clientId-error" : undefined}
                    />
                    {errors.clientId && (
                      <p id="clientId-error" className="text-sm text-red-600">
                        {errors.clientId}
                      </p>
                    )}
                  </div>

                  {/* Client Secret Field with Show/Hide Toggle */}
                  <div className="space-y-2">
                    <Label
                      htmlFor="clientSecret"
                      className="text-sm font-medium text-gray-700"
                    >
                      Client Secret <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="clientSecret"
                        type={showSecret ? "text" : "password"}
                        value={clientSecret}
                        onChange={(e) => setClientSecret(e.target.value)}
                        placeholder="Enter Cashfree Client Secret"
                        className={`w-full pr-10 ${errors.clientSecret ? "border-red-600 focus:ring-red-600" : ""}`}
                        aria-invalid={!!errors.clientSecret}
                        aria-describedby={errors.clientSecret ? "clientSecret-error" : undefined}
                      />
                      <button
                        type="button"
                        onClick={toggleShowSecret}
                        className="absolute inset-y-0 right-0 flex items-center p-3"
                        aria-label={showSecret ? "Hide client secret" : "Show client secret"}
                      >
                        {showSecret ? (
                          <EyeOff className="h-5 w-5 text-gray-500" />
                        ) : (
                          <Eye className="h-5 w-5 text-gray-500" />
                        )}
                      </button>
                    </div>
                    {errors.clientSecret && (
                      <p id="clientSecret-error" className="text-sm text-red-600">
                        {errors.clientSecret}
                      </p>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex justify-end space-x-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleCancel}
                      disabled={isSubmitting || loading || !hasChanges}
                      className="px-4 py-1 text-gray-600 border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Clear
                    </Button>
                    <Button
                      type="button"
                      onClick={() =>
                        handleUpdateCredentials({ clientId, clientSecret })
                      }
                      disabled={isSubmitting || loading || !hasChanges}
                      className="px-4 py-1 bg-blue-600 text-white hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving
                        </>
                      ) : (
                        "Save Credentials"
                      )}
                    </Button>
                  </div>
                </form>

                {/* Notes Section */}
                <section
                  className="mt-6 border-gray-200 pt-4 text-sm text-gray-600"
                  aria-labelledby="notes-heading"
                >
                  <h3 id="notes-heading" className="text-base font-semibold text-gray-900 mb-2">
                    Security & Usage Notes
                  </h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>
                      <strong>Secure Storage:</strong> Store your Client ID and Client Secret in a secure
                      location, such as a password manager or encrypted vault. Do not share them publicly.
                    </li>
                    <li>
                      <strong>Avoid Hardcoding:</strong> Never hardcode credentials in your application
                      code or version control systems like Git.
                    </li>
                    <li>
                      <strong>Where to Find Credentials:</strong> Obtain your Client ID and Client Secret
                      from the Cashfree Merchant Dashboard under API Keys.
                    </li>
                    <li>
                      <strong>Test Mode:</strong> Use test credentials for development and switch to live
                      credentials only for production.
                    </li>
                  </ul>
                </section>
              </>
            )}
          </div>
        </div>
      </div>

      <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Your Password</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <p className="text-sm text-gray-600">
              Please enter your admin password to update payment credentials
            </p>
            <Input
              type="password"
              placeholder="Enter your password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && adminPassword) {
                  validateAdminPassword(pendingCredentials);
                }
              }}
            />
          </div>
          <div className="flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setIsPasswordDialogOpen(false);
                setAdminPassword("");
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={() => validateAdminPassword(pendingCredentials)}
              disabled={!adminPassword}
            >
              Confirm
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}