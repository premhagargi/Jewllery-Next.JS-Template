"use client";
import { Input } from "@/components/ui/input";
import productImage from "../../../../public/assets/admin/productImage.png";
import Image from "next/image";
import { Divide, MessageSquareOff, Search, SendHorizonal } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import Style from "../styles/inbox.module.scss";
import { useEffect, useRef, useState } from "react";

// Define the type for a chat item
interface Chat {
  id: number;
  timestamp: string;
  senderName: string;
  messages: { sender: string; mine: string; timestamp: string }[];
  isRead: boolean;
}

export default function Inbox() {
  const chartData: Chat[] = [
    {
      id: 1,
      timestamp: "2025-02-07T12:34:00",
      senderName: "Tom Anderson",
      messages: [
        {
          sender:
            "Hello, I am interested in this course. Can you provide more details?",
          mine: "",
          timestamp: "2025-02-08T12:34:00",
        },
        {
          sender: "can we get the details",
          mine: "",
          timestamp: "2025-02-08T12:34:00",
        },
        {
          sender: "",
          mine: "Sure! I’d be happy to help. The course covers...",
          timestamp: "2025-02-06T12:35:00",
        },
        {
          sender:
            "Could you also clarify the course duration? Could you also clarify the course duration? Could you also clarify the course duration?",
          mine: "",
          timestamp: "2025-02-08T12:36:00",
        },
        {
          sender: "",
          mine: "The course lasts for 3 months, with weekly modules.",
          timestamp: "2025-02-08T12:37:00",
        },
      ],
      isRead: false,
    },
    {
      id: 2,
      timestamp: "2025-02-07T13:00:00",
      senderName: "Emily Clarke",
      messages: [
        {
          sender: "What is the eligibility criteria for the course?",
          mine: "",
          timestamp: "2025-02-07T13:00:00",
        },
        {
          sender: "can you reply ? i am waiting",
          mine: "",
          timestamp: "2025-02-07T13:00:00",
        },
        {
          sender: "",
          mine: "You should have a basic understanding of programming.",
          timestamp: "2025-02-07T13:01:00",
        },
      ],
      isRead: true,
    },
    {
      id: 3,
      timestamp: "2025-02-07T13:15:00",
      senderName: "John Doe",
      messages: [
        {
          sender: "When does the next session start?",
          mine: "",
          timestamp: "2025-02-07T13:15:00",
        },
        {
          sender: "",
          mine: "The next session starts on February 15th.",
          timestamp: "2025-02-07T13:16:00",
        },
      ],
      isRead: true,
    },
    {
      id: 4,
      timestamp: "2025-02-07T13:45:00",
      senderName: "Sophia Turner",
      messages: [
        {
          sender:
            "Can you confirm if the next batch for the course starts in March?",
          mine: "",
          timestamp: "2025-02-07T13:45:00",
        },
        {
          sender: "",
          mine: "Yes, the next batch will begin on March 1st.",
          timestamp: "2025-02-07T13:46:00",
        },
      ],
      isRead: true,
    },
    {
      id: 5,
      timestamp: "2025-02-02T14:00:00",
      senderName: "Megan Smith",
      messages: [
        {
          sender: "Can I get a discount for early registration?",
          mine: "",
          timestamp: "2025-02-07T14:00:00",
        },
        {
          sender: "",
          mine: "We offer a 10% discount if you register before the end of this month.",
          timestamp: "2025-02-07T14:01:00",
        },
      ],
      isRead: false,
    },
    {
      id: 6,
      timestamp: "2025-02-07T14:25:00",
      senderName: "Sophia Turner",
      messages: [
        {
          sender:
            "Can you confirm if the next batch for the course starts in March?",
          mine: "",
          timestamp: "2025-02-07T14:25:00",
        },
        {
          sender: "",
          mine: "Yes, the next batch will begin on March 1st.",
          timestamp: "2025-02-07T14:26:00",
        },
      ],
      isRead: true,
    },
  ];

  function getLatestMessage(messages: any) {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].sender) {
        return messages[i].sender;
      } else if (messages[i].mine) {
        return messages[i].mine;
      }
    }
    return null; // In case both sender and mine are empty
  }

  function extractTimeWithAMPMAndDate(timestamp: string) {
    const date = new Date(timestamp);
    const now = new Date();

    const hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, "0");

    const isToday = date.toDateString() === now.toDateString();

    const period = hours >= 12 ? "PM" : "AM";

    let formattedHours = hours % 12;
    formattedHours = formattedHours ? formattedHours : 12;

    const time = `${formattedHours}:${minutes} ${period}`;

    if (isToday) {
      return time;
    } else {
      const formattedDate = `${String(date.getMonth() + 1).padStart(
        2,
        "0"
      )}/${String(date.getDate()).padStart(2, "0")}/${date.getFullYear()}`;
      return formattedDate;
    }
  }

  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [messageInput, setMessageInput] = useState(""); // State to track the input message
  const [searchQuery, setSearchQuery] = useState("");

  const handleChatSelect = (chat: Chat) => {
    setSelectedChat(chat);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageInput(e.target.value); // Update the input state as the user types
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && messageInput.trim()) {
      sendMessage(); // Send the message when "Enter" is pressed
    }
  };

  const sendMessage = () => {
    if (messageInput.trim()) {
      const newMessage = {
        sender: "",
        mine: messageInput,
        timestamp: new Date().toISOString(),
      };

      // Add the message to the selected chat
      const updatedChat = { ...selectedChat! }; // We know selectedChat is not null
      updatedChat.messages.push(newMessage);

      // Update the selectedChat state with the new message
      setSelectedChat(updatedChat);

      // Clear the input field
      setMessageInput("");
      setTimeout(() => {
        scrollToBottom();
      }, 0);
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value); // Update the search query
  };

  // Filter chartData based on the search query
  const filteredChartData = chartData.filter((chart) =>
    chart.senderName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Function to scroll to the bottom of the chat
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Automatically scroll to the bottom when the selected chat or its messages change
  useEffect(() => {
    scrollToBottom();
  }, [selectedChat?.messages]);

  return (
    <div className="p-4 flex flex-col gap-4">
      <span className="text-xl font-bold">Inbox</span>
      <div className="w-full h-[85vh] bg-white rounded-xl border shadow p-4 flex gap-4 text-sm">
        <div className="w-[32%] h-full flex flex-col gap-2 border-r pr-4 overflow-y-auto">
          <div className="relative h-[40px] mb-4">
            <Search
              size={15}
              className="absolute"
              style={{ top: "12px", left: "12px" }}
            />
            <Input
              placeholder="Search"
              className="h-full rounded-lg focus-visible:ring-0 focus-visible:outline-none"
              style={{ paddingLeft: "32px" }}
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>

          {filteredChartData.map((chart) => (
            <div
              key={chart.id}
              className={`flex gap-2 items-start w-full rounded-xl p-2 hover:bg-slate-100 cursor-pointer ${
                selectedChat?.id === chart.id
                  ? "bg-slate-100" // Highlight when selected
                  : "hover:bg-slate-100"
              }`}
              onClick={() => handleChatSelect(chart)}
            >
              <div>
                <Image
                  src={productImage}
                  width={1000}
                  height={1000}
                  quality={100}
                  alt=""
                  className="rounded-full w-[50px] h-[50px]"
                />
              </div>
              <div className="w-[80%] h-full">
                <div className="flex w-full items-center justify-between w-full">
                  <span className="font-bold text-[0.9rem]">
                    {chart.senderName}
                  </span>
                  <span className="text-xs font-medium">
                    {extractTimeWithAMPMAndDate(chart.timestamp)}
                  </span>
                </div>
                <div className="text-sm font-medium w-full overflow-hidden">
                  <p
                    className="text-sm font-medium w-full h-[80%]"
                    style={{
                      color: "#626567",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                    }}
                  >
                    {getLatestMessage(chart.messages)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="w-[80%] h-full">
          {!selectedChat ? (
            <div className="w-full h-full flex flex-col gap-2 justify-center items-center">
              <MessageSquareOff size={40} />
              <p>Please select a chat.</p>
            </div>
          ) : (
            <div className="w-full h-full flex flex-col gap-4 p-4">
              <div className="border-b pb-2">
                <span className="text-xl font-bold">
                  {selectedChat.senderName}
                </span>
              </div>
              <div
                className={`flex flex-col h-full w-full gap-3 overflow-y-auto pr-4 pl-2 ${Style.messageContainer}`}
                style={{ overflowX: "hidden" }}
              >
                {selectedChat.messages.map((message, index) => (
                  <div key={index} className="w-full flex">
                    {/* Display sender's message */}
                    {message.sender && (
                      <div className="w-[65%] flex justify-start gap-1 items-center">
                        <span
                          className={`w-fit text-sm rounded-xl bg-slate-200 p-2 px-3 text-left ${Style.sender}`}
                        >
                          {message.sender}
                        </span>
                        {/* <span className="text-xs">
                          {extractTimeWithAMPMAndDate(message.timestamp)}
                        </span> */}
                      </div>
                    )}

                    {/* Display mine's message */}
                    {message.mine && (
                      <div className="w-full flex justify-end gap-[8px] items-center">
                        <span
                          className={`max-w-[65%] text-sm rounded-xl bg-slate-200 p-2 px-3 text-left ${Style.mine}`}
                        >
                          {message.mine}
                        </span>
                        {/* <span className="text-xs">
                          {extractTimeWithAMPMAndDate(message.timestamp)}
                        </span> */}
                      </div>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} /> {/* Invisible div to scroll to */}
              </div>
              <div className="flex items-center w-full relative">
                <Input
                  value={messageInput}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown} // Detect Enter key
                  className="w-full h-full rounded-lg mt-4 focus-visible:ring-0 focus-visible:outline-none"
                  placeholder="Enter a message here..."
                />
                <Button
                  className="absolute right-[5px] top-[14px] w-[40px] h-[70%] rounded-lg"
                  onClick={sendMessage}
                >
                  <SendHorizonal />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
