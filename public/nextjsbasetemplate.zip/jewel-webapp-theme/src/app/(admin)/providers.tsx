// providers.tsx
"use client";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./stores/userAuthStore";
import React from "react";

export default function ReactQueryProvider({ children }: { children: React.ReactNode }) {
  // No useState needed, use the imported queryClient directly
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}