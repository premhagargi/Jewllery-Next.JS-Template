"use client";
/* eslint-disable @next/next/no-img-element */

import React, { useEffect, useState, useCallback, useRef } from "react";
import axios from "axios";
import config from "../../../../config.json";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2, Upload, Trash2 } from "lucide-react";
import toast, { Toaster } from "react-hot-toast";
import Cookies from "js-cookie";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Component to manage company logo with a compact, extensible admin dashboard style
export default function CompanyDetailsPage() {
  // State management
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState("");
  const [existingLogoUrl, setExistingLogoUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({ logo: "" });
  const [isDragging, setIsDragging] = useState(false);
  const authToken = Cookies.get("authToken");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Track form changes
  const hasChanges = logoFile !== null;

  // Fetch company logo
  const fetchCompanyDetails = useCallback(async (bustCache = false) => {
    try {
      const url = `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getCompanyDetail?companyId=${
        config.COMPANY_ID
      }${bustCache ? `&t=${Date.now()}` : ''}`;
      const response = await axios.get(url, {
        headers: {
          adminauth: authToken,
        },
      });

      const companyData = response.data?.data;
      if (companyData && companyData.cmp_logo) {
        try {
          const logoData = JSON.parse(companyData.cmp_logo);
          if (Array.isArray(logoData) && logoData.length > 0 && logoData[0].src) {
            // Append cache-busting query parameter to the logo URL
            const logoUrl = `${config.NEXT_PUBLIC_API_URL}/${logoData[0].src}?t=${Date.now()}`;
            setExistingLogoUrl(logoUrl);
          } else {
            setExistingLogoUrl("");
          }
        } catch (parseError) {
          console.error("Failed to parse cmp_logo:", parseError);
          setExistingLogoUrl("");
        }
      } else {
        setExistingLogoUrl("");
      }
    } catch (err) {
      console.error("Failed to fetch company logo:", err);
      toast.error("Failed to load company logo. Please try again.", {
        duration: 4000,
        position: "top-right",
        style: {
          background: "#fff1f2",
          color: "#e11d48",
          border: "1px solid #e11d48",
        },
      });
    } finally {
      setLoading(false);
    }
  }, [authToken]);

  // Handle logo file selection and preview
  const handleLogoChange = (file: File | null) => {
    if (file) {
      const validTypes = ["image/png", "image/jpeg", "image/jpg"];
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (!validTypes.includes(file.type)) {
        setErrors({ logo: "Only PNG, JPG, or JPEG files are allowed" });
        return;
      }
      if (file.size > maxSize) {
        setErrors({ logo: "File size must be less than 5MB" });
        return;
      }

      setLogoFile(file);
      setErrors({ logo: "" });
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === "string") {
          setLogoPreview(reader.result);
        } else {
          setLogoPreview("");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      handleLogoChange(file);
    }
  };

//  Handle drag and drop
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      handleLogoChange(file);
    }
  };

  // Clear logo selection
  const handleClearLogo = () => {
    setLogoFile(null);
    setLogoPreview("");
    setErrors({ logo: "" });
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Handle logo upload
  const handleUpdateDetails = async () => {
    if (!logoFile) {
      setErrors({ logo: "Please select a logo to upload" });
      return;
    }

    try {
      setIsSubmitting(true);
      const toastId = toast.loading("Uploading company logo...", {
        position: "top-right",
        style: {
          background: "#f3f4f6",
          color: "#374151",
        },
      });

      const formData = new FormData();
      formData.append("image", logoFile);

      const response = await axios.post(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/uploadCmpLogo`,
        formData,
        {
          headers: {
            adminauth: authToken,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.data.status === "Success" && response.status === 200) {
        toast.success(response.data.message || "Company logo uploaded successfully", {
          id: toastId,
          duration: 4000,
          position: "top-right",
          style: {
            background: "#ecfdf5",
            color: "#047857",
            border: "1px solid #047857",
          },
        });
        setLogoFile(null);
        setLogoPreview("");
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
        // Fetch updated company details with cache busting
        await fetchCompanyDetails(true);
      } else {
        throw new Error("Unexpected response status");
      }
    } catch (err: any) {
      console.error("Failed to upload company logo:", err);
      let errorMessage = "Failed to upload company logo. Please try again.";
      if (err.response?.status === 500) {
        errorMessage = "Server error occurred while uploading the logo. Please try again later.";
      } else if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      }
      toast.error(errorMessage, {
        duration: 4000,
        position: "top-right",
        style: {
          background: "#fff1f2",
          color: "#e11d48",
          border: "1px solid #e11d48",
        },
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle form cancellation
  const handleCancel = () => {
    setLogoFile(null);
    setLogoPreview("");
    setErrors({ logo: "" });
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    toast("Form reset", {
      duration: 3000,
      position: "top-right",
      style: {
        background: "#f3f4f6",
        color: "#374151",
      },
    });
  };

  useEffect(() => {
    if (authToken) {
      fetchCompanyDetails();
    } else {
      setLoading(false);
      toast.error("Authentication token missing. Please log in.", {
        duration: 4000,
        position: "top-right",
        style: {
          background: "#fff1f2",
          color: "#e11d48",
          border: "1px solid #e11d48",
        },
      });
    }
  }, [authToken, fetchCompanyDetails]);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <Toaster />
      <div className="max-w-3xl mx-auto">
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium text-gray-900">
              Company Logo Management
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {loading ? (
              <div className="flex justify-center items-center h-24">
                <Loader2 className="h-5 w-5 animate-spin text-blue-600" aria-label="Loading" />
              </div>
            ) : (
              <div className="space-y-4">
                {/* Logo Display Section */}
                <div className="flex flex-wrap gap-6">
                  {/* Current Logo */}
                  {existingLogoUrl && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium text-gray-700">
                        Current Logo
                      </Label>
                      <img
                        src={existingLogoUrl}
                        alt="Current company logo"
                        className="h-40 w-30 object-cover rounded-lg border border-gray-200"
                      />
                    </div>
                  )}
                </div>

                {/* Upload Section */}
                <div className="space-y-2">
                  <Label htmlFor="logoUpload" className="text-sm font-medium text-gray-700">
                    Upload New Logo
                  </Label>
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={`relative flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-6 transition-colors overflow-hidden ${
                      isDragging 
                        ? "border-blue-500 bg-blue-50" 
                        : "border-gray-300 bg-gray-50"
                    }`}
                    style={{
                      backgroundImage: logoPreview ? `url(${logoPreview})` : 'none',
                      backgroundSize: 'cover',
                      backgroundPosition: 'center',
                      backgroundRepeat: 'no-repeat'
                    }}
                  >
                    {/* Overlay for better text readability */}
                    {logoPreview && (
                      <div className="absolute inset-0 bg-white/10"></div>
                    )}
                    
                    <div className="relative z-10 flex flex-col items-center">
                      <Upload className={`h-5 w-5 mb-2 ${isDragging ? 'text-blue-600' : logoPreview ? 'text-gray-700' : 'text-gray-500'}`} />
                      <p className={`text-sm mb-2 ${logoPreview ? 'text-gray-700 font-medium' : 'text-gray-600'}`}>
                        {logoPreview ? 'Replace logo or' : 'Drag and drop or'}
                      </p>
                      <label
                        htmlFor="logoUpload"
                        className="px-3 py-1.5 cursor-pointer bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 transition-colors"
                      >
                        {logoPreview ? 'Choose Different' : 'Select File'}
                      </label>
                    </div>
                    
                    {/* Remove button when image is selected */}
                    {logoPreview && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleClearLogo}
                        className="absolute top-2 right-2 z-10 h-6 w-6 p-0 rounded-full bg-red-500 text-white hover:bg-red-600"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                    
                    <Input
                      id="logoUpload"
                      type="file"
                      accept="image/png,image/jpeg,image/jpg"
                      onChange={handleFileInputChange}
                      className="hidden"
                      ref={fileInputRef}
                    />
                  </div>
                  {errors.logo && (
                    <p className="text-sm text-red-600">{errors.logo}</p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end space-x-2 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCancel}
                    disabled={isSubmitting || loading || !hasChanges}
                    className="px-3 py-1.5 text-sm"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    onClick={handleUpdateDetails}
                    disabled={isSubmitting || loading || !hasChanges}
                    className="px-4 py-1.5 text-sm bg-blue-600 text-white hover:bg-blue-700"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      "Upload Logo"
                    )}
                  </Button>
                </div>

                {/* Information Section */}
                <div className="bg-gray-50 rounded-lg p-3 border">
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Requirements
                  </Label>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Formats: PNG, JPG, JPEG (max 5MB)</li>
                    <li>• Aspect ratio: 9:1 (width:height, e.g., 900×100 px) for optimal fit</li>
                    <li>• Tips: Use a transparent background if possible for best clarity</li>
                    <li>• Recommended dimensions: At least 540×60 px</li>
                  </ul>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}