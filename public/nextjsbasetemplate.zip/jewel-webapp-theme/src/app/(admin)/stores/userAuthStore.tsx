import { create } from "zustand";
import Cookies from "js-cookie";
import { QueryClient } from "@tanstack/react-query";

export const queryClient = new QueryClient();

interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  email: string | null;
  cmp_logo: string | null;
  loading: boolean;
  logoutSignal: number;
  initializeAuth: () => void;
  login: (token: string, email: string, cmp_logo: string) => void;
  logout: () => void;
}

function storeToken(token: string) {
  const isSecure = window.location.protocol === "https:";
  Cookies.set("authToken", token, {
    expires: 7,
    sameSite: "Lax",
    site: isSecure,
    path: "/",
  });
}

function storeEmail(email: string) {
  localStorage.setItem("authEmail", email);
}

function storeLogo(cmp_logo: string) {
  localStorage.setItem("cmpLogo", cmp_logo);
}

function clearStoredEmail() {
  localStorage.removeItem("authEmail");
}

function clearStoredLogo() {
  localStorage.removeItem("cmpLogo");
}

const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  token: null,
  email: null,
  cmp_logo: null,
  loading: true,
  logoutSignal: 0,

  initializeAuth: () => {
    const token = Cookies.get("authToken");
    const email = localStorage.getItem("authEmail");
    const cmp_logo = localStorage.getItem("cmpLogo");

    set({
      isAuthenticated: !!token,
      token: token || null,
      email: email || null,
      cmp_logo: cmp_logo || null,
      loading: false,
    });
    // console.log("Initialized auth state:", { token, email, cmp_logo });
  },

  login: (token: string, email: string, cmp_logo: string) => {
    storeToken(token);
    storeEmail(email);
    storeLogo(cmp_logo);
    set({ isAuthenticated: true, token, email, cmp_logo, loading: false });
    // console.log("Login successful:", { token, email, cmp_logo });
  },

  logout: () => {
    Cookies.remove("authToken", { path: "/" });
    clearStoredEmail();
    clearStoredLogo();
    localStorage.clear(); // Optional: remove if you want to preserve other app data

    window.location.href = "/adminlogin";

    queryClient.removeQueries({
      predicate: (query) =>
        ["orderList", "productList", "invoiceList", "customerList"].includes(
          query.queryKey[0] as string
        ),
    });

    set({
      isAuthenticated: false,
      token: null,
      email: null,
      cmp_logo: null,
      logoutSignal: Date.now(),
      loading: false,
    });

    console.log("Logout signal:", Date.now());
    console.log("Remaining queries:", queryClient.getQueryCache().findAll());
  },
}));

export default useAuthStore;