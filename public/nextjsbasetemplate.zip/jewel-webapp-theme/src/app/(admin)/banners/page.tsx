/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
"use client";

import * as React from "react";
import toast, { Toaster } from "react-hot-toast";
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import Cookies from "js-cookie";
import TablePDF from "../../../components/admin/ProductPDF";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "../../../components/admin/PDFWrapper";
import dynamic from "next/dynamic";
import { Upload, Image, X, Loader2, Pencil } from 'lucide-react';

const PDFDownloadLink = dynamic(
  () =>
    import("../../../components/admin/PDFWrapper").then(
      (mod) => mod.PDFDownloadLink
    ),
  { ssr: false }
);

import axios from "axios";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import Compressor from "compressorjs";

import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
  DialogHeader,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useEffect, useState, useRef } from "react";
import config from '../../../../config.json'

export type Payment = {
  id: number,
  regcity_code: string,
  company_id: string,
  banner_title: string,
  banner_desc: string,
  banner_button_txt: string,
  image_path: string,
  display_status: boolean,
  button_redirect_path: string,
  is_delete: boolean
};

const AddBannerModal = () => {
  const queryClient = useQueryClient();
  const [bannerTitle, setBannerTitle] = useState("");
  const [bannerDesc, setBannerDesc] = useState("");
  const [bannerButtonText, setBannerButtonText] = useState("");
  const [bannerButtonRedirectPath, setBannerButtonRedirectPath] = useState("/");
  const [newImage, setNewImage] = useState<File | null>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  const [open, setOpen] = useState(false);

  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
      new Compressor(file, {
        quality: 0.8,
        mimeType: 'image/webp',
        success(result) {
          const compressedFile = new File(
            [result],
            file.name.replace(/\.[^.]+$/, '.webp'),
            { type: 'image/webp' }
          );
          resolve(compressedFile);
        },
        error(err) {
          reject(err);
        },
      });
    });
  };

  const bannerAddMutation = useMutation({
    mutationFn: async () => {
      const authToken = Cookies.get('authToken');
      if (!authToken) {
        toast.error('Please login to proceed!');
        throw new Error('No token found');
      }

      if (!newImage) {
        toast.error('Please select an image!');
        throw new Error('No image selected');
      }

      const formData = new FormData();
      setIsCompressing(true);
      const compressedImage = await compressImage(newImage);
      setIsCompressing(false);

      formData.append('image', compressedImage);
      formData.append('bannerTitle', bannerTitle);
      formData.append('bannerDesc', bannerDesc);
      formData.append('bannerButtonTxt', bannerButtonText);
      formData.append('display_status', 'false');

      const { data } = await axios.post(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/addBannerDetail`,
        formData,
        {
          headers: {
            adminauth: authToken,
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      if (data.status !== 'Success') {
        toast.error(data.message || 'Failed to add banner');
        throw new Error(data.message || 'API request failed');
      }

      return data;
    },
    onSuccess: (response) => {
      toast.success('Banner added successfully!');
      
      const newBanner = {
        id: response.data.id,
        banner_title: bannerTitle,
        banner_desc: bannerDesc,
        banner_button_txt: bannerButtonText,
        image_path: response.data.image_path,
        display_status: false,
        button_redirect_path: "/shop",
        regcity_code: "",
        company_id: "",
        is_delete: false
      };

      queryClient.setQueryData(
        ["bannersList", 0, "sorted"],
        (oldData: Payment[] | undefined) => {
          if (!oldData) return [newBanner];
          return [newBanner, ...oldData];
        }
      );

      setBannerTitle("");
      setBannerDesc("");
      setBannerButtonText("");
      setNewImage(null);
      setOpen(false);

      queryClient.invalidateQueries({
        queryKey: ["bannersList"],
      });
    },
    onError: (error: any) => {
      setIsCompressing(false);
      toast.error(error.response?.data?.message || 'Something went wrong!');
    },
  });

  const MAX_FILE_SIZE = 2 * 1024 * 1024;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];

      if (file.size > MAX_FILE_SIZE) {
        toast.error(`${file.name} exceeds 2MB limit!`);
        event.target.value = '';
        return;
      }

      if (!['image/jpeg', 'image/png'].includes(file.type)) {
        toast.error(`${file.name} is not a supported format (JPG, JPEG, PNG only)!`);
        event.target.value = '';
        return;
      }

      setNewImage(file);
      toast.success('Image selected successfully!');
    }
  };

  const removeNewImage = () => {
    setNewImage(null);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>+ Add Banner</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Add New Banner</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Title</label>
            <Input
              value={bannerTitle}
              onChange={(e) => setBannerTitle(e.target.value)}
              placeholder="Enter banner title"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Description</label>
            <Input
              value={bannerDesc}
              onChange={(e) => setBannerDesc(e.target.value)}
              placeholder="Enter banner description"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Button Text</label>
            <Input
              value={bannerButtonText}
              onChange={(e) => setBannerButtonText(e.target.value)}
              placeholder="Enter banner button text"
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Image</label>
            <div className="border-2 border-dashed p-4 text-center">
              <input
                type="file"
                accept=".jpg,.jpeg,.png"
                onChange={handleImageUpload}
                className="hidden"
                id="banner-image-upload"
              />
              <label
                htmlFor="banner-image-upload"
                className="flex flex-col items-center cursor-pointer"
              >
                <Upload className="h-10 w-10 text-gray-400 mb-2" />
                <p className="text-gray-600">Click to select image or drag and drop</p>
                <p className="text-gray-500 text-sm mt-1">
                  Max 2MB. Formats: JPG, JPEG, PNG
                </p>
              </label>
            </div>

            {newImage && (
              <div className="mt-4 relative">
                <img
                  src={URL.createObjectURL(newImage)}
                  alt="New Banner Image"
                  className="w-full h-24 object-cover rounded"
                />
                <button
                  onClick={removeNewImage}
                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button
            onClick={() => bannerAddMutation.mutate()}
            disabled={bannerAddMutation.isPending || isCompressing || !bannerTitle || !bannerDesc || !bannerButtonText || !newImage}
          >
            {isCompressing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Compressing...
              </>
            ) : bannerAddMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adding...
              </>
            ) : (
              'Add Banner'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const UpdateBannerModal = ({ banner }: { banner: Payment }) => {
  const queryClient = useQueryClient();
  const [bannerTitle, setBannerTitle] = useState(banner.banner_title);
  const [bannerDesc, setBannerDesc] = useState(banner.banner_desc);
  const [bannerButtonText, setBannerButtonText] = useState(banner.banner_button_txt);
  const [newImage, setNewImage] = useState<File | null>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  const [open, setOpen] = useState(false);

  // Reset state when banner prop changes
  useEffect(() => {
    setBannerTitle(banner.banner_title);
    setBannerDesc(banner.banner_desc);
    setBannerButtonText(banner.banner_button_txt);
    setNewImage(null); // Reset newImage when banner changes
  }, [banner, banner.image_path]);

  // Parse the image_path to get the correct image URL
  const getImageUrl = (imagePath: string): string => {
    if (!imagePath || imagePath === "null") return "";
    try {
      // Handle single URL string
      if (!imagePath.startsWith("[")) {
        return imagePath.startsWith("http")
          ? imagePath
          : `${config.NEXT_PUBLIC_API_URL}/${imagePath}`;
      }
      // Handle JSON array
      const parsed = JSON.parse(imagePath);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].src) {
        return parsed[0].src.startsWith("http")
          ? parsed[0].src
          : `${config.NEXT_PUBLIC_API_URL}/${parsed[0].src}`;
      }
      return "";
    } catch (error) {
      console.error("Error parsing image_path:", error);
      // Fallback to treating imagePath as a single URL
      return imagePath.startsWith("http")
        ? imagePath
        : `${config.NEXT_PUBLIC_API_URL}/${imagePath}`;
    }
  };

  const imageUrl = getImageUrl(banner.image_path);

  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
      new Compressor(file, {
        quality: 0.8,
        mimeType: "image/webp",
        success(result) {
          const compressedFile = new File(
            [result],
            file.name.replace(/\.[^.]+$/, ".webp"),
            { type: "image/webp" }
          );
          resolve(compressedFile);
        },
        error(err) {
          reject(err);
        },
      });
    });
  };

  const bannerUpdateMutation = useMutation({
    mutationFn: async () => {
      const authToken = Cookies.get("authToken");
      if (!authToken) {
        toast.error("Please login to proceed!");
        throw new Error("No token found");
      }

      const formData = new FormData();
      if (newImage) {
        setIsCompressing(true);
        const compressedImage = await compressImage(newImage);
        setIsCompressing(false);
        formData.append("image", compressedImage);
      }
      formData.append("bannerId", banner.id.toString());
      formData.append("bannerTitle", bannerTitle);
      formData.append("bannerDesc", bannerDesc);
      formData.append("bannerButtonTxt", bannerButtonText);

      const { data } = await axios.patch(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/updateBannerDetail`,
        formData,
        {
          headers: {
            adminauth: authToken,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (data.status !== "Success") {
        toast.error(data.message || "Failed to update banner");
        throw new Error(data.message || "API request failed");
      }

      return data;
    },
    onSuccess: (response) => {
      toast.success("Banner updated successfully!");

      // Update the cache with the new banner data
      queryClient.setQueryData(
        ["bannersList", Math.floor(banner.id / 8), "sorted"],
        (oldData: Payment[] | undefined) => {
          if (!oldData) return oldData;
          return oldData.map((item) =>
            item.id === banner.id
              ? {
                  ...item,
                  banner_title: bannerTitle,
                  banner_desc: bannerDesc,
                  banner_button_txt: bannerButtonText,
                  image_path: response.data.image_path || item.image_path, // Use new image_path
                }
              : item
          );
        }
      );

      // Update local state so modal shows the new image immediately
      if (response.data.image_path) {
        setNewImage(null);
        setBannerTitle(bannerTitle);
        setBannerDesc(bannerDesc);
        setBannerButtonText(bannerButtonText);
        // This will force the modal to use the new image
        banner.image_path = response.data.image_path;
      }

      setOpen(false);

      // Invalidate queries to refetch the latest data
      queryClient.invalidateQueries({
        queryKey: ["bannersList"],
      });
    },
    onError: (error: any) => {
      setIsCompressing(false);
      toast.error(error.response?.data?.message || "Something went wrong!");
    },
  });

  const MAX_FILE_SIZE = 2 * 1024 * 1024;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];

      if (file.size > MAX_FILE_SIZE) {
        toast.error(`${file.name} exceeds 2MB limit!`);
        event.target.value = "";
        return;
      }

      if (!["image/jpeg", "image/png"].includes(file.type)) {
        toast.error(`${file.name} is not a supported format (JPG, JPEG, PNG only)!`);
        event.target.value = "";
        return;
      }

      setNewImage(file);
      toast.success("Image selected successfully!");
    }
  };

  const removeNewImage = () => {
    setNewImage(null);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <Pencil className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Update Banner</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Title</label>
            <Input
              value={bannerTitle}
              onChange={(e) => setBannerTitle(e.target.value)}
              placeholder="Enter banner title"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Description</label>
            <Input
              value={bannerDesc}
              onChange={(e) => setBannerDesc(e.target.value)}
              placeholder="Enter banner description"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Button Text</label>
            <Input
              value={bannerButtonText}
              onChange={(e) => setBannerButtonText(e.target.value)}
              placeholder="Enter banner button text"
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Banner Image</label>
            {(newImage || imageUrl) && (
              <div className="mt-4 relative">
                <img
                  src={
                    newImage
                      ? URL.createObjectURL(newImage)
                      : imageUrl
                        ? `${imageUrl}?t=${Date.now()}`
                        : ""
                  }
                  alt="Banner Image"
                  className="w-full h-32 object-cover rounded"
                />
                <input
                  type="file"
                  accept=".jpg,.jpeg,.png"
                  onChange={handleImageUpload}
                  className="hidden"
                  id={`banner-image-upload-${banner.id}`}
                />
                <label
                  htmlFor={`banner-image-upload-${banner.id}`}
                  className="absolute top-2 left-2 bg-blue-500 text-white rounded-full p-1 cursor-pointer hover:bg-blue-600"
                >
                  <Pencil className="h-4 w-4" />
                </label>
                <button
                  onClick={removeNewImage}
                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}
            {!(newImage || imageUrl) && (
              <div className="mt-4">
                <input
                  type="file"
                  accept=".jpg,.jpeg,.png"
                  onChange={handleImageUpload}
                  className="hidden"
                  id={`banner-image-upload-${banner.id}`}
                />
                <label
                  htmlFor={`banner-image-upload-${banner.id}`}
                  className="flex justify-center items-center w-full h-32 border-2 border-gray-300 rounded bg-gray-100 cursor-pointer hover:bg-gray-200"
                >
                  <span className="text-gray-600">Select Image</span>
                </label>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button
            onClick={() => bannerUpdateMutation.mutate()}
            disabled={
              bannerUpdateMutation.isPending ||
              isCompressing ||
              !bannerTitle ||
              !bannerDesc ||
              !bannerButtonText
            }
          >
            {isCompressing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Compressing...
              </>
            ) : bannerUpdateMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Updating...
              </>
            ) : (
              "Update Banner"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const ProductImageModal = ({
  productId,
  productName,
  existingImages,
}: {
  productId: number;
  existingImages: string[];
  productName: string;
}) => {
  const parseImages = (images: string[]) => {
    if (!images) return [];
    try {
      const imagesArray = Array.isArray(images) ? images : [images];
      return imagesArray.flatMap((img) => {
        if (typeof img === 'string') {
          try {
            const parsed = JSON.parse(img);
            const imageSources = Array.isArray(parsed)
              ? parsed.map((item: { src: string }) => item.src)
              : [];
            return imageSources.map((src) =>
              src.startsWith('http')
                ? src
                : `${config.NEXT_PUBLIC_API_URL}/${src}`
            );
          } catch (error) {
            return img.startsWith('http')
              ? [img]
              : [`${config.NEXT_PUBLIC_API_URL}/${img}`];
          }
        }
        return [];
      });
    } catch (error) {
      console.error('Unexpected error processing images:', error);
      return [];
    }
  };

  const [images, setImages] = useState<string[]>(parseImages(existingImages));
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    setImages(parseImages(existingImages));
  }, [existingImages]);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" className="p-0">
          {images.length > 0 ? (
            <img
              src={images[0]}
              alt={`Thumbnail for ${productName}`}
              className="h-10 w-10 object-cover rounded"
            />
          ) : (
            <Image className="h-6 w-6" />
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>
            <span className="text-lg font-bold">{productName}</span>
          </DialogTitle>
        </DialogHeader>

        <div>
          <h3 className="text-sm mb-2">Existing Images</h3>
          <div className="grid grid-cols-4 gap-2">
            {images.map((imgSrc, index) => (
              <div key={index} className="relative">
                <img
                  src={imgSrc}
                  alt={`Banner ${productId} - Image ${index + 1}`}
                  className="w-full h-24 object-cover rounded cursor-pointer"
                  onClick={() => setSelectedImage(imgSrc)}
                />
              </div>
            ))}
          </div>

          {selectedImage && (
            <div
              className="fixed inset-0 bg-gray-300 bg-opacity-60 flex justify-center items-center z-50"
              onClick={() => setSelectedImage(null)}
            >
              <div className="relative">
                <img
                  src={selectedImage}
                  alt="Enlarged Product Image"
                  className="max-w-[90vw] max-h-[90vh] rounded-lg shadow-lg"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-3 right-3 bg-red-500 text-white rounded-full p-2"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

const ToggleOnlineShop = ({ row }: { row: any }) => {
  const queryClient = useQueryClient();
  const [checked, setChecked] = React.useState(row.original.display_status);

  useEffect(() => {
    setChecked(row.original.display_status);
  }, [row.original.display_status]);

  const toggleAvailabilityMutation = useMutation({
    mutationFn: async (newStatus: boolean) => {
      const authToken = Cookies.get("authToken");
      if (!authToken) {
        toast.error("Please login to proceed!");
        throw new Error("No token found");
      }

      const { data } = await axios.patch(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/markBannerDisplay`,
        { bannerId: row.original.id, display_status: newStatus },
        { headers: { adminauth: authToken } }
      );

      if (data.status === "Failed") {
        throw new Error(data.message || "API request failed");
      }

      return { newStatus, bannerId: row.original.id };
    },
    onSuccess: (result) => {
      toast.success("Banner visibility updated successfully!");
      
      queryClient.setQueryData(
        ["bannersList", Math.floor(result.bannerId / 8), "sorted"],
        (oldData: Payment[] | undefined) => {
          if (!oldData) return oldData;
          return oldData.map(banner => ({
            ...banner,
            display_status: banner.id === result.bannerId 
              ? result.newStatus 
              : banner.display_status
          }));
        }
      );
      
      setChecked(result.newStatus);
    },
    onError: (error: any) => {
      console.error("Error marking banner visibility:", error);
      toast.error(error.response?.data?.message || "Something went wrong!");
    },
  });

  const handleToggle = () => {
    const newStatus = !checked;
    toggleAvailabilityMutation.mutate(newStatus);
  };

  return (
    <div className="flex justify-center items-center h-full">
      <div
        className={`relative w-12 h-6 flex items-center rounded-full cursor-pointer transition-all ${
          checked ? "bg-green-500" : "bg-gray-400"
        }`}
        onClick={handleToggle}
      >
        <div
          className={`absolute w-5 h-5 bg-white rounded-full transition-all shadow-md ${
            checked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </div>
    </div>
  );
};

const columns: ColumnDef<Payment>[] = [
  {
    accessorKey: "Sl No.",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Sl No.</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.index + 1}
      </div>
    ),
  },
  {
    accessorKey: "banner Title",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Banner Title</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.original.banner_title}
      </div>
    ),
  },
  {
    accessorKey: "Description",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Description</div>
    ),
    cell: ({ row }) => {
      const description = row.original.banner_desc;
  
      return (
        <div className="flex justify-center items-center w-full text-center">
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="truncate max-w-[250px] cursor-default">
                {description}
              </div>
            </TooltipTrigger>
            <TooltipContent side="top">
              <p className="max-w-xs">{description}</p>
            </TooltipContent>
          </Tooltip>
        </div>
      );
    },
  },
  {
    accessorKey: "Banner Text",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Banner Text</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.original.banner_button_txt}
      </div>
    ),
  },
  {
    accessorKey: "Banner Redirection",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Banner Redirection</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        {row.original.button_redirect_path}
      </div>
    ),
  },
  {
    accessorKey: "Online Shop",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Show on Shop</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        <ToggleOnlineShop row={row} />
      </div>
    ),
  },
// {
//   accessorKey: "Images",
//   header: () => (
//     <div className="flex justify-center items-center w-full text-center">Images</div>
//   ),
//   cell: ({ row }) => {
//     const parseImagesForColumn = (imagePath: string | null): string[] => {
//       if (!imagePath || imagePath === 'null') return [];
//       if (typeof imagePath === 'string' && !imagePath.startsWith('[')) {
//         return imagePath.startsWith('http') 
//           ? [`${imagePath}?t=${Date.now()}`] // cache-busting
//           : [`${config.NEXT_PUBLIC_API_URL}/${imagePath}?t=${Date.now()}`];
//       }
//       try {
//         const parsed = JSON.parse(imagePath);
//         if (!Array.isArray(parsed)) return [];
//         return parsed
//           .filter((img: any) => img && typeof img.src === 'string')
//           .map((img: { src: string }) => 
//             img.src.startsWith('http') 
//               ? `${img.src}?t=${Date.now()}`
//               : `${config.NEXT_PUBLIC_API_URL}/${img.src}?t=${Date.now()}`
//           );
//       } catch (error) {
//         console.error("Error parsing image_path in column:", error);
//         return imagePath.startsWith('http') 
//           ? [`${imagePath}?t=${Date.now()}`]
//           : [`${config.NEXT_PUBLIC_API_URL}/${imagePath}?t=${Date.now()}`];
//       }
//     };

//     return (
//       <div className="flex justify-center items-center w-full text-center">
//         <ProductImageModal
//           productId={row.original.id}
//           productName={row.original.banner_title}
//           existingImages={
//             parseImagesForColumn(row.original.image_path)
//           }
//         />
//       </div>
//     );
//   },
// },
  {
    accessorKey: "Actions",
    header: () => (
      <div className="flex justify-center items-center w-full text-center">Actions</div>
    ),
    cell: ({ row }) => (
      <div className="flex justify-center items-center w-full text-center">
        <UpdateBannerModal banner={row.original} />
      </div>
    ),
  },
];

export default function Orders() {
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 8 });

  const queryClient = useQueryClient();

  const fetchOrders = async (page: number, limit: number) => {
    const authToken = Cookies.get("authToken");
    if (!authToken) {
      toast.error("Please login to proceed!");
      throw new Error("No auth token");
    }

    try {
      const { data } = await axios.get(
        `${config.NEXT_PUBLIC_API_URL}/api/v1/admin/getBanners`,
        {
          headers: {
            adminauth: authToken,
          },
          params: {
            page,
            limit,
            sort: 'created_at',
            order: 'desc'
          }
        }
      );
      
      return data.data.map((banner: Payment) => ({
        ...banner,
        display_status: banner.display_status
      }));
    } catch (error) {
      console.error("Error fetching orders:", error);
      toast.error("Failed to fetch order list. Please try again.");
      throw error;
    }
  };

  const {
    data: bannersList = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<Payment[]>({
    queryKey: ["bannersList", pagination.pageIndex, "sorted"],
    queryFn: () => fetchOrders(pagination.pageIndex + 1, pagination.pageSize),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchInterval: 5 * 60 * 1000,
  });

  const table = useReactTable({
    data: bannersList,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
      pagination,
    },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    onPaginationChange: setPagination,
    manualPagination: true,
    pageCount: Math.ceil(bannersList.length / pagination.pageSize) || 1,
  });

  useEffect(() => {}, [bannersList]);

  return (
    <>
      <Toaster position="top-center" />
      <div className="p-3 flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <span className="text-xl font-bold">Shop Banners</span>
        </div>
        <div className="w-full border shadow bg-white px-4 rounded-sm">
          <div className="flex items-end justify-between py-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto ml-2">
                  Columns <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => (
                    <DropdownMenuCheckboxItem
                      key={column.id}
                      className="capitalize"
                      checked={column.getIsVisible()}
                      onCheckedChange={(value) =>
                        column.toggleVisibility(!!value)
                      }
                    >
                      {column.id}
                    </DropdownMenuCheckboxItem>
                  ))}
              </DropdownMenuContent>
            </DropdownMenu>
          <AddBannerModal />
            
          </div>
          <div>
            <Table>
              <TableHeader
                className="border-b-2"
                style={{ borderColor: "#D3D6E8" }}
              >
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <TableHead key={header.id}>
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    ))}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && "selected"}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      No results.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {table.getFilteredSelectedRowModel().rows.length} of{" "}
              {table.getFilteredRowModel().rows.length} row(s) selected.
            </div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex - 1,
                  }));
                  refetch();
                }}
                disabled={pagination.pageIndex === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPagination((prev) => ({
                    ...prev,
                    pageIndex: prev.pageIndex + 1,
                  }));
                  refetch();
                }}
                disabled={bannersList.length < pagination.pageSize}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}