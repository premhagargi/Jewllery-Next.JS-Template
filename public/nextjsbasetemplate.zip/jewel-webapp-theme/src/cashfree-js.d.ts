declare module "@cashfreepayments/cashfree-js" {
  const cashfree: string; // Using 'any' to bypass TypeScript errors.
  export default cashfree;
}
