/* eslint-disable react-hooks/exhaustive-deps */

"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { api } from "../../utils/api";
import { jwtDecode } from "jwt-decode";
import config from "../../config.json";
import Cookies from "js-cookie";
const COMPANY_ID = config.COMPANY_ID;

// Define the ProfileData structure
interface ProfileData {
  id?: number;
  customer_id?: string;
  cust_cmp_name?: string | null;
  cust_cmp_phone?: string | null;
  cust_cmp_email?: string | null;
  company_id?: string;
  mobile_verified?: boolean;
  email_verified?: boolean;
  address1?: string | null;
  address2?: string | null;
  city?: string | null;
  state_code?: string | null;
  country_code?: string | null;
  pincode?: string | null;
  contact_person_name?: string | null;
  contact_no?: string | null;
  contact_email?: string | null;
  total_wallet_amount?: string;
  ref_wallet_amount?: string;
  password?: string;
  otp?: string | null;
  is_delete?: boolean;
  is_active?: boolean;
  City?: string | null;
  State?: string | null;
  Country?: string | null;
}

interface Category {
  category_id: string;
  category_name: string;
  totalQuantity: number;
}

interface CartData {
  totalProducts: number;
  totalPrice: string;
}

interface WishlistData {
  totalProducts: number;
}

interface Country {
  id: string;
  country_name: string;
  phonecode: string;
}

interface State {
  id: string;
  state_name: string;
  country_id: string;
}

interface City {
  id: string;
  city_name: string;
  state_id: string;
}

interface AddressList {
  id: number;
  company_id: string;
  customer_id: string;
  address_line1: string;
  address_line2: string;
  city: number;
  name: string;
  state: number;
  postal_code: string;
  country: number;
  contact_no: string;
  alternate_contact_no: string | null;
  primary_address: boolean;
  created_at: string;
  updated_at: string;
  City: {
    id: number;
    city_name: string;
    state_id: string;
  };
  State: {
    id: number;
    state_name: string;
    country_id: string;
  };
  Country: {
    id: number;
    sortname: string;
    country_name: string;
    phonecode: string;
  };
}

interface CompanyDetail {
  id: number;
  company_name: string;
  cmp_email: string;
  cmp_gst: string;
  cmp_pan: string;
}

interface GlobalStateContextType {
  cartData: CartData;
  wishlistData: WishlistData;
  categoryList: Category[];
  profileData: ProfileData | undefined;
  companyDetail: CompanyDetail | undefined;
  cmpLogo: string | undefined;
  loading: boolean;
  isLoggedIn: boolean;
  justLoggedIn: boolean;
  addressList: AddressList[];
  cityList: City[];
  stateList: State[];
  countryList: Country[];
  fetchData: (
    fetchType?:
      | "cart"
      | "wishlist"
      | "category"
      | "profile"
      | "address"
      | "cities"
      | "states"
      | "countries"
      | "company"
  ) => void;
  checkLoggedIn: () => void;
  setJustLoggedIn: (value: boolean) => void;
  isTokenExpired: (token: string) => boolean;
}

const GlobalStateContext = createContext<GlobalStateContextType | undefined>(
  undefined
);

export const GlobalStateProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [cartData, setCartData] = useState<CartData>({
    totalProducts: 0,
    totalPrice: "0",
  });
  const [wishlistData, setWishlistData] = useState<WishlistData>({
    totalProducts: 0,
  });
  const [categoryList, setCategoryList] = useState<Category[]>([]);
  const [addressList, setAddressList] = useState<AddressList[]>([]);
  const [cityList, setCityList] = useState<City[]>([]);
  const [stateList, setStateList] = useState<State[]>([]);
  const [countryList, setCountryList] = useState<Country[]>([]);
  const [profileData, setProfileData] = useState<ProfileData | undefined>(
    undefined
  );
  const [companyDetail, setCompanyDetail] = useState<CompanyDetail | undefined>(
    undefined
  );
  const [cmpLogo, setCmpLogo] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [justLoggedIn, setJustLoggedIn] = useState(false);

  const isTokenExpired = (token: string): boolean => {
    try {
      const decodedPayload: any = jwtDecode(token);
      const currentTime = Math.floor(Date.now() / 1000);
      return decodedPayload.exp < currentTime;
    } catch (error) {
      console.error("Error decoding token:", error);
      return true;
    }
  };

  const checkLoggedIn = () => {
    const token = Cookies.get("token");
    if (token) {
      if (isTokenExpired(token)) {
        Cookies.remove("token");
        setIsLoggedIn(false);
        setJustLoggedIn(false);
      } else {
        setIsLoggedIn(true);
      }
    } else {
      setIsLoggedIn(false);
      setJustLoggedIn(false);
    }
  };

const fetchData = async (
  fetchType?:
    | "cart"
    | "wishlist"
    | "category"
    | "profile"
    | "address"
    | "cities"
    | "states"
    | "countries"
    | "company"
) => {
  try {
    setLoading(true);
    const token = Cookies.get("token");
    checkLoggedIn();

    if (!fetchType || fetchType === "profile") {
      if (token) {
        const profileResponse = await api.get("/api/v1/getProfile");
        setProfileData(
          (profileResponse.data as { data: ProfileData }).data || undefined
        );
      }
    }

    if (!fetchType || fetchType === "address") {
      if (token) {
        const addressResponse = await api.get("/api/v1/address/getAddress");
        setAddressList(
          (addressResponse.data as { data: AddressList[] }).data || []
        );
      }
    }

    if (!fetchType || fetchType === "cart") {
      if (token) {
        const cartResponse = await api.get("/api/v1/cart/cartdata");
        setCartData(
          (
            cartResponse.data as {
              data: { totalProducts: number; totalPrice: string };
            }
          ).data || { totalProducts: 0, totalPrice: "0" }
        );
      }
    }

    if (!fetchType || fetchType === "wishlist") {
      if (token) {
        const wishlistResponse = await api.get("/api/v1/products/getwishlist");
        const wishlistItems =
          (wishlistResponse.data as { data: any[] }).data || [];
        setWishlistData({ totalProducts: wishlistItems.length });
      }
    }

    if (!fetchType || fetchType === "category") {
      const categoriesResponse = await api.get(
        `/api/v1/category/getCategory?company_id=${COMPANY_ID}`
      );
      setCategoryList(
        (categoriesResponse.data as { data: Category[] }).data || []
      );
    }

    if (!fetchType || fetchType === "countries") {
      const countriesResponse = await api.get(`/api/v1/countryData`);
      setCountryList(
        (countriesResponse.data as { data: Country[] }).data || []
      );
    }

    if (fetchType === "cities") {
      const state_id = localStorage.getItem("state_id");
      const citiesResponse = await api.get(
        `/api/v1/cityData?state_id=${state_id}`
      );
      setCityList((citiesResponse.data as { data: City[] }).data || []);
    }

    if (fetchType === "states") {
      const country_id = localStorage.getItem("country_id");
      const statesResponse = await api.get(
        `/api/v1/stateData?country_id=${country_id}`
      );
      setStateList((statesResponse.data as { data: State[] }).data || []);
    }

    // Modified company fetch logic
    if (!fetchType || fetchType === "company") {
      if (!companyDetail) { // Only fetch if companyDetail is undefined
        const companyResponse = await api.get(
          `/api/v1/admin/getCompanyDetail?companyId=${COMPANY_ID}`
        );
        const companyData = (companyResponse.data as {
          data: {
            mi_company: CompanyDetail;
            cmp_logo: string;
          };
        }).data;

        // Set the company detail
        setCompanyDetail(companyData.mi_company || undefined);

        // Safely parse and set the logo
      try {
  const logoArray = JSON.parse(companyData.cmp_logo || "[]");
  if (Array.isArray(logoArray) && logoArray.length > 0 && logoArray[0].src) {
    const logoPath = logoArray[0].src.startsWith("http")
      ? logoArray[0].src
      : `${config.NEXT_PUBLIC_API_URL.replace(/\/$/, "")}/${logoArray[0].src.replace(/^\//, "")}`; // safely join

    setCmpLogo(logoPath);
  } else {
    setCmpLogo(undefined);
    console.warn("Logo array is empty or missing 'src'");
  }
} catch (error) {
          console.error("Error parsing cmp_logo:", error);
          setCmpLogo(undefined);
        }
      } else {
      }
    }
  } catch (error) {
    console.error("Error fetching global data:", error);
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    checkLoggedIn();
    // fetchData();
  }, []);

  return (
    <GlobalStateContext.Provider
      value={{
        cartData,
        wishlistData,
        categoryList,
        loading,
        isLoggedIn,
        justLoggedIn,
        fetchData,
        checkLoggedIn,
        setJustLoggedIn,
        profileData,
        companyDetail,
        cmpLogo,
        addressList,
        isTokenExpired,
        cityList,
        stateList,
        countryList,
      }}
    >
      {children}
    </GlobalStateContext.Provider>
  );
};

export const useGlobalState = () => {
  const context = useContext(GlobalStateContext);
  if (!context) {
    throw new Error("useGlobalState must be used within a GlobalStateProvider");
  }
  return context;
};