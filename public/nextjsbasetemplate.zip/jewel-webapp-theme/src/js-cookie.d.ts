declare module "js-cookie" {
    const Cookies: any;
    export default Cookies;
  }
  