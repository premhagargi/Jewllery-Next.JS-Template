import { useEffect, useState } from 'react';

const THEMES = ['light', 'dark', 'rose', 'ocean'] as const;
type Theme = (typeof THEMES)[number];

export const useTheme = () => {
  const [theme, setTheme] = useState<Theme>('light');

  useEffect(() => {
    const stored = localStorage.getItem('theme') as Theme | null;
    const initial = stored && THEMES.includes(stored) ? stored : 'light';
    applyTheme(initial);
    setTheme(initial);
  }, []);

  const applyTheme = (newTheme: Theme) => {
    // Remove .dark if not dark theme
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.removeAttribute('data-theme');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.setAttribute('data-theme', newTheme);
    }

    localStorage.setItem('theme', newTheme);
    setTheme(newTheme);
  };

  return { theme, setTheme: applyTheme, availableThemes: THEMES };
};
