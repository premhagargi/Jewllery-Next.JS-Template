/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useGlobalState } from '../context/GlobalStateContext';
import Cookies from "js-cookie";

const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true); // New state to handle loading
  const router = useRouter();
  const { isTokenExpired } = useGlobalState();

  useEffect(() => {
    // Get the token from localStorage
    const token = Cookies.get("token");
    localStorage.setItem(
      "redirectAfterLogin",
      window.location.href
    );
    if (token && !isTokenExpired(token)) {
      setIsAuthenticated(true); // User is authenticated if token exists
    } else {
      setIsAuthenticated(false); // If there's no token, user is not authenticated
      router.push('/login'); // Redirect the user to login page
    }

    setLoading(false); // Stop loading after the check
  }, []); // Empty dependency array ensures this runs once when the component mounts

  return { isAuthenticated, loading }; // Return loading state
};

export default useAuth;
