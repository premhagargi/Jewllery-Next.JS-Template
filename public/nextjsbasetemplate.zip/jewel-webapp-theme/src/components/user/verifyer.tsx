"use client";
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

interface VerificationPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: "mobile" | "email";
  onVerified: () => void;
}

export default function VerificationPopup({
  open,
  onOpenChange,
  type,
  onVerified,
}: VerificationPopupProps) {
  const router = useRouter();

  const handleVerify = () => {
    onVerified();
    onOpenChange(false);
    router.push("/profile");
  };

  const handleCancel = () => {
    onOpenChange(false);
  };

  // Prevent closing on outside click or Escape key
  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      return; // Only allow closing via Cancel or Verify
    }
    onOpenChange(newOpen);
  };

  return (
    <div>
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>
              Verify Your {type === "mobile" ? "Mobile Number" : "Email Address"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex gap-2 justify-end py-4">
            <Button
              onClick={handleCancel}
              variant="outline"
              aria-label="Cancel verification"
            >
              Cancel
            </Button>
            <Button onClick={handleVerify} aria-label="Verify">
              Verify
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}