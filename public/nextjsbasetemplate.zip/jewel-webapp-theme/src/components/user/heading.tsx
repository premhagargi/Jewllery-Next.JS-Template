import React from "react";

interface HeadingProps {
  message: string; // Explicitly define the type for 'message'
}

export default function Heading({ message }: HeadingProps) {
  return (
    <div className="w-full mx-auto flex justify-center items-center gap-4 text-2xl">
      <div className="w-[50px] h-[3px] bg-[#9a602e]"></div>
      <h2 className="font-medium	">{message}</h2>
      <div className="w-[50px] h-[3px] bg-[#9a602e]"></div>
    </div>
  );
}
