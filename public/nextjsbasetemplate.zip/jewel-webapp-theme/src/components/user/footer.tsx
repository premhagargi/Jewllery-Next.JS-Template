import Link from "next/link";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { useGlobalState } from "../../context/GlobalStateContext";
import { FaInstagram } from "react-icons/fa";
import { FaFacebookF } from "react-icons/fa";
import { FaAngleUp, FaXTwitter } from "react-icons/fa6";
import Image from "next/image";
import webLogo from "../../../public/assets/user/icons/Union1.png";
import Style from "../../app/(user)/styles/footer.module.scss";
import React from "react";
import themeConfig from "../../../theme.config.json";

export default function Footer() {
    const { cmpLogo, fetchData, loading } = useGlobalState();
      // Theme Logic
    const THEME_ID = themeConfig.activeTheme;
    const isLuxury = THEME_ID === "luxury";
    
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };
  return (
    <div
      className={`w-full flex flex-col justify-center items-center text-[##565656] ${Style.footerContainer}`}
    >
      {/* <div className="text-center pb-8">
        <h2 className="text-2xl font-semibold">Local Kharid</h2>
        <p className="text-sm">@LocalKharid</p>
      </div> */}
      <div
        className={`w-full h-[250px] flex jsutify-between justify-center items-center border-t-2 border-[#9a602e] border-opacity-10 text-sm ${Style.footerUpperContainer}`}
      >
        <div className="w-[27%] h-[80%] flex flex-col justify-center items-center text-center border-r-2 border-opacity-10 border-[#9a602e] p-10">
          <p>Contact Us</p>
          <p>Working Hours Monday to Saturday 9:00am to 6:30pm</p>
          <p className="text-black mt-4">+91-7400233605</p>
        </div>
        <div className="w-[48%] h-[80%] flex flex-col justify-center items-center border-r-2 border-[#9a602e] border-opacity-10 p-10">
          <p className="text-lg text-black mb-2 font-semibold ">
            Let&apos;s Get in Touch
          </p>
          <p className="text-sm mb-6 text-center">
            We&apos;d love to hear from you. Whether you have a question,
            feedback — we&apos;re here to help!
          </p>
          <div className="flex w-[80%]">
            <Input
              placeholder="Email Address"
              className="rounded-none border-[#9a602e]"
            />
            <Button className="rounded-none font-light bg-[#9a602e]">
              SIGNUP
            </Button>
          </div>
          {/* <p className="mt-6 text-xs">
            I Accept Privacy Policy and Cookies Policy
          </p> */}
        </div>
        {/* <div className="w-[40px] h-[2px] bg-red-100 rotate-90"></div> */}
        <div className="w-[27%] h-[80%] flex flex-col justify-center items-center p-10 text-sm">
          <p className="pb-4">FOLLOW US ON SOCIAL MEDIA</p>
          <div className="flex gap-3 justify-center text-black">
            <Link href={"/"}>
              <FaInstagram />
            </Link>
            <Link href={"/"}>
              <FaFacebookF />
            </Link>
            <Link href={"/"}>
              <FaXTwitter />
            </Link>
          </div>
        </div>
      </div>
<div
  className={`w-full pt-14 flex flex-col justify-center ${
    isLuxury ? "bg-[#565656] text-white" : "bg-[#f0ebe8] text-[#8e8c8b]"
  } ${Style.footerBottomContainer}`}
>
  <div
    className={`w-[80%] mx-auto text-sm font-extralight flex border-b pb-14 ${
      isLuxury ? "border-[#7a7a7a]" : "border-[#bb9b9b]"
    } justify-between ${Style.footerBottomInnerContainer}`}
  >
    <div className={`w-[30%] ${Style.footerWebLogContainer}`}>
      <h1 className="text-2xl tracking-widest font-bold text-black">
        {/* {loading ? (
          <div className="w-[270px] h-[30px] bg-gray-300 animate-pulse rounded" />
        ) : cmpLogo ? (
          <Image
            src={cmpLogo}
            width={270}
            height={30}
            quality={100}
            alt="Company Logo"
            loading="lazy"
            className="inline-block mx-2 w-[270px] h-[40px] mb-1 text-white"
          />
        ) : (
          <p>No logo available</p>
        )} */}
                     <Image
                      src={webLogo}
                      width={270}
                      height={30}
                      quality={100}
                      alt="Company Logo"
                      loading="lazy"
                      className="inline-block mx-2 w-[270px] h-[40px] mb-1 border-none"
                    />
      </h1>
      <p
        className={`w-[250px] text-xs ${
          isLuxury ? "text-white/90" : ""
        }`}
      >
        Discover timeless jewellery pieces with Maharana Jewellers – elegance redefined.
      </p>
    </div>

    <div className={`w-[60%] flex justify-between ${Style.footerLinksContainer}`}>
      <div>
        <h4 className="text-lg mb-6">ABOUT US</h4>
        <div className="flex flex-col gap-2">
          <Link href={"/aboutus"} className="hover:underline">About Us</Link>
          <Link href={"/shop"} className="hover:underline">Our Products</Link>
          <Link href={"/privacyPolicy"} className="hover:underline">Privacy Policy</Link>
        </div>
      </div>
      <div>
        <h4 className="text-lg mb-6">CUSTOMER SERVICE</h4>
        <div className="flex flex-col gap-2">
          <Link href={"/contactus"} className="hover:underline">Contact Us</Link>
          <Link href={"/terms&condition"} className="hover:underline">Teams & Conditions</Link>
          <Link href={"/return&exchange"} className="hover:underline">Return & Exchange</Link>
          <Link href={"/orders"} className="hover:underline">Track Your Order</Link>
        </div>
      </div>
      <div className="h-full flex items-end">
        <div
          className={`w-[40px] h-[40px] ${
            isLuxury ? "bg-white" : "bg-[#9a602e]"
          } grid place-items-center cursor-pointer`}
          onClick={scrollToTop}
        >
          <FaAngleUp color={isLuxury ? "#565656" : "white"} />
        </div>
      </div>
    </div>
  </div>

  <div
    className={`w-[80%] mx-auto py-6 flex ${Style.footerBottomLowerContainer}`}
  >
    <p
      className={`text-xs ${
        isLuxury ? "text-white/80" : "text-[#bb9b9b]"
      }`}
    >
      © 2025 MAHARANA JEWELLERS. All rights reserved.
    </p>
  </div>
</div>

    </div>
  );
}
