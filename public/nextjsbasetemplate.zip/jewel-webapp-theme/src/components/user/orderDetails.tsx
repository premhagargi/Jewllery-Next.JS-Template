/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/exhaustive-deps */
import { CreditCard, X, Star, Car, BaggageClaim  } from "lucide-react";
import Image from "next/image";
import productImage from "../../../public/assets/user/product.png";
import { HiOutlineDocumentText } from "react-icons/hi";
import { useEffect, useState } from "react";
import { api } from "../../../utils/api";
import { useGlobalState } from "@/context/GlobalStateContext";
import InvoicePDF from "./InvoicePDF";
import { pdf } from "@react-pdf/renderer";
import config from "../../../config.json";
import { Clipboard } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";

// Define proper types for the API response and entities
interface PaymentMode {
  id: number;
  payment_method: string;
}

interface ProductRating {
  id: number;
  product_id: number;
  user_id: number;
  product_rating: number;
  comment: string;
  created_at: string;
  updated_at: string;
}

interface ProductMaster {
  product_name: string;
}

interface OrderItem {
  order_item_id: number;
  company_id: string;
  est_shop_id: number;
  order_id: string;
  product_id: number;
  inventory_id: number;
  quantity: number;
  price: string;
  total_price: string;
  tax_cgst: string;
  tax_sgst: string;
  tax_igst: string;
  created_at: string;
  EstShopInventories: {
    carat_value: string;
    image_path: string;
  }[];
  ProductMaster: ProductMaster;
  jw_product_ratings?: ProductRating[];
}

interface JwInvoiceItem {
  id: number;
  invoice_id: number;
  order_id: number;
  product_id: number;
  quantity: number;
  est_shop_id: string;
  unit_price: string;
  total_price: string;
  tax_cgst: string;
  tax_sgst: string;
  tax_igst: string;
  createdAt: string;
  updatedAt: string;
  ProductMaster: {
    id: number;
    product_name: string;
    product_desc: string;
    tax_gst_id: string;
    TaxRate: {
      tax_id: string;
      tax_name: string;
      tax_cgst: string;
      tax_sgst: string;
      tax_igst: string;
      company_id: string;
    };
  };
}

interface InvoiceItem {
  id: number;
  invoice_no: string;
  order_id: number;
  user_id: number;
  company_id: string;
  est_shop_id: string;
  invoice_amount: string;
  invoice_amount_aft_tax: string;
  address_id: string;
  payment_mode: string;
  payment_status: string;
  created_at: string;
  ProductMaster: ProductMaster;
  jw_invoice_items?: JwInvoiceItem[];
}

interface OrderDetails {
  company_id: string;
  id: number;
  order_id: string;
  est_shop_id: number;
  user_id: number;
  payment_reference_id: string;
  address_id: number;
  total_price: string;
  payment_method_id: number;
  payment_status: string;
  order_status: string;
  delivery_status: string;
  created_at: string;
  updated_at: string;
  jw_payment_mode: PaymentMode;
  jw_order_items: OrderItem[];
  jw_invoices: InvoiceItem[];
  cancel_button: boolean;
}

interface ApiResponse {
  status: string;
  statusCode: number;
  message: string;
  data: OrderDetails;
}

interface CreateOrderDetailsProps {
  onClose: () => void;
  orderId: number;
}

export default function OrderDetails({
  orderId,
  onClose,
}: CreateOrderDetailsProps) {
  const { addressList } = useGlobalState();
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [ratingLoading, setRatingLoading] = useState<{
    [key: string]: boolean;
  }>({});
  const [error, setError] = useState<string | null>(null);
  // State for star ratings per product
  const [ratings, setRatings] = useState<{ [key: string]: number }>({});
  // State for review texts per product
  const [reviews, setReviews] = useState<{ [key: string]: string }>({});
  // State for cancellation loading
  const [cancelLoading, setCancelLoading] = useState<boolean>(false);

  // Modal state to handle which product's review is being edited along with temporary review text
  const [activeReviewKey, setActiveReviewKey] = useState<string | null>(null);
  const [tempReviewText, setTempReviewText] = useState<string>("");

  const getKey = (productId: number, inventoryId: number) =>
    `${productId}-${inventoryId}`;

  const fetchOrderDetails = async (orderId: number) => {
    setLoading(true);
    try {
      const url = `/api/v1/order/orderDetails?order_id=${orderId}`;
      const response = await api.get<ApiResponse>(url);
      if (response.data && response.data.status === "Success") {
        const data = response.data.data;
        setOrderDetails(data);
        // Initialize both star ratings and review texts from API data
        const initialRatings: { [key: string]: number } = {};
        const initialReviews: { [key: string]: string } = {};
        data.jw_order_items.forEach((item) => {
          const key = getKey(item.product_id, item.inventory_id);
          if (item.jw_product_ratings && item.jw_product_ratings?.length > 0) {
            initialRatings[key] = item.jw_product_ratings[0].product_rating;
            initialReviews[key] = item.jw_product_ratings[0].comment || "";
          } else {
            initialRatings[key] = 0;
            initialReviews[key] = "";
          }
        });
        setRatings(initialRatings);
        setReviews(initialReviews);
      } else {
        setError("Error fetching order details");
        console.error("Error fetching order details", response.data);
      }
    } catch (err) {
      setError("API request failed");
      console.error("API request failed:", err);
    } finally {
      setLoading(false);
    }
  };

  // Check if order is eligible for cancellation (within 8 days from created_at)
  const isOrderCancellable = (createdAt: string): boolean => {
    const orderDate = new Date(createdAt);
    const currentDate = new Date();
    const diffTime = Math.abs(currentDate.getTime() - orderDate.getTime());
    const diffDays = diffTime / (1000 * 3600 * 24);
    console.log(diffDays, "days since order creation");
    return diffDays <= 8;
  };

  // Handle order cancellation
const handleCancelOrder = async () => {
  if (!orderDetails) return;

  await new Promise((resolve) => {
    const toastId = toast(
      <div className="flex flex-col space-y-3 p-4">
        <p className="text-base sm:text-lg font-semibold text-center text-gray-800">
          Are you sure you want to cancel this order?
        </p>
        <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-3">
          <button
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm sm:text-base transition-colors focus:outline-none focus:ring-2 focus:ring-red-400"
            onClick={async () => {
              toast.dismiss(toastId);
              resolve(true);
            }}
          >
            Yes, Cancel
          </button>
          <button
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-md text-sm sm:text-base transition-colors focus:outline-none focus:ring-2 focus:ring-gray-400"
            onClick={() => {
              toast.dismiss(toastId);
              resolve(false);
            }}
          >
            No
          </button>
        </div>
      </div>,
      {
        duration: Infinity,
        className: "w-full max-w-xs sm:max-w-md",
      }
    );
  }).then(async (confirmed) => {
    if (!confirmed) return;

    setCancelLoading(true);

    toast.promise(
      api.post<{ status?: string }>(`/api/v1/order/cancelOrder`, {
        orderId: orderDetails.id,
      }).then((res) => {
        if (res.data?.status === "Success") {
          setOrderDetails({
            ...orderDetails,
            order_status: "Cancelled",
            // delivery_status: "Cancelled",
          });
          return res;
        } else {
          throw new Error("Failed");
        }
      }).finally(() => {
        setCancelLoading(false);
      }),
      {
        loading: "Cancelling order...",
        success: () => "Order cancelled successfully!",
        error: "Failed to cancel order.",
      }
    );
  });
};

  // This function handles both the rating and review text update.
  // It checks for an existing rating and sends a POST (if new) or PATCH (if updating).
  const handleRating = async (
    productId: number,
    inventoryId: number,
    rating: number,
    item: OrderItem,
    comment: string
  ) => {
    const key = getKey(productId, inventoryId);
    // Optimistically update the rating in UI
    setRatings((prev) => ({ ...prev, [key]: rating }));
    setRatingLoading((prev) => ({ ...prev, [key]: true }));
    try {
      const hasExistingRating =
        item.jw_product_ratings && item.jw_product_ratings.length > 0;
      const userId = orderDetails?.user_id;
      if (!userId) {
        console.error("User ID not found");
        return;
      }
      let response;
      if (hasExistingRating || reviews[key]) {
        // Update existing rating/review via PATCH request
        const ratingId = item.jw_product_ratings![0].id;
        const payload = {
          rating: rating,
          reviewId: ratingId,
          comment: comment,
        };
        response = await api.patch(`/api/v1/products/productRating`, payload);
      } else {
        // Create new rating/review via POST request
        const payload = {
          productId: item.product_id,
          inventoryProductId: item.inventory_id,
          rating: rating,
          comment: comment,
        };
        response = await api.post(`/api/v1/products/productRating`, payload);
      }
      if (response && response.data) {
        // Update the local order details with the new rating/review information.
        if (orderDetails) {
          const updatedItems = orderDetails.jw_order_items.map((orderItem) => {
            if (
              orderItem.product_id === productId &&
              orderItem.inventory_id === inventoryId
            ) {
              if (!hasExistingRating) {
                return {
                  ...orderItem,
                  jw_product_ratings: [
                    {
                      id: (response.data as ApiResponse).data.id,
                      product_id: productId,
                      user_id: userId,
                      product_rating: rating,
                      comment: comment,
                      created_at: new Date().toISOString(),
                      updated_at: new Date().toISOString(),
                    },
                  ],
                };
              } else {
                return {
                  ...orderItem,
                  jw_product_ratings: orderItem.jw_product_ratings!.map(
                    (r) => ({
                      ...r,
                      product_rating: rating,
                      comment: comment,
                      updated_at: new Date().toISOString(),
                    })
                  ),
                };
              }
            }
            return orderItem;
          });
          setOrderDetails({
            ...orderDetails,
            jw_order_items: updatedItems,
          });
          // Also update the reviews state with the new review text.
          setReviews((prev) => ({ ...prev, [key]: comment }));
        }
      } else {
        console.error("Error saving rating/review");
      }
    } catch (err) {
      console.error("Failed to save rating/review:", err);
    } finally {
      setRatingLoading((prev) => ({ ...prev, [key]: false }));
    }
  };

  // Called when saving changes from the review dialog.
  const saveReviewChanges = (item: OrderItem) => {
    if (activeReviewKey !== null) {
      const [productId, inventoryId] = activeReviewKey.split("-").map(Number);
      const rating = ratings[activeReviewKey] || 0;
      const reviewText = tempReviewText;
      handleRating(productId, inventoryId, rating, item, reviewText);
      setActiveReviewKey(null);
      setTempReviewText("");
    }
  };

  const handleInvoiceClick = async (invoice: any, item: any, order_id: any) => {
    try {
      if (!invoice) {
        toast.info("Invoice not generated yet!");
        return;
      }

      const blob = await pdf(
        <InvoicePDF invoice={invoice} orderItem={item} orderId={order_id} />
      ).toBlob();
      const blobUrl = URL.createObjectURL(blob);

      window.open(blobUrl, "_blank");

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = `Invoice-${invoice?.id || "document"}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
    } catch (error) {
      console.error("Error generating PDF", error);
      toast.error("Failed to generate invoice PDF!");
    }
  };

  function formatIndianCurrency(num: any) {
    return num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  const handleInvoiceClick1 = async (item: any, order_id: any) => {
    try {
      if (!orderDetails) {
        toast.error("Order details not found!");
        return;
      }

      const firstItem = orderDetails.jw_order_items?.[0];

      if (!firstItem) {
        toast.error("No order items found!");
        return;
      }

      const invoice = orderDetails.jw_invoices?.find(
        (inv) => inv.order_id === Number(firstItem.order_id)
      );

      if (!invoice) {
        toast.info("Invoice not generated yet!");
        return;
      }

      const blob = await pdf(
        <InvoicePDF invoice={invoice} orderItem={item} orderId={order_id} />
      ).toBlob();

      const blobUrl = URL.createObjectURL(blob);

      window.open(blobUrl, "_blank");

      const a = document.createElement("a");
      a.href = blobUrl;
      

      a.download = `Invoice-${invoice?.id || "document"}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
    } catch (error) {
      console.error("Error generating PDF", error);
      toast.error("Failed to generate invoice PDF!");
    }
  };

  function copyToClipboard(text: any) {
    navigator.clipboard.writeText(text).then(() => {
      toast.success("Copied to clipboard!");
    });
  }

  useEffect(() => {
    fetchOrderDetails(orderId);
  }, [orderId]);

  if (error || !orderDetails) {
    return (
      <div className="w-full p-4 flex justify-center text-red-500">{error}</div>
    );
  }

  const totalQuantity = orderDetails.jw_order_items.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  return (
    <div className="w-full p-4 flex flex-col gap-6 border rounded-lg">
      <div className="flex justify-between">
        <span className="font-bold text-lg">
          Order Id: {orderDetails.order_id}
        </span>
        <X size={20} className="cursor-pointer" onClick={onClose} />
      </div>
      <div className="flex flex-col gap-4 w-full">
        {orderDetails?.jw_order_items.map((item, index) => {
          const invoice = orderDetails?.jw_invoices.find(
            (inv) => inv.order_id === Number(item.order_id)
          );
          const key = getKey(item.product_id, item.inventory_id);

          let productImage = "/placeholder.jpg";
          if (item.EstShopInventories?.length) {
            try {
              const images = JSON.parse(item.EstShopInventories[0]?.image_path);
              if (images?.length && images[0]?.src) {
                productImage = images[0].src.startsWith("http")
                  ? images[0].src
                  : `${config.NEXT_PUBLIC_API_URL}/${images[0].src}`;
              }
            } catch (error) {
              console.error("Error parsing image_path:", error);
            }
          }

          return (
            <div
              key={index}
              className="w-full p-3 border border-gray-200 rounded-md flex flex-col"
            >
              <div className="flex justify-between">
                <div className="flex gap-3">
                  <img
                    src={productImage}
                    width={80}
                    height={80}
                    alt={item.ProductMaster.product_name || "Product Image"}
                    className="w-[80px] h-[80px] rounded-xl object-cover"
                  />

                  <div className="flex flex-col justify-center">
                    <span className="font-medium">
                      {item.ProductMaster.product_name}
                    </span>
                    <span className="font-medium">
                      ₹{formatIndianCurrency(Number(item.price))}
                    </span>
                    <span className="text-sm">Qty: {item.quantity}</span>
                  </div>
                </div>

                <div className="flex items-center">
                  <span className="font-bold">
                    ₹{parseFloat(item.price).toLocaleString("en-IN")}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1 mt-2">
                <span className="text-sm font-medium">Rate this product:</span>
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={18}
                    className={`cursor-pointer ${
                      ratingLoading[key] ? "opacity-50" : ""
                    }`}
                    fill={
                      ratings[key] >= star ||
                      (item.jw_product_ratings &&
                        item.jw_product_ratings[0]?.product_rating >= star)
                        ? "#FFD700"
                        : "none"
                    }
                    stroke="#FFD700"
                    onClick={() =>
                      !ratingLoading[key] &&
                      handleRating(
                        item.product_id,
                        item.inventory_id,
                        star,
                        item,
                        reviews[key] || ""
                      )
                    }
                  />
                ))}
                {ratingLoading[key] && (
                  <span className="text-xs text-gray-500 ml-2">Saving...</span>
                )}
              </div>

              <div className="flex justify-between items-center mt-2">
                <button
                  className="text-xs text-blue-500 hover:underline"
                  onClick={() => {
                    setActiveReviewKey(key);
                    setTempReviewText(reviews[key] || "");
                  }}
                >
                  {reviews[key] ? "Edit Review" : "Write Review"}
                </button>

                {orderDetails.jw_order_items?.length > 1 && (
                  <span
                    className="flex items-center gap-1 cursor-pointer hover:underline"
                    onClick={() => handleInvoiceClick(invoice, item, orderDetails?.order_id)}
                  >
                    <HiOutlineDocumentText
                      size={18}
                      color="black"
                      className="text-xs text-gray-700"
                    />
                    Invoice
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <Dialog
        open={activeReviewKey !== null}
        onOpenChange={(open) => {
          if (!open) {
            setActiveReviewKey(null);
            setTempReviewText("");
          }
        }}
      >
        <DialogContent className="rounded-xl border border-[#a05c2c] shadow-lg p-6 bg-white">
          <DialogHeader>
            <DialogTitle className="text-[#6a3a18] text-xl font-bold">Edit Review</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <textarea
              className="border border-[#a05c2c] rounded-md p-3 w-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#a05c2c] focus:border-transparent placeholder:text-gray-400"
              rows={4}
              value={tempReviewText}
              onChange={(e) => setTempReviewText(e.target.value)}
              placeholder="Write your review here..."
            />
          </div>
          <DialogFooter className="mt-4 flex justify-end">
            <button
              className="bg-[#a05c2c] text-white font-medium px-4 py-2 rounded-lg hover:bg-[#6a3a18] transition-colors duration-200"
              onClick={() => {
                if (activeReviewKey !== null) {
                  const [productId, inventoryId] = activeReviewKey.split("-").map(Number);
                  const currentItem = orderDetails.jw_order_items.find(
                    (item) =>
                      Number(item.product_id) === productId &&
                      Number(item.inventory_id) === inventoryId
                  );
                  if (currentItem) {
                    saveReviewChanges(currentItem);
                  }
                }
              }}
            >
              Save Review
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="w-full">
        <div className="font-bold mb-2">Delivery Address</div>
        {addressList?.length > 0 ? (
          (() => {
            const address = addressList.find(
              (addr) => addr.id === orderDetails.address_id
            );

            return address ? (
              <div className="p-4 border border-gray-300 rounded-md bg-gray-50">
                <span className="block font-semibold text-lg text-gray-800">
                  {address.name}
                </span>
                <div className="mt-1 text-gray-700">
                  <p>
                    {address.address_line1}
                    {address.address_line2 && `, ${address.address_line2}`}
                  </p>
                  <p>
                    {address.City.city_name}, {address.State.state_name},{" "}
                    {address.postal_code}
                  </p>
                  <p>{address.Country.country_name}</p>
                  <p className="mt-1 font-medium text-gray-900">
                    📞 +91 {address.contact_no}
                  </p>
                </div>
              </div>
            ) : (
              <div>No address found</div>
            );
          })()
        ) : (
          <div>Loading address...</div>
        )}
      </div>

   <div className="w-full p-4 border border-gray-300 rounded-md bg-gray-50">
        <div className="font-semibold text-lg text-gray-800 mb-2">
          Order Status
        </div>
        <div className="flex items-center gap-2">
          <BaggageClaim size={20} />
          <span
            className={`font-medium ${
              orderDetails.order_status === "Order Confirm"
                ? "text-blue-600"
                : orderDetails.order_status === "Dispatched"
                ? "text-yellow-600"
                : orderDetails.order_status === "In Transit"
                ? "text-orange-600"
                : orderDetails.order_status === "Delivered"
                ? "text-green-600"
                : orderDetails.order_status === "Cancelled"
                ? "text-red-600"
                : "text-gray-600"
            }`}
          >
            {orderDetails.order_status}
          </span>
        </div>
      </div>

      <div className="w-full p-4 border border-gray-300 rounded-md bg-gray-50">
        <div className="font-semibold text-lg text-gray-800 mb-2">
          Delivery Status
        </div>
        <div className="flex items-center gap-2">
          <Car size={20} />
          <span
            className={`font-medium ${
              orderDetails.delivery_status === "Order Confirm"
                ? "text-blue-600"
                : orderDetails.delivery_status === "Dispatched"
                ? "text-yellow-600"
                : orderDetails.delivery_status === "In Transit"
                ? "text-orange-600"
                : orderDetails.delivery_status === "Delivered"
                ? "text-green-600"
                : orderDetails.delivery_status === "Cancelled"
                ? "text-red-600"
                : "text-gray-600"
            }`}
          >
            {orderDetails.delivery_status}
          </span>
        </div>
      </div>

      <div className="w-full p-4 border border-gray-300 rounded-md bg-gray-50">
        <div className="font-semibold text-lg text-gray-800 mb-2">
          Payment Method
        </div>
        <div className="flex items-center gap-2">
          <CreditCard
            size={20}
            color={orderDetails.payment_status === "Paid" ? "green" : "orange"}
          />
          <span className="text-gray-700 font-medium">
            {orderDetails.jw_payment_mode.payment_method}
          </span>
        </div>
        <div className="mt-1 text-sm text-gray-600">
          <span className="font-medium">Status:</span>
          <span
            className={`ml-1 font-semibold ${
              orderDetails.payment_status === "Paid"
                ? "text-green-600"
                : "text-orange-500"
            }`}
          >
            {orderDetails.payment_status}
          </span>
        </div>
        <div className="mt-1 text-sm text-gray-600 flex items-center ">
          <span className="font-medium">Payment Reference ID: </span>
          <span> {" " + orderDetails.payment_reference_id == null ? "" : orderDetails.payment_reference_id}</span>
          {orderDetails.payment_reference_id == null ? "" : <Clipboard
            className="ml-2 mb-1 cursor-pointer text-gray-500 hover:text-black"
            size={15}
            onClick={() => copyToClipboard(orderDetails.payment_reference_id)}
          />}
        </div>
      </div>

      <div className="w-full p-4 border border-gray-300 rounded-md bg-gray-50">
        <div className="font-semibold text-lg text-gray-800 mb-2">
          Order Summary
        </div>

        <div className="w-full flex justify-between text-gray-700">
          <span>Items ({totalQuantity})</span>
          <span className="font-medium">
            ₹{parseFloat(orderDetails.total_price).toLocaleString("en-IN")}
          </span>
        </div>

        <hr className="my-2 border-gray-300" />

        <div className="w-full flex justify-between text-gray-900">
          <span className="font-semibold">Total</span>
          <span className="font-semibold text-lg">
            ₹{parseFloat(orderDetails.total_price).toLocaleString("en-IN")}
          </span>
        </div>
      </div>

  <div className="w-full flex items-center justify-end gap-4 text-sm text-gray-800">
  <span>Need Help</span>

  {orderDetails.jw_order_items?.length === 1 && (
    <span
      className="flex items-center gap-1 cursor-pointer hover:underline text-black"
      onClick={() => {
        handleInvoiceClick1(orderDetails.jw_order_items[0], orderDetails?.order_id);
      }}
    >
      <HiOutlineDocumentText className="text-gray-700" size={18} />
      Invoice
    </span>
  )}

{orderDetails?.cancel_button && (
  orderDetails?.order_status === "Cancelled" ? (
    <button
      disabled
      className="text-sm font-semibold px-4 py-2 rounded-lg bg-red-100 text-red-600 cursor-not-allowed"
    >
      Cancelled
    </button>
  ) : (
    <button
      className={`text-sm font-medium px-4 py-2 rounded-lg ${
        cancelLoading
          ? "bg-gray-400 cursor-not-allowed"
          : "bg-red-500 text-white hover:bg-red-600"
      } transition-colors duration-200`}
      onClick={handleCancelOrder}
      disabled={cancelLoading}
    >
      {cancelLoading ? "Cancelling..." : "Cancel Order"}
    </button>
  )
)}

</div>

    </div>
  );
}