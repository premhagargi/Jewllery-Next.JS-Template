"use client";
import React, { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { useRouter } from "next/navigation";
import "swiper/css";
import { IoDiamondOutline } from "react-icons/io5";
import { PiCertificate, PiShieldCheck } from "react-icons/pi";
import { RiUserStarLine } from "react-icons/ri";
import "swiper/css/pagination";
import "swiper/css/effect-fade";
import { Pagination, Autoplay, EffectFade } from "swiper/modules";
import { Button } from "../ui/button";
import Image from "next/image";
import { useGlobalState } from "@/context/GlobalStateContext";
import Cookies from "js-cookie";
import Style from "../../app/(user)/styles/heroSwiper.module.scss";
import config from "../../../config.json";
import Slide1 from "../../../public/assets/user/slide2.png";
import themeConfig from "../../../theme.config.json";

interface Banner {
  id: number;
  banner_title: string;
  banner_desc: string;
  banner_button_txt: string;
  image_path: string;
  button_redirect_path: string;
}

export default function HeroSwiper() {
  const router = useRouter();
  const { isTokenExpired } = useGlobalState();
  const [slides, setSlides] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);

  // Theme Logic
  const THEME_ID = themeConfig.activeTheme;
  const isLuxury = THEME_ID === "luxury";

  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const token = Cookies.get("token");
        const res = await fetch(
          `${config.NEXT_PUBLIC_API_URL}/api/v1/products/getBannersDashboard?company_id=${config.COMPANY_ID}`,
          {
            headers: {
              Authorization: token || "",
            },
          }
        );

        const result = await res.json();
        if (result.statusCode === 200) {
          const banners = result.data
            .filter((item: any) => item.display_status === true)
            .map((item: any) => {
              const parsedImagePath = JSON.parse(item.image_path || "[]");
              return {
                id: item.id,
                banner_title: item.banner_title,
                banner_desc: item.banner_desc,
                banner_button_txt: item.banner_button_txt || "Shop Now",
                button_redirect_path: item.button_redirect_path || "shop",
                image_path: parsedImagePath[0]?.src
                  ? `${config.NEXT_PUBLIC_API_URL}/${parsedImagePath[0].src}`
                  : "/placeholder-image.jpg",
              };
            });

          setSlides(banners);
        }
      } catch (error) {
        console.error("Error fetching banners:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBanners();
  }, []);

  const handleShopRedirect = (redirectPath: string) => {
    router.push(`/${redirectPath}`);
  };

return (
  <div className="w-full relative">
    <div className={`w-full h-[450px] relative ${Style.heroSwiperContainer}`}>
      {loading ? (
        <div className="relative w-full h-[450px] bg-gray-200 animate-pulse">
          <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white px-4">
            <div className="w-1/2 h-8 bg-gray-400 mb-2 rounded" />
            <div className="w-2/3 h-5 bg-gray-400 mb-2 rounded" />
            <div className="w-28 h-8 bg-gray-400 rounded" />
          </div>
        </div>
      ) : (
        <Swiper
          effect="fade"
          fadeEffect={{ crossFade: true }}
          autoplay={{ delay: 5000, disableOnInteraction: false }}
          pagination={{ dynamicBullets: true, clickable: true }}
          modules={[Pagination, Autoplay, EffectFade]}
          className={`mySwiper w-full h-[450px] ${Style.swiperContainer}`}
        >
          {(slides.length > 0
            ? slides
            : [
                {
                  id: 0,
                  banner_title: "Welcome to Our Store",
                  banner_desc: "Discover top products at amazing prices.",
                  banner_button_txt: "Shop Now",
                  button_redirect_path: "shop",
                  image_path: Slide1.src,
                },
              ]).map((slide, index) => (
            <SwiperSlide key={index} className={`${Style.swiperImageContainer}`}>
              <div className="relative w-full h-[450px]">
                <Image
                  src={slide.image_path}
                  alt="Banner Image"
                  width={1600}
                  height={900}
                  quality={80}
                  loading="lazy"
                  className="w-full h-[450px] object-cover object-center"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 800px"
                />
                <div className="absolute inset-0 bg-black opacity-40 z-10"></div>

                <div
                  className={`absolute inset-0 flex flex-col ${
                    isLuxury
                      ? "items-start text-left justify-start pt-20 px-10"
                      : "items-center text-center justify-center px-3 sm:px-4"
                  } text-white z-20`}
                >
                  <h2
                    className={`drop-shadow-lg mb-1 sm:mb-2 leading-tight ${
                      isLuxury
                        ? "text-[60px] font-normal font-abril"
                        : "text-xl sm:text-2xl md:text-3xl font-bold"
                    }`}
                  >
                    {slide.banner_title}
                  </h2>

                  <p className="max-w-xs sm:max-w-sm md:max-w-md text-xs sm:text-sm md:text-base tracking-wide drop-shadow-md mb-2 sm:mb-3">
                    {slide.banner_desc}
                  </p>

                  <Button
                    onClick={() => handleShopRedirect(slide.button_redirect_path)}
                    className={`transition rounded-full flex items-center justify-center ${
                      isLuxury
                        ? "text-sm font-normal px-10 py-5 bg-white text-black shadow-md hover:bg-neutral-100"
                        : "text-sm sm:text-base font-semibold px-3 sm:px-4 py-1.5 sm:py-2 bg-white text-black hover:bg-neutral-200"
                    }`}
                  >
                    {slide.banner_button_txt}
                  </Button>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      )}
    </div>

    {/* ✅ Feature Highlights Section */}
{isLuxury ? (
  // ✅ Luxury Section
  <div className="w-full bg-[#222222] text-white py-7 mb-10">
    <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-6">
      <div className="flex items-center justify-center gap-2">
        <IoDiamondOutline className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap uppercase">LATEST DESIGNS</span>
      </div>
<div className="hidden lg:block h-10 w-px bg-[#9a602e]"></div>
      <div className="flex items-center justify-center gap-2">
        <PiCertificate className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap uppercase">CERTIFIED GUARANTEE</span>
      </div>
<div className="hidden lg:block h-10 w-px bg-[#9a602e]"></div>
      <div className="flex items-center justify-center gap-2">
        <PiShieldCheck className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap uppercase">925 FINE SILVER</span>
      </div>
<div className="hidden lg:block h-10 w-px bg-[#9a602e]"></div>
      <div className="flex items-center justify-center gap-2">
        <RiUserStarLine className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap uppercase">99% POSITIVE RESPONSE</span>
      </div>
    </div>
  </div>
) : (
  // ✅ Basic Section
  <div className="w-full max-w-6xl mx-auto text-xs md:text-sm px-4 mb-8 py-10">
    <div className="grid grid-cols-2 lg:flex lg:justify-center lg:gap-8 gap-6 items-center text-center">
      <div className="flex items-center justify-center gap-2">
        <IoDiamondOutline className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap">LATEST DESIGNS</span>
      </div>
      <div className="flex items-center justify-center gap-2">
        <PiCertificate className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap">CERTIFIED GUARANTEE</span>
      </div>
      <div className="flex items-center justify-center gap-2">
        <PiShieldCheck className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap">925 FINE SILVER</span>
      </div>
      <div className="flex items-center justify-center gap-2">
        <RiUserStarLine className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
        <span className="whitespace-nowrap">99% POSITIVE RESPONSE</span>
      </div>
    </div>
  </div>
)}

  </div>
);

}
