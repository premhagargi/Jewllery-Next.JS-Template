import Image from "next/image";

// assets
import BannerImage from "../../../public/assets/user/banner.png";
import { Button } from "../ui/button";
import Link from "next/link";

export default function Banner() {
  return (
    <div className="w-[95%] h-[400px] mx-auto relative my-10">
      <Image
        src={BannerImage}
        width={1000}
        height={1000}
        quality={100}
        alt=""
        loading="lazy"
        className="w-full h-full object-cover"
      />
      <div className="absolute top-0 w-full h-full flex flex-col justify-center items-center">
        <p className="text-white text-3xl tracking-wider mb-4">
          Shop By Category
        </p>
        <Link href="/shop">
      <Button className="bg-[#ccb162] rounded-sm">Discover Now</Button>
    </Link>      </div>
    </div>
  );
}
