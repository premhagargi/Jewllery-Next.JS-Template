/* eslint-disable @next/next/no-img-element */
import React, { useState } from "react";
import { toast } from "sonner";
import Image from "next/image";
import { Button } from "../ui/button";
import { api } from "../../../utils/api";
import { FaTrashAlt } from "react-icons/fa";
import { useRouter } from "next/navigation";
import { useGlobalState } from "@/context/GlobalStateContext";
import "../../app/(user)/product/page.css";
import dummyImage from "../../../public/assets/user/product-placeholder.jpg";
import Cookies from "js-cookie";
import config from "../../../config.json";

// Define the type for the product prop
interface Product {
  id: string;
  user_id: string;
  est_shop_id: string;
  product_id: string;
  is_deleted: boolean;
  createdAt: string;
  updatedAt: string;
  AddToCarts: {
    id: number;
    user_id: number;
    product_id: string;
    est_shop_id: string;
    quantity: number;
    createdAt: string;
    updatedAt: string;
  }[];
  ProductMaster: {
    product_name: string;
    product_desc: string;
  };
  EstShopInventory: {
    ProductMaster: any;
    quantity: string;
    exp_sellprice_aft: string;
    exp_onlinesellprice_aft: string;
    exp_onlinesellprice_bft: string;
    offer_price: string;
    last_purprice_aft: string;
    image_path?: string; // Added image_path to the type
  };
  ProductImage: {
    image_id: string;
    product_image: string;
  } | null;
}

interface JewelleryCardProps {
  product: Product;
  onRemoveFromWishlist: (productId: string, shopId: string) => void;
}

export default function JewelleryWishlistCard({
  product,
  onRemoveFromWishlist,
}: JewelleryCardProps) {
  const {
    id,
    product_id,
    est_shop_id,
    AddToCarts,
    ProductMaster,
    ProductImage,
    EstShopInventory,
  } = product;

  const router = useRouter();
  const [isShaking, setIsShaking] = useState(false);
  const { isTokenExpired, fetchData } = useGlobalState();
  const product_name = EstShopInventory?.ProductMaster?.product_name;
  const product_desc = EstShopInventory?.ProductMaster.product_desc;
  const price =
    parseFloat(EstShopInventory.offer_price) > 0
      ? parseFloat(EstShopInventory.offer_price)
      : parseFloat(EstShopInventory.exp_onlinesellprice_aft) > 0
      ? parseFloat(EstShopInventory.exp_onlinesellprice_aft)
      : parseFloat(EstShopInventory.exp_onlinesellprice_bft) || 0;

  const quantityInInventory = parseInt(EstShopInventory.quantity, 10);
  const quantityInCart =
    AddToCarts?.length > 0 ? AddToCarts[0]?.quantity ?? 0 : 0;

  const [addedToCart, setIsInCart] = useState<boolean>(quantityInCart > 0);
  const [loading, setLoading] = useState<boolean>(false);

  function formatIndianCurrency(num: any) {
    return num.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  const getImagePath = (estShopInventory: Product["EstShopInventory"]) => {
    try {
      const rawPath = estShopInventory?.image_path;
      if (!rawPath) return dummyImage.src;
      const parsedImages = JSON.parse(rawPath);
      return Array.isArray(parsedImages) && parsedImages[0]?.src
        ? `${config.NEXT_PUBLIC_API_URL}/${parsedImages[0].src}`
        : dummyImage.src;
    } catch (error) {
      console.error("Error parsing image_path:", error);
      return dummyImage.src;
    }
  };

  const handleAddToCart = async () => {
    setIsShaking(true);
    if (addedToCart) {
      window.location.href = "/cart";
      return;
    }

    try {
      setLoading(true);
      const response = await api.post("/api/v1/cart/addtocart", {
        product_id,
        quantity: 1,
        est_shop_id,
      });

      setTimeout(() => {
        setIsShaking(false);
        if (response.status === 200) {
          toast.success("🛒 Product has been added to cart!");
          setIsInCart(true);
          fetchData("cart");
        }
      }, 300);
    } catch (err) {
      console.error("Failed to add product to cart:", err);
      alert(
        "An error occurred while adding the product to your cart. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const encodeParam = (param: string): string => {
    try {
      return encodeURIComponent(btoa(param));
    } catch (error) {
      console.error("Error encoding parameter:", error);
      return "";
    }
  };

  const handleClick = () => {
    const encodedProductId = encodeParam(product_id);
    const encodedShopId = encodeParam(est_shop_id);
    router.push(`/product?id=${encodedProductId}&shopId=${encodedShopId}`);
  };

  const handleRemoveFromWishlist = async () => {
    try {
      setLoading(true);
      const response = await api.delete(
        `/api/v1/products/removefromwishlist?product_id=${product_id}&est_shop_id=${est_shop_id}`
      );

      if (response.status === 200) {
        toast.success("Product has been removed from wishlist!");
        onRemoveFromWishlist(product_id, est_shop_id);
      }
    } catch (err) {
      console.error("Failed to remove product from wishlist:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
  onClick={handleClick}
  className="w-[200px] h-[273px] p-3 rounded-lg mb-10 mx-3 cursor-pointer animate-fadeIn"
  style={{ boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px" }}
>
      <div className="relative h-[60%]">
        <button
          onClick={(event) => {
            event.stopPropagation();
            handleRemoveFromWishlist();
          }}
          className="absolute top-2 right-2 text-white hover:text-gray-300"
          disabled={loading}
        >
          <FaTrashAlt size={16} />
        </button>

        <img
          src={getImagePath(EstShopInventory)}
          width={1000}
          height={1000}
          alt={product_name}
          loading="lazy"
          className="rounded-lg w-full h-[95%] object-cover mb-2 transition-opacity duration-500"
          onError={(e) => {
            e.currentTarget.src = dummyImage.src;
          }}
        />
      </div>

      <div className="w-full h-[60%] text-center text-sm">
        <p className="font-bold mb-1">
          {product_name
            .split(" ")
            .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ")}
        </p>
        <p>
          ₹
          <span
            className={`font-bold ${
              isNaN(price) || price === null || price === undefined
                ? "text-gray-500"
                : ""
            }`}
          >
            {isNaN(price) || price === null || price === undefined
              ? " --"
              : formatIndianCurrency(price)}
          </span>
        </p>

        {quantityInInventory === 0 ? (
          <Button
            className="w-full mt-1 bg-[#6a3a18] hover:bg-[#6a3a18] border cursor-not-allowed"
            disabled
          >
            Out of Stock
          </Button>
        ) : (
          <Button
            className={`w-full mt-1 ${
              isShaking && !addedToCart ? "shake" : ""
            } ${
              addedToCart
                ? "bg-green-500 hover:bg-green-600"
                : "bg-[#6a3a18] hover:bg-[#6a3a18]"
            }`}
            onClick={(event) => {
              event.stopPropagation();

              const token = Cookies.get("token");

              if (!token || isTokenExpired(token)) {
                event.preventDefault();
                localStorage.setItem(
                  "redirectAfterLogin",
                  window.location.href
                );
                toast("Please log in to add items to your cart", {
                  duration: 3000,
                  position: "top-center",
                  icon: "🛒",
                });
                router.push("/login");
                return;
              }

              handleAddToCart();
            }}
            disabled={loading}
          >
            {loading ? "" : addedToCart ? "Go to Cart" : "Add to Cart"}
          </Button>
        )}

        {/* {quantityInInventory <= 5 && quantityInInventory > 0 ? (
          <p className="text-[0.7rem] text-red-500 mt-1 font-semibold">
            Few left in stock!
          </p>
        ) : null} */}
      </div>
    </div>
  );
}