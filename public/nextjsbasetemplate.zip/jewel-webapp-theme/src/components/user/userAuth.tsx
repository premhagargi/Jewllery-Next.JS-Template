

// components/UserAuth.tsx
"use client";
import React, { useEffect } from "react";
import { PiUserLight } from "react-icons/pi";
import Link from "next/link";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Cookies from "js-cookie";
import { useGlobalState } from "@/context/GlobalStateContext";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function UserAuth() {
  const router = useRouter();
  const { isLoggedIn, checkLoggedIn, isTokenExpired } = useGlobalState();

  const handleLogout = () => {
    try {
      console.log('logout');
      Cookies.remove("token", { path: "/" });
      localStorage.clear();
      checkLoggedIn();
      toast.success("Logged out successfully");
      router.push("/login");
    } catch (error) {
      console.error("Logout error:", error);
      toast.error("Failed to log out");
    }
  };

  useEffect(() => {
    checkLoggedIn(); // Check token on mount
  }, [checkLoggedIn]);

  return (
    <div className="">
      {isLoggedIn ? (
        <DropdownMenu>
          <DropdownMenuTrigger>
            <PiUserLight size={20} className="text-black" />
          </DropdownMenuTrigger>
          <DropdownMenuContent className="mt-2 p-2">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <Link
              href={"/profile"}
              onClick={(e) => {
                const token = Cookies.get("token");
                if (!token || isTokenExpired(token)) {
                  e.preventDefault();
                  localStorage.setItem("redirectAfterLogin", window.location.href);
                  toast("Please log in to view your profile", {
                    duration: 3000,
                    position: "top-center",
                  });
                  router.push("/login");
                }
              }}
            >
              <DropdownMenuItem>Profile</DropdownMenuItem>
            </Link>
            <Link
              href={"/orders"}
              onClick={(e) => {
                const token = Cookies.get("token");
                if (!token || isTokenExpired(token)) {
                  e.preventDefault();
                  localStorage.setItem("redirectAfterLogin", window.location.href);
                  toast("Please log in to view your orders", {
                    duration: 3000,
                    position: "top-center",
                  });
                  router.push("/login");
                }
              }}
            >
              <DropdownMenuItem>Orders</DropdownMenuItem>
            </Link>
            <DropdownMenuItem asChild>
  <Link href="/login" onClick={handleLogout}>
    Logout
  </Link>
</DropdownMenuItem>          </DropdownMenuContent>
        </DropdownMenu>
      ) : (
        <DropdownMenu>
          <DropdownMenuTrigger>
            <PiUserLight size={20} className="text-black" />
          </DropdownMenuTrigger>
          <DropdownMenuContent className="mt-2">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <Link href={"/login"}>
              <DropdownMenuItem>Login/SignUp</DropdownMenuItem>
            </Link>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
}