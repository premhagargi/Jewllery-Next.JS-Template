/* eslint-disable react-hooks/exhaustive-deps */

"use client";

import React, { useEffect } from "react";
import Link from "next/link";
import { GoHeart } from "react-icons/go";
import { SlHandbag } from "react-icons/sl";
import { IoSearchOutline } from "react-icons/io5";
import { toast } from "sonner";   
import { useRouter } from "next/navigation";
import ThemeSwitcher from "../../components/ui/ThemeSwitcher";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import UserAuth from "./userAuth";
import Cookies from "js-cookie";
import { useGlobalState } from "@/context/GlobalStateContext";
import Image from "next/image";
import style from "../../app/(user)/styles/navbar.module.scss";
// import UserAuth from "./userAuth";
import webLogo from "../../../public/assets/user/icons/Union1.png";

export default function Navbar() {
  const { cartData, wishlistData, isTokenExpired, checkLoggedIn, fetchData, cmpLogo, loading } = useGlobalState();
  const router = useRouter();

  useEffect(() => {

    checkLoggedIn(); // Check token on mount
    const isCartEmpty = !cartData?.totalProducts;
    const isWishlistEmpty = !wishlistData?.totalProducts;

    if (isCartEmpty && isWishlistEmpty) {
      fetchData("cart");
       fetchData("wishlist") // Fetch data once
    }

    const currentDomain = window.location.hostname;
    const savedDomain = sessionStorage.getItem("domain");


    if (!sessionStorage.getItem("cmp_logo") || savedDomain !== currentDomain) {
      // fetchCompanyDetail();
      sessionStorage.setItem("domain", currentDomain); // update after fetch
    }

  }, []);

  return (
    <div className={`w-full h-[90px] flex justify-center items-center justify-between px-14 ${style.navbarContainer}`}>
      <Link href="/">
        <h1 className="font-extrabold text-[1.4rem]">
          {/* {loading ? (
            <div className="w-[270px] h-[30px] bg-gray-300 animate-pulse rounded" />
          ) : cmpLogo ? (
            <Image
              src={cmpLogo}
              width={270}
              height={30}
              quality={100}
              alt="Company Logo"
              loading="lazy"
              className="inline-block mx-2 w-[270px] h-[40px] mb-1 border-none"
            />
          ) : null} */}
             
                 <Image
              src={webLogo}
              width={270}
              height={30}
              quality={100}
              alt="Company Logo"
              loading="lazy"
              className="inline-block mx-2 w-[270px] h-[40px] mb-1 border-none"
            />
        </h1>
      </Link>
      <div className="flex gap-4 items-center">
              <div className="px-2">
                {/* <ThemeSwitcher /> */}
              </div>
        <Link href="">
          <IoSearchOutline size={20} />
        </Link>
        <Link href="" className="mt-2">
          <UserAuth />
        </Link>
        <div className="relative">
          <Link
            href="/wishlist"
            onClick={(e) => {
              const token = document.cookie.split("; ").find(row => row.startsWith("token="))?.split("=")[1];
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem("redirectAfterLogin", window.location.href);
                toast("Please log in to view your wishlist", {
                  duration: 3000,
                  position: "top-center",
                  icon: "❤️",
                });
                router.push("/login");
              }
            }}
          >
            <GoHeart size={18} />
          </Link>
          <div className="absolute top-[-20px] right-[-9px] w-[20px] h-[20px] text-[9px] bg-[#9a602e] text-white rounded-full grid place-items-center">
            {wishlistData.totalProducts || 0}
          </div>
        </div>
        <div className="relative">
          <Link
            href="/cart"
            onClick={(e) => {
              const token = document.cookie.split("; ").find(row => row.startsWith("token="))?.split("=")[1];
              if (!token || isTokenExpired(token)) {
                e.preventDefault();
                localStorage.setItem("redirectAfterLogin", window.location.href);
                toast("Please log in to view your cart", {
                  duration: 3000,
                  position: "top-center",
                  icon: "🛒",
                });
                router.push("/login");
              }
            }}
          >
            <SlHandbag size={18} />
          </Link>
          <div className="absolute top-[-20px] right-[-9px] w-[20px] h-[20px] text-[9px] bg-[#9a602e] text-white rounded-full grid place-items-center">
            {cartData.totalProducts || 0}
          </div>
        </div>
      </div>
    </div>
  );
}