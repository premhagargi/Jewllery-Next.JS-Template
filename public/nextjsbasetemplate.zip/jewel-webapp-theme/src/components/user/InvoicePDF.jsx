import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer";
import { Font } from "@react-pdf/renderer";
Font.register({
  family: "NotoSans",
  src: "https://fonts.gstatic.com/s/notosans/v27/o-0IIpQlx3QUlC5A4PNb4j5Ba_2c7A.ttf",
});

// Create styles for the PDF
const styles = StyleSheet.create({
  text: {
    fontFamily: "NotoSans",
  },
  page: {
    padding: 30,
    fontSize: 9,
    fontFamily: 'Helvetica',
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 5,
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
  },
  billtosection: {
    border: "1pt solid #000",
    backgroundColor: "#D9D9D9",
    padding: 6.5,
  },
  billtotext: {
    fontWeight: "bold",
  },
  infoSection: {
    border: '1pt solid #000',
    borderBottom: 'none',
    height: 70,
  },
  infoRow: {
    flexDirection: "row",
    borderBottom: "0pt solid #000",
  },
  infoLeftColumn: {
    width: "50%",
    padding: "5",
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  infoRightColumn: {
    padding: "5",
    width: "50%",
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  infoItem: {
    flexDirection: "row",
    marginBottom: 9,
  },
  infoLabel: {
    width: 120,
  },
  infoValue: {
    flex: 1,
  },
  addressSection: {
    border: "1pt solid #000",
    borderTop: "none",
    borderBottom: "none",
    paddingVertical: 8,
    height: 55,
    paddingHorizontal: 7,
  },
  addressSection1: {
    border: "1pt solid #000",
    borderTop: "none",
    borderBottom: "none",
    paddingVertical: 8,
    height: 80,
    paddingHorizontal: 7,
  },
  addressTitle: {
    borderBottom: "1pt solid #000",
    backgroundColor: "#D9D9D9",
    padding: 5,
    marginBottom: 5,
  },
  addressName: {
    fontWeight: "bold",
    marginBottom: 6,
  },
  addressName1: {
    marginBottom: 6,
  },
  tableContainer: {
    border: "1pt solid #000",
    borderBottom: "none",
    borderTop: "1pt solid #000",
  },
  tableHeader: {
    flexDirection: "row",
    borderBottom: "1pt solid #000",
    backgroundColor: "#f0f0f0",
    height: 30,
  },
  tableRow: {
    flexDirection: "row",
    borderBottom: "none",
    height: 130,
  },
  numberCol: {
    width: "5%",
    borderRight: "1pt solid #000",
    paddingVertical: 3,
    textAlign: "center",
  },
  descriptionCol: {
    width: "22%",
    borderRight: "1pt solid #000",
    paddingHorizontal: 3,
  },
  quantityCol: {
    width: "5%",
    borderRight: "1pt solid #000",
    paddingVertical: 3,
    textAlign: "center",
  },
  priceCol: {
    width: "10%",
    borderRight: "1pt solid #000",
    paddingVertical: 3,
    textAlign: "center",
    paddingHorizontal: 3,
  },
  amountCol: {
    width: "10%",
    paddingVertical: 3,
    paddingHorizontal: 3,
    textAlign: 'right',
  },
  totalsSection: {
    flexDirection: "row",
    height: 120,
    border: "1pt solid #000",
  },
  signatureSection: {
    width: "50%",
    padding: 8,
    borderRight: "1pt solid #000",
  },
  signatureName: {
    marginBottom: 0,
    fontSize: 12,
    fontWeight: 'thin'
  },
  signature: {
    marginTop: 1.5,
    marginBottom: 5,
    fontSize: 12,
    fontWeight: 'bold',
    fontStyle: "italic"
  },
  signatureTitle: {
    marginTop: 50,
    fontWeight: 'thin',
    fontSize: 12,
  },
  totalDetails: {
    width: "50%",
    padding: 8,
  },
  totalRow: {
    flexDirection: "row",
    borderBottom: "none",
    paddingVertical: 5,
    marginBottom: 5,
  },
  totalLabel: {
    width: "60%",
    paddingLeft: 5,
  },
  totalValue: {
    width: "40%",
    textAlign: "right",
    paddingRight: 5,
  },
  notesSection: {
    padding: 7,
    border: "1pt solid #000",
    borderTop: "none",
    minHeight: 30,
  },
  notesTitle: {
    fontWeight: "bold",
    marginBottom: 5,
    fontSize: 10
  },
  footer: {
    marginTop: 10,
    fontSize: 10,
    fontWeight: "thin",
    textAlign: "left",
  },
  boldText: {
    fontWeight: "bold",
  },
  subText: {
    fontSize: 9,
    color: 'black',
  },
  spacing: {
    marginTop: 5,
  },
});

function numberToWords(num) {
  const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
  const teens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
  const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
  const thousands = ['', 'thousand', 'million', 'billion'];

  if (num === 0) return 'zero';

  let result = '';
  let i = 0;
  while (num > 0) {
    if (num % 1000 !== 0) {
      result = helper(num % 1000) + ' ' + thousands[i] + ' ' + result;
    }
    num = Math.floor(num / 1000);
    i++;
  }

  return result.trim();

  function helper(num) {
    if (num === 0) return '';
    if (num < 10) return ones[num];
    if (num < 20) return teens[num - 10];
    if (num < 100) return tens[Math.floor(num / 10)] + (num % 10 === 0 ? '' : ' ' + ones[num % 10]);
    return ones[Math.floor(num / 100)] + ' hundred' + (num % 100 === 0 ? '' : ' ' + helper(num % 100));
  }
}

// Helper function to safely access nested properties
const safeGet = (obj, path, fallback = '') => {
  try {
    return path.split('.').reduce((o, key) => (o || {})[key], obj) || fallback;
  } catch (e) {
    return fallback;
  }
};

const InvoicePDF = ({ invoice = {}, orderItem = {}, orderId = {} }) => {
  // Extract shop and customer details
  const shopName = safeGet(invoice, 'mi_shop_est.est_shop_name', 'Shop');
  const shopAddress = [
    safeGet(invoice, 'mi_shop_est.address1', ''),
    safeGet(invoice, 'mi_shop_est.address2', '')
  ].filter(Boolean).join(", ");
  const shopCity = safeGet(invoice, 'mi_shop_est.City.city_name', 'ShopCity');
  const shopState = safeGet(invoice, 'mi_shop_est.State.state_name', 'ShopState');
  const shopCountry = safeGet(invoice, 'mi_shop_est.Country.country_name', 'ShopCountry');
  const shopPincode = safeGet(invoice, 'mi_shop_est.pincode', 'ShopPincode');
  const shopGst = safeGet(invoice, 'mi_shop_est.shop_gst', 'ShopGst');
  const shopPhoneNumber = safeGet(invoice, 'mi_shop_est.est_shop_phone', 'ShopGst');
  const stateName = safeGet(invoice, 'jw_customer_address.State.state_name', '');

  // Calculate tax amounts, taxable amount, and store tax rates
  const taxCalculations = (invoice?.jw_invoice_items ?? []).reduce(
    (acc, item) => {
      const totalPrice = parseFloat(item?.total_price ?? 0); // Tax-inclusive
      const quantity = parseFloat(item?.quantity ?? 1);
      // Get base tax rates
      const cgstRate =
        parseFloat(item?.tax_cgst ?? '') ||
        parseFloat(item?.ProductMaster?.TaxRate?.tax_cgst ?? 0);
      const sgstRate =
        parseFloat(item?.tax_sgst ?? '') ||
        parseFloat(item?.ProductMaster?.TaxRate?.tax_sgst ?? 0);
      const igstRate =
        parseFloat(item?.tax_igst ?? '') ||
        parseFloat(item?.ProductMaster?.TaxRate?.tax_igst ?? 0);

      // Determine if transaction is intra-state or inter-state
      const isIntraState = shopState === stateName && shopState && stateName;
      console.log(`Shop State: ${shopState}, Customer State: ${stateName}, Is Intra-State: ${isIntraState}`);
      // Apply appropriate tax rates
      const appliedCgstRate = isIntraState ? cgstRate : 0;
      const appliedSgstRate = isIntraState ? sgstRate : 0;
      const appliedIgstRate = isIntraState ? 0 : igstRate;

      // Calculate taxable price and tax amounts
      const totalTaxRate = isIntraState ? (cgstRate + sgstRate) / 100 : igstRate / 100;
      const taxablePrice = totalPrice / (1 + totalTaxRate); // Tax-exclusive
      const cgstAmount = isIntraState ? taxablePrice * (cgstRate / 100) : 0;
      const sgstAmount = isIntraState ? taxablePrice * (sgstRate / 100) : 0;
      const igstAmount = isIntraState ? 0 : taxablePrice * (igstRate / 100);

      return {
        totalTaxableAmount: acc.totalTaxableAmount + taxablePrice,
        totalCgstAmount: acc.totalCgstAmount + cgstAmount,
        totalSgstAmount: acc.totalSgstAmount + sgstAmount,
        totalIgstAmount: acc.totalIgstAmount + igstAmount,
        totalAmount: acc.totalAmount + totalPrice, // Tax-inclusive total
        cgstRate: appliedCgstRate,
        sgstRate: appliedSgstRate,
        igstRate: appliedIgstRate,
      };
    },
    {
      totalTaxableAmount: 0,
      totalCgstAmount: 0,
      totalSgstAmount: 0,
      totalIgstAmount: 0,
      totalAmount: 0,
      cgstRate: 0,
      sgstRate: 0,
      igstRate: 0,
    }
  );

  const {
    totalTaxableAmount,
    totalCgstAmount,
    totalSgstAmount,
    totalIgstAmount,
    totalAmount,
    cgstRate,
    sgstRate,
    igstRate,
  } = taxCalculations;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>TAX INVOICE</Text>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <View style={styles.infoLeftColumn}>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Invoice Number</Text>
                <Text style={styles.infoValue}>: {invoice?.invoice_no ?? "N/A"}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Order Number</Text>
                <Text style={styles.infoValue}>: {orderId ?? "N/A"}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Place of Supply</Text>
                <Text style={styles.infoValue}>
                  : {invoice?.jw_customer_address?.State?.state_name ?? "N/A"}
                </Text>
              </View>
            </View>
            <View style={styles.infoRightColumn}>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Invoice Date</Text>
                <Text style={styles.infoValue}>
                  :{" "}
                  {invoice?.createdAt
                    ? new Date(invoice.createdAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })
                    : "N/A"}
                </Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Order Date</Text>
                <Text style={styles.infoValue}>
                  :{" "}
                  {invoice?.createdAt
                    ? new Date(invoice.createdAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })
                    : "N/A"}
                </Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Nature of Supply</Text>
                <Text style={styles.infoValue}>: E-commerce</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.billtosection}>
          <Text style={styles.billtotext}>Bill To / Ship To</Text>
        </View>

        <View style={styles.addressSection}>
          <Text style={styles.addressName}>
            {invoice?.jw_customer_address?.name ?? "N/A"}
          </Text>
          <Text style={styles.addressName1}>
            {[
              invoice?.jw_customer_address?.address_line1,
              invoice?.jw_customer_address?.address_line2,
              invoice?.jw_customer_address?.City?.city_name,
              invoice?.jw_customer_address?.State?.state_name,
              invoice?.jw_customer_address?.Country?.country_name,
              invoice?.jw_customer_address?.postal_code,
            ]
              .filter(Boolean)
              .join(", ") || "N/A"}
          </Text>
          <Text>{invoice?.jw_customer_address?.contact_no ? `+91 ${invoice.jw_customer_address.contact_no}` : "N/A"}</Text>
        </View>

        <View style={styles.billtosection}>
          <Text style={styles.billtotext}>Bill From / Ship From</Text>
        </View>

        <View style={styles.addressSection1}>
          <Text style={[styles.addressName1, { marginBottom: 8 }]}>
            <Text style={{ fontWeight: 'bold' }}>Shop: </Text>
            {shopName
              .split(' ')
              .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
              .join(' ')}
          </Text>
          <Text style={[styles.addressName1, { marginBottom: 8 }]}>
            <Text style={{ fontWeight: 'bold' }}>Address: </Text>
            {[
              shopAddress
                .split(' ')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(' '),
              shopCity,
              shopState,
              shopCountry
            ]
              .filter(Boolean)
              .join(', ') + (shopPincode ? ` - ${shopPincode}` : '')}
          </Text>
          {shopPhoneNumber ? (
            <Text style={[styles.addressName1, { marginBottom: 8 }]}>
              <Text style={{ fontWeight: 'bold' }}>Contact No: </Text>
              +91 {shopPhoneNumber}
            </Text>
          ) : null}
          {shopGst ? (
            <Text style={[styles.addressName1, { marginBottom: 8 }]}>
              <Text style={{ fontWeight: 'bold' }}>GSTIN: </Text>
              {shopGst}
            </Text>
          ) : null}
        </View>

        <View style={styles.tableContainer}>
          <View style={styles.tableHeader}>
            <Text style={styles.numberCol}>#</Text>
            <Text style={styles.descriptionCol}>Item & Description</Text>
            <Text style={styles.quantityCol}>Qty.</Text>
            <Text style={styles.priceCol}>Gross Weight(gm)</Text>
            <Text style={styles.priceCol}>Net Weight(gm)</Text>
            <Text style={styles.priceCol}>Stone Weight(gm)</Text>
            <Text style={styles.priceCol}>Stone Price</Text>
            <Text style={styles.priceCol}>Rate</Text>
            <Text style={styles.priceCol}>Making Charges</Text>
            <Text style={styles.amountCol}>Amount</Text>
          </View>

          {(invoice?.jw_invoice_items ?? []).map((item, index) => {
            const product = item?.ProductMaster ?? {};
            const totalPrice = parseFloat(item?.total_price ?? 0); // Tax-inclusive
            const quantity = parseFloat(item?.quantity ?? 1);
            // Get base tax rates
            const cgstRate =
              parseFloat(item?.tax_cgst ?? '') ||
              parseFloat(item?.ProductMaster?.TaxRate?.tax_cgst ?? 0);
            const sgstRate =
              parseFloat(item?.tax_sgst ?? '') ||
              parseFloat(item?.ProductMaster?.TaxRate?.tax_sgst ?? 0);
            const igstRate =
              parseFloat(item?.tax_igst ?? '') ||
              parseFloat(item?.ProductMaster?.TaxRate?.tax_igst ?? 0);
            // Determine if transaction is intra-state or inter-state
            const isIntraState = shopState === stateName && shopState && stateName;
            // Apply appropriate tax rates
            const appliedCgstRate = isIntraState ? cgstRate : 0;
            const appliedSgstRate = isIntraState ? sgstRate : 0;
            const appliedIgstRate = isIntraState ? 0 : igstRate;
            // Calculate taxable price and tax amounts
            const totalTaxRate = isIntraState ? (cgstRate + sgstRate) / 100 : igstRate / 100;
            const taxablePrice = totalPrice / (1 + totalTaxRate); // Tax-exclusive
            const unitPrice = taxablePrice / quantity;
            const cgstAmount = isIntraState ? taxablePrice * (cgstRate / 100) : 0;
            const sgstAmount = isIntraState ? taxablePrice * (sgstRate / 100) : 0;
            const igstAmount = isIntraState ? 0 : taxablePrice * (igstRate / 100);
            const estShopInventories = orderItem?.EstShopInventories?.[0] ?? {};
            const grossWeight = estShopInventories?.weight ?? 0;
            const netWeight = estShopInventories?.netweight ?? 0;
            const stoneWeight = estShopInventories?.stone_weight ?? 0;
            const makingCharges = parseFloat(estShopInventories?.making_charges ?? 0);
            const stonePrice = parseFloat(estShopInventories?.stone_price ?? 0) || 0;
            const totalTaxableAmount = taxablePrice + makingCharges + stonePrice;

            return (
              <View key={item?.id ?? index} style={styles.tableRow}>
                <Text style={styles.numberCol}>{index + 1}</Text>
                <View style={styles.descriptionCol}>
                  <Text>
                    {(product?.product_name ?? "N/A")
                      .toLowerCase()
                      .replace(/\b\w/g, char => char.toUpperCase())}
                  </Text>
                  <Text style={[styles.subText, styles.spacing]}>
                    <Text style={styles.boldText}>HSN Code:</Text>{" "}
                    {product?.Hsn?.hsn_code ?? "N/A"}
                  </Text>
                  {Number(estShopInventories?.carat_value) > 0 ? (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Carat Value:</Text>{" "}
                      {estShopInventories.carat_value}
                    </Text>
                  ) : (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Purity:</Text>{" "}
                      {(() => {
                        const raw = Number(estShopInventories?.purity);
                        if (Number.isNaN(raw)) return "N/A"; // safety guard
                        if (raw % 1 === 0) return raw.toFixed(0);
                        const truncated = Math.trunc(raw * 10) / 10;
                        return truncated.toFixed(1);
                      })()}
                    </Text>
                  )}
                  {parseFloat(estShopInventories?.stone_weight ?? 0) > 0 && (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Stone Weight:</Text>{" "}
                      {estShopInventories?.stone_weight ?? "N/A"}
                    </Text>
                  )}
                  {parseFloat(estShopInventories?.stone_price ?? 0) > 0 && (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Stone Price:</Text>{" "}
                      {parseFloat(estShopInventories?.stone_price ?? 0).toFixed(2)}
                    </Text>
                  )}
                </View>
                <Text style={styles.quantityCol}>{item?.quantity ?? 0}</Text>
                <Text style={styles.priceCol}>{grossWeight}</Text>
                <Text style={styles.priceCol}>{netWeight}</Text>
                <Text style={styles.priceCol}>{stoneWeight}</Text>
                <Text style={styles.priceCol}>Rs. {stonePrice.toFixed(2)}</Text>
                <Text style={styles.priceCol}>Rs. {unitPrice.toFixed(2)}</Text>
                <Text style={styles.priceCol}>Rs. {makingCharges.toFixed(2)}</Text>
                <Text style={styles.amountCol}>Rs. {totalTaxableAmount.toFixed(2)}</Text>
              </View>
            );
          })}
        </View>

        <View style={styles.totalsSection}>
          <View style={styles.signatureSection}>
            <Text style={styles.signatureName}>Total in Words: </Text>
            <Text style={styles.signature}>
              {numberToWords(Math.floor(totalAmount))
                .toLowerCase()
                .replace(/\b\w/g, c => c.toUpperCase())} Rupees
              {totalAmount % 1 !== 0 &&
                ` And ${numberToWords(Math.round((totalAmount % 1) * 100))
                  .toLowerCase()
                  .replace(/\b\w/g, c => c.toUpperCase())} Paise`} Only
            </Text>
            <Text style={styles.signatureTitle}>Authorized Signatory</Text>
          </View>
          <View style={styles.totalDetails}>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Sub Total</Text>
              <Text style={styles.totalValue}>Rs. {totalTaxableAmount.toFixed(2)}</Text>
            </View>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total Taxable Amount</Text>
              <Text style={styles.totalValue}>Rs. {totalTaxableAmount.toFixed(2)}</Text>
            </View>
            {shopState === stateName && shopState && stateName ? (
              <>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>CGST ({cgstRate}%)</Text>
                  <Text style={styles.totalValue}>Rs. {totalCgstAmount.toFixed(2)}</Text>
                </View>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>SGST ({sgstRate}%)</Text>
                  <Text style={styles.totalValue}>Rs. {totalSgstAmount.toFixed(2)}</Text>
                </View>
              </>
            ) : (
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>IGST ({igstRate}%)</Text>
                <Text style={styles.totalValue}>Rs. {totalIgstAmount.toFixed(2)}</Text>
              </View>
            )}
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>Rs. {totalAmount.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        <View style={styles.notesSection}>
          <Text style={styles.notesTitle}>Notes</Text>
          <Text style={styles.notesText}>
            This is a computer generated invoice and does not require signature.
          </Text>
        </View>
      </Page>
    </Document>
  );
};

export default InvoicePDF;