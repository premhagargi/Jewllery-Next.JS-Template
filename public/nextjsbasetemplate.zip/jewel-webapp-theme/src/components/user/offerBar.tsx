import React from "react";

export default function OfferBar() {
  return (
    <div className="w-full h-[28px] flex justify-center items-center bg-[#9a602e] text-xs font-thin tracking-wide	text-white">
      <p>Free express worldwide shipping. Subscribe to discover</p>
    </div>
  );
}
