"use client";

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { REGEXP_ONLY_DIGITS } from "input-otp";
import { toast } from "sonner";
import { api } from "../../../utils/api";
import config from "../../../config.json";
import { IoArrowBack, IoClose } from "react-icons/io5";
import { AxiosError } from "axios";

const COMPANY_ID = config.COMPANY_ID;

interface VerificationPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: "mobile" | "email";
  initialValue: string | null;
  verified?: boolean;
  isVerificationMode: boolean;
  onVerified: () => void;
}

export default function VerificationPopup({
  open,
  onOpenChange,
  type,
  initialValue,
  verified = false,
  isVerificationMode,
  onVerified,
}: VerificationPopupProps) {
  const [inputValue, setInputValue] = useState(initialValue || "");
  const [otp, setOtp] = useState("");
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(verified && isVerificationMode);

  //animations framer variatnions
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1,
        duration: 0.15
      }
    },
    exit: { 
      opacity: 0,
      transition: { duration: 0.15 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.3 }
    },
    exit: { 
      y: -10, 
      opacity: 0,
      transition: { duration: 0.15 }
    }
  };
  
  const fadeVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.25 } },
    exit: { opacity: 0, transition: { duration: 0.15 } }
  };

  const REGEXP_ONLY_DIGITS = /^\d+$/;


  const validateInput = (value: string) => {
    if (type === "mobile") {
      const isPhoneNumber = /^\d{10}$/.test(value);
      if (!isPhoneNumber) {
        setErrorMessage("Please enter a valid 10-digit mobile number");
        return false;
      }
    } else {
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      if (!isEmail) {
        setErrorMessage("Please enter a valid email address");
        return false;
      }
    }
    setErrorMessage("");
    return true;
  };

  const handleUpdateContact = async () => {
    if (!validateInput(inputValue)) {
      toast.info(errorMessage, { duration: 2000 });
      return;
    }
  
    setLoading(true);
    try {
      const endpoint = `/api/v1/contact/${type}/otp/send`;
    
      const response = await api.post(endpoint, {
        [type === "mobile" ? "new_cust_phone" : "new_cust_email"]: inputValue,
      });
    
      if (response.status === 200) {
        toast.success(
          `${type === "mobile" ? "Mobile number" : "Email address"} updated successfully!`
        );
        onVerified();
        onOpenChange(false);
      } else {
        const data = response.data as { message?: string };
        toast.error(data.message || "Failed to update contact");
      }
    } catch (error) {
      const err = error as AxiosError<{ message?: string }>;
      console.error(`Error updating ${type}:`, err);
  
      // Check for 403 error with token expired message
      if (
        err.response?.status === 403 &&
        err.response?.data?.message === "Token has expired. Please login again."
      ) {
        toast.error("Session expired. Please login again.");
        window.location.href = "/login"; // Redirect to login page
        return;
      }
  
      toast.error(err.response?.data?.message || `An error occurred while updating ${type}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async () => {
    if (!validateInput(inputValue)) {
      toast.info(errorMessage, { duration: 2000 });
      return;
    }
  
    setLoading(true);
    try {
      let endpoint;
      if (type === "mobile") {
        if (!initialValue) {
          endpoint = "/api/v1/contact/mobile/otp/send";
        } else {
          endpoint =
            inputValue === initialValue
              ? "/api/v1/contact/otp/resendOtp"
              : "/api/v1/contact/mobile/otp/send";
        }
      } else {
        endpoint =
          !initialValue && !verified
            ? "/api/v1/contact/email/otp/send"
            : "/api/v1/contact/otp/resendOtp";
      }
      const payload =
        endpoint === "/api/v1/contact/otp/resendOtp"
          ? { [type === "mobile" ? "new_cust_phone" : "new_cust_email"]: inputValue }
          : {
              [type === "mobile" ? "new_cust_phone" : "new_cust_email"]: inputValue,
              companyId: COMPANY_ID,
            };
      const response = await api.post(endpoint, payload);
  
      if (response.status === 200) {
        toast.success("OTP sent successfully!");
        setIsOtpSent(true);
      } else {
        const data = response.data as { message?: string };
        toast.error(data.message || "Failed to send OTP");
      }
    } catch (error) {
      const err = error as AxiosError<{ message?: string }>;
      console.error(`Error sending ${type} OTP:`, err);
  
      // Check for 403 error with token expired message
      if (
        err.response?.status === 403 &&
        err.response?.data?.message === "Token has expired. Please login again."
      ) {
        toast.error("Session expired. Please login again.");
        window.location.href = "/login"; // Redirect to login page
        return;
      }
  
      toast.error(err.response?.data?.message || "An error occurred while sending OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.length !== 4) {
      toast.info("Please enter a valid 4-digit OTP", { duration: 2000 });
      return;
    }
  
    setLoading(true);
    try {
      const response = await api.post("/api/v1/contact/otp/verify", {
        [type === "mobile" ? "new_cust_phone" : "new_cust_email"]: inputValue,
        otp,
      });
  
      if (response.status === 200) {
        toast.success(`${type === "mobile" ? "Mobile" : "Email"} verified successfully!`);
        onVerified();
        onOpenChange(false);
      } else {
        const data = response.data as { message?: string };
        toast.error(data.message || "OTP verification failed");
      }
    } catch (error) {
      const err = error as AxiosError<{ message?: string }>;
      console.error("Error during OTP verification:", err);
  
      // Check for 403 error with token expired message
      if (
        err.response?.status === 403 &&
        err.response?.data?.message === "Token has expired. Please login again."
      ) {
        toast.error("Session expired. Please login again.");
        window.location.href = "/login"; // Redirect to login page
        return;
      }
  
      toast.error(err.response?.data?.message || "An error occurred during OTP verification");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    validateInput(value);
  };

  const handleOtpChange = (value: string) => {
    setOtp(value);
  };

  const handleBack = () => {
    setIsOtpSent(false);
    setOtp("");
  };

  const handleConfirmUpdate = () => {
    setShowConfirmation(false);
  };

  const handleCancelUpdate = () => {
    onOpenChange(false);
  };

  useEffect(() => {
    if (open) {
      setInputValue(initialValue || "");
      setIsOtpSent(false);
      setOtp("");
      setErrorMessage("");
      setShowConfirmation(verified && isVerificationMode);
    }
  }, [open, initialValue, type, verified, isVerificationMode]);

  return (
<Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[450px] p-0  shadow-2xl overflow-hidden border-0">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="w-full"
        >
          <DialogHeader className="bg-gradient-to-r from-[#6a3a18] to-[#5a2f12] p-7 ">
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.25, delay: 0.1 }}
              className="flex items-center justify-between"
            >
              <DialogTitle className="text-2xl font-bold text-white tracking-tight">
                {isVerificationMode
                  ? `Verify Your ${type === "mobile" ? "Mobile Number" : "Email Address"}`
                  : `Update Your ${type === "mobile" ? "Mobile Number" : "Email Address"}`}
              </DialogTitle>
            </motion.div>
          </DialogHeader>
          
          <div className="flex flex-col gap-6 p-7 bg-gradient-to-b from-white to-gray-50">
            <AnimatePresence mode="wait">
              {showConfirmation ? (
                <motion.div
                  key="confirmation"
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex flex-col gap-6"
                >
                  <motion.p variants={itemVariants} className="text-base text-gray-700">
                    Would you like to update your {type === "mobile" ? "mobile number" : "email address"} to <span className="font-semibold text-gray-900">{inputValue}</span>?
                  </motion.p>
                  <motion.div variants={itemVariants} className="flex justify-end gap-3">
                    <Button
                      onClick={() => setShowConfirmation(false)}
                      variant="outline"
                      className="border-gray-300 text-gray-700 hover:bg-gray-100 shadow-sm transition-all duration-200"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleConfirmUpdate}
                      className="bg-[#6a3a18] hover:bg-[#5a2f12] text-white shadow-md hover:shadow-lg transition-all duration-200"
                    >
                      {loading ? (
                        <motion.div 
                          animate={{ rotate: 360 }}
                          transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                          className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                        />
                      ) : "Confirm Update"}
                    </Button>
                  </motion.div>
                </motion.div>
              ) : isVerificationMode ? (
                !isOtpSent ? (
                  <motion.div
                    key="verification"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className="flex flex-col gap-6"
                  >
                    <motion.p variants={itemVariants} className="text-base text-gray-700">
                      Please verify your {type === "mobile" ? "mobile number" : "email address"}:
                      <motion.span 
                        variants={fadeVariants}
                        className="block mt-2 font-semibold text-gray-900 text-lg"
                      >
                        {inputValue}
                      </motion.span>
                    </motion.p>
                    <motion.div variants={itemVariants}>
                      <Button
                        onClick={handleSendOtp}
                        disabled={loading}
                        className="w-full bg-[#6a3a18] hover:bg-[#5a2f12] text-white shadow-md hover:shadow-lg transition-all duration-200"
                      >
                        {loading ? (
                          <motion.div 
                            animate={{ rotate: 360 }}
                            transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                            className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                          />
                        ) : "Send OTP"}
                      </Button>
                    </motion.div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="otp"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className="flex flex-col gap-6"
                  >
                    <motion.div variants={itemVariants} className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        onClick={handleBack}
                        className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-all duration-200"
                        aria-label="Go back to edit contact"
                      >
                        <IoArrowBack size={20} />
                      </Button>
                      <p className="text-sm text-gray-600">
                        OTP sent to <span className="font-medium text-gray-800">{inputValue}</span>
                      </p>
                    </motion.div>
                    
                    <motion.div variants={itemVariants} className="w-auto mx-auto mb-2">
                      <p className="text-center text-gray-500 text-sm mb-4">
                        Enter 4-digit verification code
                      </p>
                      <InputOTP
                        maxLength={4}
                        pattern={REGEXP_ONLY_DIGITS.source}
                        onChange={handleOtpChange}
                        aria-label="Enter 4-digit OTP"
                        className="flex justify-center"
                      >
                        <InputOTPGroup className="flex gap-4">
                          {[0, 1, 2, 3].map((index) => (
                            <motion.div
                              key={index}
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              transition={{ duration: 0.3, delay: index * 0.1 }}
                            >
                              <InputOTPSlot
                                index={index}
                                className="w-14 h-14 text-center text-xl font-semibold border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-[#6a3a18]/50 focus:border-[#6a3a18] transition-all duration-200"
                              />
                            </motion.div>
                          ))}
                        </InputOTPGroup>
                      </InputOTP>
                    </motion.div>
                    
                    {errorMessage && (
                      <motion.p
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="text-red-600 text-sm text-center"
                      >
                        {errorMessage}
                      </motion.p>
                    )}
                    
                    <motion.div variants={itemVariants}>
                      <Button
                        onClick={handleVerifyOtp}
                        disabled={loading || otp.length !== 4}
                        className="w-full bg-[#6a3a18] hover:bg-[#5a2f12] text-white shadow-md hover:shadow-lg transition-all duration-200"
                      >
                        {loading ? (
                          <motion.div 
                            animate={{ rotate: 360 }}
                            transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                            className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                          />
                        ) : "Verify"}
                      </Button>
                    </motion.div>
                    
                    <motion.div 
                      variants={fadeVariants}
                      className="flex justify-center"
                    >
                      <Button
                        variant="link"
                        onClick={handleSendOtp}
                        className="text-[#6a3a18] hover:text-[#5a2f12] text-sm font-medium"
                      >
                        Resend OTP
                      </Button>
                    </motion.div>
                  </motion.div>
                )
              ) : (
                <motion.div
                  key="input"
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex flex-col gap-6"
                >
                  <motion.p variants={itemVariants} className="text-base text-gray-700">
                    Enter your new {type === "mobile" ? "mobile number" : "email address"}
                  </motion.p>
                  
                  <motion.div variants={itemVariants}>
                    <Input
                      type={type === "mobile" ? "tel" : "email"}
                      placeholder={type === "mobile" ? "+91 9000000000" : "user@gmail.com"}
                      value={inputValue}
                      onChange={handleInputChange}
                      autoFocus
                      aria-invalid={!!errorMessage}
                      aria-describedby={errorMessage ? "error-message" : undefined}
                      className="border-gray-300 focus:ring-2 focus:ring-[#6a3a18]/50 focus:border-[#6a3a18] shadow-sm text-lg p-6 rounded-lg transition-all duration-200"
                    />
                    
                    {errorMessage && (
                      <motion.p
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        id="error-message"
                        className="text-red-600 text-sm mt-2"
                      >
                        {errorMessage}
                      </motion.p>
                    )}
                  </motion.div>
                  
                  <motion.div variants={itemVariants}>
                    <Button
                      onClick={handleUpdateContact}
                      disabled={loading || !inputValue || !!errorMessage}
                      className="w-full bg-[#6a3a18] hover:bg-[#5a2f12] text-white py-6 text-lg font-medium shadow-md hover:shadow-lg transition-all duration-200 rounded-lg"
                    >
                      {loading ? (
                        <motion.div
                          className="flex items-center justify-center"
                        >
                          <motion.div 
                            animate={{ rotate: 360 }}
                            transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                            className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                          />
                          <span>Processing...</span>
                        </motion.div>
                      ) : "Continue"}
                    </Button>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}