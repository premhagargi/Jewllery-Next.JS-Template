/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect, useState } from "react";
import { IoDiamondOutline } from "react-icons/io5";
import { PiCertificate, PiShieldCheck } from "react-icons/pi";
import { RiUserStarLine } from "react-icons/ri";
import axios from "axios";
import config from "../../../config.json";
import Link from "next/link";

interface Category {
  id: number;
  regcity_code: string;
  company_id: string;
  category_id: string;
  category_desc: string;
  category_name: string;
  image_path: string | null;
  display_status: boolean;
  totalQuantity: number;
  offer_percentage: string;
}

export default function HeroGrid() {
  const [isMobileOrTablet, setIsMobileOrTablet] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleResize = () => {
      setIsMobileOrTablet(window.innerWidth <= 768);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const fetchDashboardCategories = async () => {
      try {
        setIsLoading(true);
        const { data } = await axios.get(
          `${config.NEXT_PUBLIC_API_URL}/api/v1/category/getCategoryDashboard?company_id=${config.COMPANY_ID}`
        );

        if (data.status !== "Success") {
          throw new Error(data.message || "Failed to fetch categories");
        }

        setCategories(data.data.filter((cat: Category) => cat.display_status));
        setIsLoading(false);
      } catch (err: any) {
        console.error("Error fetching categories:", err);
        setError("Failed to load categories. Please try again later.");
        setIsLoading(false);
      }
    };

    fetchDashboardCategories();
  }, []);

  const parseImagePath = (imagePath: string | null): string | null => {
    if (!imagePath || imagePath === "null") return null;
    try {
      const parsed = JSON.parse(imagePath);
      if (!Array.isArray(parsed) || !parsed[0]?.src) return null;
      return parsed[0].src.startsWith("http")
        ? parsed[0].src
        : `${config.NEXT_PUBLIC_API_URL}/${parsed[0].src}`;
    } catch (error) {
      console.error("Error parsing image_path:", error);
      return null;
    }
  };

  return (
    <div className="w-[95%] min-h-[40vh] mx-auto my-10 mb-20">
      {/* Header */}
      {/* <div className="w-full max-w-6xl mx-auto text-xs md:text-sm px-4 mb-8">
        <div className="grid grid-cols-2 lg:flex lg:justify-center lg:gap-8 gap-6 items-center text-center">
          <div className="flex items-center justify-center gap-2">
            <IoDiamondOutline className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
            <span className="whitespace-nowrap">LATEST DESIGNS</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <PiCertificate className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
            <span className="whitespace-nowrap">CERTIFIED GUARANTEE</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <PiShieldCheck className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
            <span className="whitespace-nowrap">925 FINE SILVER</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <RiUserStarLine className="w-4 h-4 md:w-5 md:h-5 text-[#9a602e]" />
            <span className="whitespace-nowrap">99% POSITIVE RESPONSE</span>
          </div>
        </div>
      </div> */}

      {/* Image Grid */}
      {isLoading ? (
        <div className="w-full flex flex-wrap justify-center gap-3">
          {[...Array(3)].map((_, idx) => (
            <div
              key={idx}
              className="w-full sm:w-[48%] lg:w-[32%] h-[550px] bg-gray-200 animate-pulse rounded-md"
            />
          ))}
        </div>
      ) : error ? (
        <div className="w-full flex justify-center items-center h-[50vh]">
          <p className="text-red-500">{error}</p>
        </div>
      ) : categories.length === 0 ? (
        <div className="w-full flex justify-center items-center h-[50vh]">
          <p className="text-gray-500">No categories available</p>
        </div>
      ) : (
        <div className="w-full flex flex-wrap justify-center gap-3 h-full">
          {categories
            .filter((cat) => parseImagePath(cat.image_path))
            .map((category) => {
              const imageUrl = parseImagePath(category.image_path);
              return (
                <Link
                  key={category.id}
                  href={`/shop?category_id=${category.category_id}`}
                  className="relative overflow-hidden 
                    w-full sm:w-[48%] lg:w-[32%] h-[550px] block cursor-pointer"
                >
                  <img
                    src={imageUrl!}
                    alt={category.category_name}
                    width={1000}
                    height={1000}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex justify-center items-end bg-black bg-opacity-50">
                    <div className="flex flex-col text-center tracking-widest leading-[35px] mb-8 text-white">
                      <span>{category.category_name.toUpperCase()}</span>
                      <div className="h-[80px] flex flex-col items-center justify-center">
                        {category.offer_percentage ? (
                          <>
                            <span className="text-[#9a602e] text-4xl md:text-5xl">
                              {category.offer_percentage}%
                            </span>
                            <span>OFF</span>
                          </>
                        ) : (
                          <div className="invisible text-4xl md:text-5xl">
                            00%
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
        </div>
      )}
    </div>
  );
}
