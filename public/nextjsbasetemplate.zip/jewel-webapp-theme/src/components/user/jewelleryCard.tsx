/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import Style from "../../app/(user)/styles/jewelleryCard.module.scss";
import ProductImage from "../../../public/assets/user/product.png"; // Fallback image
import config from "../../../config.json";
import ImageNotFound from "../../../public/assets/user/product-placeholder.jpg";

interface Product {
  ProductImage: any;
  id: any;
  ProductMaster: {
    category_id: any;
    product_id: string;
    product_name: string;
    id: string;
  };
  product_name: string;
  discountPrice: number;
  price: number;
  savedPrice: number;
  discount: string;
  exp_sellprice_aft: string;
  exp_onlinesellprice_aft: string;
  exp_onlinesellprice_bft: string;
  offer_price: string;
  est_shop_id: string;
  image_path: string; // Stringified JSON array like "[{\"src\":\"path/to/image\"}]"
}

interface JewelleryCardProps {
  product: Product;
}

// Function to parse image_path and extract src
const parseImagePath = (imagePath: string): string => {
  try {
    if (!imagePath) return ImageNotFound.src;
    const parsed = JSON.parse(imagePath);
    if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].src) {
      return `${config.NEXT_PUBLIC_API_URL}/${parsed[0].src}`;
    }
    return ImageNotFound.src;
  } catch (error) {
    console.error("Failed to parse image_path:", error);
    return ImageNotFound.src;
  }
};

function formatIndianCurrency(num: any) {
  return num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function JewelleryCard({ product }: JewelleryCardProps) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true); // Track image loading state
  const [hasError, setHasError] = useState(false); // Track image error state

  const {
    ProductMaster,
    est_shop_id,
    exp_onlinesellprice_aft,
    offer_price,
    image_path,
  } = product;

  const product_id = product?.id;
  const product_name = ProductMaster?.product_name;
  const cat_id = product?.ProductMaster?.category_id;

  const encodeParam = (param: string): string => {
    try {
      return encodeURIComponent(btoa(param)); // Base64 encode the string and then encode for URL safety
    } catch (error) {
      console.error("Error encoding parameter:", error);
      return "";
    }
  };

  const handleClick = () => {
    console.log(product_id, est_shop_id, cat_id);
    
    const encodedProductId = encodeParam(product_id);
    const encodedShopId = encodeParam(est_shop_id);
    const encodedCatId = encodeParam(cat_id);
    // router.push(`/product/${encodedProductId}?shopId=${encodedShopId}`);
    router.push(`/product?id=${encodedProductId}&shopId=${encodedShopId}&cat=${encodedCatId}`);

  };

  // Convert price values to numbers and calculate the difference
  const originalPrice = parseFloat(exp_onlinesellprice_aft) || 0;
  const discountedPrice = parseFloat(offer_price) || 0;
  const savings = originalPrice - discountedPrice;
  const discountPercentage = ((savings / originalPrice) * 100).toFixed(2);

  // Get the image source from image_path, fallback to ProductImage
  const imageSrc = parseImagePath(image_path) || ProductImage;
  return (
    <div
      className={`w-[220px] h-[260px] p-3 rounded-lg mb-10 cursor-pointer ${Style.jewelleryCardContainer}`}
      style={{ boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px" }}
      onClick={handleClick}
    >
      <div className="relative w-full h-[60%] mb-2">
        {/* Loader while image is loading */}
        {isLoading && (
          <div className="absolute inset-0 bg-gray-200 rounded-lg overflow-hidden">
            <div className="w-full h-full bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-pulse"></div>
          </div>
        )}

        {/* Image */}
        <img
          src={typeof imageSrc === "string" ? imageSrc : imageSrc?.src || ImageNotFound.src}
          width="1000"
          height="1000"
          alt={product_name || "Product Image"}
          loading="lazy"
          className="rounded-lg w-full h-full object-cover"
          onLoad={() => setIsLoading(false)} // Hide loader when image loads
          onError={(e) => {
            setIsLoading(false); // Stop loading
            setHasError(true); // Show error state
            e.currentTarget.src = ImageNotFound.src;
          }}
        />

        {/* Fallback UI if image not found */}
        {hasError && !isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg">
            <img
              src={ImageNotFound.src}
              alt="Product not found"
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
        )}
      </div>

      <div className="w-full h-[30%] text-center text-sm">
        <p className="font-regular mb-2">
          {product_name
            ?.split(" ") // Split the string into words
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1)) // Capitalize each word
            .join(" ")}
        </p>

        {/* Price Section */}
        <p>
          {Number(offer_price) > 0 &&  Number(savings) > 0 && Number(offer_price) !== Number(exp_onlinesellprice_aft) ? (
            <>
              <span className="font-bold">
  ₹{formatIndianCurrency(Number(offer_price)).replace(/\.00$/, "")}
</span>{" "}
₹<del>{formatIndianCurrency(Number(exp_onlinesellprice_aft)).replace(/\.00$/, "")}</del>{" "}            </>
          ) : (
            <>
              <span className="text-[#7a7c88] font-normal">MRP </span> 
              <span className="font-bold">
   ₹{formatIndianCurrency(Number(offer_price || exp_onlinesellprice_aft)).replace(/\.00$/, "")}
</span>
            </>
          )}
        </p>

        {/* Savings Display */}
        {Number(offer_price) > 0 && Number(savings) > 0 && (
          <p className="text-[0.7rem]">
You save ₹<span className="text-red-600">{formatIndianCurrency(savings).replace(/\.00$/, "")}</span> ({discountPercentage}% off)          </p>
        )}
      </div>
    </div>
  );
}