import Image from "next/image";
import Golbe from "../../../public/assets/user/icons/globe.png";
import Return from "../../../public/assets/user/icons/return.png";
import SecurePayment from "../../../public/assets/user/icons/securepayment.png";
import Style from "../../app/(user)/styles/webInfo.module.scss";
import { PiCar } from "react-icons/pi";

export default function WebInfo() {
  return (
    <div
      className={`w-full my-20 h-[250px] border-t-[3px] border-b-[3px] ${Style.webInfoContainer}`}
    >
      <div className="w-full h-full flex justify-center items-center gap-[5rem] text-sm text-[#707070]">
        <div className="flex flex-col justify-center items-center">
          <Image
            src={Golbe}
            width={1000}
            height={1000}
            quality={100}
            alt=""
            loading="lazy"
            className="w-[60px] h-[60px] mb-5"
          />
          <p className="font-semibold">ALL INDIA SHIPPING</p>
          <p className="text-xs w-[80%] text-center mt-2">
            We deliver across India with fast and reliable shipping services.
          </p>
        </div>
        <div className="flex flex-col justify-center items-center">
  <PiCar className="w-[60px] h-[60px] mb-5" /> {/* You can customize color with Tailwind classes */}
  <p className="font-semibold">FREE DELIVERY</p>
  <p className="text-xs w-[80%] text-center mt-2">
  Complimentary shipping on all your precious pieces.  </p>
</div>

        <div className="flex flex-col justify-center items-center">
          <Image
            src={SecurePayment}
            width={1000}
            height={1000}
            quality={100}
            alt=""
            loading="lazy"
            className="w-[60px] h-[60px] mb-5"
          />
          <p className="font-semibold">SECURE PAYMENT</p>
          <p className="text-xs w-[80%] text-center mt-2">
            Your payments are protected with industry-standard encryption.
          </p>
        </div>
      </div>
    </div>
  );
}
