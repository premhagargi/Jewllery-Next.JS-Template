import React from "react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
// import "./CategorySwiper.css"; // import your custom CSS

export default function CategorySwiper({ categories }: any) {
  return (
    <div className="w-[80%] my-10 mb-20">
      <Carousel
        opts={{
          align: "start",
        }}
        className="w-full max-w-7xl mx-auto"
      >
        <CarouselContent className="flex md:justify-center">
          {categories.map((category: any, index: number) => (
            <CarouselItem
              key={category.id}
              className="basis-1/2 sm:basis-1/3 md:basis-1/4 lg:basis-1/6"
            >
              <Link href={`/shop/?category_id=${category.category_id}`}>
                <div className="inline-block max-w-[160px] w-full overflow-hidden text-ellipsis whitespace-nowrap text-center text-sm font-medium py-4 px-6 bg-slate-200 rounded-2xl hover:bg-slate-300 transition">
  {category.category_name}
</div>

              </Link>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
    </div>
  );
}
