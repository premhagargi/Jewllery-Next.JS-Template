/* eslint-disable react/no-unescaped-entities */

import Link from "next/link";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { useGlobalState } from "../../context/GlobalStateContext";
import { FaInstagram, FaFacebookF, FaAngleUp, FaXTwitter } from "react-icons/fa6";
import Image from "next/image";
import Style from "../../app/(user)/styles/footer.module.scss";
import React, { useEffect } from "react";
import config from "../../../config.json";
import webLogo from "../../../public/assets/user/icons/Union1.png";

export default function Footer() {
  const { cmpLogo, fetchData, loading } = useGlobalState();

  // useEffect(() => {

  //   // Fetch company data if cmpLogo is undefined
  //   if (!cmpLogo) {
  //     fetchData("company");
  //   }
  // }, [cmpLogo, fetchData]);

  // Prevent rendering on server-side
  // if (typeof window === "undefined") return null;

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <div
      className={`w-full flex flex-col justify-center items-center text-[#707070] ${Style.footerContainer}`}
    >
      <div
        className={`w-full h-[250px] flex justify-center items-center border-t-2 border-[#9a602e] border-opacity-10 text-sm ${Style.footerUpperContainer}`}
      >
        <div className="w-[27%] h-[80%] flex flex-col justify-center items-center text-center border-r-2 border-opacity-10 border-[#9a602e] p-10">
          <p>Contact Us</p>
          <p>Working Hours Monday to Saturday 9:00am to 6:30pm</p>
          <p className="text-black mt-4">+91-7400233605</p>
        </div>
        <div className="w-[48%] h-[80%] flex flex-col justify-center items-center border-r-2 border-[#9a602e] border-opacity-10 p-10">
          <p className="text-lg text-black mb-2 font-semibold">
            Let's Get in Touch
          </p>
          <p className="text-sm mb-6 text-center">
            We'd love to hear from you. Whether you have a question, feedback —
            we're here to help!
          </p>
          <div className="flex w-[80%]">
            <Input
              placeholder="Email Address"
              className="rounded-none border-[#9a602e]"
            />
            <Button className="rounded-none font-light bg-[#9a602e]">
              SIGNUP
            </Button>
          </div>
        </div>
        <div className="w-[27%] h-[80%] flex flex-col justify-center items-center p-10 text-sm">
          <p className="pb-4">FOLLOW US ON SOCIAL MEDIA</p>
          <div className="flex gap-3 justify-center text-black">
            <Link href={"/"}>
              <FaInstagram />
            </Link>
            <Link href={"/"}>
              <FaFacebookF />
            </Link>
            <Link href={"/"}>
              <FaXTwitter />
            </Link>
          </div>
        </div>
      </div>
      <div
        className={`w-full bg-[#f0ebe8] pt-14 flex flex-col justify-center text-[#8e8c8b] ${Style.footerBottomContainer}`}
      >
        <div
          className={`w-[80%] mx-auto text-sm font-extralight flex border-b pb-14 border-[#bb9b9b] justify-between ${Style.footerBottomInnerContainer}`}
        >
          <div className={`w-[30%] ${Style.footerWebLogContainer}`}>
            {/* {loading ? (
  <div className="w-[270px] h-[30px] bg-gray-300 animate-pulse rounded" />
            ) : cmpLogo ? (
              <Image
                src={cmpLogo}
                width={270}
                height={30}
                quality={100}
                alt="Company Logo"
                loading="lazy"
                className="inline-block mx-2 w-[270px] h-[30px] mb-1"
              />
            ) : (
              <p>No logo available</p>
            )} */}

                  <Image
                   src={webLogo}
                   width={270}
                   height={30}
                   quality={100}
                   alt="Company Logo"
                   loading="lazy"
                   className="inline-block mx-2 w-[270px] h-[40px] mb-1 border-none"
                 />
            <p className="w-[250px] text-xs">
              Discover timeless jewellery pieces with Maharana Jewellers –
              elegance redefined.
            </p>
          </div>
          <div
            className={`w-[60%] flex justify-between ${Style.footerLinksContainer}`}
          >
            <div>
              <h4 className="text-lg mb-6">ABOUT US</h4>
              <div className="flex flex-col gap-2">
                <Link href={"/aboutus"} className="hover:underline">
                  About Us
                </Link>
                <Link href={"/shop"} className="hover:underline">
                  Our Products
                </Link>
                <Link href={"/privacyPolicy"} className="hover:underline">
                  Privacy Policy
                </Link>
              </div>
            </div>
            <div>
              <h4 className="text-lg mb-6">CUSTOMER SERVICE</h4>
              <div className="flex flex-col gap-2">
                <Link href={"/contactus"} className="hover:underline">
                  Contact Us
                </Link>
                <Link href={"/terms&condition"} className="hover:underline">
                  Terms & Conditions
                </Link>
                <Link href={"/return&exchange"} className="hover:underline">
                  Return & Exchange
                </Link>
                <Link href={"/orders"} className="hover:underline">
                  Track Your Order
                </Link>
              </div>
            </div>
            <div className="h-full flex items-end">
              <div
                className="w-[40px] h-[40px] bg-[#9a602e] grid place-items-center cursor-pointer"
                onClick={scrollToTop}
              >
                <FaAngleUp color="white" />
              </div>
            </div>
          </div>
        </div>
        <div
          className={`w-[80%] mx-auto py-6 flex ${Style.footerBottomLowerContainer}`}
        >
          <p className="text-xs text-[#bb9b9b]">
            © 2025 Maharana Silver All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}