/* eslint-disable @next/next/no-img-element */
"use client";
import React, { useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/effect-fade";
import { Pagination } from "swiper/modules";
import Image from "next/image";
import Style from "../../app/(user)/styles/cardSwiper.module.scss";
import { GoHeart } from "react-icons/go";
import { SlHandbag } from "react-icons/sl";
import ImageNotFound from "../../../public/assets/user/product-placeholder.jpg";
import { useRouter } from "next/navigation";
import config from "../../../config.json";
import themeConfig from "../../../theme.config.json";

export default function CardSwiper({ products = [] }: { products: any[] }) {
  const router = useRouter();
    const THEME_ID = themeConfig.activeTheme;
    const isLuxury = THEME_ID === "luxury";
  const encodeParam = (param: string): string => {
    try {
      return encodeURIComponent(btoa(param)); // Base64 encode
    } catch (error) {
      console.error("Error encoding parameter:", error);
      return "";
    }
  };

  const stripHtmlTags = (str: any) => {
  if (!str) return "";
  return str.replace(/<[^>]*>/g, '').trim();
};



  const handleClick = (est_shop_id: any, product_id: any, cat_id: any) => {
    const encodedProductId = encodeParam(product_id);
    const encodedShopId = encodeParam(est_shop_id);
    const encodedCatId = encodeParam(cat_id);
    console.log(product_id, est_shop_id, cat_id);

    router.push(
      `/product?id=${encodedProductId}&shopId=${encodedShopId}&cat=${encodedCatId}`
    );
  };

  const getFirstImageSrc = (imagePath: string) => {
    try {
      const parsedImages = JSON.parse(imagePath);
      return Array.isArray(parsedImages) && parsedImages.length > 0
        ? parsedImages[0].src
        : ImageNotFound;
    } catch (error) {
      console.error("Error parsing image_path:", error);
      return ImageNotFound;
    }
  };

  return (
    <div className="w-[90%] max-w-7xl mx-auto my-10 relative h-[350px]">
      {products.length === 0 ? (
        <p className="text-center text-gray-500 text-lg">
          No products available
        </p>
      ) : (
        <Swiper
          slidesPerView={5}
          spaceBetween={200}
          pagination={{ dynamicBullets: true, clickable: true }}
          breakpoints={{
            1280: { slidesPerView: 5 },
            1024: { slidesPerView: 4 },
            768: { slidesPerView: 3 },
            640: { slidesPerView: 2 },
            0: { slidesPerView: 1 },
          }}
          modules={[Pagination]}
          className="w-full h-full"
        >
          {products.map((product, index) => {
            const originalPrice = Number(product.exp_onlinesellprice_aft) || 0;
            const offerPrice = Number(product.offer_price) || 0;
            const discount =
              originalPrice && offerPrice
                ? ((originalPrice - offerPrice) / originalPrice) * 100
                : 0;

            const firstImageSrc = product.image_path
              ? getFirstImageSrc(product.image_path)
              : ImageNotFound;

            return (
    <SwiperSlide
  key={product.id || index}
  onClick={() =>
    handleClick(
      product.est_shop_id,
      product.id,
      product.ProductMaster?.Category?.category_id
    )
  }
  className={`${isLuxury ? "px-3" : "pb-12"} flex justify-center items-center`}
>
  <div
    className={`cursor-pointer overflow-hidden rounded-lg transition hover:scale-[1.02] duration-300 ${
      isLuxury
        ? "w-[260px] h-[325px] bg-[#f5e7d7] shadow-lg p-4 flex flex-col"
        : "w-[230px] h-[280px] bg-white shadow-md"
    }`}
  >
    {/* Image */}
    <div
      className={`${
        isLuxury
          ? "w-full h-[55%] mb-3 rounded-md overflow-hidden"
          : "relative w-full h-[70%] bg-gray-100 group"
      }`}
    >
      <img
        src={
          firstImageSrc === ImageNotFound.src
            ? ImageNotFound.src
            : `${config.NEXT_PUBLIC_API_URL}/${firstImageSrc}`
        }
        alt={product.ProductMaster?.product_name || "Product"}
        className={`w-full h-full object-cover ${
          isLuxury ? "" : "transition-transform duration-300 group-hover:scale-110"
        }`}
        onError={(e) => {
          e.currentTarget.src = ImageNotFound.src;
        }}
      />
    </div>

    {/* Product Info */}
    <div
      className={`${
        isLuxury
          ? "flex flex-col items-center text-center font-opensans gap-y-1 h-[45%]"
          : "w-full h-[30%] p-3 text-center space-y-1"
      }`}
    >
      <p
        className={`${
          isLuxury
            ? "text-base font-normal text-gray-800 leading-tight"
            : "text-sm font-bold text-gray-800 truncate"
        }`}
      >
        {product.ProductMaster?.product_name}
      </p>

      <div
        className={`flex justify-center gap-2 items-center ${
          isLuxury ? "text-lg font-bold" : "text-sm font-semibold"
        }`}
      >
        <span>₹{offerPrice}</span>
        {originalPrice !== offerPrice && (
          <del
            className={`text-gray-500 ${
              isLuxury ? "text-sm font-normal" : "text-xs"
            }`}
          >
            ₹{originalPrice}
          </del>
        )}
      </div>

      {originalPrice !== offerPrice && discount > 0 && (
        <p
          className={`${
            isLuxury
              ? "text-xs text-red-500"
              : "text-xs font-medium text-green-600"
          }`}
        >
          {isLuxury
            ? `You save ₹${(originalPrice - offerPrice).toFixed(0)} (${discount.toFixed(0)}% OFF)`
            : `${discount.toFixed(0)}% OFF`}
        </p>
      )}

      {isLuxury && (
        <p className="text-xs text-gray-700 leading-snug max-w-[90%] mx-auto line-clamp-2">
          {stripHtmlTags(product.ProductMaster?.product_desc) ||
            "No description available"}
        </p>
      )}
    </div>
  </div>
</SwiperSlide>

            );
          })}
        </Swiper>
      )}
    </div>
  );
}
