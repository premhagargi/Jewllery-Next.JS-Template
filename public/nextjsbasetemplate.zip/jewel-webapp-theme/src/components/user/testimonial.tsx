"use client";
import React from "react";
import Autoplay from "embla-carousel-autoplay";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Image from "next/image";
import { FaQuoteLeft } from "react-icons/fa6";
import { FaStar } from "react-icons/fa";
import { CheckCircle } from "lucide-react";
import Boy from "../../../public/assets/user/boy.png";
import Style from "../../app/(user)/styles/testimonial.module.scss";
import themeConfig from "../../../theme.config.json";

export default function Testimonial() {
  const THEME_ID = themeConfig.activeTheme;
  const isLuxury = THEME_ID === "luxury";

  const plugin = React.useRef(
    Autoplay({ delay: isLuxury ? 1200 : 2000, stopOnInteraction: true })
  );

  const testimonials = [
    {
      text: "Absolutely loved the necklace I ordered! It looks even better in person and goes well with my sarees.",
      name: "PRIYA SHARMA",
      image: Boy,
    },
    {
      text: "The kundan earrings are stunning! Wore them to a wedding and got so many compliments.",
      name: "ARJUN MEHRA",
      image: Boy,
    },
    {
      text: "Beautiful craftsmanship and fast delivery. The bracelet I bought feels very premium.",
      name: "NEHA PATIL",
      image: Boy,
    },
    {
      text: "Best purchase I’ve made recently, packaging and finish is absolutely top-notch!",
      name: "RAVI KAPOOR",
      image: Boy,
    },
    {
      text: "Loved the designs, quality feels good. Definitely ordering again soon!",
      name: "SNEHA YADAV",
      image: Boy,
    },
    {
      text: "Impressed with their service, amazing value for money!",
      name: "RAHUL SINGH",
      image: Boy,
    },
    {
      text: "Quick delivery and beautiful packaging. Highly recommend!",
      name: "ANJALI VERMA",
      image: Boy,
    },
    {
      text: "Great quality products at affordable prices.",
      name: "KARAN MALHOTRA",
      image: Boy,
    },
    {
      text: "Their designs are very elegant and classy.",
      name: "SIMRAN JOSHI",
      image: Boy,
    },
    {
      text: "Love their new collection, looks so premium.",
      name: "VIKRAM DESAI",
      image: Boy,
    },
  ];

  return (
    <div className={`${isLuxury ? "w-full relative" : "w-[80%] mx-auto"} my-10 mb-20 ${Style.testimonialContainer}`}>
      <Carousel
        className={`${isLuxury ? "w-full" : "w-[80%] mx-auto"}`}
        plugins={[plugin.current]}
        onMouseEnter={plugin.current.stop}
        onMouseLeave={plugin.current.reset}
      >
        <CarouselContent className={`w-full pb-10 ${isLuxury ? "-ml-2 gap-2" : "-ml-1"}`}>
          {testimonials.map((testimonial, index) => (
            <CarouselItem
              key={index}
              className={`pl-1 ${
                isLuxury
                  ? "basis-1/5 lg:basis-1/5 md:basis-1/3 sm:basis-1/2"
                  : "basis-full"
              }`}
            >
              {isLuxury ? (
                <div className="bg-white rounded-xl  px-4 py-4 flex flex-col gap-3 text-left border border-[#0000001A] h-[160px] mx-auto w-full max-w-[260px] transition hover:scale-[1.02] duration-300">
                  <div className="flex text-[#ffb700]">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <FaStar key={i} className="w-4 h-4" />
                    ))}
                  </div>
                  <div className="flex items-center gap-1">
                    <p className="text-sm font-semibold text-black">{testimonial.name}</p>
                    <CheckCircle className="text-green-500 w-3.5 h-3.5" />
                  </div>
                  <p className="text-xs font-normal text-[#00000099] line-clamp-3">{testimonial.text}</p>
                </div>
              ) : (
                <div className={`w-[90%] mx-auto flex flex-col gap-4 justify-center items-center text-sm px-20 py-10 bg-[#fff6ec] rounded-lg shadow-xl text-center ${Style.testimonialCard}`}>
                  <FaQuoteLeft size={50} />
                  <p>{testimonial.text}</p>
                  <Image
                    src={testimonial.image}
                    width={1000}
                    height={1000}
                    quality={100}
                    alt=""
                    loading="lazy"
                    className="w-[60px] h-[60px] rounded-full"
                  />
                  <p>{testimonial.name}</p>
                </div>
              )}
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>

      {/* Blurry edges for luxury theme */}
      {isLuxury && (
        <>
          <div className="absolute left-0 top-0 h-full w-20 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 h-full w-20 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />
        </>
      )}
    </div>
  );
}
