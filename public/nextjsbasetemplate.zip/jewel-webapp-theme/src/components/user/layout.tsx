// components/ClientLayout.tsx
"use client";

import { usePathname } from "next/navigation";
import Navbar from "@/components/user/navabar";
import Footer from "@/components/user/footer";
import OfferBar from "./offerBar";
import MobileNavbar from "./mobileNavbar";
import style from "../../app/(user)/styles/layout.module.scss";
import React from "react";

const ClientLayout = ({ children }: { children: React.ReactNode }) => {
  const pathname = usePathname();

  // Check the current URL
  const isRoot = pathname === "/";
  const isLogin = pathname === "/login";
  return (
    <>
      {/* {isRoot && <OfferBar />} */}
      {/* {!isLogin && ( */}
        <div className={style.navbarContainer}>
          <Navbar />
        </div>
       {/* )} */}
      {/* {!isLogin && ( */}
        <div className={style.mobileNavbarContainer}>
          <MobileNavbar />
        </div>
      {/* )} */}
      <main>{children}</main>
      {!isLogin && <Footer />}
    </>
  );
};

export default ClientLayout;
