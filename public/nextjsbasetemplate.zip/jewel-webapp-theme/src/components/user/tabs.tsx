import { useState } from "react";
import Image from "next/image";
import { Button } from "../ui/button";

// assets
import Tab1 from "../../../public/assets/user/tab1.png";
import Tab2 from "../../../public/assets/user/tab2.png";
import Style from "../../app/(user)/styles/tab.module.scss";

export default function Tabs() {
  const [isTab1Pressed, setISTab1Pressed] = useState(true);
  const [isTab2Pressed, setISTab2Pressed] = useState(false);
  const [isTab3Pressed, setISTab3Pressed] = useState(false);

  const handleTabClick = (tab: number) => {
    setISTab1Pressed(tab === 1);
    setISTab2Pressed(tab === 2);
    setISTab3Pressed(tab === 3);
  };

  return (
  //   <div
  //   className={`w-[80%] h-[500px] bg-[#eae1c8] mx-auto p-10 text-sm rounded-sm ${Style.tabContainer}`}
  // >
    <div
    >
      {/* <div
        className={`w-full h-[10%] mx-auto flex justify-center gap-10 mb-10 ${Style.tabButtons}`}
      >
        <p
          onClick={() => handleTabClick(1)}
          className="cursor-pointer text-lg border-b-2 border-red"
        >
          Beauty & Elegance
        </p>
        <p onClick={() => handleTabClick(2)} className="cursor-pointer text-lg">
          Neck Stage Magic
        </p>
        <p onClick={() => handleTabClick(3)} className="cursor-pointer text-lg">
          Western Wear
        </p>
      </div>

      {isTab1Pressed && (
        <div
          className={`w-[80%] h-[90%] flex mx-auto gap-10 py-10 ${Style.tabInnerContainer}`}
        >
          <div className="w-[60%] h-full">
            <p className="text-lg mb-2 font-semi">BEAUTY & ELEGANCE</p>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry&apos;s standard dummy
              text ever since the 1500s, when an unknown printer took a galley
              of type and scrambled it to make a type specimen book.
            </p>
            <Button className="mt-4">SHOP NOW</Button>
          </div>
          <div className="w-[40%] h-full relative">
            <Image
              src={Tab2}
              width={1000}
              height={1000}
              quality={100}
              alt=""
              loading="lazy"
              className="absolute bottom-[80px] left-[30px] w-[250px] h-[260px]"
            />
            <Image
              src={Tab1}
              width={1000}
              height={1000}
              quality={100}
              alt=""
              loading="lazy"
              className="w-[250px] h-[260px]"
            />
          </div>
        </div>
      )}

      {isTab2Pressed && (
        <div
          className={`w-[80%] h-[90%] flex mx-auto gap-10 py-10 ${Style.tabInnerContainer}`}
        >
          <div className="w-[60%] h-full">
            <p className="text-lg mb-2 font-semi">Neck Stage Magic</p>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry&apos;s standard dummy
              text ever since the 1500s, when an unknown printer took a galley
              of type and scrambled it to make a type specimen book.
            </p>
            <Button className="mt-4">SHOP NOW</Button>
          </div>
          <div className="w-[40%] h-full relative">
            <Image
              src={Tab2}
              width={1000}
              height={1000}
              quality={100}
              alt=""
              loading="lazy"
              className="absolute bottom-[80px] left-[30px] w-[250px] h-[260px]"
            />
            <Image
              src={Tab1}
              width={1000}
              height={1000}
              quality={100}
              alt=""
              loading="lazy"
              className="w-[250px] h-[260px]"
            />
          </div>
        </div>
      )}

      {isTab3Pressed && (
        <div
          className={`w-[80%] h-[90%] flex mx-auto gap-10 py-10 ${Style.tabInnerContainer}`}
        >
          <div className="w-[60%] h-full">
            <p className="text-lg mb-2 font-semi">Western Wear</p>
            <p className={Style.para}>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry&apos;s standard dummy
              text ever since the 1500s, when an unknown printer took a galley
              of type and scrambled it to make a type specimen book.
            </p>
            <Button className="mt-4">SHOP NOW</Button>
          </div>
          <div className="w-[40%] h-full relative">
            <Image
              src={Tab2}
              width={1000}
              height={1000}
              quality={100}
              alt=""
              loading="lazy"
              className="absolute bottom-[80px] left-[30px] w-[250px] h-[260px]"
            />
            <Image
              src={Tab1}
              width={1000}
              height={1000}
              quality={100}
              alt=""
              loading="lazy"
              className="w-[250px] h-[260px]"
            />
          </div>
        </div>
      )} */}
    </div>
  );
}
