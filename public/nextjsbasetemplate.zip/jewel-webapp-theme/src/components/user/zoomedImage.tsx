
"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import styles from "@/app/(user)/styles/zoomed.module.scss";

interface ZoomImageProps {
  src: string;
  alt: string;
  width: number;
  height: number;
  quality?: number;
}

const ZoomImage: React.FC<ZoomImageProps> = ({
  src,
  alt,
  width,
  height,
  quality = 100,
}) => {
  const [isHovering, setIsHovering] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const imageRef = useRef<HTMLImageElement>(null);
  const zoomRef = useRef<HTMLDivElement>(null);

  const handleMouseEnter = () => {
    setIsHovering(true);
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (imageRef.current) {
      const rect = imageRef.current.getBoundingClientRect();
      const x = Math.max(0, Math.min(e.clientX - rect.left, width));
      const y = Math.max(0, Math.min(e.clientY - rect.top, height));
      setMousePosition({ x, y });
    }
  };

  useEffect(() => {
    if (isHovering && zoomRef.current) {

      const computedStyles = window.getComputedStyle(zoomRef.current);
      console.log("Zoom Container Styles:", {
        display: computedStyles.display,
        visibility: computedStyles.visibility,
        width: computedStyles.width,
        height: computedStyles.height,
        left: computedStyles.left,
        top: computedStyles.top,
        zIndex: computedStyles.zIndex,
      });
    }
  }, [src, isHovering, mousePosition]);

  return (
    <div className={styles.container}>
      <div
        className={styles.imageWrapper}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onMouseMove={handleMouseMove}
      >
        <Image
          ref={imageRef}
          src={src}
          alt={alt}
          width={width}
          height={height}
          quality={quality}
          loading="lazy"
          className={styles.mainImage}
          onError={(e) => console.error("Main Image Load Error:", src, e)}
          onLoad={() => console.log("Main Image Loaded:", src)}
        />
        {isHovering && (
          <div ref={zoomRef} className={styles.zoomContainer}>
            <span>hovred</span>
            <div style={{ width: "100px", height: "100px" }}></div>
            <Image
              src={src}
              alt="Zoomed view"
              width={width * 3}
              height={height * 3}
              quality={quality}
              className={styles.zoomedImage}
              style={{
                transform: `translate(-${mousePosition.x * 2}px, -${
                  mousePosition.y * 2
                }px)`,
                transformOrigin: "top left",
              }}
              onError={(e) => console.error("Zoom Image Load Error:", src, e)}
              onLoad={() => console.log("Zoom Image Loaded:", src)}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default ZoomImage;
