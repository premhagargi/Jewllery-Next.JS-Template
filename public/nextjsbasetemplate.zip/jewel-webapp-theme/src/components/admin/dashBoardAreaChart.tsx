// import React from "react";
// import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardHeader,
//   CardTitle,
// } from "@/components/ui/card";
// import {
//   ChartConfig,
//   ChartContainer,
//   ChartLegend,
//   ChartLegendContent,
//   ChartTooltip,
//   ChartTooltipContent,
// } from "@/components/ui/chart";
// import {
//   Select,
//   SelectContent,
//   SelectItem,
//   SelectTrigger,
//   SelectValue,
// } from "@/components/ui/select";
// import { Skeleton } from "@/components/ui/skeleton";

// const chartConfig = {
//   visitors: {
//     label: "Visitors",
//   },
//   desktop: {
//     label: "Desktop",
//     color: "hsl(var(--chart-1))",
//   },
//   mobile: {
//     label: "Mobile",
//     color: "hsl(var(--chart-2))",
//   },
// } satisfies ChartConfig;

// export default function DashboardChart({ data }: any) {
//   const [timeRange, setTimeRange] = React.useState("90d");
//   const [loading, setLoading] = React.useState(true);

//   React.useEffect(() => {
//     setTimeout(() => setLoading(false), 500);
//   }, []);

//   const filteredData = data.filter((item: any) => {
//     const date = new Date(item.date);
//     const referenceDate = new Date("2024-06-30");
//     let daysToSubtract = 90;
//     if (timeRange === "30d") {
//       daysToSubtract = 30;
//     } else if (timeRange === "7d") {
//       daysToSubtract = 7;
//     }
//     const startDate = new Date(referenceDate);
//     startDate.setDate(startDate.getDate() - daysToSubtract);
//     return date >= startDate;
//   });

//   return (
//     <Card className="w-full h-full">
//       <CardHeader className="flex items-center gap-2 space-y-0 border-b py-5 sm:flex-row text-sm">
//         <div className="grid flex-1 gap-1 text-center sm:text-left">
//           <CardTitle>Area Chart - Interactive</CardTitle>
//           <CardDescription className="text-xs">
//             Showing total visitors for the last 3 months
//           </CardDescription>
//         </div>
//         <Select value={timeRange} onValueChange={setTimeRange}>
//           <SelectTrigger className="w-[140px] rounded-lg text-sm sm:ml-auto">
//             <SelectValue placeholder="Last 3 months" />
//           </SelectTrigger>
//           <SelectContent className="rounded-xl">
//             <SelectItem value="90d" className="rounded-lg">
//               Last 3 months
//             </SelectItem>
//             <SelectItem value="30d" className="rounded-lg">
//               Last 30 days
//             </SelectItem>
//             <SelectItem value="7d" className="rounded-lg">
//               Last 7 days
//             </SelectItem>
//           </SelectContent>
//         </Select>
//       </CardHeader>
//       <CardContent className="pl-0 pr-8 pt-6">
//         {loading ? (
//           <Skeleton className="h-[250px] w-[98%] ml-6" />
//         ) : (
//           <ChartContainer
//             config={chartConfig}
//             className="aspect-auto h-[250px] w-full"
//           >
//             <AreaChart data={filteredData}>
//               <defs>
//                 <linearGradient id="fillDesktop" x1="0" y1="0" x2="0" y2="1">
//                   <stop
//                     offset="5%"
//                     stopColor="var(--color-desktop)"
//                     stopOpacity={0.8}
//                   />
//                   <stop
//                     offset="95%"
//                     stopColor="var(--color-desktop)"
//                     stopOpacity={0.1}
//                   />
//                 </linearGradient>
//                 <linearGradient id="fillMobile" x1="0" y1="0" x2="0" y2="1">
//                   <stop
//                     offset="5%"
//                     stopColor="var(--color-mobile)"
//                     stopOpacity={0.8}
//                   />
//                   <stop
//                     offset="95%"
//                     stopColor="var(--color-mobile)"
//                     stopOpacity={0.1}
//                   />
//                 </linearGradient>
//               </defs>
//               <CartesianGrid vertical={false} />
//               <YAxis
//                 tickLine={false}
//                 axisLine={false}
//                 tickMargin={8}
//                 tickCount={10}
//               />
//               <XAxis
//                 dataKey="date"
//                 tickLine={false}
//                 axisLine={false}
//                 tickMargin={8}
//                 minTickGap={32}
//                 tickFormatter={(value) =>
//                   new Date(value).toLocaleDateString("en-US", {
//                     month: "short",
//                     day: "numeric",
//                   })
//                 }
//               />
//               <ChartTooltip
//                 cursor={false}
//                 content={
//                   <ChartTooltipContent
//                     labelFormatter={(value) =>
//                       new Date(value).toLocaleDateString("en-US", {
//                         month: "short",
//                         day: "numeric",
//                       })
//                     }
//                     indicator="dot"
//                   />
//                 }
//               />
//               <Area
//                 dataKey="mobile"
//                 type="natural"
//                 fill="url(#fillMobile)"
//                 stroke="var(--color-mobile)"
//                 stackId="a"
//               />
//               <Area
//                 dataKey="desktop"
//                 type="natural"
//                 fill="url(#fillDesktop)"
//                 stroke="var(--color-desktop)"
//                 stackId="a"
//               />
//               <ChartLegend content={<ChartLegendContent />} />
//             </AreaChart>
//           </ChartContainer>
//         )}
//       </CardContent>
//     </Card>
//   );
// }

// import React from "react";
// import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardHeader,
//   CardTitle,
// } from "@/components/ui/card";
// import {
//   ChartConfig,
//   ChartContainer,
//   ChartTooltip,
//   ChartTooltipContent,
// } from "@/components/ui/chart";
// import { Skeleton } from "@/components/ui/skeleton";
// import { base_url } from "@/app/(admin)/config";
// import Cookies from "js-cookie";
// import axios from "axios";
// import toast from "react-hot-toast";
// import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

// interface OrderItem {
//   order_item_id: number;
//   company_id: string;
//   est_shop_id: string;
//   order_id: number;
//   product_id: number;
//   inventory_id: number;
//   quantity: number;
//   price: string;
//   total_price: string;
//   tax_cgst: string;
//   tax_sgst: string;
//   tax_igst: string;
//   created_at: string;
//   ProductMaster: {
//     product_name: string;
//     id: number;
//   };
// }

// interface Order {
//   company_id: string;
//   id: number;
//   order_id: string;
//   est_shop_id: string;
//   payment_reference_id: string | null;
//   user_id: number;
//   address_id: number;
//   total_price: string;
//   payment_method_id: number;
//   payment_status: string;
//   order_status: string;
//   delivery_status: string;
//   created_at: string;
//   updated_at: string;
//   jw_payment_mode: {
//     id: number;
//     payment_method: string;
//   };
//   jw_order_items: OrderItem[];
// }

// interface ChartData {
//   date: string;
//   sales: number;
// }

// interface ApiResponse {
//   data: Order[];
//   total: number;
//   page: number;
//   limit: number;
// }

// const chartConfig = {
//   sales: {
//     label: "Sales",
//     color: "hsl(var(--chart-1))",
//   },
// } satisfies ChartConfig;

// export default function DashboardChart() {
//   const [chartData, setChartData] = React.useState<ChartData[]>([]);
//   const [loading, setLoading] = React.useState<boolean>(true);
//   const [error, setError] = React.useState<string | null>(null);
//   const [timeRange, setTimeRange] = React.useState<"7d" | "1m" | "3m">("7d");

//   React.useEffect(() => {
//     const fetchAllOrders = async () => {
//       const authToken = Cookies.get("authToken");
//       if (!authToken) {
//         toast.error("Please login to proceed!");
//         setError("No authentication token found");
//         setLoading(false);
//         return;
//       }

//       try {
//         setLoading(true);
//         const limit = 10;
//         let page = 1;
//         let allOrders: Order[] = [];
//         const cutoffDate = new Date();

//         // Set cutoff date based on selected time range
//         switch (timeRange) {
//           case "7d":
//             cutoffDate.setDate(cutoffDate.getDate() - 7);
//             break;
//           case "1m":
//             cutoffDate.setMonth(cutoffDate.getMonth() - 1);
//             break;
//           case "3m":
//             cutoffDate.setMonth(cutoffDate.getMonth() - 3);
//             break;
//         }

//         while (true) {
//           const { data }: { data: ApiResponse } = await axios.get(
//             `${base_url}/api/v1/admin/getOrderList?page=${page}&limit=${limit}`,
//             {
//               headers: {
//                 adminauth: authToken,
//               },
//             }
//           );

//           if (!data.data || data.data.length === 0) break;

//           allOrders = [...allOrders, ...data.data];

//           const oldestOrderDate = new Date(
//             data.data[data.data.length - 1].created_at
//           );
//           if (oldestOrderDate < cutoffDate) {
//             allOrders = allOrders.filter(
//               (order) => new Date(order.created_at) >= cutoffDate
//             );
//             break;
//           }

//           if (data.data.length < limit || page * limit >= data.total) break;

//           page++;
//         }

//         if (allOrders.length > 0) {
//           const processedData = processOrderData(allOrders);
//           setChartData(processedData);
//         } else {
//           setError(
//             `No orders found in the last ${
//               timeRange === "7d"
//                 ? "7 days"
//                 : timeRange === "1m"
//                 ? "month"
//                 : "3 months"
//             }`
//           );
//         }
//       } catch (error) {
//         console.error("Error fetching orders:", error);
//         setError("Failed to fetch order list. Please try again.");
//         toast.error("Failed to fetch order list. Please try again.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchAllOrders();
//   }, [timeRange]); // Re-fetch when timeRange changes

//   const processOrderData = (orders: Order[]): ChartData[] => {
//     const dailyData: { [key: string]: ChartData } = {};

//     orders.forEach((order) => {
//       const orderDate = new Date(order.created_at);
//       const dayKey = orderDate.toLocaleDateString("en-US", {
//         month: "short",
//         day: "numeric",
//       });

//       if (!dailyData[dayKey]) {
//         dailyData[dayKey] = {
//           date: dayKey,
//           sales: 0,
//         };
//       }

//       const price = parseFloat(order.total_price) || 0;
//       dailyData[dayKey].sales += price;
//     });

//     return Object.values(dailyData).sort(
//       (a, b) => Number(new Date(a.date)) - Number(new Date(b.date))
//     );
//   };

//   // Format large numbers to short form (e.g., 1000 -> 1K)
//   const formatNumber = (value: number): string => {
//     if (value >= 1000000) return `₹${(value / 1000000).toFixed(1)}L`;
//     if (value >= 1000) return `₹${(value / 1000).toFixed(1)}K`;
//     return `₹${value.toLocaleString()}`;
//   };

//   return (
//     <Card className="w-full h-full">
//       <CardHeader className="flex items-center gap-2 space-y-0 border-b py-5 sm:flex-row text-sm">
//         <div className="grid flex-1 gap-1 text-center sm:text-left">
//           <CardTitle>Sales Overview</CardTitle>
//           <CardDescription className="text-xs">
//             Showing total sales over selected time period
//           </CardDescription>
//         </div>
//         <Tabs
//           value={timeRange}
//           onValueChange={(value: string) =>
//             setTimeRange(value as "7d" | "1m" | "3m")
//           }
//         >
//           <TabsList className="bg-[#f1f5f9]">
//             <TabsTrigger value="7d">7 Days</TabsTrigger>
//             <TabsTrigger value="1m">1 Month</TabsTrigger>
//             <TabsTrigger value="3m">3 Months</TabsTrigger>
//           </TabsList>
//         </Tabs>
//       </CardHeader>
//       <CardContent className="pl-2 pr-8 pt-6">
//         {loading ? (
//           <Skeleton className="h-[250px] w-[98%] ml-6" />
//         ) : error ? (
//           <div className="text-red-500 text-center h-[250px] flex items-center justify-center">
//             {error}
//           </div>
//         ) : chartData.length === 0 ? (
//           <div className="text-gray-500 text-center h-[250px] flex items-center justify-center">
//             No data available
//           </div>
//         ) : (
//           <ChartContainer
//             config={chartConfig}
//             className="aspect-auto h-[250px] w-full"
//           >
//             <AreaChart data={chartData}>
//               <defs>
//                 <linearGradient id="fillSales" x1="0" y1="0" x2="0" y2="1">
//                   <stop
//                     offset="5%"
//                     stopColor="var(--color-sales)"
//                     stopOpacity={0.8}
//                   />
//                   <stop
//                     offset="95%"
//                     stopColor="var(--color-sales)"
//                     stopOpacity={0.1}
//                   />
//                 </linearGradient>
//               </defs>
//               <CartesianGrid vertical={false} stroke="none" />{" "}
//               {/* Remove grid borders */}
//               <YAxis
//                 tickLine={false}
//                 axisLine={false} // Remove Y-axis line
//                 tickMargin={8}
//                 tickCount={5}
//                 tickFormatter={formatNumber}
//               />
//               <XAxis
//                 dataKey="date"
//                 tickLine={false}
//                 axisLine={false} // Remove X-axis line
//                 tickMargin={8}
//                 minTickGap={32}
//               />
//               <ChartTooltip
//                 cursor={false}
//                 content={
//                   <ChartTooltipContent
//                     labelFormatter={(value: string) => value}
//                     indicator="dot"
//                     formatter={(value) => {
//                       const numValue = Number(value);
//                       return [`₹${numValue}`, null];
//                     }}
//                   />
//                 }
//               />
//               <Area
//                 dataKey="sales"
//                 type="natural"
//                 fill="url(#fillSales)"
//                 strokeWidth={2} // Optional: adjust stroke width if needed
//                 stroke="var(--color-sales)"
//               />
//             </AreaChart>
//           </ChartContainer>
//         )}
//       </CardContent>
//     </Card>
//   );
// }

"use client";

import React from "react";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ChartData {
  date: string;
  sales: number;
}

const chartConfig = {
  sales: { label: "Sales", color: "hsl(var(--chart-1))" },
} satisfies ChartConfig;

export default function DashboardChart({
  data,
  loading,
  error,
  timeRange,
  setTimeRange,
}: {
  data: ChartData[];
  loading: boolean;
  error: string | null;
  timeRange: "7d" | "1m" | "3m";
  setTimeRange: (value: "7d" | "1m" | "3m") => void;
}) {
  const formatNumber = (value: number): string => {
    if (value >= 1000000) return `₹${(value / 1000000).toFixed(1)}L`;
    if (value >= 1000) return `₹${(value / 1000).toFixed(1)}K`;
    return `₹${value.toLocaleString()}`;
  };

  console.log(data);
  

  return (
    <Card className="w-full h-full">
      <CardHeader className="flex items-center gap-2 space-y-0 border-b py-5 sm:flex-row text-sm">
        <div className="grid flex-1 gap-1 text-center sm:text-left">
          <CardTitle>Sales Overview</CardTitle>
          <CardDescription className="text-xs">
            Showing total sales over selected time period
          </CardDescription>
        </div>
        <Tabs
          value={timeRange}
          onValueChange={(value) => setTimeRange(value as "7d" | "1m" | "3m")}
        >
          <TabsList className="bg-[#f1f5f9]">
            <TabsTrigger value="7d">7 Days</TabsTrigger>
            <TabsTrigger value="1m">1 Month</TabsTrigger>
            <TabsTrigger value="3m">3 Months</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="pl-2 pr-8 pt-6">
        {loading ? (
          <Skeleton className="h-[250px] w-[98%] ml-6" />
        ) : error ? (
          <div className="text-red-500 text-center h-[250px] flex items-center justify-center">
            {error}
          </div>
        ) : data.length === 0 ? (
          <div className="text-gray-500 text-center h-[250px] flex items-center justify-center">
            No data available
          </div>
        ) : (
          <ChartContainer
            config={chartConfig}
            className="aspect-auto h-[250px] w-full"
          >
            <AreaChart data={data}>
              <defs>
                <linearGradient id="fillSales" x1="0" y1="0" x2="0" y2="1">
                  <stop
                    offset="5%"
                    stopColor="var(--color-sales)"
                    stopOpacity={0.8}
                  />
                  <stop
                    offset="95%"
                    stopColor="var(--color-sales)"
                    stopOpacity={0.1}
                  />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="none" />{" "}
              {/* Remove grid borders */}
              <YAxis
                tickLine={false}
                axisLine={false} // Remove Y-axis line
                tickMargin={8}
                tickCount={5}
                tickFormatter={formatNumber}
              />
              <XAxis
                dataKey="date"
                tickLine={false}
                axisLine={false} // Remove X-axis line
                tickMargin={8}
                minTickGap={32}
              />
              <ChartTooltip
                cursor={false}
                content={
                  <ChartTooltipContent
                    labelFormatter={(value: string) => value}
                    indicator="dot"
                    formatter={(value) => {
                      const numValue = Number(value);
                      return [`₹${numValue}`, null];
                    }}
                  />
                }
              />
              <Area
                dataKey="sales"
                type="natural"
                fill="url(#fillSales)"
                strokeWidth={2} // Optional: adjust stroke width if needed
                stroke="var(--color-sales)"
              />
            </AreaChart>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  );
}
