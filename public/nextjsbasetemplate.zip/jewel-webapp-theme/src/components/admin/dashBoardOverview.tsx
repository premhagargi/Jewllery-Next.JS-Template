"use client";
import { useEffect, useState } from "react";
import { IndianRupee, ShoppingCart, User, Folder, Gem } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import Cookies from "js-cookie";
import axios from "axios";
// import { base_url } from "@/app/(admin)/config";
import config from '../../../config.json'

// Define the expected type for dashboard data
interface DashboardData {
  totalRevenut: string;
  totalOrders: number;
  totalUsers: number;
  totalCategory: number;
  totalProducts: number;
  totalSales: number;
}

export default function DashboardOverview() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const authToken = Cookies.get("authToken");
        const response = await axios.get<{ data: DashboardData }>(`${config.NEXT_PUBLIC_API_URL}/api/v1/admin/dashboardCount`, {
          headers: { adminauth: authToken },
        });

        setData(response.data.data);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  return (
    <div className="flex gap-4">
      {[
        {
          value: data?.totalRevenut
            ? new Intl.NumberFormat("en-IN", {
                style: "currency",
                currency: "INR",
                minimumFractionDigits: 2,
              }).format(Number(data.totalRevenut))
            : "₹0.00",
          label: "Total Revenue",
        },
        {
          value: data?.totalOrders || "0",
          label: "Total Orders",
          icon: <ShoppingCart color="blue" />,
        },
        {
          value: data?.totalUsers || "0",
          label: "Total Users",
          icon: <User color="orange" />,
        },
        {
          value: data?.totalCategory || "0",
          label: "Total Categories",
          icon: <Folder color="red" />,
        },
        {
          value: data?.totalProducts || "0",
          label: "Total Products",
          icon: <Gem color="grey" />,
        },
        // {
        //   value: data?.totalSales || "0",
        //   label: "Total Sales",
        //   icon: <IndianRupee color="purple" />,
        // },
      ].map((item, index) => (
        <div
          key={index}
          className="bg-white w-full rounded-lg text-sm flex justify-between items-center px-4 py-5 shadow"
        >
          <div>
            {loading ? (
              <>
                <Skeleton className="h-6 w-16 mb-2" />
                <Skeleton className="h-4 w-24" />
              </>
            ) : (
              <>
                <p className="font-regular text-4xl">{item.value}</p>
                <p>{item.label}</p>
              </>
            )}
          </div>
          <div>{loading ? <Skeleton className="h-6 w-6 rounded-full" /> : item.icon}</div> 
        </div>
      ))}
    </div>
  );
}
