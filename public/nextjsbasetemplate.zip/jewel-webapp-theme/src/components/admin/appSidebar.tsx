"use client";

import { Box, Folder, Gem, Home, FileText, KeyIcon, FlagIcon, InfoIcon, Settings2, ChevronDown } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
} from "../../components/ui/sidebar";
import { usePathname } from "next/navigation";
import useAuthStore from "../../app/(admin)/stores/userAuthStore";
import Link from "next/link";
import Image from "next/image"; // Import the Image component
import React, { useEffect, useState } from "react";
import config from "../../../config.json";

const items = [
  {
    title: "Dashboard",
    url: "/admin",
    icon: Home,
  },
  {
    title: "Orders",
    url: "/adminorders",
    icon: Box,
  },
  {
    title: "Products",
    url: "/adminproducts",
    icon: Gem,
  },
  {
    title: "Categories",
    url: "/admincategories",
    icon: Folder,
  },
  {
    title: "Banners",
    url: "/banners",
    icon: FlagIcon,
  },
  {
    title: "Invoices",
    url: "/invoicelist",
    icon: FileText,
  },
  {
    title: "Customers",
    url: "/admincustomers",
    icon: Home, // Placeholder; replace with Users or appropriate icon
  },
  {
    title: "Settings",
    icon: Settings2,
    subItems: [
      {
        title: "Company Details",
        url: "/companydetails",
        icon: InfoIcon,
      },
      {
        title: "Button Settings",
        url: "/buttonsettings",
        icon: Settings2,
      },
      {
        title: "Cashfree Credentials",
        url: "/paymentcred",
        icon: KeyIcon,
      },
    ],
  },
];

export function AppSidebar() {
    const [imageError, setImageError] = useState(false);
  const pathName = usePathname();
  const [openSettings, setOpenSettings] = useState(false);
  const { cmp_logo } = useAuthStore();

  useEffect(() => {
    // Any side effects related to cmp_logo can be handled here
    // console.log("Company logo updated:", cmp_logo);
  }, [cmp_logo]);

  return (
    <Sidebar className="border-r border-gray-200 shadow-sm">
      <SidebarContent className="bg-white">
        <SidebarGroup>
          <SidebarGroupLabel className="font-semibold text-gray-900 text-md px-4 py-5 tracking-tight">
             {!imageError && cmp_logo ? (
        <Image
          src={`${config.NEXT_PUBLIC_API_URL.replace(/\/$/, "")}/${cmp_logo}`}
          alt="Company Logo"
          width={120}
          height={32}
          className="h-8 w-auto object-contain max-h-12"
          onError={() => setImageError(true)}
          priority={true}
        />
      ) : (
        <span className="text-sm text-gray-500">Company Logo</span>
      )}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.subItems ? (
                    <>
                      <SidebarMenuButton
                        onClick={() => setOpenSettings(!openSettings)}
                        className="flex items-center justify-between w-full px-4 py-2.5 text-gray-700 font-medium text-sm hover:bg-gray-50 transition-all duration-200 ease-in-out rounded-md"
                      >
                        <div className="flex items-center gap-3">
                          <item.icon className="h-5 w-5 text-gray-500" />
                          <span>{item.title}</span>
                        </div>
                        <ChevronDown
                          className={`h-4 w-4 text-gray-500 transition-transform duration-300 ease-in-out ${
                            openSettings ? "rotate-180" : ""
                          }`}
                        />
                      </SidebarMenuButton>
                      <SidebarMenuSub
                        className={`transition-all duration-300 ease-in-out overflow-hidden ${
                          openSettings ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                        } ml-0 border-l-0`}
                      >
                        {item.subItems.map((subItem) => (
                          <SidebarMenuSubItem key={subItem.title}>
                            <SidebarMenuSubButton asChild>
                              <Link
                                href={subItem.url}
                                prefetch={true}
                                replace={true}
                                className={`flex items-center gap-3 w-full px-2 py-2.5 text-gray-600 text-sm font-normal hover:bg-gray-50 transition-all duration-200 ease-in-out rounded-md ${
                                  pathName === subItem.url
                                    ? "bg-gray-100 text-gray-900 font-medium"
                                    : ""
                                }`}
                              >
                                <subItem.icon className="h-4 w-4 text-gray-400" />
                                <span>{subItem.title}</span>
                              </Link>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </>
                  ) : (
                    <SidebarMenuButton asChild>
                      <Link
                        href={item.url}
                        prefetch={true}
                        replace={true}
                        className={`flex items-center gap-3 w-full px-4 py-2.5 text-gray-700 text-sm font-medium hover:bg-gray-50 transition-all duration-200 ease-in-out rounded-md ${
                          pathName === item.url
                            ? "bg-gray-100 text-gray-900 font-medium"
                            : ""
                        }`}
                      >
                        <item.icon className="h-5 w-5 text-gray-500" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}