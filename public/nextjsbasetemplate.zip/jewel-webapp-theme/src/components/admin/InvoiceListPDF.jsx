import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";

// Define styles
const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontFamily: "Helvetica",
  },
  table: {
    display: "table",
    width: "100%",
    border: "1px solid black",
    marginBottom: 10,
  },
  tableRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  tableCol: {
    width: "12.5%", // Adjusted width for other columns
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8, // Smaller text size
  },
  invoiceCol: {
    width: "15%", // Merged invoice fields
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8,
  },
  tableHeader: {
    backgroundColor: "#f2f2f2",
    fontWeight: "bold",
  },
  headerText: {
    fontSize: 14,
    marginBottom: 10,
  },
});

// PDF Document Component
const TablePDF = ({ data }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.headerText}>Invoices Generated (Admin)</Text>
      <View style={styles.table}>
        {/* Table Header */}
        <View style={[styles.tableRow, styles.tableHeader]}>
          <Text style={styles.invoiceCol}>Invoice No.</Text>
          <Text style={styles.invoiceCol}>Order ID</Text>
          <Text style={styles.invoiceCol}>Payment Status</Text>
          <Text style={styles.tableCol}>Product ID</Text>
          <Text style={styles.tableCol}>Product Name</Text>
          <Text style={styles.tableCol}>Shop Name</Text>
          <Text style={styles.tableCol}>Quantity</Text>
          <Text style={styles.tableCol}>Unit Price</Text>
          <Text style={styles.tableCol}>Total Price</Text>
        </View>

        {/* Table Rows */}
        {data.map((invoice, invoiceIndex) => {
          return invoice.jw_invoice_items.map((item, itemIndex) => (
            <View style={styles.tableRow} key={`${invoiceIndex}-${itemIndex}`}>
              {/* Merge Invoice Details in First Row */}
              {itemIndex === 0 ? (
                <>
                  <Text style={styles.invoiceCol} rowSpan={invoice.jw_invoice_items.length}>
                    {invoice.invoice_no}
                  </Text>
                  <Text style={styles.invoiceCol} rowSpan={invoice.jw_invoice_items.length}>
                    {invoice.order_id}
                  </Text>
                  <Text style={styles.invoiceCol} rowSpan={invoice.jw_invoice_items.length}>
                    {invoice.payment_status}
                  </Text>
                </>
              ) : null}

              {/* Product Details */}
              <Text style={styles.tableCol}>{item.product_id}</Text>
              <Text style={styles.tableCol}>{item.ProductMaster.product_name}</Text>
              <Text style={styles.tableCol}>{item.mi_shop_est.est_shop_name}</Text>
              <Text style={styles.tableCol}>{item.quantity}</Text>
              <Text style={styles.tableCol}>{item.unit_price}</Text>
              <Text style={styles.tableCol}>{item.total_price}</Text>
            </View>
          ));
        })}
      </View>
    </Page>
  </Document>
);

export default TablePDF;
