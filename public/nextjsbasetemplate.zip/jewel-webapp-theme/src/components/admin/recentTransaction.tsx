// import { useEffect, useState } from "react";
// import {
//   Table,
//   TableBody,
//   TableCell,
//   TableHead,
//   TableHeader,
//   TableRow,
// } from "@/components/ui/table";
// import { Skeleton } from "../ui/skeleton";

// interface Invoice {
//   invoice: string;
//   paymentStatus: string;
//   paymentMethod: string;
//   totalAmount: string; // Keeping as string assuming it comes formatted, otherwise use `number`
// }

// interface Transaction {
//   data: Invoice[];
// }

// export function RecentTransaction({ data }: Transaction) {
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     // Simulating data fetch
//     setTimeout(() => setLoading(false), 500);
//   }, []);
//   return (
//     <div className="bg-white p-4 rounded-xl shadow text-sm">
//       <p className="font-bold pl-1 my-2">Recent Transaction</p>
//       <Table>
//         <TableHeader>
//           <TableRow>
//             <TableHead className="w-[100px]">Invoice</TableHead>
//             <TableHead>Status</TableHead>
//             <TableHead>Method</TableHead>
//             <TableHead className="text-right">Amount</TableHead>
//           </TableRow>
//         </TableHeader>
//         <TableBody>
//           {loading
//             ? Array.from({ length: 5 }).map((_, index) => (
//                 <TableRow key={index}>
//                   <TableCell>
//                     <Skeleton className="h-4 w-20 rounded" />
//                   </TableCell>
//                   <TableCell>
//                     <Skeleton className="h-4 w-24 rounded" />
//                   </TableCell>
//                   <TableCell>
//                     <Skeleton className="h-4 w-24 rounded" />
//                   </TableCell>
//                   <TableCell className="text-right">
//                     <Skeleton className="h-4 w-16 rounded" />
//                   </TableCell>
//                 </TableRow>
//               ))
//             : data.map((invoice) => (
//                 <TableRow key={invoice.invoice}>
//                   <TableCell className="font-medium">
//                     {invoice.invoice}
//                   </TableCell>
//                   <TableCell>{invoice.paymentStatus}</TableCell>
//                   <TableCell>{invoice.paymentMethod}</TableCell>
//                   <TableCell className="text-right">
//                     {invoice.totalAmount}
//                   </TableCell>
//                 </TableRow>
//               ))}
//         </TableBody>
//       </Table>
//     </div>
//   );
// }


"use client";

import { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "../ui/skeleton";
import { Payment } from "@/app/(admin)/admin/page";

interface TransactionProps {
  data: Payment[];
}

export function RecentTransaction({ data }: TransactionProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate initial loading or wait for real data
    setTimeout(() => setLoading(false), 500);
  }, []);

  return (
    <div className="bg-white p-4 rounded-xl shadow text-sm">
      <p className="font-bold pl-1 my-2">Recent Transactions</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[200px]">Order ID</TableHead>
            <TableHead>Customer Name</TableHead>
            <TableHead>Payment Mode</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Order Status</TableHead>
            <TableHead>Payment Status</TableHead>
            <TableHead>Delivery Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {loading ? (
            Array.from({ length: 5 }).map((_, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Skeleton className="h-4 w-20 rounded" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-24 rounded" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-24 rounded" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-16 rounded" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-24 rounded" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-24 rounded" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-24 rounded" />
                </TableCell>
              </TableRow>
            ))
          ) : data.length > 0 ? (
            data.map((order) => {
              const amount = parseFloat(order.total_price) || 0;
              const formattedAmount =
                amount % 1 === 0
                  ? new Intl.NumberFormat("en-IN", {
                      style: "currency",
                      currency: "INR",
                      maximumFractionDigits: 0,
                    }).format(amount)
                  : new Intl.NumberFormat("en-IN", {
                      style: "currency",
                      currency: "INR",
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    }).format(amount);

              return (
                <TableRow key={order.order_id}>
                  <TableCell className="font-medium">{order.order_id}</TableCell>
                  <TableCell>{order.mi_customer?.cust_cmp_name}</TableCell>
                  <TableCell>{order.jw_payment_mode.payment_method}</TableCell>
                  <TableCell className="text-left">{formattedAmount}</TableCell>
                  <TableCell>{order.order_status}</TableCell>
                  <TableCell>{order.payment_status}</TableCell>
                  <TableCell>{order.delivery_status}</TableCell>
                </TableRow>
              );
            })
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center pt-6">
                No recent transactions found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}