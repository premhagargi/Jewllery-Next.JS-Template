/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import { useEffect, useState } from 'react';
import { usePathname, useRouter } from "next/navigation";
import { jwtDecode } from 'jwt-decode';
import Navbar from "./navbar";
import { SidebarProvider, SidebarTrigger } from "../ui/sidebar";
import { AppSidebar } from "./appSidebar";
import Style from "../../app/(admin)/styles/clientLayout.module.scss";
import PageNotFound from "@/app/(user)/not-found";
import Cookies from "js-cookie";

// Define an interface for the decoded token to ensure type safety
interface DecodedToken {
    exp?: number;
    [key: string]: any; // Allow other potential properties
}

const ClientLayout = ({ children }: { children: React.ReactNode }) => {
    const pathname = usePathname();
    const router = useRouter();
    const isLogin = pathname === "/adminlogin";

    const appRoutes = [
        "/admin",
        "/adminlogin",
        "/adminproducts",
        "/invoicelist",
        "/adminorders",
        "/admincategories",
        "/admincustomers",
        "/admincoupons",
        "/admininbox",
        "/companydetails",
        "/paymentcred",
        "/banners",
        "/buttonsettings",
    ];

    // Add state to prevent re-renders
    const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

    useEffect(() => {
        // Function to check authentication token
        const checkAuthToken = () => {
            const authToken = Cookies.get("authToken");

            // If no token exists and not on login page, redirect to login
            if (!authToken) {
                if (!isLogin) {
                    router.replace('/adminlogin'); // Use replace to prevent going back
                }
                setIsAuthenticated(false);
                return;
            }

            // If token exists, validate it
            try {
                const decodedToken = jwtDecode<DecodedToken>(authToken);
                const currentTime = Math.floor(Date.now() / 1000); // Convert to seconds

                if (decodedToken.exp && decodedToken.exp < currentTime) {
                    // Token expired, clear token and redirect
                    Cookies.remove('authToken');
                    sessionStorage.clear();

                    if (!isLogin) {
                        router.replace('/adminlogin'); // Use replace to prevent looping
                    }
                    setIsAuthenticated(false);
                    return;
                }

                setIsAuthenticated(true);
            } catch (error) {
                // Invalid token format, remove it
                Cookies.remove('authToken');
                sessionStorage.clear();

                if (!isLogin) {
                    router.replace('/adminlogin');
                }
                setIsAuthenticated(false);
            }
        };

        if (!isLogin) {
            checkAuthToken();
        } else {
            setIsAuthenticated(true);
        }
    }, [pathname]);

    // Avoid rendering anything until authentication is checked
    if (isAuthenticated === null) return null;

    // If not authenticated, don't render layout
    if (!isAuthenticated && !isLogin) {
        return null;
    }

    // Route validation
    if (!appRoutes.includes(pathname)) {
        return <PageNotFound />;
    }

    // Login page render
    if (isLogin) {
        return <>{children}</>;
    }

    // Regular layout render
    return (
        <>
            <Navbar />
            <SidebarProvider className="w-full">
                <SidebarTrigger />
                <AppSidebar />
                <main className={`w-full ${Style.mainContainer}`}>{children}</main>
            </SidebarProvider>
        </>
    );
};

export default ClientLayout;
