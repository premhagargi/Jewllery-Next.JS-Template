import React from 'react';
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

// Create styles for the PDF
const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 9,
    fontFamily: 'Helvetica',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  billtosection: {
    border: '1pt solid #000',
    backgroundColor: '#D9D9D9',
    padding: 6.5,
  },
  billtotext: {
    fontWeight: 'bold',
  },
  infoSection: {
    border: '1pt solid #000',
    borderBottom: 'none',
    height: 70,
  },
  infoRow: {
    flexDirection: 'row',
    borderBottom: '0pt solid #000',
  },
  infoLeftColumn: {
    width: '50%',
    padding: '5',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  infoRightColumn: {
    padding: '5',
    width: '50%',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  infoItem: {
    flexDirection: 'row',
    marginBottom: 9,
  },
  infoLabel: {
    width: 120,
  },
  infoValue: {
    flex: 1,
  },
  addressSection: {
    border: '1pt solid #000',
    borderTop: 'none',
    borderBottom: 'none',
    paddingVertical: 8,
    height: 55,
    paddingHorizontal: 7,
  },
  addressSection1: {
    border: '1pt solid #000',
    borderTop: 'none',
    borderBottom: 'none',
    paddingVertical: 8,
    height: 80,
    paddingHorizontal: 7,
  },
  addressName: {
    fontWeight: 'normal',
    marginBottom: 6,
  },
  addressName1: {
    marginBottom: 6,
  },
  tableContainer: {
    border: '1pt solid #000',
    borderBottom: 'none',
    borderTop: '1pt solid #000',
  },
  tableHeader: {
    flexDirection: 'row',
    borderBottom: '1pt solid #000',
    backgroundColor: '#f0f0f0',
    fontSize: 10,
    height: 30,
  },
  tableRow: {
    flexDirection: "row",
    borderBottom: "none",
    fontSize: 10,
    height: 130,
  },
  numberCol: {
    width: '5%',
    borderRight: '1pt solid #000',
    paddingVertical: 3,
    textAlign: 'center',
  },
  descriptionCol: {
    width: '23%',
    borderRight: '1pt solid #000',
    paddingVertical: 3,
    paddingHorizontal: 3,
  },
  quantityCol: {
    width: '5%',
    borderRight: '1pt solid #000',
    paddingVertical: 3,
    textAlign: 'center',
  },
  priceCol: {
    width: '11.5%',
    borderRight: '1pt solid #000',
    paddingVertical: 3,
    textAlign: 'center',
    paddingHorizontal: 3,
  },
  amountCol: {
    width: "10%",
    paddingVertical: 3,
    paddingHorizontal: 3,
    textAlign: 'center',
  },
  totalsSection: {
    flexDirection: 'row',
    height: 120,
    fontSize: 10,
    border: '1pt solid #000',
  },
  signatureSection: {
    width: "50%",
    padding: 8,
    borderRight: "1pt solid #000",
  },
  signatureName: {
    marginBottom: 0,
    fontSize: 12,
    fontWeight: 'thin'
  },
  signature: {
    marginTop: 1.5,
    marginBottom: 5,
    fontSize: 12,
    fontWeight: 'bold',
    fontStyle: "italic"
  },
  signatureTitle: {
    marginTop: 50,
    fontWeight: 'thin',
    fontSize: 12,
  },
  totalDetails: {
    width: '50%',
    padding: 8,
  },
  totalRow: {
    flexDirection: 'row',
    borderBottom: 'none',
    paddingVertical: 5,
    marginBottom: 5
  },
  totalLabel: {
    width: '60%',
    paddingLeft: 5,
  },
  totalValue: {
    width: '40%',
    textAlign: 'right',
    paddingRight: 5,
  },
  notesSection: {
    padding: 7,
    border: '1pt solid #000',
    borderTop: 'none',
    minHeight: 30,
  },
  notesTitle: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  boldText: {
    fontWeight: 'bold',
  },
  subText: {
    fontSize: 9,
    color: 'black',
  },
  spacing: {
    marginTop: 5,
  },
});

function numberToWords(num) {
  const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
  const teens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
  const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
  const units = ['', 'thousand', 'lakh', 'crore'];

  if (num === 0) return 'zero';

  let result = '';
  let parts = [];

  if (num >= 10000000) {
    parts.push(helper(Math.floor(num / 10000000)) + ' crore');
    num %= 10000000;
  }
  if (num >= 100000) {
    parts.push(helper(Math.floor(num / 100000)) + ' lakh');
    num %= 100000;
  }
  if (num >= 1000) {
    parts.push(helper(Math.floor(num / 1000)) + ' thousand');
    num %= 1000;
  }
  if (num > 0) {
    parts.push(helper(num));
  }

  result = parts.join(' ').trim();
  return result.charAt(0).toUpperCase() + result.slice(1);

  function helper(num) {
    if (num === 0) return '';
    if (num < 10) return ones[num];
    if (num < 20) return teens[num - 10];
    if (num < 100) return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + ones[num % 10] : '');
    return ones[Math.floor(num / 100)] + ' hundred' + (num % 100 !== 0 ? ' ' + helper(num % 100) : '');
  }
}

const formatDate = (dateString) => {
  try {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch (error) {
    return 'N/A';
  }
};

const safeGet = (obj, path, fallback = '') => {
  try {
    return path.split('.').reduce((o, key) => (o || {})[key], obj) || fallback;
  } catch (e) {
    return fallback;
  }
};

const InvoicePDF = ({ invoice }) => {
  if (!invoice) {
    return (
      <Document>
        <Page size="A4" style={styles.page}>
          <Text>No invoice data available</Text>
        </Page>
      </Document>
    );
  }

  const order_number = invoice?.jw_order?.order_id;
  const customerName = safeGet(invoice, 'jw_customer_address.name', 'Customer');
  const addressLine1 = safeGet(invoice, 'jw_customer_address.address_line1', '');
  const addressLine2 = safeGet(invoice, 'jw_customer_address.address_line2', '');
  const cityName = safeGet(invoice, 'jw_customer_address.City.city_name', '');
  const stateName = safeGet(invoice, 'jw_customer_address.State.state_name', '');
  const countryName = safeGet(invoice, 'jw_customer_address.Country.country_name', '');
  const postalCode = safeGet(invoice, 'jw_customer_address.postal_code', '');
  const contactNo = safeGet(invoice, 'jw_customer_address.contact_no', '');

  const fullAddress = [
    addressLine1,
    addressLine2,
    cityName,
    stateName,
    countryName,
    postalCode
  ].filter(Boolean).join(", ");

  const shopName = safeGet(invoice, 'mi_shop_est.est_shop_name', 'Shop');
  const shopAddress = [
    safeGet(invoice, 'mi_shop_est.address1', ''),
    safeGet(invoice, 'mi_shop_est.address2', '')
  ].filter(Boolean).join(", ");
  const shopPincode = safeGet(invoice, 'mi_shop_est.pincode', 'ShopPincode');
  const shopGst = safeGet(invoice, 'mi_shop_est.shop_gst', 'ShopGst');
  const shopPhoneNumber = safeGet(invoice, 'mi_shop_est.est_shop_phone', 'ShopGst');
  const shopCity = safeGet(invoice, 'mi_shop_est.City.city_name', 'ShopCity');
  const shopState = safeGet(invoice, 'mi_shop_est.State.state_name', 'ShopState');
  const shopCountry = safeGet(invoice, 'mi_shop_est.Country.country_name', 'ShopCountry');

  // Tax Calculations based on shopState and stateName
  const taxCalculations = (invoice.jw_invoice_items || []).reduce(
    (acc, item) => {
      const totalPrice = parseFloat(item.total_price || 0);
      const quantity = parseFloat(item.quantity || 1);
      // Get tax rates from item or ProductMaster
      const baseCgstRate =
        parseFloat(item?.tax_cgst ?? '') ||
        parseFloat(item?.ProductMaster?.TaxRate?.tax_cgst ?? 0);
      const baseSgstRate =
        parseFloat(item?.tax_sgst ?? '') ||
        parseFloat(item?.ProductMaster?.TaxRate?.tax_sgst ?? 0);
      const baseIgstRate =
        parseFloat(item?.tax_igst ?? '') ||
        parseFloat(item?.ProductMaster?.TaxRate?.tax_igst ?? 0);

      // Determine if transaction is intra-state or inter-state
      const isIntraState = shopState === stateName && shopState && stateName;
      console.log('is intra state:', isIntraState, 'shopState:', shopState, 'stateName:', stateName);
      // Apply appropriate tax rates
      const cgstRate = isIntraState ? baseCgstRate : 0;
      const sgstRate = isIntraState ? baseSgstRate : 0;
      const igstRate = isIntraState ? 0 : baseIgstRate;

      // Calculate taxable price and tax amounts
      const totalTaxRate = isIntraState ? (cgstRate + sgstRate) / 100 : igstRate / 100;
      const taxablePrice = totalPrice / (1 + totalTaxRate);
      const cgstAmount = isIntraState ? taxablePrice * (cgstRate / 100) : 0;
      const sgstAmount = isIntraState ? taxablePrice * (sgstRate / 100) : 0;
      const igstAmount = isIntraState ? 0 : taxablePrice * (igstRate / 100);

      return {
        totalTaxableAmount: acc.totalTaxableAmount + taxablePrice,
        totalCgstAmount: acc.totalCgstAmount + cgstAmount,
        totalSgstAmount: acc.totalSgstAmount + sgstAmount,
        totalIgstAmount: acc.totalIgstAmount + igstAmount,
        totalAmount: acc.totalAmount + totalPrice,
        cgstRate,
        sgstRate,
        igstRate,
      };
    },
    {
      totalTaxableAmount: 0,
      totalCgstAmount: 0,
      totalSgstAmount: 0,
      totalIgstAmount: 0,
      totalAmount: 0,
      cgstRate: 0,
      sgstRate: 0,
      igstRate: 0,
    }
  );

  const {
    totalTaxableAmount,
    totalCgstAmount,
    totalSgstAmount,
    totalIgstAmount,
    totalAmount,
    cgstRate,
    sgstRate,
    igstRate,
  } = taxCalculations;

  const invoiceAmountWithTax = parseFloat(invoice.invoice_amount_aft_tax || totalAmount);

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.title}>TAX INVOICE</Text>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <View style={styles.infoLeftColumn}>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Invoice Number</Text>
                <Text style={styles.infoValue}>{`: ${invoice.invoice_no || 'N/A'}`}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Order Number</Text>
                <Text style={styles.infoValue}>{`: ${order_number || 'N/A'}`}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Place of Supply</Text>
                <Text style={styles.infoValue}>{`: ${stateName || 'N/A'}`}</Text>
              </View>
            </View>
            <View style={styles.infoRightColumn}>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Invoice Date</Text>
                <Text style={styles.infoValue}>{`: ${formatDate(invoice.createdAt)}`}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Order Date</Text>
                <Text style={styles.infoValue}>{`: ${formatDate(invoice.createdAt)}`}</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Nature of Supply</Text>
                <Text style={styles.infoValue}>: E-commerce</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.billtosection}>
          <Text style={styles.billtotext}>Bill To / Ship To</Text>
        </View>
        <View style={styles.addressSection}>
          <Text style={styles.addressName}>{customerName}</Text>
          <Text style={styles.addressName1}>{fullAddress}</Text>
          <Text>{contactNo ? `+91 ${contactNo}` : ''}</Text>
        </View>

        <View style={styles.billtosection}>
          <Text style={styles.billtotext}>Bill From / Ship From</Text>
        </View>
        <View style={styles.addressSection1}>
          <Text style={[styles.addressName1, { marginBottom: 8 }]}>
            <Text style={{ fontWeight: 'bold' }}>Shop: </Text>
            {shopName
              .split(' ')
              .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
              .join(' ')}
          </Text>
          <Text style={[styles.addressName1, { marginBottom: 8 }]}>
            <Text style={{ fontWeight: 'bold' }}>Address: </Text>
            {[
              shopAddress
                .split(' ')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(' '),
              shopCity,
              shopState,
              shopCountry
            ]
              .filter(Boolean)
              .join(', ') + (shopPincode ? ` - ${shopPincode}` : '')}
          </Text>
          {shopPhoneNumber ? (
            <Text style={[styles.addressName1, { marginBottom: 8 }]}>
              <Text style={{ fontWeight: 'bold' }}>Contact No: </Text>
              +91 {shopPhoneNumber}
            </Text>
          ) : null}
          {shopGst ? (
            <Text style={[styles.addressName1, { marginBottom: 8 }]}>
              <Text style={{ fontWeight: 'bold' }}>GSTIN: </Text>
              {shopGst}
            </Text>
          ) : null}
        </View>

        <View style={styles.tableContainer}>
          <View style={styles.tableHeader}>
            <Text style={styles.numberCol}>#</Text>
            <Text style={styles.descriptionCol}>Item & Description</Text>
            <Text style={styles.quantityCol}>Qty</Text>
            <Text style={styles.priceCol}>Gross Weight(gm)</Text>
            <Text style={styles.priceCol}>Net Weight(gm)</Text>
            <Text style={styles.priceCol}>Stone Weight(gm)</Text>
            <Text style={styles.priceCol}>Stone Price(gm)</Text>
            <Text style={styles.priceCol}>Rate</Text>
            <Text style={styles.priceCol}>Making Charges</Text>
            <Text style={styles.amountCol}>Amount</Text>
          </View>

          {(invoice.jw_invoice_items || []).map((item, index) => {
            const product = item.ProductMaster || {};
            const estShopInventories = item.EstShopInventories?.[0] || {};
            const unitPrice = parseFloat(item.unit_price || 0);
            const totalPrice = parseFloat(item.total_price || 0);
            const quantity = parseFloat(item.quantity || 1);
            const grossWeight = estShopInventories?.weight ?? 0;
            const netWeight = estShopInventories?.netweight ?? 0;
            const stoneWeight = estShopInventories?.stone_weight ?? 0;
            const makingCharges = parseFloat(estShopInventories?.making_charges ?? 0);
            const stonePrice = parseFloat(estShopInventories?.stone_price ?? 0) || 0;
            // Calculate per-item tax for display
            const isIntraState = shopState === stateName && shopState && stateName;
            const cgstRate =
              parseFloat(item?.tax_cgst ?? '') ||
              parseFloat(item?.ProductMaster?.TaxRate?.tax_cgst ?? 0);
            const sgstRate =
              parseFloat(item?.tax_sgst ?? '') ||
              parseFloat(item?.ProductMaster?.TaxRate?.tax_sgst ?? 0);
            const igstRate =
              parseFloat(item?.tax_igst ?? '') ||
              parseFloat(item?.ProductMaster?.TaxRate?.tax_igst ?? 0);
            const totalTaxRate = isIntraState ? (cgstRate + sgstRate) / 100 : igstRate / 100;
            const taxablePrice = totalPrice / (1 + totalTaxRate);
            const unitPriceBeforeTax = taxablePrice / quantity;

            return (
              <View key={item.id || index} style={styles.tableRow}>
                <Text style={styles.numberCol}>{index + 1}</Text>
                <View style={styles.descriptionCol}>
                  <Text>
                    {(product?.product_name ?? "--")
                      .toLowerCase()
                      .replace(/\b\w/g, char => char.toUpperCase())}
                  </Text>
                  {product?.Hsn?.hsn_code ? (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>HSN Code:</Text>{" "}
                      {product?.Hsn?.hsn_code}
                    </Text>
                  ) : null}
                  {Number(estShopInventories?.carat_value) > 0 ? (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Carat Value:</Text>{" "}
                      {Number(estShopInventories.carat_value)}
                    </Text>
                  ) : (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Purity:</Text>{" "}
                      {(() => {
                        const purity = Number(estShopInventories?.purity);
                        if (Number.isNaN(purity)) return "--";
                        return purity % 1 === 0
                          ? purity.toFixed(0)
                          : (Math.trunc(purity * 10) / 10).toFixed(1);
                      })()}
                    </Text>
                  )}
                  {parseFloat(estShopInventories?.stone_weight ?? 0) > 0 && (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Stone Weight:</Text>{" "}
                      {estShopInventories?.stone_weight ?? "--"}
                    </Text>
                  )}
                  {parseFloat(estShopInventories?.stone_price ?? 0) > 0 && (
                    <Text style={[styles.subText, styles.spacing]}>
                      <Text style={styles.boldText}>Stone Price:</Text>{" "}
                      Rs. {parseFloat(estShopInventories?.stone_price ?? 0).toFixed(2)}
                    </Text>
                  )}
                </View>
                <Text style={styles.quantityCol}>{item.quantity || 0}</Text>
                <Text style={styles.priceCol}>{grossWeight}</Text>
                <Text style={styles.priceCol}>{netWeight}</Text>
                <Text style={styles.priceCol}>{stoneWeight}</Text>
                <Text style={styles.priceCol}>Rs. {stonePrice.toFixed(2)}</Text>
                <Text style={styles.priceCol}>Rs. {unitPriceBeforeTax.toFixed(2)}</Text>
                <Text style={styles.priceCol}>Rs. {makingCharges.toFixed(2)}</Text>
                <Text style={styles.amountCol}>Rs. {(unitPriceBeforeTax * quantity).toFixed(2)}</Text>
              </View>
            );
          })}
        </View>

        <View style={styles.totalsSection}>
          <View style={styles.signatureSection}>
            <Text style={styles.signatureName}>Total in Words: </Text>
            <Text style={styles.signature}>
              {numberToWords(Math.floor(invoiceAmountWithTax))
                .toLowerCase()
                .replace(/\b\w/g, c => c.toUpperCase())} 
              {" Rupees"}
              {invoiceAmountWithTax % 1 !== 0
                ? ` And ${numberToWords(Math.round((invoiceAmountWithTax % 1) * 100))
                    .toLowerCase()
                    .replace(/\b\w/g, c => c.toUpperCase())} Paise Only`
                : " Only"}
            </Text>
            <Text style={styles.signatureTitle}>Authorized Signatory</Text>
          </View>
          <View style={styles.totalDetails}>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Sub Total</Text>
              <Text style={styles.totalValue}>{`Rs. ${totalTaxableAmount.toFixed(2)}`}</Text>
            </View>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total Taxable Amount</Text>
              <Text style={styles.totalValue}>{`Rs. ${totalTaxableAmount.toFixed(2)}`}</Text>
            </View>
            {shopState === stateName && shopState && stateName ? (
              <>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>CGST ({cgstRate}%)</Text>
                  <Text style={styles.totalValue}>Rs. {totalCgstAmount.toFixed(3)}</Text>
                </View>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>SGST ({sgstRate}%)</Text>
                  <Text style={styles.totalValue}>Rs. {totalSgstAmount.toFixed(3)}</Text>
                </View>
              </>
            ) : (
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>IGST ({igstRate}%)</Text>
                <Text style={styles.totalValue}>Rs. {totalIgstAmount.toFixed(2)}</Text>
              </View>
            )}
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>{`Rs. ${invoiceAmountWithTax.toFixed(2)}`}</Text>
            </View>
          </View>
        </View>

        <View style={styles.notesSection}>
          <Text style={styles.notesTitle}>Notes</Text>
          <Text>This is a computer generated invoice and does not require signature.</Text>
        </View>
      </Page>
    </Document>
  );
};

export default InvoicePDF;