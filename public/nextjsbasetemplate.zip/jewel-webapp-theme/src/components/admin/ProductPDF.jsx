import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";

// Define styles
const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontFamily: "Helvetica",
  },
  table: {
    display: "table",
    width: "100%",
    border: "1px solid black",
    marginBottom: 10,
  },
  tableRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  tableCol: {
    width: "12.5%", // Adjusted width for other columns
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8, // Smaller text size
  },
  orderIdCol: {
    width: "15%", // Increased width for Order ID
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8, // Smaller text size
  },
  tableHeader: {
    backgroundColor: "#f2f2f2",
    fontWeight: "bold",
  },
  headerText: {
    fontSize: 14, // Slightly larger header text
    marginBottom: 10,
  },
});

// PDF Document Component
const TablePDF = ({ data }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.headerText}>Product List (Admin)</Text>
      <View style={styles.table}>
        {/* Table Header */}
        <View style={[styles.tableRow, styles.tableHeader]}>
          <Text style={styles.orderIdCol}>Product ID</Text>
          <Text style={styles.orderIdCol}>Name</Text>
          <Text style={styles.tableCol}>Category</Text>
          <Text style={styles.tableCol}>Sold By (Shop)</Text>
          <Text style={styles.tableCol}>Purchase Price</Text>
          <Text style={styles.tableCol}>Online Price</Text>
          <Text style={styles.tableCol}>Offer Price</Text>
          <Text style={styles.tableCol}>CGST</Text>
          <Text style={styles.tableCol}>SGST</Text>
          <Text style={styles.tableCol}>IGST</Text>

        </View>
        {/* Table Rows */}
        {data.map((order, index) => (
          <View style={styles.tableRow} key={index}>
            <Text style={styles.orderIdCol}>{order.ProductMaster.id}</Text>
            <Text style={styles.orderIdCol}>{order.ProductMaster.product_name}</Text>
            <Text style={styles.tableCol}>{order.ProductMaster.Category.category_name}</Text>
            <Text style={styles.tableCol}>{order.mi_shop_est.est_shop_name}</Text>
            <Text style={styles.tableCol}>{order.last_purprice_aft}</Text>
            <Text style={styles.tableCol}>{order.exp_onlinesellprice_aft}</Text>
            <Text style={styles.tableCol}>{order.offer_price}</Text>
            <Text style={styles.tableCol}>{order.ProductMaster.TaxRate.tax_cgst}</Text>
            <Text style={styles.tableCol}>{order.ProductMaster.TaxRate.tax_sgst}</Text>
            <Text style={styles.tableCol}>{order.ProductMaster.TaxRate.tax_igst}</Text>

          </View>
        ))}
      </View>
    </Page>
  </Document>
);

export default TablePDF;
