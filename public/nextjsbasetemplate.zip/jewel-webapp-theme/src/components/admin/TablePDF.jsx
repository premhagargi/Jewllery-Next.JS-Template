import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";

// Define styles
const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontFamily: "Helvetica",
  },
  table: {
    display: "table",
    width: "100%",
    border: "1px solid black",
    marginBottom: 10,
  },
  tableRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  tableCol: {
    width: "12.5%", // Adjusted width for other columns
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8, // Smaller text size
  },
  orderIdCol: {
    width: "20%", // Increased width for Order ID
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8, // Smaller text size
  },
  tableHeader: {
    backgroundColor: "#f2f2f2",
    fontWeight: "bold",
  },
  headerText: {
    fontSize: 14, // Slightly larger header text
    marginBottom: 10,
  },
});

// PDF Document Component
const TablePDF = ({ data }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.headerText}>Order List</Text>
      <View style={styles.table}>
        {/* Table Header */}
        <View style={[styles.tableRow, styles.tableHeader]}>
          <Text style={styles.orderIdCol}>Order ID</Text>
          <Text style={styles.tableCol}>Customer Name</Text>
          <Text style={styles.tableCol}>Order Status</Text>
          <Text style={styles.tableCol}>Payment Status</Text>
          <Text style={styles.tableCol}>Delivery Status</Text>
          <Text style={styles.tableCol}>Total Amount</Text>
          <Text style={styles.tableCol}>Date Ordered</Text>
        </View>
        {/* Table Rows */}
        {data.map((order, index) => (
          <View style={styles.tableRow} key={index}>
            <Text style={styles.orderIdCol}>{order.order_id}</Text>
            <Text style={styles.tableCol}>{order.mi_customer?.cust_cmp_name}</Text>
            <Text style={styles.tableCol}>{order.order_status}</Text>
            <Text style={styles.tableCol}>{order.payment_status}</Text>
            <Text style={styles.tableCol}>{order.delivery_status}</Text>
            <Text style={styles.tableCol}>{order.total_price}</Text>
            <Text style={styles.tableCol}>
  {order.created_at
    ? new Intl.DateTimeFormat('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false, // Use 24-hour format
      }).format(new Date(order.created_at))
    : 'N/A'}
</Text>

          </View>
        ))}
      </View>
    </Page>
  </Document>
);

export default TablePDF;
