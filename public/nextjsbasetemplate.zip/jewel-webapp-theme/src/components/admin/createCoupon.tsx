import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface CreateCouponProps {
  onClose: () => void;
}

export default function CreateCoupon({ onClose }: CreateCouponProps) {
  const [selectedOption, setSelectedOption] = useState(0);

  const handleClick = (index: number) => {
    setSelectedOption(index);
  };

  const discountType = [
    "Fixed Discount",
    "Percentage Discount",
    "Free Shipping",
    "Price Discount",
  ];

  return (
    <div className="w-full h-full p-6 border shadow flex flex-col gap-6 text-sm rounded-xl bg-white py-8">
      <div className="flex flex-col gap-1">
        <span className="font-bold">Coupon Information</span>
        <span>Code will be used by users in checkout</span>
      </div>
      <div className="w-full flex gap-4 border-b pb-10">
        <div className="w-[50%] flex flex-col gap-1">
          <span>Coupon Code</span>
          <Input
            type="text"
            placeholder="ShipFree20"
            className="rounded-lg focus-visible:ring-0 focus-visible:outline-none"
          />
        </div>
        <div className="w-[50%] flex flex-col gap-1">
          <span>Coupon Name</span>
          <Input
            type="text"
            placeholder="Free Shippping"
            className="rounded-lg focus-visible:ring-0 focus-visible:outline-none"
          />
        </div>
      </div>
      <div className="pt-4">
        <div className="flex flex-col gap-1">
          <span className="font-bold">Coupon Type</span>
          <span>Type of coupon you want to create</span>
        </div>
      </div>
      <div className="w-full flex gap-4 pb-4">
        {/* <div
          className={`p-10 border rounded-lg ${
            selectedOption === 0 ? "border-blue-500" : ""
          }`}
          onClick={() => handleClick(0)}
        >
          <span>Fixed Discount</span>
        </div>
        <div
          className={`p-10 border rounded-lg ${
            selectedOption === 1 ? "border-blue-500" : ""
          }`}
          onClick={() => handleClick(1)}
        >
          <span>Percentage Discount</span>
        </div>
        <div
          className={`p-10 border rounded-lg ${
            selectedOption === 2 ? "border-blue-500" : ""
          }`}
          onClick={() => handleClick(2)}
        >
          <span>Free Shipping</span>
        </div>
        <div
          className={`p-10 border rounded-lg ${
            selectedOption === 3 ? "border-blue-500" : ""
          }`}
          onClick={() => handleClick(3)}
        >
          <span>Price Discount</span>
        </div> */}
        {discountType.map((discount, key) => (
          <div
            key={key} // Add the key prop here
            className={`p-10 border rounded-lg ${
              selectedOption === key ? "border-blue-500" : ""
            }`}
            onClick={() => handleClick(key)}
          >
            <span>{discount}</span>
          </div>
        ))}
      </div>
      <div className="w-full flex gap-4">
        <div className="w-[50%] flex flex-col gap-1">
          <span>Coupon Code</span>
          <Input
            type="text"
            placeholder="ShipFree20"
            className="rounded-lg focus-visible:ring-0 focus-visible:outline-none"
          />
        </div>
        <div className="w-[50%] flex flex-col gap-1">
          <span>Coupon Name</span>
          <Input
            type="text"
            placeholder="Free Shippping"
            className="rounded-lg focus-visible:ring-0 focus-visible:outline-none"
          />
        </div>
      </div>
      <div className="w-full flex gap-4">
        <div className="w-[50%] flex flex-col gap-1">
          <span>Coupon Code</span>
          <Input
            type="text"
            placeholder="ShipFree20"
            className="rounded-lg focus-visible:ring-0 focus-visible:outline-none"
          />
        </div>
        <div className="w-[50%] flex flex-col gap-1">
          <span>Coupon Name</span>
          <Input
            type="text"
            placeholder="Free Shippping"
            className="rounded-lg focus-visible:ring-0 focus-visible:outline-none"
          />
        </div>
      </div>
      <div className="flex gap-2 justify-end mt-4">
        <Button onClick={onClose}>Cancle</Button>
        <Button>Save</Button>
      </div>
    </div>
  );
}
