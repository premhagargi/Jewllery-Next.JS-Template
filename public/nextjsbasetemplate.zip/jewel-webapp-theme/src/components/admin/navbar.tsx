import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Inbox } from "lucide-react";
import Link from "next/link";
import { useState, useEffect } from "react";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import { useRouter } from "next/navigation";
import useAuthStore from "@/app/(admin)/stores/userAuthStore";

export default function Navbar() {
  const router = useRouter();
  const { logout, isAuthenticated, initializeAuth, loading } = useAuthStore();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [inboxCount, setInboxCount] = useState(2);

  // Run authentication check on mount
  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  // Redirect only after authentication state is known
  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push("/adminlogin");
    }
  }, [isAuthenticated, loading, router]);

  // ✅ Hide UI until authentication is checked
  if (loading) return null;

  return (
    <div className="w-full h-[70px] bg-[#fafafa] shadow-sm px-8 flex items-center justify-between text-[#3f3f46] sticky top-0 z-10">
      <Link href={"/admin"}>
        <span className="font-bold text-lg">MAHARANA SILVER</span>
      </Link>
      <div className="flex items-center gap-5">
        {/* <Link href="/admininbox">
          <div className="relative cursor-pointer">
            {inboxCount > 0 && (
              <div className="w-[22px] h-[22px] bg-red-500 flex grid place-items-center rounded-full text-white absolute top-[-12px] right-[-12px]">
                <span className="text-[12px]">{inboxCount}</span>
              </div>
            )}
            <Inbox size={18} />
          </div>
        </Link> */}
        <DropdownMenu open={isDropdownOpen} onOpenChange={setIsDropdownOpen}>
          <DropdownMenuTrigger asChild>
            <div className="text-sm flex items-center gap-1 text-black font-medium p-1 px-2 rounded-lg cursor-pointer">
              <span>Admin</span>
              {isDropdownOpen ? <IoIosArrowUp /> : <IoIosArrowDown />}
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-10 mr-2">
            <DropdownMenuItem onClick={logout} className="cursor-pointer">
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
