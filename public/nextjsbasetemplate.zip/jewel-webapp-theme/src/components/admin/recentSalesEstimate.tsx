// "use client";

// import { useState, useEffect } from "react";
// import { TrendingUp } from "lucide-react";
// import { Bar, BarChart, CartesianGrid, LabelList, XAxis } from "recharts";
// import { Skeleton } from "@/components/ui/skeleton";
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardFooter,
//   CardHeader,
//   CardTitle,
// } from "@/components/ui/card";
// import {
//   ChartConfig,
//   ChartContainer,
//   ChartTooltip,
//   ChartTooltipContent,
// } from "@/components/ui/chart";

// const chartConfig = {
//   desktop: {
//     label: "Desktop",
//     color: "hsl(var(--chart-1))",
//   },
// } satisfies ChartConfig;

// export function RecentSalesEstimate({ data }: any) {
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     // Simulating data fetch
//     setTimeout(() => setLoading(false), 500);
//   }, []);

//   return (
//     <Card className="w-full h-full flex flex-col justify-between text-sm">
//       <CardHeader>
//         <CardTitle>Bar Chart - Label</CardTitle>
//         <CardDescription className="text-xs">
//           January - June 2024
//         </CardDescription>
//       </CardHeader>
//       <CardContent>
//         {loading ? (
//           <Skeleton className="h-[200px] w-full rounded-lg" />
//         ) : (
//           <ChartContainer config={chartConfig}>
//             <BarChart
//               accessibilityLayer
//               data={data}
//               margin={{
//                 top: 20,
//               }}
//             >
//               <CartesianGrid vertical={false} />
//               <XAxis
//                 dataKey="month"
//                 tickLine={false}
//                 tickMargin={10}
//                 axisLine={false}
//                 tickFormatter={(value) => value.slice(0, 3)}
//               />
//               <ChartTooltip
//                 cursor={false}
//                 content={<ChartTooltipContent hideLabel />}
//               />
//               <Bar dataKey="desktop" fill="var(--color-desktop)" radius={8}>
//                 <LabelList
//                   position="top"
//                   offset={12}
//                   className="fill-foreground"
//                   fontSize={12}
//                 />
//               </Bar>
//             </BarChart>
//           </ChartContainer>
//         )}
//       </CardContent>
//       <CardFooter className="flex-col items-start gap-2 text-sm">
//         {loading ? (
//           <Skeleton className="h-4 w-48 rounded" />
//         ) : (
//           <div className="flex gap-2 font-medium leading-none">
//             Trending up by 5.2% this month <TrendingUp className="h-4 w-4" />
//           </div>
//         )}
//         {loading ? (
//           <Skeleton className="h-3 w-64 rounded" />
//         ) : (
//           <div className="leading-none text-muted-foreground">
//             Showing total visitors for the last 6 months
//           </div>
//         )}
//       </CardFooter>
//     </Card>
//   );
// }

"use client";

import { useState, useEffect } from "react";
import { TrendingUp } from "lucide-react";
import { Bar, BarChart, CartesianGrid, LabelList, XAxis } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

const chartConfig = {
  desktop: {
    label: "Sales",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig;

export function RecentSalesEstimate({
  data,
  loading: parentLoading,
}: {
  data: any[];
  loading: boolean;
}) {
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (!parentLoading && data) {
      setChartData(data);
    }
  }, [data, parentLoading]);

  // Calculate trend percentage (example calculation)
  const calculateTrend = () => {
    if (chartData.length < 2) return 0;
    const currentMonth = chartData[chartData.length - 1].desktop;
    const previousMonth = chartData[chartData.length - 2].desktop;
    if (previousMonth === 0) return currentMonth > 0 ? 100 : 0;
    return ((currentMonth - previousMonth) / previousMonth) * 100;
  };

  const trend = calculateTrend();
  const currentDate = new Date();
  const threeMonthsAgo = new Date(
    currentDate.setMonth(currentDate.getMonth() - 2)
  );
  const dateRange = `${threeMonthsAgo.toLocaleString("en-US", {
    month: "long",
  })} - ${new Date().toLocaleString("en-US", {
    month: "long",
  })} ${new Date().getFullYear()}`;

  return (
    <Card className="w-full h-full flex flex-col justify-between text-sm">
      <CardHeader>
        <CardTitle>Sales Overview</CardTitle>
        <CardDescription className="text-xs">{dateRange}</CardDescription>
      </CardHeader>
      <CardContent>
        {parentLoading ? (
          <Skeleton className="h-[200px] w-full rounded-lg" />
        ) : (
          <ChartContainer config={chartConfig}>
            <BarChart
              accessibilityLayer
              data={chartData}
              margin={{
                top: 20,
              }}
            >
              <CartesianGrid vertical={false} />
              <XAxis
                dataKey="month"
                tickLine={false}
                tickMargin={10}
                axisLine={false}
                tickFormatter={(value) => value.slice(0, 3)}
              />
              <ChartTooltip
                cursor={false}
                content={<ChartTooltipContent hideLabel />}
              />
              <Bar dataKey="desktop" fill="var(--color-desktop)" radius={8}>
                <LabelList
                  position="top"
                  offset={12}
                  className="fill-foreground"
                  fontSize={12}
                  formatter={(value: number) => `₹${value}`}
                />
              </Bar>
            </BarChart>
          </ChartContainer>
        )}
      </CardContent>
      <CardFooter className="flex-col items-start gap-2 text-sm">
        {parentLoading ? (
          <>
            <Skeleton className="h-4 w-48 rounded" />
            <Skeleton className="h-3 w-64 rounded" />
          </>
        ) : (
          <>
            <div className="flex gap-2 font-medium leading-none">
              {trend > 0 ? "Trending up" : "Trending down"} by{" "}
              {Math.abs(trend).toFixed(1)}% this month
              <TrendingUp className="h-4 w-4" />
            </div>
            <div className="leading-none text-muted-foreground">
              Showing total sales for the last 3 months
            </div>
          </>
        )}
      </CardFooter>
    </Card>
  );
}
