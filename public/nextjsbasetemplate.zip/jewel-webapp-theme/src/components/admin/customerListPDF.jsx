import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";

// Define styles
const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontFamily: "Helvetica",
  },
  table: {
    display: "table",
    width: "100%",
    border: "1px solid black",
    marginBottom: 10,
  },
  tableRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  smallCol: {
    width: "10%", // Reduced width for User ID & Customer ID
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8,
  },
  mediumCol: {
    width: "15%", // Adjusted for Customer Name & Contact No.
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8,
  },
  emailCol: {
    width: "20%", // Increased space for Email
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8,
  },
  addressCol: {
    width: "35%", // More space for Address
    border: "1px solid black",
    padding: 5,
    textAlign: "center",
    fontSize: 8,
  },
  tableHeader: {
    backgroundColor: "#f2f2f2",
    fontWeight: "bold",
  },
  headerText: {
    fontSize: 14,
    marginBottom: 10,
  },
});

// PDF Document Component
const TablePDF = ({ data }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.headerText}>Customer List (Admin)</Text>
      <View style={styles.table}>
        {/* Table Header */}
        <View style={[styles.tableRow, styles.tableHeader]}>
          <Text style={styles.smallCol}>User ID</Text>
          <Text style={styles.smallCol}>Customer ID</Text>
          <Text style={styles.mediumCol}>Customer Name</Text>
          <Text style={styles.mediumCol}>Contact No.</Text>
          <Text style={styles.emailCol}>Email</Text>
          <Text style={styles.addressCol}>Address</Text>
        </View>

        {/* Table Rows */}
        {data.map((order, index) => (
          <View style={styles.tableRow} key={index}>
            <Text style={styles.smallCol}>{order?.id}</Text>
            <Text style={styles.smallCol}>{order?.customer_id}</Text>
            <Text style={styles.mediumCol}>{order?.cust_cmp_name}</Text>
            <Text style={styles.mediumCol}>{order?.cust_cmp_phone}</Text>
            <Text style={styles.emailCol}>{order?.cust_cmp_email}</Text>
            <Text style={styles.addressCol}>
              {order.address1 + ", " + order.address2}
            </Text>
          </View>
        ))}
      </View>
    </Page>
  </Document>
);

export default TablePDF;
