// components/PDFWrapper.js
'use client';

import React from 'react';
import { Document, Page, Text, View, StyleSheet, PDFDownloadLink } from "@react-pdf/renderer";

export { Document, Page, Text, View, StyleSheet, PDFDownloadLink };