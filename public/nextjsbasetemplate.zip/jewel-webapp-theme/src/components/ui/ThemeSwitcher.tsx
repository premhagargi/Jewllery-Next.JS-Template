'use client';

import { useTheme } from '@/hooks/useTheme';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Sun, Moon, Laptop } from 'lucide-react';

const ICONS: Record<string, JSX.Element> = {
  light: <Sun className="w-4 h-4 mr-2" />,
  dark: <Moon className="w-4 h-4 mr-2" />,
  system: <Laptop className="w-4 h-4 mr-2" />,
  rose: <span className="w-4 h-4 mr-2">🌹</span>,
  ocean: <span className="w-4 h-4 mr-2">🌊</span>,
};

export default function ThemeSwitcher() {
  const { theme, setTheme, availableThemes } = useTheme();

  const currentIcon = ICONS[theme] ?? <Sun className="w-4 h-4" />;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="rounded-full">
          {currentIcon} 
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        {availableThemes.map((t) => (
          <DropdownMenuItem key={t} onClick={() => setTheme(t)} className="capitalize">
            {ICONS[t] ?? null}
            {t}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
