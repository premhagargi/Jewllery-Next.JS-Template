import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  output: "export",
  images: {
    // domains: ["api.maharanasilver.com"], // Add your IP or hostname here
    unoptimized: true, // Disable optimization for all images
  },
};

export default nextConfig;
